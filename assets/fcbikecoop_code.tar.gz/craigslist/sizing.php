<?php
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<div class="heading">Frame Sizing</div>
			<table width="322" border=1 cellpadding=2 cellspacing="0">
				<tr><td colspan=4 align=center><b>ROAD BIKE SIZING</b></td></tr>
				<tr><td width="88" align=center><b>Height</b></td><td width="115" align=center><b>Inseam Length</b></td>
					<td width="99" align=center><strong><b>Road Frame Size</strong></td></tr>
				<tr><td align=center>4'10" - 5'1"</td><td align=center>25.5" - 27"</td><td align=center>46 - 48 cm</td></tr>
				<tr><td align=center>5'0" - 5'3" </td><td align=center> 26.5" - 28"  </td><td align=center>48 - 50 cm</td></tr>
				<tr><td align=center>5'2" - 5'5" </td><td align=center> 27.5" - 29" </td><td align=center>50 - 52 cm </td></tr>
				<tr><td align=center>5'4" - 5'7"</td><td align=center>28.5" - 30"</td><td align=center>52 - 54 cm </td></tr>
				<tr><td align=center>5'6" - 5'9"</td><td align=center>29.5" - 31"</td><td align=center>54 - 56 cm</td></tr>
				<tr><td align=center>5'8" - 5'11"</td><td align=center>30.5" - 32"</td><td align=center>56 - 58 cm</td></tr>
				<tr><td align=center>5'10" - 6'1"</td><td align=center>31.5" - 33"</td><td align=center>58 - 60 cm</td></tr>
				<tr><td align=center>6'0" - 6'3"</td><td align=center>32.5" - 34" </td><td align=center>60 - 62 cm</td></tr>
				<tr><td align=center>6'2" - 6'5" </td><td align=center>34.5" - 36" </td><td align=center>62 - 64 cm </td></tr>
			</table>
			</br>
			</br>
			</br>
			<table width="323" border=1 cellpadding=2 cellspacing="0">
				<tr><td colspan=4 align=center><b>MOUNTAIN BIKE SIZING</b></td></tr>
				<tr><td width="80" align=center><b> Height</b></td><td width="108" align=center><b> Inseam Length</b></td>
					<td width="115" align=center><strong> Mountain Frame Size</strong></td></tr>
				<tr><td align=center>4'11" - 5'3"</td><td align=center>25" - 27"</td>
					<td align=center>13 - 15''</td></tr>
				<tr><td align=center>5'3" - 5'7" </td><td align=center> 27" - 29"  </td>
					<td align=center>15 to 17''</td></tr>
				<tr><td align=center>5'7" - 5'11" </td><td align=center> 29" - 31" </td>
					<td align=center>17 to 19''</td></tr>
				<tr><td align=center>5'11" - 6'2"</td><td align=center>31" - 33"</td>
					<td align=center>19 to 21''</td></tr>
				<tr><td align=center>6'2" - 6'4"</td><td align=center>33" - 35"</td>
					<td align=center>21 to 23''</td></tr>
				<tr><td align=center>6'4" and up</td><td align=center>35 up</td><td align=center>23 inches and up</td></tr>
			</table>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
