<?php
#This script will take a given image file and create a web friendly size version of it with the name filename-small.extension

#first we set the filename
$filename = '/var/www/fcbikecoop.org/root/craigslist/images/test.gif';

#test to verify that we actually have an image
#This covers JPG PNG and GIF, perhaps more.
if(!shell_exec("file $filename | grep -q \"image\""))
	{
	#we need to be concious of files called foo.jpg.bar.jpg while rare, these will trip up typical rename scripts
	#First explode the filename into segments divided by "."
	$exts = explode(".", $filename);
	
	#Count the number of segments that we exploded into
	$n = count($exts)-1;
	
	#Set $exts to the last segement of the above explode command
	$exts = $exts[$n]; 
	
	#Replace the last .$exts with -small.$exts 
	$newname = preg_replace("/\.$exts$/i", "-small.$exts", $filename);
	
	#Finally create a small image with no more than 307200 pixels (Typically 640x480 or 480X640)
	shell_exec("convert $filename -resize 307200@> $newname");

	#In the above command, the > symbol insures that we don't enlarge small images, however it still outputs an empty $newfile.

	#check for empty files and replace them with non-empty files
	if(filesize($newname) == 0)
		{
		if (!copy($filename, $newname))
			{
			#Proabaly a file permission mistake if we get here
    			echo "failed to copy $filename...";
			}
		}
	}
?>
