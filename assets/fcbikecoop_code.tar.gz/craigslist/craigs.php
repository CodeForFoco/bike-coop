<h1>$frame_size cm $color and $other_color $make $model - $bike_type \$$price</h1>

<img src="http://fcbikecoop.org/images/craigslist/small.jpg" align="right" width="320px">
<font size="4" color="red"><b>Frame:</b></font><br />
$frame_size_cm cm \($frame_size_inches inches/) $frame_material frame $front_suspension_fork<br />
(See our <a href="http://fcbikecoop.org/craigslist/sizing.php">Frame sizing chart</a>.)<br /><br />

<font size="4" color="red"><b>Drivetrain:</b></font><br />
$speeds speeds, with $shifter_brand $shifter_model $shifter_type shifters.
$front_deraileur_brand $front_deraileur_model front deraileur.
$rear_deraileur_brand $rear_deraileur_model rear deraileur.
<br /><br />

<font size="4" color="red"><b>Wheels:</b></font><br />
$wheel_size\" $wheel_brand $wheel_model wheels with $hub_brand $hub_model hubs.<br /><br />

<font size="4" color="red"><b>Brakes:</b></font><br />
$brake_type<br /><br />

<font size="4" color="red"><b>Accessories:</b></font><br />
This bike has the following accessories:

<ul>
	<li> $accessories0</li>
	<li> $accessories1</li>
	<li> $accessories2</li>
	<li> $accessories3</li>
	<li> $accessories4</li>
	<li> $accessories5</li>
	<li> $accessories6</li>
	<li> $accessories7</li>
	<li> $accessories8</li>
	<li> $accessories9</li>
	<li> $accessories10</li>
	<li> $accessories11</li>
	<li> $accessories12</li>
	<li> $accessories13</li>
	<li> $accessories14</li>
</ul>

<font size="4" color="red"><b>Condition:</b></font><br />
This bike is in <b>$condition</b> condition.<br /><br />

<font size="4" color="red"><b>Price:</b></font><br />
<b>/$$price</b><br /><br />

<font size="4" color="red"><b>Additional Comments:</b></font><br />
$comments<br /><br />

<font size="4" color="red"><b>Pictures:</b></font><br />
<b>Click on the images below to view larger:</b>
<p><a href="http://fcbikecoop.org/images/craigslist/small.jpg"><img src="http://fcbikecoop.org/images/craigslist/large.jpg/"></a></p>
<hr size="5" noshade>
<p align="center"><b>Proceeds from the sale of this bike will benefit
<a href="http://fcbikecoop.org">The Fort Collins Bike Co-op</a>
and its <a href="http://fcbikecoop.org/programs.php">programs</a>.</p>

<p align="center"><b>To test ride this bike
<a href="http://fcbikecoop.org/contact.php">stop by our shop</a> during <a href="http://fcbikecoop.org/calendar.php">open hours</a><b></p>

<p align="center">
<table border="0" align="center">
<tr> <td colspan="3" bgcolor="black"></td></tr>
<tr> <td colspan="1" align="center"><a href="http://fcbikecoop.org"><img width="150px" height="150px" src="http://fcbikecoop.org/posters/logo/fcbikecoop-white.png"></a></td><td colspan="2" align="center"><b>Fort Collins Bike Co-op</b></br>"Building Community Through Bicycling"</td></tr>
<tr> <td colspan="3" bgcolor="black"></td></tr>
<tr> <td>Mon:</td> <td><b>CLOSED</b></td>
     <td rowspan="7" align="center" valign="middle"><b>We are located at:<br />
<a href="http://maps.google.com/maps?f=q&source=s_q&hl=en&geocode=&q=fort+collins+bike+coop&aq=&sll=37.0625,-95.677068&sspn=50.956929,89.560547&ie=UTF8&hq=fort+collins+bike+coop&hnear=&t=h&z=13&iwloc=A">1501 North College Ave.<br />
Fort Collins, CO 80524</a></b> </td></tr>
<tr> <td>Tue:</td> <td><b>CLOSED</b></td>   </tr>
<tr> <td>Wed:</td> <td><b>2pm-5pm</b></td>   </tr>
<tr> <td>Thu:</td> <td><b>CLOSED</b></td>   </tr>
<tr> <td>Fri:</td> <td><b>2pm-5pm</b></td>  </tr>
<tr> <td>Sat:</td> <td><b>CLOSED</b></td>   </tr>
<tr> <td>Sun:</td> <td><b>Noon-6pm</b></td> </tr>
<tr> <td colspan="3" bgcolor="black"></td></tr>
</table>
</p>

<hr size="5" noshade>

<h1 align="center">THIS POSTING WILL BE REMOVED WHEN THE BIKE IS SOLD.  IF YOU ARE INTERESTED IN THIS BIKE AND CANNOT FIND THIS POSTING AGAIN THE BIKE IS NO LONGER AVAILABLE.</h1>
