#!/usr/bin/python

#import cgitb; cgitb.enable()
import cgi
import sys, time
import smtplib
import re

print "Content-Type: text/html"     # HTML is following
print                               # blank line, end of headers

form = cgi.FieldStorage()

required = ['firstname',
            'lastname',
            'phone',
            'email']
                  
for f in required:
    if f not in form.keys():
        sys.stdout.write("<font color=red>Missing required field (%s).</font><br>" % (f))
        sys.exit(0)

emailre = '.+\\@(\\[?)[a-zA-Z0-9\\-\\.]+\\.([a-zA-Z]{2,3}|[0-9]{1,3})(\\]?)'
emailsre = re.compile('(?P<email>(%s\s*,\s*)*)(?P<finalemail>%s)' % (emailre, emailre))
def validateEmail(email):
	if len(email) > 7:
		if re.match("^%s$"%(emailre), email) != None:
			return 1
		return 0

if not validateEmail(form['email'].value):
        sys.stdout.write("<font color=red>Not a vaild E-mail Address.</font><br>")
	sys.exit(0)

templatefile = file('/var/www/fcbikecoop.org/root/volunteer_forms/template', 'r')

template = templatefile.readlines()
templatefile.close()

msg = ''
fromre = re.compile('^From:\s*(?P<addr>\S*)\s*$')
#tore = re.compile('^To:\s*(?P<addr>\S*)\s*$')
#ccre = re.compile('^Cc:\s*(?P<addr>\S*)\s*$')
tore = re.compile('^To:\s*(?P<addr>.*)$')
ccre = re.compile('^Cc:\s*(?P<addr>.*)$')

def parseEmails(s):
    emails = []
    m = emailsre.match(s)
    if m:
        emails = m.group('email').split(',')
        emails.append(m.group('finalemail'))

    L = []
    for e in emails:
        e = e.strip()
        if e != '':
            L.append(e)

    return L

for line in template:
    m = fromre.match(line)
    if m:
        From = m.group('addr')
    
    m = tore.match(line)
    if m:
        To = parseEmails(m.group('addr'))
    
    m = ccre.match(line)
    if m:
        Cc =  parseEmails(m.group('addr'))
    
    for f in form.keys():
        try:
            L = form.getlist(f)
            val = ' '
            for i in L:
                if i != 'NULL':
                    val = i
            line = line.replace('$' + f + '$', val)
        except AttributeError:
            line = line.replace('$' + f + '$', 'ERROR')
    msg = msg + line

subfrom = form['email'].value
subto = "volunteers-join@fcbikecoop.org"
submsg = """From: %s
To: volunteers-join@fcbikecoop.org
Subject: Subscribe


Subscribe
""" % (subfrom)

server = smtplib.SMTP('localhost')
server.sendmail(From, To + Cc, msg)
try:
	server.sendmail(subfrom, [subto], submsg)
except SMTPRecipientsRefused:
        sys.stdout.write("<font color=red>We're having problems sending mail to that email address.  Are you sure it's correct?</font><br>")
	sys.exit(0)
server.quit()

html = file('/var/www/fcbikecoop.org/root/volunteer_forms/volunteer_form_done.php', 'r')
sys.stdout.writelines(html.readlines())
html.close()
