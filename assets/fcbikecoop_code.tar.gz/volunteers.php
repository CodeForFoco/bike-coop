<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<div class="heading">Volunteers</div>
			<p>The Fort Collins Bike Co-op is entirely run by volunteers.  These people give their time to help our community realize its true biking potential.
			<h2>Future Volunteers</h2>
			Since the Co-op is run by volunteers, we need your help.  Everyone can volunteer no matter what their experience is.  There is always something to be done, and always the need for more hands.  You don't have to be a bike mechanic to volunteer at the Co-op, see our list of <a href="http://fcbikecoop.org/programs/index.php">programs </a>you can get involved in <br><br>
			If you want to volunteer you only need to follow these steps to get involved.<br>
			<h3><font color="red">Please note: This is not the signup process for our Earn-a-Bike Program. 
<br>For information about community service, please stop by the shop during <a href="http://fcbikecoop.org/calendar.php">public hours</a>.</font></h3>
			1. You need to fill out the <a href="volunteer_db/volunteer_form.php">Volunteer application.</a><br>
			2. After that a confirmation email will be sent to you so you can join the volunteer mailing list.<br>
			3. Then you can come in during our open hours, get a tour of the shop and get started helping out.  There is always something to help with no matter what your skill level.<br>
			4.  Once we feel you're a good fit for the Co-op you will become an official volunteer, and you will become eligible for volunteer benefits.<br><br>
			It's just that easy!!
			<h2>Current Volunteers</h2>
			Current Volunteers are welcome to use the <a href="http://fcbikecoop.org/volunteer_db/volunteer_only/">volunteer only</a> section of the website.  This area allows volunteers to log their hours as well as allowing access co-op files.
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
