<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.collegian.com/index.php/article/2010/04/042810_bike">Original Story - 04-27-2010 - Rocky Mountain Collegian</a>
			<h1>Local cyclists vent complaints</h1>
			<p>By <a href="mailto:news@collegian.com">Ali Sylte</a></p>
			<p>Rick Price logs 70 miles per week on his Cannondale commuter bike.</p>
			<p>Price, 60, is a member of the Fort Collins Bike Co-op, a group that looks to further the interests of Choice City cyclists and ultimately hopes to make the <span class="caps">CSU</span> campus free from automobiles.</p>
			<p>The organization hosted a meeting of about a dozen students and community members Tuesday to discuss the future of the cycling community in Fort Collins.</p>
			<p>The meeting was one of eight listening events to be held throughout town.</p>
			<p>"The ultimate goal of these listening events is not only to make it safe and convenient to cycle in Fort Collins, but also fun," Price said. "In an automotive dominated environment, it's tough to make the roads safe for cyclists and pedestrians."</p>
			<p>The information gathered from these meetings will be delivered to the Bicycle Advisory Committee, the Transportation Board and Fort Collins city planners.</p>
			<p>Price fielded many complaints about the poor etiquette shown around campus and the community by student cyclists.</p>
			<p>"In their defense, it is hard to pay attention to the road while arranging a date on your cell phone and listening to your iPod," Price said.</p>
			<p>Additional comments included complaints about ice on bike lanes, unclear signage about dismount zones on campus and the lack of knowledge that students have about bicycling laws and regulations.</p>
			<p>"It's important to acknowledge our deficiencies, in terms of bike accessibility, so that we can move forward," said David Kemp, the Fort Collins City ike coordinator.</p>
			<p>The ultimate goal of bike reform is to make the CSU campus entirely car free. But this goal is far from being realized, Price said.</p>
			<p>"We'll have to wait for them to build a couple more parking garages before that can happen," Price joked.</p>
			<p>Fort Collins has already improved tremendously in terms of bike accessibility, Price said. Listening events such as this one have been responsible for positive reforms in the cycling community, like the addition of bike lanes on Laurel Street, and the expansion of the Mason Trail.</p>
			<p>"When we come up with goals, city planners listen to us," Price said. "The city staff, grants and resources have enabled the city to make great progress. But unfortunately, there's still work to be done."</p>
			<p>"CSU students are the most common bike users in Fort Collins, given that it's the most economical type of transport," said Shane Miller, a member of the city's Transportation board. "It is important that they really get active in the cycling community."</p>
			<p>For Russell Geisthardt, a CSU physics major, the meeting was worthwhile.  "As a biker on campus, it's nice to have my voice heard," Geisthardt said.</p>
	<p>_Staff writer Ali Sylte can be reached at <a href="mailto:news@collegian.com">news@collegian.com</a>._</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
