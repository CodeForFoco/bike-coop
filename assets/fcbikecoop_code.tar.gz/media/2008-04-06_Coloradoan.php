<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <a href="http://www.coloradoan.com/apps/pbcs.dll/article?AID=/20080406/NEWS01/804060345/1002/CUSTOMERSERVICE02">Original Story - 04-06-2008 - Coloradoan</a>
         <h1> Turn off engine and check out a free bike</h1>
	 <p>By: <a href="mailto:TimKeith@coloradoan.com">Tim Keith</a></p>
	 <div class="contents-image"><a href="images/2008-04-06.jpg"><img src="images/2008-04-06.jpg" alt="Michael G. Seamans/The Coloradoan"></a>
	 Michael G. Seamans/The Coloradoan - Matt McCune walks his bike Saturday past the new Bike Library in Old Town Square in Fort Collins.
	 </div>
	 <p>Dan and Ronnie Lipp came to Fort Collins for the first time in 1992 while on vacation.</p>
	<p>The trip was only their second visit into Colorado.</p>
	<p>Among their first experiences in town was a bike ride on one of the many paths Fort Collins has to offer.</p>
	<p>"This is one of the things that attracted us," Ronnie said.</p>
	<p>The couple moved to Colorado from New York 12 years ago.</p>
	<p>The Lipps told a captive audience of volunteers and organizers about that first Fort Collins experience Saturday morning at the opening of the city's Bike Library.</p>
	<p>The new library has 50 available bikes and hopes to expand to 200, said Rafael Cletero, the library's fleet manager and director of the co-op.</p>
	<p>There are two locations were bikes can be borrowed: a kiosk on the north side of Old Town Square and at 222 LaPorte Ave., the location of the Fort Collins Bike Co-op.</p>
	<p>The Lipps' story and stories like it are the reason the library is opening, said Chris Pranskatis, the library's volunteer coordinator.</p>
	<p>The library lends bikes to the public, free of charge. Lenders can borrow a bike for up to a week.</p>
	<p>The bikes were donated by Fort Collins police and refurbished with the help of the Fort Collins Bike Co-op, he said.</p>
	<p>"It's really a collaborative of a number of organizations," Pranskatis said.</p>
	<p>The library is funded by a $132,000 federal grant for reducing traffic congestion and improving air quality and $33,000 in matching donations from local groups.</p>
	<p>It is staffed by volunteers.</p>
	<p>"It's great to get people out and exploring the town (on a) bike," Pranskatis said. "It's a friendly way to explore the town. It's great for the fabric of the community."</p>
	<p>The bikes will help improve air quality in Fort Collins, Cletero said.</p>
	<p>"If you get 25 people (borrowing bikes) in one day, that's 25 less cars on the road," he said.</p>
	<p>The new library and the co-op are important to the unique atmosphere of Fort Collins, City Councilman Wade Troxell said. The community is an outdoors-focused place.</p>
	<p>"There's nothing better than biking in Fort Collins on a day like today," Troxell said. </p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
