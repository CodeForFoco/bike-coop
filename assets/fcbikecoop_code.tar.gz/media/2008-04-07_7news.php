<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <a href="http://www.thedenverchannel.com/news/15814314/detail.html">Original Story - 04-07-2008 - 7News, Denver</a>
         <h1>Forget Books, New Library Lends Bicycles</h1>
	 <h3>Bikes May be Borrowed For Up To A Week</h3>
	  <p><a href="mailto:deb_stanley@kmgh.com">Deb Stanley</a>, 7NEWS Producer</p>
	  <p>FORT COLLINS, Colo. -- Fort Collins has a new lending library.</p>
	  <p>But this library doesn't lend out books, it lends out bicycles.</p>
	  <p>Everyone is welcome to borrow a bike, including residents, students, and visitors. Members may borrow a bike for as short as one hour or for as long as a week.</p>
	  <p>There are a variety of bicycles and bike trailers for children and cargo as well as tandems and tag-a-longs for older children.</p>
	  <p>Right now, the library has 50 bikes available, it hopes to expand to 200 bikes.</p>
	  <p>There are currently two checkout locations for the Fort Collins Bike Library. One in the heart of Old Town Fort Collins at the Café Bicyclette, 970.419.1050. The other locations is the Fort Collins Bike CO-OP at 222 LaPorte Avenue.</p>
	  <p>The Fort Collins Bike Library is a free service thanks to FC Bikes (City's Bike Program), Bike Fort Collins, and the Fort Collins Bike Co-Op.</p>
	  <p>The Fort Collins Bike Library has more details on its <a href="http://www.fcbikelibrary.org/">Web site.</a></p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
