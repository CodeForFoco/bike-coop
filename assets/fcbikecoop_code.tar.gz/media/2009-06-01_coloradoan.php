<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.coloradoan.com/article/20090601/OPINION01/906010317">Original Story - 06-01-2009 - Coloradoan</a>
			<h1>Refurbished bikes aid people, environment</h1>
			<h3>Fort Collins Bike Co-op, others support Village Bicycle Project</h3>
			<p>Opinion Piece <a href="mailto:">-Uncredited Author-</a></p>
			<p>As Albert Einstein once said, "Life is like riding a bicycle. To keep your balance, you must keep moving."</p>
			<p>That's where Village Bicycle Project and supporting groups such as the Fort Collins Bike Co-op come into play to ensure people in need can strike a balance in their lives with refurbished rides.</p>
			<p>For people a world away, the value of a good bike goes well beyond recreational pursuits; bicycles often help to ease poverty by improving access to farms, markets, jobs, schools and health care.</p>
			<p>Recently, members of the Fort Collins Bike Co-op packed hundreds of abandoned and donated bikes into a shipping container destined for Ghana through Village Bicycle Project.</p>
			<p>Since its start in 1999, this international effort has provided 36,000 bicycles, taught 5,500 people about bicycle maintenance and distributed 15,000 tools in 12 African countries.</p>
			<p>Through its involvement with the project, the Fort Collins Bike Co-op has continued to educate people about the environmental benefits of a good bike and has helped to keep our regional landfills free of discarded rides.</p>
			<p>We salute this effort and hope there will be more localized initiatives to help people around the world find balance and keep moving forward on two wheels.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
