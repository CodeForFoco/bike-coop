<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <a href="http://www.denverpost.com/breakingnews/ci_10683095">Original Story - 10-10-2008 - denverpost.com</a>
         <h1>Pedals of empowerment</h1>
	 <p>By: <a href="mailto:jblevins@denverpost.com?subject=The Denver Post: Pedals of empowerment">Jason Blevins</a></p>
	 <div class="contents-image"><a href="http://fcbikecoop.org/media/images/2008-10-10.jpg"><img src="http://fcbikecoop.org/media/images/2008-10-10_thumb.jpg" alt="Box of Derailers"></a>
	    People in need of refurbished bikes work at Derailer Bicycle Collective, where they have a variety of bike hardware, tools and rims from which to choose. (Photos by Karl Gehring, The Denver Post ) 
	 </div>
	 <p>Carla Quist slowly spins her pedals along the gravel driveway, testing her purple mountain bike.</p>
	 <p>It doesn't look like much, but the brakes are good. It shifts smoothly. The tires are new.</p>
	 <p>"I had to push it here," she says with a shy smile. "I don't know what I'd do without this place. I sure wouldn't be riding without them."</p>
	 <p>Thanks to a team of volunteers at the Derailer Bicycle Collective, Quist can now pedal to her doctor. To her church. To the park.</p>
	 <p>"These guys save me a lot of walking," she says.</p>
	 <p>Now in its sixth year, Derailer has helped thousands like Quist &mdash; down-and-outers who struggle to make bus fare &mdash; find some two-wheeled freedom. From a humble warehouse at 411 Lipan St., a hustling crew of volunteer bike mechanics does more than ration free bikes and parts to a steady stream of Denver's needy. </p>
	 <p>"Our emphasis is having people learn to work on their own bikes," says Benji Nelson, a five-year volunteer at Derailer.</p>
	 <p>Nelson, his hands black with bike grease and his worn blue jeans even blacker, checks a list of scribbled names on a yellow tablet and begins a new bike project, a custom build with a man named Juan. Some, like Quist, come looking for a repair. Others, like Juan, need a new ride. </p>
	 <p>Behind the warehouse, a multihued yard of miscellaneous metal provides the beginning. First-timers can pick a frame from a pile cresting the top of an 8-foot chain-link fence. A stack of wheels reaches the roof of the warehouse.</p>
	 <p>Crates of fading seats, handlebars and pedals await selection. Everything is either scavenged from scrap yards or donated.</p>
	 <p>Inside, pyramids of parts form islands in a sea of tools and bike stands. Mechanics patiently teach, starting with the most basic "righty-tighty, left-loosey" and proceeding all the way up to tricky installations of bottom brackets and bearings.</p>
	 <p>The line outside can grow a hundred deep during the busy summer season. Tattered bench seats from ancient cars provide respite for those waiting for an opportunity to pedal.</p>
	 <p>"After a few years here, I realize now how profound a difference a bike can make in some people's lives," Nelson says during a rare break in the four-hour shift. "It can get you a job and to a job. It can get you home. It can get you to a doctor, to help. A free bike is a free bike, but a free bike you built yourself means a little more. It's something you created."</p>
	 <p>There's a little hope with each bike that leaves the shop.</p>
	 <p>"These guys are doing such a good thing," says Gerardo Leyba as he tests his new-found transport, a dinged-up but functional 10-speed. "Lots of people can use this kind of help."</p>
	 <p>There are more than a 100 similar nonprofit outfits in the U.S., including at least six in Colorado.</p>
	 <p>The bike collectives in Colorado serve varying purposes. The new Bike Depot in Park Hill has distributed almost 500 rides to neighborhood residents since opening in April and teaches kids about bike maintenance. The Spokes Community Bicycle Project in Boulder fixes up bikes for communities in Africa. Boulder's Community Cycles uses donated rides to teach bike repair and maintenance as well as promote cycling. The Fort Collins Bicycle Co-op teaches bike repair and stocks the community's popular bike library.</p>
	 <p>Recycle Bicycles has given away almost 7,000 bikes to kids and struggling adults since its inception in 2004.</p>
	 <p>"A bike is an empowering thing, especially for someone down on their luck," says Recycle Bicycles' Bruce Lien, a retired Adams County schoolteacher who now converts old rides into new from his home in Pine. "It can become their sole reliance, and it can lead to a job, security."</p>
	 <p>Alsup Elementary principal Lynn Heintzman has given away more than 300 Recycle Bicycles at her  school. Kids recognized for a variety of achievement milestones get a shot at winning one of Lien's recycled bikes.</p>
	 <p>"The bikes are such a hit," Heintzman says. "We give away as many as we can. It's fantastic program."</p>
	 <p>More than a third of Colorado citizens can't or don't drive, says Dan Grunig, executive director of Bicycle Colorado. Those are folks most  likely to choose a bike for transportation. The more pedalers there are, Grunig says, the more biker-friendly Colorado's streets will become.</p>
	 <p>"The co-ops are fulfilling a need, for sure," Grunig says. "I wish we had one in every community."</p>
	 -------------------------------
	 <br>
	 <br>Community Cycles 
	 <br>2805 Wilderness Pl., Boulder 
	 <br>720-565-6019 
	 <br><a href="http://communitycycles.org">communitycycles.org</a> 
	 <br><br>
	 <br>Fort Collins Bicycle Co-op 
	 <br>222 Laporte Ave., Fort Collins 
	 <br>970-484-3804 
	 <br><a href="http://fcbikecoop.org">fcbikecoop.org</a>
	 <br><br>
	 <br>Spokes Community Bicycle Project 
	 <br><a href="http://spokesforfolksbicycles.org">spokesforfolksbicycles.org</a>
	 <br><br>
	 <br>The Bike Depot 
	 <br>2825 Fairfax St., Denver 
	 <br>303-393-1963 
	 <br><a href="http://thebikedepot.org">thebikedepot.org</a>
	 <br><br>
	 <br>Recycle Bicycles 
	 <br>303-908-7982 
	 <br><a href="http://Recyclebicyles.net">Recyclebicyles.net</a>
	 <br><br>
	 <br>Derailer Bicycle Collective 
	 <br>411 Lipan, Denver 
	 <br>303-893-0305 
	 <br><a href="http://derailerbicyclecollective.org">derailerbicyclecollective.org</a>
	 <p><I>Jason Blevins: 303-954-1374 or <a href="mailto:jblevins@denverpost.com">jblevins@denverpost.com</a></I>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
