<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.coloradoan.com/article/20100218/NEWS01/2180323/1002/CUSTOMERSERVICE02">Original Story - 02-18-2010 - Coloradoan</a>
			<h1>Bike safety simplified for students</h1>
			<p>By Coloradoan Staff</p>
			<div class="contents-image"><a href="http://fcbikecoop.org/media/images/2010-02-18_dave-rich.jpg"><img src="http://fcbikecoop.org/media/images/2010-02-18_dave-rich.jpg" alt="Rick and Dave teaching children"></a>
				Courtesy of Bill Black/1st Choice After School Kare Dave Roberts, left, owner of Spokes bike shop in Windsor, and Rick Price, second from left, safe cycling coordinator for the Bike Co-op of Fort Collins, provide lessons in safe bike riding for students at Liberty Common School. First-grader David Geo, second from right, and second-grader Leo VonBargen, right, learn about the 'ABC Quick Check.'
			</div>
			<p>Bill Black, owner of the 1st Choice After School Kare, or ASK, program, decided to get a jump-start on spring and brought two experts to share their knowledge about bike safety to students at Liberty Common.</p>
			<p>Dave Roberts, owner of Spokes bike shop in Windsor, and Rick Price, safe cycling coordinator for the Bike Co-op of Fort Collins, taught students about using the ABC Quick Check list before they ride to make sure their bikes are in good operating condition.</p>
			<p>Both experts emphasized wearing helmets and showed how to inspect them to make sure there are no cracks.</p>
			<p>"If your helmet has a crack, send it to file 13 (trash can) and purchase a new one," Price said.</p>
			<p>Roberts explained the importance of giving proper hand signals to let people know riders their intentions for turning, slowing or stopping.</p>
			<p>Black is working with Price to get the safety program into all 12 ASK programs. Black also wants to work with other after-school care companies.</p>
			<p>"If we could save one child's life with these seminars, it would be worth a lifetime of classes," Black said.</p>
			<h3>Interested?</h3>
			<p>For more information on the ASK program, visit <a href="http://www.1stchoiceask.com">www.1stchoiceask.com</a>. For more information on bike safety classes, e-mail Price at <a href="mailto:rick@experienceplus.com">rick@experienceplus.com</a>.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
