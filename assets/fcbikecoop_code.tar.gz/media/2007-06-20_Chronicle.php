<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<a href="http://www.rmchronicle.com/index.php?option=com_content&amp;task=view&amp;id=1092">Original Story - 06-13-2007 - Rocky Mountain Chronicle</a>
<p>LIFE IN THE BIKE LANE</p>
<p>By JOSH JOHNSON</p>
<p>Fort Collins is becoming a sanctuary for bicyclists -- well, most of them</p>
<div class="contents-image"><a href="images/2007-06-20/cover-picture.jpg"><img src="images/2007-06-20/cover-picture.jpg" alt="Cover Image"></a>
</div>
<p>Every inch of Rafael Cletero's backyard is filled with bikes or bike parts: more than 250 bicycles, stacks of inner tubes, rims, frames, tires -- a bike salvage yard.</p>
<p>"I've created a monster. I don't know what to do," says Cletero, looking across the covered grounds of his Smith Street residence in Old Town Fort Collins. The home also serves as the bicycle co-op Bike Against, which he founded humbly a few years ago.</p>
<p>"Every year, it just gets more out of control," he says. "We're almost afraid to advertise."</p>
<p>The co-op is in so much demand that it's currently closed. The 14 or so volunteers are still hauling -- behind a bike, of course -- rubber, steel and aluminum they can't use to the recycling center, as well as rebuilding neglected bikes, but they simply don't have enough space to take in more donations.  A sign on the front door reminds visitors that this is a home.</p>
<p>When open, Bike Against teaches bike owners how to repair their bikes. They assist in building original bikes, using parts from donated ones. Or they'll trade a refurbished bike for volunteer hours.</p>
<p>"Bike collectives like Bike Against have traditionally been perceived as part of the radical-left culture, like Critical Mass, a group bike ride popular worldwide for displacing traffic. What they do is subversive. By teaching people to repair their own bikes, they liberate cyclists from the stranglehold of bike shops, which is in line with leftist cultures DIY philosophies. And by putting people on bikes, they reduce oil consumption and air pollution.</p>
<p>Despite its subcultural roots, Bike Against is now negotiating for government-funded space -- and the timing itself seems fixed. The city is embracing subgroups of cyclists, like those who ride brakeless, fixed-gear track bikes on city streets, or those who build dangerous but creative Frankenbikes. Bicycles have become a highly visible, mainstream part of Fort Collins culture. And it's about to get a push.</p>
<hr>
<p>IT JUST MAKES CENTS</p>
<div class="contents-image"><a href="images//2007-06-20/cover2.jpg"><img src="images/2007-06-20/cover2.jpg" alt="2nd Image"></a>
</div>
<p>City Manager Darin Atteberry recently addressed an audience gathered at the Fort Collins Hilton. They were there to hear a report from UniverCity Connections on the future of the Choice City.</p>
<p>Like the introduction of the report -- "It all started with a bicycle ride" -- Atteberry discussed a ride he took with Colorado State University President Larry Penley, during which the two decided to work together on the town's future, the foundation of the UniverCity collaboration. Atteberry was careful to point out that the men were not riding tandem, but the real point was already made.</p>
"Our leaders right now are looking to be progressive, and they see the bicycle almost like a savior in many cases," says Dave "DK" Kemp, the bike coordinator for the city's transportation planning department. "They're picking up on biking as a form of social development, building healthy community lifestyles, environmental stewardship, air quality, traffic congestion reduction and economic development."
<p>Increasingly, bike friendliness is an asset for a city. Businesses look to locate in towns that offer amenities -- like bike lanes -- to attract the employees they want. And bike culture entices tourists. As attractive as the environmental and health benefits may be, it's not cynical to suggest that the city's love affair with bicycles is due, in part, to the development dollars they bring in.</p>
<p>"People want to move to this city because we're a bike-friendly community," Kemp says. "People are looking for that type of lifestyle. If you're living in the suburbs of the major cities, you can't bike to the library, you can't bike to the grocery store, you can't bike to the liquor store. But we have that luxury here, and people want that luxury."</p>
<p>One of the projects proposed by UniverCity is a lifelong learning center, and at the anchor of the building is a velodrome, a 250-meter, world-class bike-racing track, which the Fort Collins Velodrome Association has been pushing for years.</p>
<p>It remains to be seen if the area has an audience for track racing, but the athletes may currently be on the streets. Over the past ten years, fixed-gear and single-speed bikes have surged in popularity. Originally designed as track bikes, they were adopted by bike couriers because of their lightness. They have one gear, often a fixed gear, meaning that back-pedaling will not apply a brake or allow the wheels to spin freely. As long as the wheels are moving, the riders' feet must be moving equally as fast. Fixed-gears are made to be as simple as possible, and the annual One Speed Open, a single-speed race organized by Bike Against, gives preference to fixies and bikes without brakes.</p>
<p>"I think people ride fixed-gears because they're purists," says Dan Lionberg of Bike Against. "It eliminates so much shit that can go wrong."</p>
<p>And there's the thrill.</p>
<p>"Every second is an adventure," adds Coleman Morris, also with the co-op. "It's scary as hell."</p>
<p>Jeff Nye is the local go-to guy for bike history. His collection of bicycles, which ranges from the turn of the 20th century to the 1970s, is often on display at bike events and in local businesses. With Bike Week upon us, Nye's bikes can be seen about town, including at Ace Hardware and a tandem at The Bean Cycle, a cyclist's hub.</p>
<p>"Ten years ago, there were three of us who rode single-speed and fixed-gears in town," he says. "Now, that's all you see."</p>
<p>While bike trends, like fixies, ebb and flow, Nye says, the bicycle has not radically changed since the 1890s.</p>
<p>"There's nothing really new under the sun in cycling."</p>
<p>Nye also points out that if the interest is in simplicity, the high-wheel, what many people recognize as the first bicycle style, is simpler than a fixed-gear: The high-wheel has no chain.</p>
<p>BikeFortCollins.org, a local bicycle advocacy nonprofit, has been working toward a permanent bike museum in Fort Collins, but until one is founded, "It will be mobile."</p>
<p>Modifying bikes is nothing new, but how they are modified is as varied as the cyclists.</p>
<p>"Having a bicycle is an invitation to be creative," says Nye. "It's simple and easy to change."</p>
<p>And locals like to modify. Around town, riders tower above the street on stacked frames. Cyclists employ two front wheels and one rear for hauling. And come Tour de Fat, New Belgium Brewing's annual celebration of beer and bicycles that Kemp was instrumental in shaping, creations span everything from a chariot to a full drum kit on peddled wheels -- endlessly imaginative modifications.</p>
<p>But bikes aren't only sources of health, mobility, thrill and creativity. They're also a form of political expression.</p>
<hr>
<p>BIKING WHILE RADICAL</p>
<div class="contents-image"><a href="images/2007-06-20/cover1.jpg"><img src="images/2007-06-20/cover1.jpg" alt="3rd Image"></a>
</div>
<p>Officer Stephan Sparacio</p>
<p>Local activists have quipped that if you want to get arrested during a protest, ride a bike.</p>
<p>When Critical Mass cyclists convened in the CSU Oval on May 25, they must've known a confrontation with Fort Collins' finest was likely. It was the last Friday of May, the day Massers in cities worldwide meet for probike, anticar rally rides. There hadn't been a Critical Mass ride in the Fort in more than a year, and the last one ended with two arrests.</p>
<p>The recent ride started well enough, with more than 30 people meandering leaderlessly through town and, traditionally, without a set route, displaying bike power in the face of polluting motorists and having fun doing it.</p>
<p>Trouble started when the group turned right onto Walnut Street from College Avenue, through a red light, which is legal but, considering the number of riders, is disruptive to 5:30 p.m. traffic. Police stopped the ride with emergency lights and air horns. Some Massers dismounted and dispersed, moving their bikes onto the sidewalks.</p>
<p>But Officer Stephan Sparacio wanted to chat.</p>
<p>"I said, 'Hey, guys, can I talk to you for a minute?" Sparacio wrote in an incident report.</p>
<p>What happened next differs between the report and witness accounts.</p>
<p>Eric Podzemny, a Masser who is identified as a "transient" in the report, either approached Officer Sparacio or, as witnesses attest, the officer approached him. When asked to dismount his bicycle, Podzemny, straddling the bike instead, did not dismount to Sparacio's satisfaction. The two quarreled.  Witnesses say Sparacio got rough, kicking Podzemny's bike out from under him and pressing his face to the ground. Sparacio's report acknowledges that he at least took Podzemny down to a kneeling position: "I told him over and over 'to get on the ground."</p>
<p>After Podzemny refused to, or simply couldn't, "get on the ground" any further, Sparacio maced Podzemny's face. Intimidated by the size of the crowd, Sparacio then called for backup, and Officer Heather Moore soon arrived. In her report, she wrote that Sparacio threatened a woman in the group with pepper spray and pushed a male onto his bike by striking him in his "jugular notch."</p>
<p>Podzemny was arrested for an outstanding warrant.</p>
<p>"It's interesting with Critical Mass: It's the aggressive to be aggressive and radical and public protest part, the anarchy, that some folks look for," says Kemp, the city's bike coordinator. "The thing about Critical Mass is that it was needed. Back in San Francisco 15 years ago, when it started, there was a serious issue with motor vehicles not respecting biking. That was necessary there."</p>
"Now, here in Fort Collins, we have a certain bicycle-friendly atmosphere already, so that type of thing is not needed."
<p>Cletero, who has participated in Critical Mass rides, thinks the group's message gets lost in the approach and wishes the riders were more diverse.</p>
"To the average citizens, you're just some crazy people on bikes," he says.
<p>"Critical Mass met in Library Park after Podzemny's arrest and reached consensus on a few ground rules, like obeying lights and perhaps establishing a route. After all, Podzemny had an outstanding warrant, and he was one of a collective.</p>
<p>"It is Critical Mass, so we don't want it to be lots of rules and stipulations and such, because it is an act of disobedience," says John Farinelli, who also volunteers at Bike Against. "But what we realized is to do that and get our point across, we do need to have the basic rules."</p>
<p>FREE FOR ALL</p>
<p>The city briefly shut down Bike Against last year -- not for being radical, but rather for simply not following code -- for operating a "business," albeit a nonprofit without recognized nonprofit status, out of a residence.</p>
<p>Luckily for Bike Against, the city had just hired Kemp.</p>
<p>"We worked with Planning and Zoning and found the middle ground, and opened them back up again," Kemp says. It was a matter of filling out a couple of forms and installing proper signage.
<p>Kemp began looking into how the city could help Bike Against find a more appropriate, permanent location.</p>
<p>"These guys just need to get their private residence separate from their business so they can have a healthy life, you know?" he says.</p>
<p>After a six-month process requiring approval from all city departments, city council and the city manager, Kemp told Bike Against that they would likely be able to move into the city-owned former Poudre Valley Creamery building on Laporte Avenue. Kemp says the arrangement is almost a done deal, but the site is still in the change-of-use process, which requires a minor amendment to city code. He expects the group will be working out of their new building by mid-August at the latest. With bay-door garages, an Old Town location and administrative offices, the spot is well suited for a bike co-op.</p>
<p>The approval process has dragged on for so long that Bike Against volunteers discussed pressuring city council, but Kemp advised against it, explaining that city cogs often turn at a slow pace.</p>
<p>"Some of the folks don't understand that it takes a bit of time for a concept like this to get digested," Kemp says.</p>
<p>The city doesn't need to contribute a dime to the project. It can lease the space as a donation. And BikeFortCollins.org has merged with Bike Against, giving them nonprofit status and allowing them to jointly apply for a $165,000 Congestions Mitigation Air Quality grant with FC Bikes, the city organization run by Kemp. New Belgium Brewing and the Downtown Development Authority have promised matching funds.</p>
<p>Bike Against volunteers also considered the co-op's name as perhaps unusual for a city-sponsored program. Referencing the hardcore band Rise Against, the moniker carries a radical aesthetic. For city purposes, grants and paperwork, the group will be called the Fort Collins Bike Co-op. But the choice lies with the volunteers.</p>
<p>"I don't care what it's called, Kemp says. "Those guys do a great service for our city, and that"s why I"m trying to find them space."</p>
<hr>
<p>CRUSING INTO THE SUNSET</p>
<div class="contents-image"><a href="images/2007-06-20/cover3.jpg"><img src="images/2007-06-20/cover3.jpg" alt="4th Image"></a>
</div>
<p>Jeff Nye</p>
<p>On Friday, June 1, in the bustle of Old Town, the Colorado Cycling Festival sponsored a cruiser ride through Fort Collins. Kemp opened Café Bicyclette, a bike-culture center, in the information kiosk by the fountain. New Belgium sponsored Bike Against to build 20 bikes for loan. While cyclists got free tune-ups, Nye set up a display from his collection, including a fixie with wooden rims that he takes to "centuries," 100-mile-long rides. Beside the collector's bikes was the first fleet of community bikes, painted red.</p>
<p>Along with bicycle education and the recycled bike project, The Fort Collins Bike Co-op's most ambitious mission in their new home will be to maintain the bike library, which is exactly what it sounds like: Members will be able to check out bikes of varying styles for up to a week, free of charge. Along with the donations currently covering Cletero's backyard, Fort Collins Police Services will donate the 500 to 600 bikes they annually ship to California for auction.</p>
<p>The library will loan bikes of all styles and sizes, and they will all be solidly built, not the "Wal-Mart shitty specials that are dangerous off the shelf," as Cletero puts it.</p>
<p>There will soon be no reason why every resident of Fort Collins cannot have a bike. Perhaps then, cyclists will truly reach a critical mass.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
