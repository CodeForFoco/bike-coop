<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <a href="http://www.theage.com.au/world/bicycle-library-popularity-a-turn-up-for-the-books-20080721-3iro.html">Original Story - 07-22-2008 - theage.com.au</a>
         <h1>Bicycle library popularity a turn up for the books</h1>
	 <p>By Steve Graff, Fort Collins, Colorado</p>
	 <p>THE price of petrol was a good enough reason for Amanda Gilson, a student at Colorado State University, to sell her SUV and jump on a bike - even if she only gets to ride it every other week. "You have to let other people use them," she said.</p>
	 <p>Ever since the Fort Collins Bike Library, which offers free bike rentals, opened its doors last northern spring, it has been juggling an excess of riders with a shortage of bikes.</p>
	 <p>"It's a great program," said Jeff Morrell, president of Bike Fort Collins. "We just need more volume." Anyone with an ID and email address can borrow a bike for up to a week from the library's two stations. But they have to get in line first.</p>
	 <p>Since the library opened on April 5, the waiting list for a bike on Fridays and at weekends can be up to six people deep. To keep up with the demand, the library boosted the fleet from 20 bikes to 60. They're hoping for 200 by summer 2009. The fleet is mostly made up of bikes that went unclaimed after being recovered by Fort Collins police.</p>
	 <p>About 600 riders have checked out bikes since the library opened. For the past couple of months, Ms Gilson and her boyfriend, who use bikes to get to class and work, have been able to borrow a bike only every other week.</p>
	 <p>Because bikes are such a hot item in Fort Collins, some people are willing to buy one. "When they realise we don't have any free bikes, they go and pay for bikes," Mr Morrell said.</p>
	 <p>The city's bike shops caught wind of the demand and started renting out bikes again, he said.</p>
	 <p>Dave "DK" Kemp, who helped start the library with federal grant money, predicts four more bike stations around the city by next year.DENVER POST</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
