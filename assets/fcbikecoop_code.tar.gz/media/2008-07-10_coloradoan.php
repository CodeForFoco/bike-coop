<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <a href="http://www.coloradoan.com/apps/pbcs.dll/article?AID=/20080710/OPINION01/807100344">Original Story - 07-10-2008 - Coloradoan</a>
         <h1>Bike library's a positive contribution</h1>
	 <h3>Demand, funding, volunteers will ensure ongoing success</h3>
	 <p>Unknown Writer</p>
	 <p>Libraries aren't just for books. They can be for bikes, too.</p>
	 <p>The success of the Fort Collins Bike Library deserves to be applauded. Starting with 50 red bikes this spring, the program that allows Fort Collins residents and visitors to check out bikes for a limited time is expected to grow to 100 bicycles by this fall.</p>
	 <p>Demand for the free service is so high that one library volunteer told the Coloradoan that people are "desperate" for bikes. The service is funded through a federal clean-air grant with the city in partnership with Bike Fort Collins and the Fort Collins Bike Co-op.</p>
	 <p>Borrowers get a bike and all the benefits of cycling, including free transportation, increased health and knowing they are helping to clear the air. Users have included visitors, college students and retirees - all seeking a convenient way to get around town.</p>
	 <p>About the only downfall is that some, including homeless men and women, haven't returned their bikes on time, forcing library volunteers to track them down. The library is considering the use of credit-card imprints to ensure bikes make their way back to the program.</p>
	 <p>The continuation of this success will depend on several factors: demand (which seems ensured); funding and volunteer support; and availability of bikes. Similar bike-lending programs have failed due to one or all of the above. Currently, bikes for the library come from unclaimed stolen bikes from the Fort Collins police. The bikes are stripped down, rebuilt and painted before they are loaned out. Still, there aren't enough volunteers to restore donated bikes.</p>
	 <p>We hope the Fort Collins Bike Library, with its local popularity, continues with this free and beneficial service.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
