<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.coloradoan.com/apps/pbcs.dll/article?AID=2011111080314">Original Story - 11-07-2008 - Coloradoan</a>
			<h1>McWhinney backs out of Block 23 deal</h1>
			<p>By <a href="mailto:PatFerrier@coloradoan.com">Pat Ferrier</a></p>
			<p>An entire city block in Old Town Fort Collins is back on the market.</p>

<p>McWhinney, the Loveland development company that built Centerra, has pulled out of a contract to buy the underdeveloped block on North College Avenue between Maple and Cherry streets, also known as Block 23.</p>

<p>Company representatives said they couldn't make the economics work for the kind of project they envisioned - about 300 apartments, office and retail space and a parking garage.</p>

<p>The 3.49 acres previously owned by Realtor Michael Jensen went into foreclosure earlier this year and is owned by Bank of Choice.</p>

<p>It is a large and tough site for apartments, said Kevin Brinkman, principal with Brinkman Partners, which is listing the property for sale.</p>

<p>Even with near-record-low vacancy rates "we need rents to come up in that trade area before it really works well."</p>

<p>Brinkman said he has another group "interested in taking a hard look" at the property. "Everyone wants the right development there. It's a matter of finding the right group, the right mix. The bank is willing to take its time."</p>

<p>For the past four weeks, the property has been home to Occupy Fort Collins, a small group of activists supporting the Occupy Wall Street movement in New York City.</p>

<p>The loosely affiliated movement that began last month is peacefully protesting the power of the financial and political sectors.</p>

<p>Police accompanied bank officials to the site Friday and posted "no trespassing" signs on the property, giving protesters until Monday to either move to the sidewalk or elsewhere in the city.</p>

<p>The activists complied, took down the tents they had erected to stay warm and have largely moved to the sidewalk.</p>

<p>Mike Hill, senior director of multifamily development and operations for McWhinney, said McWhinney dropped its pending contract before the Occupy movement or the fire that destroyed an apartment building under construction one block west.</p>

<p>Jensen once heralded the block, known as Block 23, as a key location for a proposed downtown hotel.</p>

<p>While McWhinney won't be building in Old Town at this juncture, the company is negotiating another site in Fort Collins on which to build higher-end apartments, Hill said.</p>

<p>"They will be Class A market rentals with top quality for the region and Fort Collins."</p>

<p>The site is not in Old Town but Doug Hill, chief operating officer, declined comment on where in Fort Collins it is.</p>

<p>McWhinney has not submitted any preliminary plans to the city of Fort Collins as of Monday.</p>

<p>McWhinney has been building apartments by the hundreds in Loveland. Last year, it built a $45 million, 303-unit luxury apartment complex, Lake Vista, and in March broke ground on 252 units on the Van de Water property off U.S. Highway 34.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
