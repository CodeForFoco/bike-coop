<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <a href="http://www.fortcollinsnow.com/article/20080317/NEWS/654869779">Original Story - 03-17-2008 - Fort Collins NOW</a>
         <h1>Checking Out Sweet Rides</h1>
	 <h3>Bike Fort Collins set to launch Bike Library program</h3>
	  <p>By Matt Brady</p>
	  <div class="contents-image"><a href="images/2008-03-17.jpg"><img src="images/2008-03-17.jpg" alt="Story Image"></a>
	  </div>
	  <p>If given a choice between paying three dollars and rising for a gallon of gas or tooling around town on a free bicycle, which seems the most practical decision? It might be an easy question for many, but there are still those willing to continue paying for the gas.</p>
	 <p>Bike Fort Collins is attempting to change that reality by launching a new program to offer you the extra incentive needed to keep those cars in the garage and off the road. On April 5, Fort Collins will launch its first ever city bike library. It's not a "library" in the sense that you check out books on bicycling, but a place to check out the bicycles themselves.</p>
	 <p>The library will work in conjunction with the Fort Collins Bike Co-op, which will oversee any bikes in need of repair.</p>
	 <p>"We'll have about 50 bicycles that we'll lend to patrons with no charge" said Jeff Morrell, President of Bike Fort Collins. The volunteer-run library will have its base of operations at the freestanding kiosk in Old Town Square. The checkout procedure will be relatively simple.</p>
	 <p>"They'll need to come in, fill out a form, and we'll just hand them a key and they're off" Morrell said</p>
	 <p>Library users can rent a bike for anywhere from an hour to two weeks. Arrangements can be made if they need to borrow for longer, Morrell said.</p>
	 <p>The kiosk won't be the only library site.</p>
	 <p>"We will have another location at 222 Laporte Ave. That's where our shop and our warehouse are" Morrell said. "We will also have a substation at the Colorado State University center; the grand opening for that one is April 11."</p>
	 <p>Eventually, the full scope of Morrell's vision is to have even more checkout locations. He's working on securing sites in hotels and other public places around town. Morrell's idea is to have it be very convenient for cyclists to check out bikes at one location and be able to ride to another destination point where a site will be available to check the bike back in.</p>
	 <p>Gas may not be cheap, but neither is launching a free-of-charge city-wide bike library program. Fortunately for Morrell and Bike Fort Collins, the federal government has allotted a two year grant equalling about $170,000. The Congestion Mitigation and Air Quality grant was granted specifically to the Bike Library; though the money is from the federal government, it's administered by the city of Fort Collins.</p>
	 <p>"We will be using the money to purchase more bikes, as well as to pay for a part-time coordinator and project manager" Morrell said. The grant requires that the library be involved in research towards reducing traffic and improving air quality.</p>
	 <p>"Through the library we are going to monitor how many miles and how many days the bikes will be used" Morrell said.  "We'll know that there are less vehicles being driven for those dates and we'll monitor how much less CO2 is being put into the atmosphere."</p>
	 <p>Following the grand opening, the plan is to expand the 50 bike fleet to 200 bicycles by next spring. The fleet will include bikes for children, cargo trailers and baby trailers.</p>
	 <p>"We also plan to have brochures with self-guided tour maps" Morrell said.  "We already have a Poudre river tour brochure and a historical tour."</p>
	 <p>Morrell and Bike Fort Collins think the self-guided tours will be quite successful.  "If somebody wants to bring their family or friends to Fort Collins they can check out a bike, ride up and down the Poudre, and bring the bike back in."</p>
	 <p>After a cold winter, it'll be hard to beat a warm and breezy ride up the Poudre River on one of the Bike Library's newly tuned rides.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
