<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.coloradoan.com/article/20120118/NEWS01/201180347/How-safe-your-bike-">Original Story - 01-18-2012 - Coloradoan</a>
			<h1>How safe is your bike?</h1>
			<h3>As the number of Fort Collins bicycle thefts continues to rise year over year, many are asking ...</h3>
			<p>By <a href="mailto:davidyoung@coloradoan.com">David Young</a></p>
			<div class="contents-image"><a href="http://fcbikecoop.org/media/images/2012-01-18.jpg"><img src="http://fcbikecoop.org/media/images/2012-01-18.jpg" alt="Bikes Locked to rack in old town"></a>
				Bikes are locked Sunday to racks along South College Avenue in downtown Fort Collins. Lost, stolen and abandoned bikes are housed at the Fort Collins Bike Co-op at 331 N. College Ave.<br>
				RICH ABRAHAMSON/THE COLORADOAN 
			</div>
			<p>When John Eklund bought a Yeti mountain bike on Craigslist last year, he never thought he would be searching the same website a month later for the same bicycle.</p>
			<p>Eklund was only able to ride his bike a few times before it was stolen, along with three other bikes, right out of his garage.
			<p>Eklund is not alone.
			<p>Bike thefts in Fort Collins are on the rise. In 2010, the latest data available, the city reports 747 bicycles were stolen in Fort Collins - a number that has gone up every year since 2006. Those numbers do not reflect thefts not reported.
			<p>Bicycles are often easy targets for criminals - they are mobile and often left unlocked or insecurely stored in dark alleys. Thieves can strip a bicycle for parts or resell it cheap.
			<p>It is a problem in Fort Collins that continues to grow each year, Dave "DK" Kemp, the city's bicycle coordinator, said in an email.
Stolen Bicycles</p>
			<p>John Eklund and his wife, Lindsay Brinkman Eklund, became victims last year when four of their six bicycles, valued at about $7,500, were stolen from their garage.</p>
			<p>In August, John Eklund said he got up in the middle of the night to check out a noise. After checking the perimeter of his house, he returned to bed, but forgot to close the garage door. The next morning, he awoke to find two mountain bikes, a road bike and a vintage Schwinn missing.</p>
			<div class="contents-image"><a href=""><img src="" alt=""></a>
FORT COLLINS BIKE THEFTS<br>
2006 - 552<br>
2007 - 556<br>
2008 - 679<br>
2009 - 710<br>
2010 - 747<br><br>
BIKE THEFT PREVENTION/RECOVERY TIPS<br>
� Write down bicycle serial numbers and take pictures of the bikes<br>
� Register bikes with local law enforcement or the National Bike Registry<br>
� File a report with local police if stolen<br>
� Insure bicycles<br>
			</div>
			<p>"It was pretty unreal at first," John Eklund said. "It took me a second to realize there was a lot of space in here (the garage). Then, it clicked."</p>
			<p>The Eklunds said they immediately contacted police and filed a report. While they had photos of all the bikes, they were only able to provide the serial number for the Specialized road bike. They watched Craigslist to see if the bikes would appear - they even rode around town looking for them on occasion.</p>
			<p>Nothing turned up. That is, until a few months later, when John Eklund was out to lunch.</p>
			<p>He was returning to work from Justine's Pizza when he noticed a familiar looking bike chained up in front of JCPenney. Upon closer inspection, he realized it was the stolen road bike. He called police who verified the serial number.</p>
			<p>The officer was prepared to drill the heavy duty chain lock for them, when a store employee stepped forward and claimed the bike, they said.</p>
			<p>Eklund said the man told him that he bought the bike at a moving sale in Weld County for $130. He turned the bike back to the Eklunds, admitting that the deal was too good to be true. The bike retailed for $1,200 and was worth at least $650, said Brinkman Eklund.</p>
			<p>While insurance covered the loss of the other bikes, the Eklunds said the theft left them feeling violated and a bit insecure in their own home.</p>
			<p>The couple is in the process of constructing a bike rack in the garage that can be locked.</p>
			<p>The Eklunds' experience is shared by many others.</p>
			<p>Lauren Hoff, 24, lives in Old Town and works at Pateros Creek Brewing. In July, she left her Trek road bike and an old Schwinn cruiser unlocked on her enclosed porch overnight. The screen door was unlocked and her Schwinn was gone in the morning.</p>
			<p>Hoff said she never understood why the thief took the Schwinn - worth about $150 - when there was the $1,500 Trek sitting next to it.</p>
			<p>While the bike had little monetary value, it had a lot of sentimental value for Hoff. The bike belonged to her roommate, Mary Warren, who was killed by a drunken driver on Interstate 25 on July 5, 2010.</p>
			<p>Hoff never reported the theft to the police, because she said reporting it would be a "waste of time," but she did keep an eye on Craigslist.</p>
			<p>The bike never turned up, but Hoff makes sure to secure her bike inside now.
Protecting Bicycles</p>
			<p>The reason bike thefts are on the rise is because there are more cyclists and bicycles each year as Fort Collins grows as a bicycling community, Kemp said.</p>
			<p>"Being a bike-friendly community, thieves may target Fort Collins rather than Loveland and Greeley simply because there is a high number of cyclists," Kemp said.</p>
			<p>Of 685 bikes reported stolen in 2010, only 60 were recovered, according to Fort Collins police statistics.</p>
			<p>Jim Szakmeister, captain of the patrol division with Fort Collins Police Department, said bicycles are a popular item for people to steal either for a joy ride or to resell. He attributes the increased thefts to CSU's population and the fact that Fort Collins is a bicycle savvy community.</p>
			<p>Szakmeister knows firsthand what it's like to lose a bike; he had his stolen one night when he forgot to close his garage. The majority of bike thefts occur when a garage is left open or a bike is unlocked. Some bike locks are clipped, but Szakmeister said that is the minority of thefts.</p>
			<p>Szakmeister said bike thefts have risen on his radar in the past six months and he would like to be able to combat it more, but said it is hard unless owners have the serial number.</p>
			<p>Like the city, CSU has seen an increase in bike thefts on campus</p>
			<p>Joy Childress, CSU traffic and bicycle education and enforcement program coordinator, said bicycle thefts spike during winter or summer breaks.</p>
			<p>"I think biking has become more sociably cool," she said. "It is definitely on the rise - I see a correlation."</p>
			<p>Along with the increase in thefts, Childress said, they have seen more bikes registered on campus. Cyclists on campus are required to pay $10 to register their bikes with the campus police. That information is also shared with local and regional police departments.</p>
			<p>In an effort to stop the growing number of bike thefts, Fort Collins Police, the city of Fort Collins and CSU police along with some residents are exploring possible bicycle sting operations to bust bicycle theft rings, said Kemp.</p>
			<p>Police work in tandem with the Fort Collins Bike Co-op to help return stolen bikes to the proper owner.</p>
			<p>Rick Price, Fort Collins bike co-op safe cycling coordinator and chairman of the bike advisory committee, said bike thefts are an issue in any university town.</p>
			<p>While he has a hunch that a lot of bike thefts are the result of carelessness on the owners' behalf, he said a lot of people in town use bikes as a primary form of transportation and there are not enough racks to accommodate them.</p>
			<p>As a result, many bikes end up chained in alleyways and outside apartments where they are easy targets for thieves.</p>
			<p>The Bike Co-op handles all of Fort Collins' recovered bikes. Each recovered bike is logged, tagged and filed in its database.</p>
			<p>A Co-op group - Bicycle Army Retrieval Squad - or BARS, combs Fort Collins to pick up any abandoned bikes. The Bike Co-op cross references its recovered bikes with the police department's stolen bike reports once a week. If there is a match, the Co-op will contact the officer in charge of the case to help victims get their bikes back.</p>
			<p>In 2011, BARS recovered 222 bikes and returned 11 of those back to owners, according to Paul Lugo, Bike Co-op database manager.</p>
			<p>Laura Rogge, abandoned bike coordinator, said the remaining bikes are used for education programs or donated, but never sold.</p>
			<p>In some cases, Rogge has tracked down owners who were unaware the bikes were even missing.</p>
			<p>"It (found bikes) comes in waves and varies greatly. I don't know what causes it," said Rogge, who recovers about five bikes a week in the spring through fall.</p>
			<p>The Facebook group "Fort Collins Stolen Bike Report" and "Stolen Bikes Colorado" page is dedicated to helping recover stolen bicycles. The pages are littered with posts and photos of stolen bikes that cyclists are looking to retrieve.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
