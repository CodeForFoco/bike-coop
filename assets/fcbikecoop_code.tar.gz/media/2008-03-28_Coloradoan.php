<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <a href="http://www.coloradoan.com/apps/pbcs.dll/article?AID=/20080328/NEWS01/803280328/1002/CUSTOMERSERVICE02">Original Story - 03-28-2008 - Coloradoan</a>
         <h1>Fort Collins Bike Library opens April 5</h1>
	  <p>By: <a href="mailto:JasonKosena@coloradoan.com ">Jason Kosena</a></p>
	  <div class="contents-image"><a href="images/2008-03-28.jpg"><img src="images/2008-03-28.jpg" alt="Story Image"></a>
	  V. Richard Haro/Coloradoan library - Bikes lay scattered near the Bike to Work Day station at Rolland Moore Park on June 27, 2007. The grand opening of the Fort Collins Bike Library on April 5 will allow anyone with a valid ID to check out a bicycle at two Old Town locations.
	  </div>
	  <p>Fort Collins residents will soon be able to park in Old Town, borrow a bicycle and head to the Poudre River Trail - free of charge.</p>
	  <p>The grand opening of the new Fort Collins Bike Library, a program sponsored by Bike Fort Collins, the Fort Collins Bike Co-op and the city through the FC Bikes Program, will allow anyone with a valid ID to check out a bicycle at two Old Town locations and use it for up to a week.</p>
	  <p>"This is one of the most immediately gratifying ways to get people on bikes. It's that simple," said Chris Pranskatis, executive assistant for Bike Fort Collins. "If you enjoy seeing people on bikes, for whatever reason, this is a great. No matter who you are or where you are from, you can check out a bike and away you go."</p>
	  <p>The program, working primarily through volunteers, is funded through a federal grant awarded to help improve air quality by getting people out of cars and on the street walking or riding a bike, Pranskatis said.</p>
	  <p>The grand opening at the Fort Collins Bike Co-op, 222 LaPorte Ave., will be from 11 a.m. to 4 p.m. April 5. The event will feature free live music, food and bike riding.</p>
	  <p>The Bike Library will have two permanent locations, one at the Fort Collins Bike Co-op and another at a stand-up kiosk in Old Town Square. Both will be open from 10 a.m. to 6 p.m. Fridays, Saturdays and Sundays.</p>
	  <p>"Fort Collins is very fortunate because we have a community that is blessed with 300 days of sunshine and the geography of the town center is flat, so we really have the appropriate environment for this kind of program," Pranskatis said. "I am an avid (bicycle) commuter, and I have been doing it for years, and every day I find a new advantage to seeing the town by bike."</p>
	  <p>Unlike the library system, which charges late fees for belated book returns, the Fort Collins Bike Library will work on the honor system. But volunteers aren't checking IDs before loaning bikes out for no reason, either.</p>

	  <p>"There are no late fees, but if they don't return the bike, we will send them a warning, and if they still don't return it we will send their information over to police services," Pranskatis said.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
