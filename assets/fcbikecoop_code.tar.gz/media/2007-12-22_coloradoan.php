<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <a href="http://www.bikefortcollins.org/news_and_letters/council_oks_bike_coop_space_ma.html">Original Story - 12-22-2007 - Coloradoan</a>
	 <h1>Council OKs bike co-op space.</h1>
	 <h3>Mayor: Program assists in economic health of city</h3>
	 By <a href="mailto:JasonKosena@coloradoan.com">JASON KOSENA</a>
	 <p>The Fort Collins Bike Co-op will pay $5 a year to lease prime downtown real estate, thanks to City Council.</p>
	 <p>The council recently approved the lease agreement at the old Fort Collins Creamery, 222 LaPorte Ave., for the volunteer-based nonprofit organization that refurbishes donated, abandoned and recovered bikes and gives them to low-income families.</p>
	 <p>"This space is absolutely crucial to what we're trying to do," co-op member Coleman Morris-Goodrick said. "We have been operating out of a garage since we started five years ago, and the use of this space will allow us to expand and grow the program, taking it to the next level."</p>
	 <p>Mayor Doug Hutchinson said the vote was easy to make, equating a bicycle-healthy community with economic stability.</p>
	 <p>"I have spoken to many businesses who have told me they are better able to attract and recruit some of the world's best talent to Fort Collins because of the bike paths and open space and other amenities," Hutchinson said. "I think this program is an extension of that. It will have a positive impact."</p>
	 <p>The city's facilities department completed roofing and plumbing repairs to parts of the creamery site, and the city attorney's office helped draft ordinance language to change the land-use plan to allow for the operation.</p>
	 <p>"Before, the police department was shipping off all the bikes they recovered to California to go up for auction, with very few of those proceeds every being realized," said Dave Kemp, the city's bike coordinator. "Essentially, the city was just shipping them out there because they didn't have a place to store them all."</p>
	 <p>Allowing the co-op, which works in partnership with the Recycled Bike Project, to use the city space allows the bikes to be put to good use locally.</p>
	 <p>"We aren't giving bikes away to just anybody who comes here," Kemp said. "We want to make sure we're getting them into the hands of children and people in the at-risk population."</p>
	 <p>The volunteers have refurbished and repaired thousands of bicycles for the community, sometimes servicing 40 or 50 bikes each day during the summer months, program volunteer Rafael Cletero said.</p>
	 <p>"We outgrew our old location two or three years ago but didn't really have anywhere to go," Cletero said. "We have gotten so much help from the city and the community though, and now we're excited to see where we can take it from here."</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
