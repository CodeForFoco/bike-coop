<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.coloradoan.com/article/20090406/NEWS01/904060322">Original Story - 04-06-2009 - Coloradoan</a>
			<h1>Fort Collins bike co-op among finalists for grant</h1>
			<p>By <a href="mailto:TrevorHughes@coloradoan.com">TREVOR HUGHES</a></p>
			<p>The Fort Collins bike co-op is one of 10 finalists for a $10,000 grant to give free bike tours around Old Town and city bike paths to tourists and residents.</p>
			<p>Clorox, which makes Green Works natural cleaners, is giving out five grants to organizations across the country. The finalists were selected by the Sierra Club, The Lazy Environmentalist and ecofabulous.com.</p
			<p>People can vote online  until Friday to select the five winners, which will be announced April 22.</p>
			<p>Rick Price, a member of the board of directors for the Bicycle Cooperative of Fort Collins, entered the contest on the co-op's behalf. Price founded the Fort Collins-based bike touring company now known as ExperiencePlus.</p>
			<p>Under Price's application, the co-op would work in partnership with the Fort Collins bike library to offer guided tours of the city. Price said he envisions easy rides that get people acquainted with the Choice City, giving them "a taste of all the possibilities."</p>
			<p>Price said: "It gives the visitor, even people who live here who haven't had an opportunity, to get out on the trails."</p>
			<p>Price said he's heard from many senior citizens in the community that they'd like to get back on their bikes but are reluctant to do so because they haven't ridden in decades.</p>
			<p>Other finalists for the grants include backers of a 30-mile recreational trail from Grants Pass to Central Point in Oregon, a worm farm at a Brooklyn school and a group of Tennessee high school students working to persuade parents to shut off their vehicles while waiting outside the building.</p>
			<p>The co-op, which recently was certified as a nonprofit by the IRS, is a longtime volunteer organization that helps keep bikes out of landfills and supports community cycling efforts.</p>
			<p>Volunteers have helped rebuild most of the bikes in the city's popular bike library by stripping down abandoned and donated bikes and adding new parts. The co-op also hosts the popular Earn-A-Bike program in which volunteers, including the homeless, can earn their way to their own ride.</p>
			<p>Price said the tours would be a little outside the co-op's normal mission, but he said he believes winning the grant and giving the tours would help raise awareness of the organization and the city's biking culture.</p></div><br><div class="clear"></div><br><div id="article-pagination"></div><div class="clear"></div>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
