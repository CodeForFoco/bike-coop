<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.reporterherald.com/news/larimer-county/ci_18898487">Original Story - 09-15-2011 - Reporterherald.com</a>
			<h1>McWhinney eyes huge Fort Collins project</h1>
			<h3>Apartments, offices, stores slated for full downtown block</h3>
			<p>By <a href="mailto:thacker@reporter-herald.com">Tom Hacker Reporter-Herald Staff Writer </a></p>
			<p>Raising its stake in Northern Colorado's rental housing market, McWhinney plans a summer groundbreaking on an apartment project that consumes an entire city block in downtown Fort Collins.</p>
<p>The developer has filed conceptual plans that describe a 608,000-square-foot, five-story building that includes a five-level parking garage, rental apartments and office-retail space.</p>
<p>"We looking at breaking ground in the second or third quarter of next year," said Mike Hill, who directs McWhinney's multifamily housing projects.</p>
<p>Hill did not venture more information than is contained in the concept plan, declining to discuss project costs or pricing for the available residential and commercial space.</p>
<p>Hill said the project will put about 300 rental apartments on the downtown Fort Collins market, and an additional 13,000 square feet of combined office and retail space.</p>
<p>The block is on the northern edge of Old Town, fronts College Avenue and is bounded on the north and south by Maple and Cherry streets and on the west by Mason Street.</p>
<p>For about a decade, the block had been the center of a plan by Fort Collins Real Estate founder Mike Jensen to build at 10-story downtown hotel.</p>
<p>Jensen had assembled a half dozen separate properties, worth more than $8 million, to put to that use.</p>
<p>But the economic collapse of late 2008 iced the plan, and the block went into foreclosure with ownership reverting to Greeley-based Bank of Choice.</p>
<p>Fort Collins real estate development and brokerage firm Brinkman Partners listed the block for $4.6 million before McWhinney's recent purchase contract.</p>
<p>McWhinney has jumped into the rental apartment market with major projects in the past two years.</p>
<p>In 2010 the developer broke ground on the $45 million, 303-unit Lake Vista apartment complex at Centerra, now close to completion. A new 252-unit apartment project is under construction at the company's Van de Water holding, just south of Kohl's department store.</p>
<p>"As Chad McWhinney likes to say, we like to get in front of the inevitable," Hill said of the region's rental market. He added that he was "absolutely confident" that the downtown Fort Collins market would absorb another 300 residential rentals.</p>
<p>The block totals three and a half acres, part of it clipped by a Burlington Northern Santa Fe rail line, complicating the development process.</p>
<p>McWhinney has engaged Denver firm Oz Architecture, designers of the Lake Vista and Van de Water projects, to design its new Fort Collins venture.</p>
<p>Tom Hacker can be reached at 669-5050, ext. 521, or <a href="thacker@reporter-herald.com">thacker@reporter-herald.com</a>.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
