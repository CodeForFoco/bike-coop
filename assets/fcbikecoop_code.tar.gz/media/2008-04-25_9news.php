<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <a href="http://www.9news.com/news/article.aspx?storyid=90633">Original Story - 04-25-2008 - 9 News (Denver)</a>
         <h1>Take out a bike with a library card</h1>
	 <h3>Written by: <a href="mailto:mailto:adam.chodak@9news.com?subject=RE:Take out a bike with a library card">Adam Chodak</a>, 9NEWS Northern Reporter</h3>
	 <div class="contents-image"><a href="images/2008-04-25.jpg"><img src="images/2008-04-25.jpg" alt="Library Bikes In Use"></a>
	    Take out a bike with a library card. Adam Chodak reports. 9NEWS at 5 p.m. 4/25/08
	 </div>
	 <p>FORT COLLINS . Earlier this month, Fort Collins opened up a different type of library.&nbsp;Instead of handing out books, it hands out bikes.</p>
	 <p>To take out a bike, you just have to be a member - and membership is free. <p>Given the popularity of bikes in Fort Collins, the city's new bike library has proven to be an instant success.</p>
	 <p>"It's kind of like going to a convention of ice cream enthusiasts and then saying you're going to hand out free Ben and Jerry's," said Chris Pranskatis, manager of the Fort Collins Bike Library.</p>
	 <p>Within minutes of opening Friday morning, the library was out of bikes.</p>
	 <p>Pranskatis says hundreds more that have been donated are being fixed up and will bolster his fleet soon.</p>
	 <p>Funding rode in on a federal grant aimed at lowering the amount of traffic rolling through Fort Collins.</p>
	 <p>The project was created by FC Bikes, Bike Fort Collins and Fort Collins Bike Co-Op.</p>
	 <p>Outside of getting cars off the road, the library's purpose is to promote a healthy lifestyle.</p>
	 <p>"This kind of system is totally what this town is all about," said Erin Friedline, a Fort Collins resident who rented a bike with her friends Friday morning.</p>
	 <p>Like a library with books, the bike library will send out a bill to those who don't return the bikes.&nbsp; Of course, instead of $30, the bill will run about $300.</p>
	 <p>For more information go to <a href="http://www.fcbikelibrary.org" target=blank>www.fcbikelibrary.org</a>.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
