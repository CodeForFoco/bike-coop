<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.collegian.com/index.php/article/2012/04/fort_collins_bike_coop_rides_on_despite_uncertain_future">Original Story - 04-12-2012 - Collegian</a>
			<h1>Fort Collins Bike Co-op rides on despite uncertain future</h1>
			<p>By <a href="mailto:news@collegian.com">Jason Pohl</a></p>
			<div class="contents-image"><a href="images/2012-04-26_image1.jpg"><img src="images/2012-04-26_image1.jpg" alt="Girl Working on Bike"></a>
				Photo Credit: Chase Baker<br>
				Alicia Leonardi, Fort Collins resident, works on her bike at the Fort Collins Bike Co-op. With the current location of the bike co-op for sale, they are on a search for a new, permanent location. 
			</div>
			<div class="contents-image">
				<h4>About the Fort Collins Bike Co-op</h4>
				<ul>
					<li>Volunteer-operated</li>
					<li>Free tools, mechanics available for repairs</li>
					<li>Take abandoned, used bikes, refurbish and sell or donate</li>
					<li>Donates hundreds of bikes to countries in need, including Ghana</li>
					<li>For more information or to get involved, visit <a href="http://fcbikecoop.org">fcbikecoop.org</a>.</li>
				</ul>
			</div>
			<p>Nestled near an empty parking lot north of the summer crowds and busy shops of Old Town, the Fort Collins Bike Co-op awaits the onslaught of warm-weather cyclists, tourists and curious passersby -- at least for now.</p>
			<p>Currently in its 10th year serving the city with free maintenance help, bike advice and even a chance to earn a bike by volunteering, the land surrounding the co-op on North College Avenue is up for sale, prompting a scramble to find a more permanent location.</p>
			<p>"When the right buyer comes along, they are going to want to level all the buildings, and build from scratch," said John Taggart, a volunteer and vice president of the Bike Co-op's board of directors. "Moving the co-op is quite an undertaking, so we're hoping to find something more permanent."</p>
			<p>But that takes time and money, the sole source of which comes from donations and business through community awareness.</p>
			<p>Relocating a cycle shop and thousands of parts and bikes may be tough, but it's something the nonprofit and volunteer-driven organization has grown accustomed to during the years. Since its 2003 inception at a local garage, the co-op has moved almost a half-dozen times thanks to growth and a series of run-ins with tough renting situations.  It has even moved each winter to a building that had heat -- a luxury it had grown without.</p>
			<p>But constantly changing locations doesn't hinder the co-op's main goal -- to get the community riding while fostering knowledge of cycling maintenance and to put a two-wheeled-ride in the hands of everyone, including those who can't afford it.</p>
			<p>"I believe that everyone should get out and ride their bike," Taggart said. "Why commute in a car and then go to the gym when you get home? Ride a bike and save the money. There's very little road rage on the bike trail, and it's rare to ever see even the slightest frown."</p>
			<p>The Bike Co-op reaches out around the community, including cycling education events and bike giveaways. It also works with the city to ensure abandoned rides stay out of landfills and even the most damaged or forgotten bike is stripped of valuable parts before being scrapped.</p>
			<p>Perhaps the noblest program the co-op offers is Bikes for Ghana, which teams with the <a href="http://villagebicycleproject.org">Village Bicycle Project</a> and ships nearly 500 bikes each year to people who may look at the transit option as a luxury overseas.</p>
			<p>"When you have to walk five miles each day to get clean water to cook with, a bike can be life changing," Taggart said.</p>
			<p>Doug Cutter, a volunteer mechanic and president of the co-op, said he enjoys meeting the people from all walks of life during his typical Sunday shift at the shop. The true value, he said, is teaching people how to use tools themselves, rather than just having someone fix your bike like at a typical bike shop.</p>
			<p>The freedom helps, too.</p>
			<p>"I particularly like that the co-op serves the full range of the Fort Collins demographic instead of just particular segments" he said. "Many co-op customers ride because that is their only mode of transportation."</p>
			<p>Though many students questioned were unaware of the opportunity to earn a free bike and learn how to fix it or even recycle old rides for a good cause, Sarah Hylander, a senior natural resource management major said the community -- and student -- support of the program will be key in its future success.</p>
			<p>"I think the bike co-op brings publicity to the biking culture," she said, explaining how different that lifestyle is from what many experience growing up in areas across the country. Using the knowledge and tools at the Bike Co-op, she said, was really empowering and contributes to Fort Collins being a "bastion of sustainability and forward thinking."</p>
			<p>"They're putting themselves through a lot of tough times right now just to keep people biking," she said. "That's pretty honorable."</p>
			<p>Though Hylander said the nonprofit is run on "goals and ideals," she and others affiliated with the project urge people to get involved. Whether a financial contribution or simply helping out a couple hours each week, Taggart, who has volunteered since 2007, said the value and contributions of the Fort Collins Bike Co-op far exceeds a simple list of numbers or facts. </p>
			<p>Though the future and location of the program will likely change with the times, everyone involved believes in the mission of the Fort Collins Bike co-op and the future of cycling in the city.</p>
			<p>To get involved or to learn more, visit <a href="http://fcbikecoop.org">http://fcbikecoop.org</a>.</p>
 			<p>"It's a constant battle, but to ensure that each of our customers gets our full attention, we strive to not spread our volunteers too thin," Taggart said. "I'm normally very introverted, but my involvement with the co-op has introduced me to hundreds of new people."
			<p>"It's a wonderful family," he added. "I met my fianc�e at the co-op. What more could I ask for?"</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
