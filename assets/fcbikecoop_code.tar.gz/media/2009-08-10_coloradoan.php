<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.coloradoan.com/article/20090810/NEWS01/908100317/1002/CUSTOMERSERVICE02">Original Story - 08-10-2009 - Coloradoan</a>
			<h1>Bicyclists learn rules of the road</h1>
			<p>By <a href="mailto:NateTaylor@coloradoan.com">Nate Taylor</a></p>
			<div class="contents-image"><a href="http://fcbikecoop.org/media/images/2009-08-10_intersection.jpeg"><img src="http://fcbikecoop.org/media/images/2009-08-10_intersection.jpeg" alt="Cyclists riding through an intersection"></a>
			Cyclists taking part in bike instructor certification instruction from the League of American Bicyclists make a left-hand turn onto College Avenue from Mulberry Street on Sunday. (Michael G. Seamans/The Coloradoan)
			</div>
			<div class="contents-image"><a href="http://fcbikecoop.org/media/images/2009-08-10_parked.jpeg"><img src="http://fcbikecoop.org/media/images/2009-08-10_parked.jpeg" alt="Cyclists waiting at an intersection"></a>
			Cyclists wait at the traffic light at the intersection of Mulberry Street and College Avenue. (Michael G. Seamans/The Coloradoan)
			</div>
			<p>The number of League of American Bicyclists trained instructors in Fort Collins is likely to more than double after a handful of residents participated in a weekend training to become certified to become certified to teach the community how to ride safely in traffic.</p>
			<p>The three-day session began Friday, and assuming the six Fort Collins participants pass tests, the city will have 10 certified instructors to teach cyclists proper behaviors in traffic.</p>
			<p>"Cyclists fare best when they behave and are treated as if they are motor vehicles, and that's what we're here to teach and pass on to the community," said Rick Price, a board member with the Bicycle Cooperative of Fort Collins and one of four in the city currently certified as a league cycling instructor.</p>
			<p>Members from different cycling organizations through-out the city were among those attempting to earn the certification, but there were also cyclists from Longmont and even Montana. The course incorporates classroom learning and hands-on experience with cone courses and road cycling experiences.</p>
			<p>Preston Tyree, who taught the weekend course, said the value of the instruction is exponential when instructors can start to influence younger generations' cycling behaviors.</p>
			<p>"We all learn to ride as kids, and everyone thinks about riding in that same way," said Tyree, the league's director of education from Austin, Texas. "But when we go out and see you hugging the curb, I'll tell you we need to talk about safety."</p>
			<p>The bike co-op is targeting younger riders after receiving a grant from REI to instruct children ages 10 to 14 for the next few years. Price said the goal is to reach 5 percent of the students in Poudre School District each year with the grant money.</p>
			<p>"It's a good place to start," Price said, adding he'd like to be able to offer the training to businesses and most of all to the thousands of  Colorado State University freshmen who are new to Fort Collins.</p>
			<p>"That's probably the biggest demographic we need to educate," he said. "We have very limited educational outreach in this community, and that's where the bike co-op wants to make a difference."</p>
			<p>As a teacher in Poudre School District and a member of the Fort Collins Cycling Club, Karen Koski said she was attempting to become an instructor because she values her personal safety on the road and wants to be able to better teach her students safety when she takes them on an annual 12-mile bike ride.</p>
			<p>"It's very practical, and I know I'll be able to use all this information," Koski.</p>
			<p>Koski and other members of the cycling club have plans to also get involved with the safe routes to school program.</p>
			<p>"I think we can make a huge influence," she said. "To me, though, it's not only important to target kids, but we also need to target kids and their parents who can help reinforce the lessons."</p>
			<p>Reaching adults is one of the biggest challenges, Tyree said. It's very common for cyclists to have the impression that if they ride frequently, they don't need to take a class about safety.</p>
			<p>John Taggart, a co-op board member and participant in the training, said there probably isn't a cyclist on the road who wouldn't learn something valuable from the course.</p>
			<p>"It's valuable because people want to learn in a safe environment like this."</p>

<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
