<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="">Original Story - 11-06-2011 - 9news.com</a>
			<h1>Time change creates hazards for commuters</h1>
			<p>By <a href="mailto:lauren.lang@9news.com">Lauren Lang</a></p>
			<p>FORT COLLINS - Switching the clocks back from Daylight Saving Time to Standard Time in the fall requires an adjustment for everyone, including motorists, who have to get used to driving home when it's darker.</p>
<p>However, the change can prove dangerous for commuters.
According to the Fort Collins Bike Co-op, the earlier sunset typically causes an increase in vehicle-versus-cyclist and pedestrian accidents for the first few weeks after the time change in the fall.</p>
<p>In order to avoid accidents, the co-op encourages bikers and motorists to avoid distractions while driving and obey all traffic laws, including having visible reflectors or lights on the front, back and side of their bicycles.</p>
<p>However, according to Rick Price, the Safe Cycling Coordinator at the Fort Collins Bike Co-op, there are additional steps cyclists can take to increase their visibility as motorists adjust to the time change.</p>
<p>"If your bike doesn't have pedal reflectors, go to the bike co-op or go to the bike store and get pedal reflectors on them because that's one of the most visible things on the bike," Price told 9NEWS. "As those pedals are going up and down a car behind you will see them immediately. They're tiny, but they're highly visible."</p>
<p>Price also says retro reflective bicycle tires and brightly colored clothing such as yellow jackets or vests with retro reflective tape will also help make cyclists more visible.</p>
<p>However drivers that would like an additional reminder to pay extra attention to cyclists can get it for free in the form the co-op's "Watch for Bikes" sticker. The sticker is intended to be placed on the rear or side view mirror or on the windshield of a vehicle to remind drivers that cyclists can be more difficult to see this time of year.</p>
<p>The co-op began giving the stickers away in February 2010 and has since handed out over 9,000 of them.</p>
<p>Anyone who would like to receive a sticker can request one through the Co-op's website at <a href="http://fcbikecoop.org/">http://fcbikecoop.org/</a>.</p>
<p>(KUSA-TV � 2011 Multimedia Holdings Corporation) </p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
