<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <a href="http://www.coloradoan.com/article/20081208/OPINION01/812080304/1014/OPINION">Original Story - 12-08-2008 - Coloradoan</a>
         <h1>Bike Co-op gift will go a long way</h1>
	 <h3>$10,000 anonymous donation lifts nonprofit</h3>
	 <p>Some don't have to wait for the holidays to find a gift.</p>
	 <p>Such is the case with the Fort Collins Bike Co-op, which last week received $10,000 from an anonymous donor. Putting the donation in perspective, the contribution is about double what the nonprofit organization receives in a single year.</p>
	 <p>The Bike Co-op is indeed a treasure in a community filled with effective and generous nonprofits. The organization, which works with an advocacy group called Bike Fort Collins and the city's FC Bikes program, was created to help return lost, abandoned or stolen bicycles to their owners by using a database.</p>
	 <p>Police retain the stolen and abandoned bikes for six weeks. If an owner doesn't surface, Bike Co-op volunteers refurbish the unclaimed bikes and give them to those who can't afford them through nonprofits or its Earn-A-Bike Program. That program is a pay-it-forward process that requires bike recipients to volunteer for the co-op or other nonprofit in exchange for their new ride. The co-op also accepts bike donations and works diligently to recycle bike parts.</p>
	 <p>Co-op officials say the $10,000 will be used to rent heated space for bike repairs and to offer locks and lights to go along with the donated bikes.</p>
	 <p>Both the donation and the pay-it-forward nature of the Bike Co-op program are reminders of the importance of giving and gratitude this holiday season.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
