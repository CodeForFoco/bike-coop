<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <p><a href="http://www.coloradoan.com/apps/pbcs.dll/article?AID=/20080630/NEWS01/806300327/1002/CUSTOMERSERVICE02">Original Story - 06-30-2008 - Coloradoan</a></p>
         <p><a href="http://www.denverpost.com/news/ci_9860242">Original Story - 07-08-2008 - Denver Post</a></p>
         <p><a href="http://www.examiner.com/a-1484350~Free_bike_library_service_booming_in_Fort_Collins.html">Original Story - 07-08-2008 - Examiner.com</a></p>
         <p><a href="http://www.thedenverchannel.com/news/16870614/detail.html?rss=den&psp=news#">Original Story - 07-12-2008 - thedenverchannel.com</a></p>
         <p><a href="http://cbs4denver.com/consumer/Bike.Library.booming.2.771885.html">Original Story - 07-15-2008 - CBS 4 Denver</a></p>
         <h1>Free bike library service booming in Fort Collins</h1>
	 By <a href="mailto:TrevorHughes@coloradoan.com">TREVOR HUGHES</a>
	 <div class="contents-image"><a href="images/2008-07-12.jpg"><img src="images/2008-07-12.jpg" alt="Bicycle"></a></div>
	 The Fort Collins Bike Library plans to quadruple the number of bikes available to loan by next spring after finding itself dramatically and happily oversubscribed.</p>
	 <p>The library permits anyone with an ID and an e-mail address to borrow a bike for a week at a time. The library started with 50 bright red bikes this spring, officials said.</p>
	 <p>"We are a victim of our own success," Jeff Morrell, president of Bike Fort Collins. "There's a waiting list every week."</p>
	 <p>That's sort of an understatement: The manager of the Old Town Square branch said people have actually darted away from half-eaten meals in the plaza to snag a newly returned bike. Another woman was so reluctant to return it that the police were nearly called, he said.</p>
	 <p>"The demand for bikes in this community is more than we can fulfill," said library manager Chris Pranskatis. "Any problems we've had stem from the fact that people are desperate for bicycles."</p>
	 <p>Morrell said the library is considering changing its policies to require a credit card imprint, just to ensure all the bikes are returned.</p>
	 <p>Homeless men and women are regularly using the service, and organizers say they need to balance making bikes available to them with the need to ensure the bikes make it back at the end of the week-long rental period.</p>
	 <p>Morrell said bike library workers are having to "pester" some library users to return their bikes. Pranskatis said it's actually gone as far as having library volunteers track down the homeless men and women who haven't returned the bikes as promised so they can take the bikes back.</p>
	 <p>On the wall of the Old Town Square library location, a "Hall of Shame" lists the names of 10 people who are no longer allowed to borrow bikes.</p>
	 <p>But on the flip side, Pranskatis said, one formerly homeless man borrowed a bike and used it to ride to job interviews. He returned the loaner bike recently, proud of his new job and his own bike.</p>
	 <p>On a recent Friday afternoon, new Fort Collins residents Michael Roberts and Kayla McMahon stopped to borrow a pair of bikes. The two were moving from upstate New York to Denver but fell in love with the Choice City on a chance stop a few days before.</p>
	 <p>"It's perfect. And we're stoked about the bikes," Roberts said. "We're going to ride them and learn the city."</p>
	 <p>Since the library opened April 5, more than 500 people have borrowed bikes, Morrell said.</p>
	 <p>The bikes come from abandoned or unclaimed stolen bikes collected by Fort Collins police; they are stripped down and rebuilt before being loaned out.</p>
	 <p>The library also takes donations of used bikes from the public but right now is struggling to find enough volunteers to help strip them down and rebuild them into the single-speed models typically loaned out.</p>
	 <p>Morrell said the library is working with hotels to provide them bikes to loan to guests.</p>
	 <p>That's the kind of thinking that Dave "DK" Kemp, the city's bike coordinator, hopes will keep flourishing.</p>
	 <p>"A lot of people have friends who come into town on vacation and they can't bring their bikes," he said.</p>
	 <p>The University of Colorado at Boulder announced recently it is considering issuing bikes to freshmen in an effort to reduce the number of cars on campus.</p>
	 <p>Cody Gieselman, a coordinator with the Bike Library in Iowa City, said college students are some of that library's biggest users. The Iowa City library permits people to take bikes for up to six months after leaving a deposit. If they keep the bike longer, the library keeps the deposit.</p>
	 <p>Gieselman said her library, which opened in 2004, shares the same problem as Fort Collins: "We can't keep up supply with demand."</p>
	 <p>She said dedicated volunteers are critical to keeping the library running. The Iowa City library has loaned out more than 600 bikes since it opened, she said.</p>
	 <p>Fort Collins' library started with 50 bikes and expects to have 100 by the end of the summer and 200 by next spring.</p>
	 <p>The bike library is a free service paid for with a federal clean-air grant funneled through the city, in partnership with Bike Fort Collins and the Fort Collins Bike Co-Op.</p>
	</span>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
