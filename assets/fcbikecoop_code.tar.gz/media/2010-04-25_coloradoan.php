<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.coloradoan.com/article/20100425/NEWS01/4250318/Co-op-donates-bicycles-to-60-Putnam-School-of-Science-kids">Original Story - 04-25-2010 - Coloradoan</a>
			<h1>Co-op donates bicycles to 60 Putnam School of Science kids</h1>
			<p>By <a href="mailto:MarcyMiranda@coloradoan.com">Marcy Miranda</a></p>
			<div class="contents-image"><a href="http://fcbikecoop.org/media/images/2010-04-25_heistermann.jpg"><img src="http://fcbikecoop.org/media/images/2010-04-25_heistermann.jpg" alt="Bill Heistermann"></a>
				Bill Heistermann fits 6-year-old Arissa Frikken for a bike helmet as the Putnam School of Science student waited to receive her free bicycle Saturday at the Fort Collins Bike Co-op. (V. Richard Haro Rich Abrahamson Dawn Madura/The Co)
			</div>
			<p>For 7-year-old Anthony Fernandez, Saturday was a day to remember.</p>
			<p>The first-grader at Putnam School of Science received his first bicycle Saturday afternoon, a cherry red model with two training wheels, courtesy of the Fort Collins Bike Co-op.</p>
			<p>Anthony was one of 60 students from Putnam who received a free bike and helmet for winning a contest held by the school, said Kristen Dart-Gmeiner, a third-grade teacher at the school.</p>
			<p>Anthony's mother, Angelica Cid, said Anthony was counting down the hours until he could go to the co-op and pick up his bicycle.</p>
			<p>"He said, 'we can't be late,' " with urgency, she said in Spanish.</p>
			<p>Immediately after seeing his new bicycle, Anthony got to work on learning how to ride it, practicing in the parking lot outside the co-op.</p>
			<p>Also riding outside was 9-year-old Krista Grossmann, who received a pink bicycle with gears and handle brakes.</p>
			<p>Grossman, a fourth-grader, wrote a winning essay about what she would do with a bicycle, although the excitement of winning made her forget the content of her essay.</p>
			<p>"I was really, really excited to win," Krista said.</p>
			<p>Dart-Gmeiner approached the co-op several weeks ago and asked to see if they would be interested in donating bikes to Putnam students, 80 percent of who qualify for free and reduced lunch.</p>
			<p>"For a lot of our kids, a bike is a real expense," she said.</p>
			<p>Students who entered the contest either drew a picture or wrote an essay about what they would do with a bicycle, depending on their grade, Dart-Gmeiner said.</p>
			<p>Volunteers with the co-op visited the winning students at school to measure them and fix a bicycle that would suit them, said Rick Price, safe cycling coordinator for the co-op. </p>
			<p>The bikes given to kids were first donated to the co-op and were repaired before going out again, he said.</p>
			<p>In the next few weeks, the co-op will host bicycle safety classes and bike rodeos at Putnam and Laurel School of Arts and Technology. Students will learn the rules for safely riding on the street.</p>
			<p>Other cycling organizations in town, including the city's Safe Routes to School program, have also hosted rodeos throughout theyear.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
