<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="">Original Story - 01-01-2008 - Source</a>
			<h1>Title</h1>
			<h3>subtitle</h3>
			<p>By <a href="mailto:writer">writer</a></p>
			<div class="contents-image"><a href=""><img src="" alt=""></a>
				imagetext
			</div>
			<p>Story</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
