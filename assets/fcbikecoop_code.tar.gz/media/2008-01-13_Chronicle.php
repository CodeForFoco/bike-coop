<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <a href="http://www.rmchronicle.com/index.php?option=com_content&amp;task=view&amp;id=1844&amp;Itemid=61">Original Story - 01-13-2008 - Rocky Mountain Chronicle</a>
         <p>COMMUNICATION TOOLS</p>
	  <p>By MARISSA GAVEL</p>
	  <p>Fort Collins' bike co-op tries to make good with miffed bike-shop owners.</p>
	  <div class="contents-image"><a href="images/2008-01-13/raf.jpg"><img src="images/2008-01-13/raf.jpg" alt="Rafael"></a>
	  </div>
	   <p>Rafael Cletero spends so much time at the Bean Cycle that he doesn't even glance at the surroundings when he walks into the downtown Fort Collins coffeehouse. The visionary behind the Fort Collins Bike Co-Op, formerly known as Bike Against, passes a homemade poster for Dave's Bike Shop --"Get your bike fixed right"-- hanging on the wall, as he makes his way to the counter, where a Bike Against sticker clings to the cash register. Cletero orders a "hippie" drink -- code for "made with soy milk" -- and trades his fluorescent yellow vest for an equally loud orange sweater before cleaning his glasses, thick lenses attached to what appear to be cracked and glued Oakley-style frames.</p>
	   <p>While he says he's much more comfortable with a greasy chain in his hand than being in the spotlight, Cletero has been in the midst of a local bike-community controversy over the city- and nonprofit-funded plan to rescue, fix up and rent out bicycles.</p>
	   <p>Since signing a lease on the building that used to house the Poudre Valley Creamery, at 222 Laporte Avenue, the Fort Collins Bike Co-op and Bike Library have been operating out of prime downtown real estate and are in the final stages of becoming business-ready. (For more on the origins of the co-op, read "Life in the Bike Lane," from the June 21, 2007 issue, online at rmchronicle.com.)</p>
	   <p>But not all of the city's private bike-shop owners are impressed, namely Spring Creek Recumbent Bicycles and Recycled Cycles.</p>
	   <p>"They're doing free rentals. Well, isn't that nice," Rob Walton, owner of Spring Creek Recumbent, says sarcastically. "What about my rental business? I think it's something that if I were coming from a more Machiavellian perspective, I'd say, "Yea, co-op!"</p>
	    <p>While Recycled Cycles owner Dave Hudson is admittedly skeptical about the co-op's anticipated expansion, his primary issue lies with their potential use of the term "recycled," since the majority, if not all, of the co-op's bikes will be fixer-uppers.</p>
	    <p>"Honestly, I'll say it's inevitable," Hudson says. "There's no sense in fighting the inevitability, but there's going to be an uncomfortable discussion about the name 'recycled.' That's my only current beef."</p>
	    <p>But Will Overbagh, co-owner of Road 34, in the Campus West area, is on board.</p>
	    <p>From the start, we've been for that whole setup," he says. "Anybody who bitches about the co-op in the bike business is in the business for the wrong reason."</p>
	    <p>In an effort to ease worries about business matters and customer allegiance, the co-op and Bike Fort Collins, a local nonprofit that helps maintain the Bike Library, formed BRAG, or the bicycle retailers advisory group.</p>
	    <p>The first meeting was held in August of last year, when several local bike-shop owners were told the co-op would serve only as an additional tool for cyclists -- nothing more, nothing less.</p>
	    <p>All but Walton attended and asked questions, Cletero says.</p>
	    <p>"I feel like you're demonized if you're not on board," Walton says. "Maybe I should have gone to some more of those meetings, but I thought it was a waste of time. It seems like a lost cause, and I'm sick of arguing."</p>
	    <p>Walton, who is adamant about being portrayed as a concerned small-business owner -- not, he says, the anti-co-op rightwinger some have called him -- compares his shop to local breweries.</p>
	    <p>"If this was something else, like free beer, New Belgium wouldn't like anybody handing out free gourmet beer," he says.</p>
	    <p>As an outcome of the first meeting of BRAG, the co-op is currently running what it hopes will become an annual tool drive that includes seven local bike shops, which were chosen to participate based on previous ties to and support for the co-op.</p>
	    <p>"Our goal is to engage all of the bike shops in town for events," Cletero says. "We want to rotate them, so we can get shops to scratch each other's backs."</p>
	    <p>Each shop is given a wish list of tools needed to fully equip the co-op's workstations. Patrons can purchase anything from the list to be given to the co-op after the January 20 deadline. Any equipment that is not donated will be purchased by the co-op from only those seven stores, using money generated from donation jars around town.</p>
	    <p>Walton is not participating in the drive, but, he says, "I think it's an improvement. But it kind of seems like a bribe to me."</p>
	    <p>Hudson, of Recycled Cycles, however, is game.</p>
	    <p>"We are in the process of remodeling, so we will have a box of tools for the guys here," he says.</p>
	    <p>If all goes as planned, Cletero says, the co-op will be fully operational by mid-spring.</p>
	    <hr>
	      THE FULL WHEEL DEAL
	      <p>Biking FoCo, by the numbers</p>
	      <p>BY VANESSA MARTINEZ</p>
	      <p>500-600: Number of bikes Fort Collins Police Services used to ship to California each year for auction. FCPD now donates the wheels to the Fort Collins Bike Library.</p>
	      <p>3,600: Approximate number of bicyclists participating in New Belgium Brewing's 2007 Tour de Fat in Fort Collins. The microbrewery attempted a Guinness World Record for longest bike parade but recently received word that it "has been momentarily denied due to a technicality. Upon review of our videotaped (and time-coded) submission, Guinness officials concluded that there were too many gaps in rider flow across the finish line (most likely the result of traffic lights) to qualify as a continuous parade," according to a New Belgium release. (For more on their effort, read "Almost Famous," from the December 6, 2007 issue, online at rmchronicle.com.)</p>
	      <p>2008-2009: Years the USA Cycling Collegiate Road National Championships will be held in Fort Collins, between May 9 and 11 each year.</p>
	      <p>May 25: Date of a confrontation between probike, anticar Critical Mass cyclists and Fort Collins police, leaving at least a few cyclists claiming that an officer had used unnecessary force. Another officer claimed to have seen the aggressive cop threaten a woman with pepper spray and push a man onto his bike by striking him in the "jugular notch." One cyclist was arrested for an outstanding warrant.</p>
	      <p>7: Number of area bike shops participating in the Fort Collins Bike Co-op's Tool Drive, which ends on January 20. (Read the above article for more information.) </p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
