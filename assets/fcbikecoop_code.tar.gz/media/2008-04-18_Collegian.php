<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <a href="http://media.www.collegian.com/media/storage/paper864/news/2008/04/18/News/Fort-Collins.Bike.Library.Promotes.Riding.Bikes.To.Campus-3331678.shtml">Original Story - 04-18-2008 - The Rocky Mountain Collegian</a>
         <h1>Fort Collins Bike library promotes riding bikes to campus</h1>
	 By Heidi Reitmeier
	 <p>CSU students and Fort Collins citizens have a new alternative to driving this week with the opening of a downtown bike library.<br><br>
	 The Fort Collins Bike Library will offer riders the chance to rent bikes free of charge.<br><br>
	 Currently, 50 bikes are available to rent, and the library plans to have 220 bikes by the end of next year. Bikes that can be rented vary from mountain bikes to road bikes and range from kid to adult-sized. Trailers for kids or cargo can also be rented.<br><br>
	 Renters need to have a valid ID to rent a bike, and bikes can be rented for a week at a time with an hour being the smallest amount of time allotted for renting.<br><br>
	 In early efforts to make itself known among students, the library recently teamed with CSU RamWheels to host the first annual CSU Bike to Campus Day today on the LSC plaza from 12 p.m. to 3 p.m. Fort Collins Bike, Bike for Fort Collins, Fort Collins Bike Co-op and New World Sports will sponsor the event.<br><br>
	 Dave Kemp, the City of Fort Collins bike coordinator, hopes the event will help students gain knowledge about bicycling.<br><br>
	 "We will provide information about how students can start biking and about the local bike advocacy, RamWheels," Kemp said. <br><br>
	 Along with providing resources for students, the FC Bike Library will dare students to take the "Two-mile Challenge." The challenge urges students to ride a bike, instead of driving a car, for all trips that are less than two miles away from where they live.<br><br>
	 The library also offers self-guided tours free of charge.  Tours include brewery tours, historic tours and an environmental tour on the Cache La Poudre River Bike Trail.<br><br>
	 CSU RamWheels inspired the idea for the FC Bike Library.<br><br>
	 "We wanted to extend the program to a city level," Kemp said. "We are working to partner with RamWheels to incorporate more bikes into the program."<br><br>
	 Nick D'Innocenzo, student coordinator for RamWheels, is excited about the partnership with the FC Bike Library.<br><br>
	 "It's good for students because it provides more bikes on campus," D'Innocenzo said.<br><br>
	 Currently, RamWheels offers 12 bikes for CSU students to rent free of charge. The bikes can be rented out at the Information Desk in the LSC.<br><br>
	 The FC Bike Library opened on April 5 and has two locations: Caf&eacute; Bicyclette located in Old Town Square, and Fort Collins Co-op, located at 222 Laporte Ave.<br><br>
	 The library is opened Friday, Saturday and Sunday from 10 a.m. to 6 p.m. and has rented 63 bikes to 100 customers since opening.<br><br>
	 "The library has jumped to success," Kemp said. "We had 40 bikes rented on opening weekend alone."<br><br>
	 More information about the FC Bike Library can be found at <a href="http://www.fcbikelibrary.org">www.fcbikelibrary.org</a> or by calling (970) 491-1050.<br><br>
	 Staff writer Heidi Reitmeier can be reached at <a href="mailto:news@collegian.com">news@collegian.com</a>.<br>
	 
	 			</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
