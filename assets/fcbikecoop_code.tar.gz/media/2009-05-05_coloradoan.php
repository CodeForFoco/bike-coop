<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.coloradoan.com/apps/pbcs.dll/article?AID=2009905050305">Original Story - 05-05-2009 - Coloradoan</a>
			<h1>Time to nurture our bicycle culture</h1>
			<p>By <a href="mailto:rick@experienceplus.com">Rick Price</a></p>
			<p>Richard Florida observed in the March Atlantic Monthly that recovering from our economic woes 'will require a new kind of geography .... a new spatial fix for the next chapter of American economic history"</p>
			<p>Indeed, for a century now, we've nurtured a car culture. From Henry Ford's assembly line, to the birth and growth of suburbia after World War II, to Dwight Eisenhower's interstate highway system (he really never intended for it to give us Centerra) and on to rampant suburban growth from 1960 until last November, our love affair with the automobile seemed to thrive on its own.</p>
			<p>Florida is right that we need a "new kind of geography." Those of you who have lived in Fort Collins for long might already feel that you've even helped to create one. If you push the walk button more than you push the button on the automatic garage door opener, you probably have. And if you are one of the 7,200 cyclists who, on average, ride their bike to work, school or to shop every day, you are, indeed, creating the new geography.</p>
			<p>How can we further nurture this new geography? Well, you could ride your bike more. But there's more to building a bike culture than just riding your bike. In fact, you don't need to be a bike geek to be a part of Fort Collins' bike culture. You don't need to be a mechanic to know the difference between a fixie and a single speed. You just need to become involved with the Bike Co-op. But before I tell you about the opportunities there, I suggest you ponder the following numbers.</p>
			<p>Until 2008 abandoned and recovered bicycles in the city were retrieved by police officers using police cruisers to pick up abandoned bikes. Bicycles were stored for a required impound period and then shipped to auction in California. In 2006, the last year for which complete records are available, the bikes sold at auction brought $3,367 to city coffers. The Bike Co-op, by contract with the city, now physically picks up these bikes, refurbishes them and keeps them in the community.</p>
			<p>In 2008, the co-op donated 50 bikes to children at the Salud Family Clinic for a value of $2,000. It released 89 bikes to disadvantaged citizens for a value of approximately $13,350, and it donated ten bikes for non-profit auctions or door prizes for a value of $3,000. The total value of bikes returned to the community by the co-op in 2008 was $18,350. We expect to double these numbers in 2009.</p>
			<p>To do that, though, we need your help. Maybe you could help us write a business plan, a fundraising plan or develop and deliver a bike-safety curriculum for public schools in the Fort? Or perhaps you could simply give us 90 minutes of your time this Friday through Sunday at the National Collegiate Road Cycling championships right here in Fort Collins. The co-op has committed to finding 100 volunteers especially for Friday, or fewer on Saturday, beginning at 7:30 a.m. each day.</p>
			<p>Visit the Bike Co-op Web site for more information on how you might volunteer to build the culture: www.FCBike Coop.org, or write to Rick@Experience Plus.com if you can help Friday or Saturday.</p>
<p>Rick Price, a geographer, lives in Fort Collins and is a member of the board of the Bike Co-op.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
