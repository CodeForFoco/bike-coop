<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.collegian.com/2015/01/the-fort-collins-bike-co-op-offers-a-variety-of-programs/109652/">Original Story - 01-29-2015 - Collegian Central</a>
			<h1>The Fort Collins Bike Co-Op offers a accumulation of programs</h1>
			<p>By <a href="mailto:entertainment@collegian.com">A&E Writer Caitlyn Berman</a></p>
			<div class="contents-image"><a href="images/2015-01-29_shop_image.jpg"><img src="images/2015-01-29_shop_image.jpg" alt=""></a>
				Photo credit: Caitlyn Berman
			</div>
			<p>The Fort Collins Bike Co-Op, initially started in a neighborhood garage, has blossomed into a community-centered, non-profit organization tailoring their actions to the well-being of the community.</p>
			<p>In addition to their regularly-scheduled open shop bicycle repair hours, during which time volunteer mechanics teach customers how to fix their own bikes for $10 an hour, the Co-Op hosts Women's Wrenching Nights, mechanics classes and the 'Earn-a-Bike' program.</p>
			<p>The 'Earn-a-Bike' program offers those who are in need of a bicycle the chance to obtain one by volunteering 20 hours of work at another local non-profit organization.</p>
			<p>"'Earn-a-Bike' is our longest-running program, and is typically targeted at people who otherwise can't afford a bike," said Justin Mohar, Fort Collins Bike Co-Op manager and Colorado State masters graduate. "Anyone can participate, but our goal is to help people who really need it."</p>
			<p>The Bike Co-Op provides 15 applications per month for this program, and works with applicants to facilitate the process.</p>
			<p>"If we get a reference letter from some sort of social service agency explaining someone's circumstances, we can cut the number of required volunteer hours down to 10 instead of 20," Mohar said. "We like to work with people."</p>
			<p>Other community inspired functions held at the Bike Co-Op are Women's Wrenching Nights, which are bike workshops lead by skilled women volunteers.</p>
			<p>"Women's Wrenching Nights usually start with lecture based on some kind of system like bike fit or brakes, and then we break off into smaller groups and go over the specifics of each person's bike," said Dondi Barrowclough, Fort Collins Bike Co-Op representative.</p>
			<p>Following the lecture, participants have time to work shop.</p>
			<p>"We'll then usually end with an open shop component where women can work on their own bikes," Barrowclough said. "We like to encourage all women and LGBTQ members to join in for a fun, free night."</p>
			<p>This 2-year-old program was "designed specifically to get more women interested in their bikes in a comfortable environment with other women," Mohar said.</p>
			<p>There is no set date as to when the next wrenching night will be, as the Bike Co-Op will be moving from its current location at 331 N College Ave. to its newly purchased building located at 1501 N College Ave. around spring of 2015.</p>
			<p>Another class offered at the Bike Co-Op similar in structure to Women's Wrenching Nights is the mechanic class series, starting Feb. 19.</p>
			<p>"The mechanics classes are beginner classes open to anyone who wants to learn more about their bike," Mohar said.</p>
			<p>For a $50 donation, participants get six classes, one per week over the span of six consecutive weeks. The goal of these workshops is to equip each participant with the basic ability to identify issues with their bikes and the knowledge to provide solutions, according to Mohar.</p>
			<p>"I've taken the workshop and it's really awesome," Barrowclough said. "You learn different types of braking systems, how to work on wheels ... it's really great."</p>
			<p>Overall, the Fort Collins Bike Co-Op is an organization focused on the engagement and education of community members through bikes.</p>
			<p>"I think our mission statement sums it up best," Barrowclough said. "We're "building community through bicycles," so anyone who comes in and needs help leaves having received what they needed."</p>
			<p>Collegian AE Writer Caitlyn Berman can be reached at <a href="mailto:entertainment@collegian.com">entertainment@collegian.com</a> or on Twitter <a href="https://twitter.com/CaitlynBerman">@CaitlynBerman</a></p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
