<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.collegian.com/index.php/article/2010/09/090910_main">Original Story - 09-09-2010 - Verve</a>
			<h1>Creating a cycling culture: Old Town crew gives back to FoCo, Ghana</h1>
			<p>By <a href="mailto:verve@collegian.com">David Martinez</a></p>
			<div class="contents-image"><a href="http://fcbikecoop.org/media/images/2010-09-09_cover.jpg"><img src="http://fcbikecoop.org/media/images/2010-09-09_cover.jpg" alt="Verve Cover Image"></a>
				Cover designed by Katie Dalsimer | Collegian
			</div>
			<p>Just a brief jaunt from Old Town Fort Collins lays an unassuming shack on a patch of worn, crumbly asphalt.</p>
			<p>In front, a small, quaint sign that reads "Bike Co-op" dangles gingerly, looking sorely out of place.</p>
			<p>You wouldn't know it, but through the front doors a handful of volunteers sit and wait for local riders to take away an endless menagerie of used bikes and parts.</p>
			<p>The Fort Collins Co-op, a non-profit organization, currently houses between 800 and 900 bikes of every shape, model and price level, almost all of which are organized haphazardly in a giant warehouse.</p>
			<p>Despite the shoddy appearances, those at the Co-op believe they are providing Fort Collins with invaluable services: affordable bikes for students and low-income residents, bike repair education and bike safety education.</p>
			<h2>Will work for bikes</h2>
			<p>Rick Price, the Co-op's Safe Cycling Coordinator, said their used bikes usually sell from anywhere between $25 to $150 depending on the quality, but a higher-end bike in good condition can cost up to $600. And while many of the bikes are in less-than-pristine condition, the Co-op helps people repair their new bikes through their open shop on Wednesdays and Fridays.</p>
			<p>During those sessions, from 2 to 5 p.m., volunteers work with people for a complete diagnosis on their bike's problems and go over quick-fix details to help people repair their own bikes.</p>
			<p>People do have to pay for their own parts, but prices rarely exceed $15. According to Price, there's also an option to trade volunteer work for parts.</p>
			<p>For Mike Cullerton, a software engineer who volunteers on open shop days, the line of people who need bike help is "non-stop."</p>
			<p>Cullerton's boss, a cyclist himself, gave him time off to work the open shop Wednesdays and Fridays when Cullerton learned the Co-op needed volunteers. He said his job is to answer questions and teach people how to take care of their bikes. And while he said the work is sometimes difficult, it is was altogether rewarding.</p>
			<p>"Bikes are in my blood," he said. "I love doing this."</p>
			<h2>Cycles for Ghana</h2>
			<div class="contents-image"><a href="http://fcbikecoop.org/media/images/2010-09-09_image1.jpg"><img src="http://fcbikecoop.org/media/images/2010-09-09_image1.jpg" alt="Alicia Leonardi"></a>
				Chase Baker | Collegian<br>
				Alicia Leonardi, Fort Collins resident, works on her bike at the Fort Collins Bike Co-op. If your bike needs repaired, the Bike Co-op will help you fix it for only five dollars an hour. 
			</div>
			<p>In the warehouse, at least 400 of the 800 to 900 bikes lay in a mountainous heap. Out of the pile, it's seemingly impossible to distinguish one bike out of the cluster of wheels and handlebars.</p>
			<p>But this Saturday, nearly a dozen volunteers will load those bikes into a giant crate and ship them to Ghana, Africa where they will be auctioned off eight to 12 bikes at a time.</p>
			<p>Shops in Ghana will then fix the bikes and sell them cheaply to their residents.</p>
			<p>Price said with about 10 new bikes coming into the Co-op daily, it was easy to fill a crate, which will go toward the Village Bicycle Project, a nationwide project to provide Africans with a cheap means of transportation. Plus, the Co-op doesn.t have enough volunteers to turn all of its bikes around and put them back on the streets of Fort Collins.</p>
			<p>"The flow is endless," Price said. "Bikes just walk in the door."</p>
			<p>The donation on Saturday will be the second one in as many years. In May 2009 the Co-op shipped close to 450 bikes.</p>
			<h2>The good, the bad and the ugly</h2>
			<p>For Darryl Sanders, the Co-op has provided a small bright spot in his time in Fort Collins.</p>
			<p>A chef who has worked in Washington D.C. and Jackson Hole, Wyo., Sanders has had his first bike stolen and his second bike, which he bought at the Co-op, vandalized. He's gone back to the Co-op to find new wheels, as his had been bent past the point of repair.</p>
			<p>"I'm from D.C. I've never been jacked before," Sanders said.</p>
			<p>His bike was vandalized while he was in Old Town one night. Which he had to walk it back to his house.</p>
			<p>And judging from the state of some of the bikes donated to the Co-op, Sanders isn't alone.</p>
			<p>In the corner of the warehouse lays a 7-by-10-foot steel garbage bin filled with spare bike parts donated to the Co-op that are too broken or disfigured to fix -- a cornucopia of bent bicycle handlebars, stripped wheels and a cluster of five bike frames that had been solderized together.</p>
			<p>Filled to the brim, the Co-op emptied the bin only four months earlier.</p>
			<p>Price said the volunteers do what they can to fix the donations they receive, but many end up requiring too much labor to repair.</p>
			<p>"We've got more drama with bikes than cars here," Sanders said.</p>
			<h2>Helping the community</h2>
			<div class="contents-image"><a href="http://fcbikecoop.org/media/images/2010-09-09_image2.jpg"><img src="http://fcbikecoop.org/media/images/2010-09-09_image2.jpg" alt="Alicia Leonardi and Claire Mechtly"></a>
				Chase Baker | Collegian<br>
				Alicia Leonardi, left, and Claire Mechtly, senior landscape architecture major, work together on repairing Leonardi.s bicycle. Mechtly is one of several workers at the Fort Collins Bike Co-op who lend their time toward helping individuals fix their bikes for a cheap price. 
			</div>
			<p>But while the Co-op gets nearly more bikes than they can handle, they go to great lengths to help their community in other ways.</p>
			<p>Fort Collins Police Services has teamed up with the Co-op to deliver bikes that police have recovered as stolen or abandoned. The Co-op keeps each bike for 60 days, waiting for anyone to call and claim it.</p>
			<p>According to Price, only about 1 or 2 percent of the bikes' owners end up reclaiming their bikes.</p>
			<p>The rest are then placed in the Co-op's Earn-a-Bike Program, which donates 10 bikes a month to select people who donate 10 hours of community service to the Fort Collins community.</p>
			<p>The Co-op also branches out to schools and organizations with operations like the Bicycle Safety Program, which offers classes such as Traffic Skills 101 and children's safety and riding "rodeos," teaching children safe cycling skills.</p>
			<p>Price said they also try to reach out to motorists and college students as much as possible. According to Price, the city's highest bicycle crash rates belong to students, about 16 to 24 percent.</p>
			<p>He also said motorists need to learn where to look for cyclists and how to treat them on the road.</p>
			<p>"The education of cyclists is complicated," Price said. "The education of motorists, relative to cyclists, is complicated."</p>
			<h2>Cycling to the future</h2>
			<p>In five years, Price said he hopes to see the Co-op with paid staff and a new place for business.</p>
			<p>Price said for a business that was founded in 2003 by Rafael Cletero, who "came in with a dog and a trailer," that would be a sweet sight.</p>
			<p>The only paid member on staff, Cletero, the Co-op's president, receives a small stipend from the sales of the Co-op. Even Price, who is one of six members on the Co-op's board of directors, works for free.</p>
			<p>Several of the volunteers at the Co-op said they don't mind volunteering, saying they appreciate the work they're doing.</p>
			<p>Or, as Price said, it's worth it to be "building communities through bicycling."</p>
			<p>"There's a certain pleasure in putting people on bicycles."</p>
			<p><i>Assistant News Editor David Martinez can be reached at <a href="mailto:verve@collegian.com">verve@collegian.com</a>.</i></p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
