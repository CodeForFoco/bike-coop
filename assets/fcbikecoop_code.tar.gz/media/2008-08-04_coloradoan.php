<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <a href="http://coloradoan.com/apps/pbcs.dll/article?AID=/20080804/UPDATES01/80804012">Original Story - 08-04-2008 - Coloradoan</a>
         <h1>Decision to keep money local means Fort Collins' bike library short on two-wheel loaners</h1>
	 <p><a href="mailto:TrevorHughes@coloradoan.com">By: TREVOR HUGHES</a></p>
	<p>The city's decision to refurbish old bicycles instead of buying new ones from China means the Fort Collins Bike Library is lagging well behind initial projections of having 220 bikes available to lend by the end of the summer.</p>
	<p>Instead, the library will have only 120 bikes available by the end of summer.  The library, which this summer has experienced shoving matches between riders fighting over the free-to-borrow bikes, has about 70 bikes to lend right now.</p>
	<p>Organizers said the delay in getting additional bikes is also a result of the federal government's tardiness is turning over the grant money making the library possible.</p> 
	<p>To make up for the delay, the library is now also buying new bikes, while ramping up refurbishment of abandoned bikes collected by police.</p>
	<p>"Instead of paying another vendor from China more money for new bikes, we were able to pay local Fort Collins bike mechanics to fix up bikes that already existed in our community, thus keeping the project and the spending local," said city bike coordinator Dave "DK" Kemp. "Plus, with a smaller amount of bikes to start off with, we were able to manage the program with more success and we were able to work out the bugs.  We will still incorporate refurbished, repainted bikes into the library program, but to meet current demands, we are now also buying new bicycles."</p>
	<p>Kemp said he believes there's such a great demand of bike loans in Fort Collins that the library would likely have seen waiting lists even if it had 400 bikes to loan.</p>
	<p>The library has been oversubscribed since it opened on April 5.</p>
	<p>The library is a free service paid for with a federal clean-air grant funneled through the city, in partnership with Bike Fort Collins and the Fort Collins Bike Co-Op.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
