<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <a href="http://www.coloradoan.com/apps/pbcs.dll/article?AID=/20081102/NEWS01/811020335/1002/CUSTOMERSERVICE02">Original Story - 11-02-2008 - Coloradoan</a>
         <h1>Bike library goes into winter mode, plans a big spring</h1>
	 <p>By <a href="mailto:TrevorHughes@coloradoan.com">Trevor Hughes</a></p>
	 <div class="contents-image"><a href="http://fcbikecoop.org/media/images/2008-11-02_large.jpg"><img src="http://fcbikecoop.org/media/images/2008-11-02.jpg" alt="Signing Up"></a>
	    Robert Brischetto of San Antonio, Texas, fills out the forms and credit card information Friday now required to check out a bike at the bike library at Old Town Square. (Michael G. Seamans/The Coloradoan)
	 </div>
	 <p>Fort Collins' bike library is about to start gearing down for the winter, but managers say they're planning for major expansion come spring.</p>
	 <p>The library, funded in large part by a federal grant, lets people borrow bikes for free, for up to a week at a time. Since it opened April 5, more than 1,700 different people have checked out a bike, reducing vehicle trips by an estimated 15,958 miles, city bike coordinator Dave "DK" Kemp said.</p>
	 <p>"So many bits and pieces of the community came together to make this happen," Kemp said.</p>
	 <p>Today, the library has about 130 bikes to loan, and Kemp said he hopes to have about 220 by this time next year. The library started out with abandoned bikes collected by the police department and rebuilt largely by volunteers, but it recently received 30 bikes used during the Democratic National Convention in Denver.</p>
	 <p>During the summer, all of the library's bikes typically were checked out all of the time. As soon as one was returned, it would go right back out the door. Bike library workers said they've actually seen patrons at area restaurants leave mid-meal so they could secure a bike.</p>
	 <p>Kemp said the first season of operation helped iron out a number of wrinkles in the library, which has two locations, in Old Town Square and at the Fort Collins Bike Co-Op at 222 LaPorte Ave.</p>
	 <p>First, library workers discovered that homeless people were checking out the bikes so they could travel around the city and find work. In order to keep the library bikes available for visitors, Kemp and FC Bikes worked with Bike Fort Collins and the bike co-op to help outfit the most frequent homeless users with bikes of their own. People earned bikes by volunteering at least 15 hours at the co-op.</p>
	 <p>Second, Kemp said, too many bikes were coming back with bent rims, broken spokes and other relatively large mechanical problems. "People were abusing the bikes," he said. The solution: Every library user must now provide a credit card imprint. Kemp said attaching a value to the bikes significantly reduced breakage. "It made people more respectful."</p>
	 <p>The library is switching to winter hours later this month, cutting its Friday hours entirely. Patrons will be able to check out bikes from 11 a.m. to 4 p.m. Saturdays and Sundays.</p>
	 <p>Kemp said he believes the library will continue to have customers during the winter because snows that fall on Fort Collins typically melt off the streets and sidewalks quickly.</p>
	 <p>This spring, the library plans to open a new branch on the Colorado State University campus, Kemp said.  And he said he hopes to acquire additional bikes that can be assigned to local hotels for use by their guests.</p>
	 <p>"I think we're going to have a big spring," he said.</p>
	 <p>The typical bike library user is an out-of-town visitor with friends or relatives in the area, Kemp said.</p>
	 <p>The bike library is being funded with a federal Congestion Mitigation and Air Quality grant, which aims to help municipalities find ways to reduce vehicle traffic and air pollution. Kemp said the library believes it has kept 7.3 metric tons of carbon dioxide out of the air because people are using the bikes instead of cars.</p>
	 <p>The League of American Bicyclists in September ranked Fort Collins as one of the most bicycle-friendly cities in the country, specifically noting the library as a reason for its promotion from "silver" to "gold" status.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
