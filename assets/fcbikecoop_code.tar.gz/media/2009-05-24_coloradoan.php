<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.coloradoan.com/article/20090524/NEWS01/90523034">Original Story - 05-24-2009 - Coloradoan</a>
			<h1>Saved from landfill, bikes now Africa-bound</h1>
			<p>By <a href="mailto:TrevorHughes@coloradoan.com">Trevor Hughes</a></p>
			<div class="contents-image"><a href="images/2009-05-24_riley_big.jpg"><img src="images/2009-05-24_riley_small.jpg" alt=" Riley Phipps Stacking Tires"></a>
				Riley Phipps creates a pile of bike tires outside of the former home of Steele's Market in Fort Collins on Saturday. Fort Collins Bike Co-Op loaded a container of over 400 bikes and miscellaneous parts which will be shipped to Ghana, where the government levies higher taxes on bicycles , viewing them as recreation rather than low-cost transportation (Photos by Miranda Grubbs/The Coloradoan)
			</div>
			<div class="contents-image"><a href="images/2009-05-24_truck_big.jpg"><img src="images/2009-05-24_truck_small.jpg" alt="Doug Cutter Loading Bikes Into Container"></a>
				Fort Collins Bike Co-Op board member Doug Cutter loads bikes at the former Steele's Market in Fort Collins on Saturday. Pedals were screwed on facing in, handlebars turned sideways and tires deflated in order to more tightly pack the container. Cutter estimated about 450 bikes would fit.
			</div>
			<div class="contents-image"><a href="images/2009-05-24_john_big.jpg"><img src="images/2009-05-24_john_small.jpg" alt="John Toerper loads bike wheels into container"></a>
				Volunteer John Toerper loads bike wheels Saturday into a shipping container bound for the African country of Ghana. The Fort Collins Bike Co-op works to keep bikes out of landfills by repairing or recycling them.
			</div>
			<p>Volunteers in Fort Collins on Saturday loaded hundreds of abandoned and donated bikes into a shipping container bound for Africa.  </p>
			<p>The bikes collected by the Fort Collins Bike Co-op are destined for Ghana under the auspices of the Village Bike Project.</p>
			<p>Co-op volunteers have been collecting and refurbishing the bikes for months, concentrating mostly on adult bikes in reasonably good condition, said co-op board member Doug Cutter.</p>
			<p>"The criteria is that it's not totally a rust bucket," Cutter said during a break from loading.</p>
			<p>Cutter and several other volunteers Saturday were wheeling the bikes from the basement of the old Steele's Market out into the parking lot, where local Ghana project coordinator Riley Phipps packed them into the steel shipping container.</p>
			<p>Pedals were screwed on facing in, handlebars turned sideways and tires deflated. Cutter estimated about 450 bikes would be loaded and sent off.</p>
			<p>Packed among the bikes are seats, spare parts and helmets.</p>
			<p>"They're all compressed as much as possible to save space," Phipps said.<br>Cutter said the bikes will be trucked to Denver, put on a train and sent to a port, then shipped to Africa, where they will be distributed. He said some of the bikes will be sold, to pay for the shipping costs.</p>
			<p>Since its founding in 1999, the Village Bicycle Project has provided 36,000 bikes to Africans. According to VBP, some African countries charge high taxes on bikes, considering them a form of recreation, not low-cost transportation.</p>
			<p>Cutter said while this is the first shipment of bikes from Fort Collins to Ghana, it likely won't be the last. The co-op rewards volunteers with refurbished bikes, if they want them, with the aim of diverting as many bikes as possible from landfills. Worst-case scenario, the group recycles broken bikes as scrap metal.</p>
			<p>"If you have an abandoned bike, you can call us and we'll take care of it," Cutter said.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
