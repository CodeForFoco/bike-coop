<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <a href="">Original Story - 04-03-2008 - Reporter Herald</a>
         <h1>Check out these bikes</h1>
	 <h3>Fort Collins co-op to offer free bicycle rentals from Old Town Square kiosk</h3>
	  <p>By Pamela Dickman</p>
	  <div class="contents-image"><a href="images/2008-04-03.jpg"><img src="images/2008-04-03.jpg" alt="Story Image"></a>
	  Fleet manager Rafael Cletero stands near a bike he is building that the Fort Collins Bicycle Co-op will loan out from its Bicycle Library. Saturday marks the beginning of the bike library program at the co-op at 222 Laporte Ave. in Fort Collins. Reporter-Herald/Christopher Stark
	  </div>
	<p>New York City. Paris. Amsterdam. Chicago. San Francisco.</p>
	<p>"The bicycle library concept has been popping up in many of the chic cities" said Dave "DK" Kemp, the city of Fort Collins bicycle coordinator.</p>
	<p>And, starting Saturday, also Fort Collins.</p>
	<p>At two different locations in Fort Collins, anyone with identification will be able to check out a bicycle for free. They can keep that particular cycle for 72 hours, and upon its return, are eligible to check out another.</p>
	<p>"This is one of the most immediately gratifying ways that I've experienced to get people out on bikes" said Chris Pranskatis, with Bike Fort Collins.</p>
	<p>By Saturday, the library will have 50 bicycles of different sizes and styles as well as lights, helmets, locks and other gear available at the kiosk in Old Town Square and the Fort Collins Bicycle Co-op, 222 Laporte Ave.</p>
	<p>"It's an eclectic mix" said Pranskatis</p>
	<p>"By the end of next year, the bank of borrowable bicycles should grow to 220" said Kemp.</p>
	<p>Three bicycle mechanics and volunteers are completely refurbishing and rebuilding each bicycle for the program as well as bikes for two other programs through the Bicycle Co-op to provide cycles to those who cannot afford to buy, he said.</p>
	<p>We're going to town on these bikes" said Rafael Cletero, project coordinator for the Bicycle Co-op. "They will be nice and smooth and fast and efficient."</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
