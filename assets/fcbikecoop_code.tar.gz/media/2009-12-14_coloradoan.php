<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.coloradoan.com/article/20091214/BUSINESS/912140301/Q&A++Co-op+cycles+into+new+locale">Original Story - 12-14-2009 - Coloradoan</a>
			<h1>Co-op cycles into new locale</h1>
			<p>By Coloradoan Staff</a></p>
			<div class="contents-image"><a href="http://fcbikecoop.org/media/images/2009-12-14_rick.jpg"><img src="http://fcbikecoop.org/media/images/2009-12-14_rick.jpg" alt="Rick Price Cleans Bike"></a>
				Rick Price, safe cycling coordinator at Fort Collins Bike Co-op, checks a bicycle at the co-op's new facility at 331 N. College Ave. (Dawn Madura/The Coloradoan)
			</div>
			<p>Question: What services does the Bike Co-op offer?</p>
			<p>Answer: The Bike Co-op does everything it can to keep our community bicycling, including those who can.t afford to buy a bike. We try to educate our neighbors in all things bike-related including bike maintenance, bicycle education and safety. We keep good bikes out of the landfill and recycle poorly built or unsafe bikes. We refurbish and donate bicycles for a wide variety of charity events and programs for those in need, including the Earn-a-Bike program.</p>
			<p>Q: How long has it been in existence?</p>
			<p>A: (The co-op has been open) since spring 2003.</p>
			<p>Q: When and where did the co-op move?</p>
			<p>A: (The co-op) first moved from its original location in the winter 2007-08 and to its current location, 331 N. College Ave., in late August.</p>
			<p>Q: Why did the co-op decide to relocate?</p>
			<p>A: Adequate space for the Co-op means enough room for workspace, offices and storage as well as heated quarters to allow for full operational mode through the winter months; we didn.t have either of these at our last location. That.s the reason we moved to a temporary heated space last winter, and we.d rather not do that again as this is like moving three or four houses. Until late August, we were housed in city space linked to our work for the city with the Bike Library and the Found and Abandoned bikes for the city.s police services.</p>
			<p>Q: What advantages/disadvantages does the new location offer?</p>
			<p>A: Advantages: The entire operation is under one roof, we have heat, and we have great visibility on College Avenue. The disadvantages are that we now have to pay rent. Since we can sell services and bicycles from our new location, though (we were not allowed to do so from the city space) we hope to sell a few used bikes to cover the rent. (But donations are welcome to help pay that, too).</p>
			<p>Q: How has the public reacted to the move?</p>
			<p>A: With excitement and enthusiasm as most folks around town knew our last situation was no good, especially during the winter months. We are now outfitted in every aspect to better serve the community within this new format. People seem to love our new home as much as we do. Now that we are open (from) 2 to 5 p.m. Monday, Wednesday and Friday, we are attracting more and more people to sign up as volunteers, to register for our Earn-a-Bike program and those just looking for bike parts.</p>
			<p>Q: What will the open house on Saturday entail?</p>
			<p>A: Short, informal guided tours of our new facility (8,600 square feet). Come and see how many bikes get thrown away in this community annually. Ask questions about our programs and learn how you can help as a volunteer. Oh yeah, did we say that we.ve got Christmas presents? Pick up three helmets for the entire family for $25 (yes, that.s a package of three for $25), lights and locks as stocking stuffers as well. Or maybe you need mountain bikes? We.ve got a bunch.</p>
			<p>Q: How will the new building lend to future growth?</p>
			<p>A: For the most part, our programs are not tied to a place. That said, having winter space to work in will allow us to prepare Earn-a-Bikes for the public throughout the winter and to teach bicycle maintenance year-round.</p>
			<p>Q: What is the Earn-a-Bike program?</p>
			<p>A: People in the community can earn a quality, fully refurbished bicycle from the co-op by volunteering 20 hours at any nonprofit in town; those in need referred by a social work agency only need to volunteer 10 hours to receive a bike from the co-op.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
