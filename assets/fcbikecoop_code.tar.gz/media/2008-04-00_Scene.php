<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <a href="http://www.scenemagazine.info/online_this_month/Coop_Apr08.html">Original Story - 04-00-2008 - Scene Magazine</a>
         <h1>Bike Co-op Reopens in New Location</h1>
	 <h3>By David Boerner</h3>
	 <div class="contents-image"><a href="images/2008-04-00.jpg"><img src="images/2008-04-00.jpg" alt="electric car funeral"></a>
	    The new  and improved bike co-op
	 </div>
	 <p >The Fort Collins populous will release a collective sigh of relief on April 5th when the Fort Collins Bike Co-op, formerly Bike Against, <em>finally</em> reopens in their new, city-funded location after being closed for almost a year.&nbsp; Not only is the bike co-op reopening, they now have hundreds of donated police evidence bikes; they have thousands of dollars worth of tools donated by the Fort Collins community and a well-trained volunteer staff; they.re managing the new Fort Collins Bike Library, which allows anyone to rent out a bicycle for free; and they have a new city-owned space approximately five times the former co-op.s size rented to them at a reasonable $5 a year at 222 Laporte Avenue.&nbsp; From an anarchic garage in Old Town to city-funded digs next to the police station, the bike co-op has come a long way.    
	 <br />
	 It all started accidentally, five years ago when co-op founder Rafael Cletero ended up stranded in a blizzard in Fort Collins.    
	 <br />
	 I was on a bike tour,. Cletero said, wrenching on a bike in the co-op.s new garage.&nbsp; .I was going to ride across the country with Rosco [the dog] on a trailer.&nbsp; I flew into DIA, but I only made it to Fort Collins..    
	 <br />
	 </p>
	 <p>The blizzard stranded Rosco and Cletero in Fort Collins where a house full of friendly people took them in.&nbsp; They ended up staying, and Cletero repaid them by helping out with chores around the house.    
	 <br />
	 I was doing the dishes and cleaning,. Cletero said.&nbsp; .And I noticed that their bikes were in pretty bad shape.&nbsp; So I fixed up their bikes too, just for something to do to pay them back..  <br />  
	 And then they were like, .can you look at my girlfriend.s bike?. and then their girlfriend.s friend.s bike, and their neighbor.s bike..<br />
	 All I had were the tools I brought for my bike tour,. Cletero said.<br />
	 So when people needed things fixed that Cletero didn.t have a tool for, he.d make them a deal:&nbsp; .If you bring the tool and leave it for other people to use, I.ll show you how to fix this..<br />
	 And that.s how it started . in the garage of that house, where Cletero has lived ever since.<br />
	 I blink my eye and next thing I know I.ve been here for five years,. Cletero said, pausing for a second in disbelief, before going back to his work.<br />
	 Since then, the co-op accumulated many volunteers to share the workload that a free bike mechanic inevitably attracted.&nbsp; They set official hours.&nbsp; They developed .system after system. to deal with donations, organization, and repairs.&nbsp; <br />
	 Now they even have a board of directors.<br />
	 The grand opening on the fifth is a big deal, for several reasons:&nbsp; Most importantly, the co-op will be once again open to the public.&nbsp; Cletero estimates that 20-25 volunteer mechanics will be ready to help the public with their bike problems upon opening.&nbsp; The co-op will be staffed and open to the public Wednesday and Friday from noon to six and Sunday from ten to six.&nbsp; Anyone can use the co-op.s tools.&nbsp; And if you need parts . or a bike, for that matter . you can get it at the co-op for free, provided that you put in some work.<br />
	 We're not gonna do it for you,. Cletero says.&nbsp; .There has to be a co-operative effort..<br />
	 The second reason that the co-op reopening is big is because it is also the start of the Fort Collins Bike Library.&nbsp; Here.s the deal: You show up at one of the two locations (the co-op or the Caf� Biciclette (the former Downtown Information Kiosk)), sign a waiver, and check out one of the Bike Library.s 50 bikes, free of charge. CMAQ, the U.S. Department of Transportation Congestion Mitigation and Air Quality Improvement Program, funds the Bike Library, and co-op volunteers maintain the bikes.<br />
	 And the last reason to look forward to the co-op.s grand opening is the grand opening party.&nbsp; Fort Collins bluegrass band Wildwood Holler is playing along with special guest musicians.&nbsp; Team Wonderbike will encourage people to sign up for the Team Wonderbike Pledge to commute by bike at least once a week.&nbsp; There will be games for young and old, including a trackstand competition.&nbsp; You.ll be able to meet the Fort Collins Bike Co-op volunteers. &nbsp;And parking will be plentiful.&nbsp; Provided, of course, that you.re parking a bike.<br />
	 The new and improved Bike Co-op should have a long life ahead of it, with so many volunteers, help from FC Bikes and Bike Fort Collins, huge community support, and longtime co-op director Raphael Cletero.<br />
	 Before five years ago, Fort Collins didn.t have a bike co-op.&nbsp; Now we have a successful one.&nbsp; Until now, there hasn.t been a bike library, and we want that to be as successful as the co-op.&nbsp; And five years from now, I think it.ll still be around with a lot of support..<br />
	 As for whether or not Cletero will still be around in five more years, he.s not sure.<br />
	 Who knows.&nbsp; Now that the co-op is more settled and structured, it doesn.t need me as much anymore.&nbsp; Now I could possibly continue my bike tour..<br />
         </p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
