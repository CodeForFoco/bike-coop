<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <a href="http://www.coloradoan.com/apps/pbcs.dll/article?AID=200881031011">Original Story - 10-31-2008 - Coloradoan</a>
         <h1>Fort Collins' bike library gearing up for big spring</h1>
	 <p>By <a href="mailto:TrevorHughes@coloradoan.com">Trevor Hughes</a></p>
	 <p><a href="http://www.fcbikelibrary.org/index.asp">Fort Collins bike library</a> is about to start gearing down for the winter, but managers say they're planning for major expansion come spring.</p>
	 <p>The library, funded in large part by a federal grant, lets people borrow bikes for free, for up to a week at a time. Since it opened on April 5, more than 1,700 different people have checked out a bike, reducing vehicle trips by an estimated 15,958 miles, said city bike coordinator Dave "DK" Kemp.</p>
	 <p>"So many bits and pieces of the community came together to make this happen" Kemp said.<br><br>
	 Today, the library has about 130 bikes to loan, and Kemp said he hopes to have about 220 by this time next year. The library started out with abandoned bikes collected by the police department and rebuilt largely by volunteers, but recently received 30 bikes used during the Democratic National Convention in Denver.<br><br>
	 During the summer, all of the library's bikes were typically in use all of the time. As soon as one was returned, it would go right back out the door. Bike library workers said they've actually seen patrons at area restaurants leave mid-meal so they could secure a bike.<br><br>
	 Kemp said the first season of operation helped iron out a number of wrinkles in the library, which has two locations, in Old Town Square and at the Fort Collins Bike Co-Op at 222 LaPorte Ave. <br><br>
	 First, library workers discovered that homeless people were checking out the bikes so they could travel around the city and find work. In order to keep the library bikes available for visitors, Kemp and FC Bikes worked with the Bike Fort Collins and the bike co-op to help outfit the most frequent homeless users with bikes of their own. People earned bikes by volunteering at least 15 hours at the co-op.<br><br>
	 Second, Kemp said, too many bikes were coming back with bent rims, broken spokes and other relatively large mechanical problems. "People were abusing the bikes," he said. The solution: Every library user must now provide a credit card imprint. Kemp said attaching a value to the bikes significantly reduced breakage.  "It made people more respectful."<br><br>
	 The library is switching to winter hours later this month, cutting its Friday hours entirely. Patrons will be able to check out bikes from 11 a.m. to 4 p.m. on Saturdays and Sundays.<br><br>
	 Kemp said he believes the library will continue to have customers during the winter because snows that do fall on Fort Collins typically melt off the streets and sidewalks quickly.<br><br>
	 This spring, the library plans to open a new branch on the CSU campus, Kemp said.  And he said he hopes to acquire additional bikes that can be assigned to local hotels for use by their guests.<br><br>
	 "I think we're going to have a big spring," he said.<br><br>
	 The typical bike library user is an out-of-town visitor with friends or relatives in the area, Kemp said.<br><br>
	 The bike library is being funded with a federal Congestion Mitigation and Air Quality grant, which aims to help municipalities find ways to reduce vehicle traffic and air pollution. Kemp said the library believes it has kept 7.3 metric tons of carbon dioxide out of the air because people are using the bikes instead of cars.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
