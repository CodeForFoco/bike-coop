<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <a href="http://origin.denverpost.com/headlines/ci_9314363">Original Story - 05-19-2008 - Denver Post</a>
         <h1>Check out Fort Collins atop a rebuilt cruiser</h1>
	 <h3>By: Jacob Whitsitt</h3>
	 <p>The Fort Collins Bike Library offers its members a way to get around town, enjoy the scenery or see if they're up to the challenge of leaving their car behindfor free.</p>
	 <p>The library opened on April 5, with the help of three bicycle-friendly organizations: Bike Fort Collins, The Fort Collins Bike Co-Op and FC Bikes, the city's bike program. Originally, the program was meant to make Fort Collins an even friendlier cyclist community, says Bike Library manager Chris Pranskatis.</p>
	 <p>In its short life, the bike library has morphed into something even bigger, drawing all kinds of people  checking out bikes for every reason imaginable.</p>
	 <p>Affluent? Homeless? It doesn't matter. You need a bike, and you're welcome to borrow one, for a day or for a week. "It's open to anyone," Pranskatis says.</p>
	 <p>Although checking a bike out is free, the library  requires participants to become  members and present  valid  identification.</p>
	 <p>Membership &mdash; basically the completion of a short form &mdash; helps the library keep track of the bikes without being too restrictive.</p>
	 <p>Since April, the library has lent a fleet of 40 bikes to 248 riders, and only one has been lost. Two bikes went missing for a while but eventually were returned.</p>
	 <p>To ensure members are careful with the bikes, the library provides a lock. The bikes are also conspicuous, with a big "Bike Library" sign affixed to the frame, that is supposed to discourage theft. </p>
	 <p>All the bikes at the library come from donations or from reconstructed bikes that were either abandoned or confiscated by police and never reclaimed by their owners, Pranskatis said.</p>
	 <p>Today, the library is run by a group of about 20 volunteers and a federal grant. Members can check out bikes at Cafe Bicyclette in Old Town Square, open 10 a.m.- 6 p.m. Fridays, Saturdays and Sundays, or at the Bike Co-Op, 222 LaPorte Ave., during the week.</p>
	 <p>Pranskatis hopes to see the number of check-out locations grow. "Ideally, we'd like to expand the number of check-out stations and fleet of bicycles, to create a web of stations all over town so people can access a bike from almost any location in the city." </p>
	 <p>For more information about donating to or volunteering for the Fort Collins Bike Library, or to become a member, visit <a href="http://fcbikelibrary.org">fcbikelibrary.org</a>.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
