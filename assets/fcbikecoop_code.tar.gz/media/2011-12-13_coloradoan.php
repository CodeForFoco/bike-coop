<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.coloradoan.com/article/20111213/UPDATES01/111213023/Larimer-County-recognizes-environmental-stewards">Original Story - 12-13-2011 - Coloradoan</a>
			<h1>Larimer County recognizes environmental stewards</h1>
			<p>By Coloradoan Staff</p>
			<p>The Larimer County commissioners have announced the 2011 Larimer County Environmental Stewardship Awards:</p>
<p>� The Fort Collins Bicycle Co-op for its comprehensive actions designed to make bicycles and bicycle riders sustainable: Those include safety education programs and refurbishing bikes that were abandoned and returning them to the community.</p>
<p>� RB+B Architects for its Sustainability Management System: Principle elements of the plan relate to carbon emissions, health and well being, waste reduction, sustainable materials, and culture and community.</p>
<p>� Redstone Mitigators for its example of how a community can work together to achieve common forest management and wildfire safety goals: Community members work every Saturday from Novem-ber to February to cut down and stack trees marked for removal. Funds from a Colorado State Forest Service grant are spent in the spring when a contractor with heavy equipment chips the wood waste onsite.</p>
<p>� The Growing Project for its efforts to connect community members to each other, their food, and their land through urban agriculture and community gardening: The project has implemented a series of efforts ranging from community gardens to a .Glean Team. that cooperates with farmers to harvest food that might otherwise be wasted for delivery to the Food Bank for Larimer County.</p>
<p>� Irene Little for her efforts on behalf of recycling opportunities in the Estes Park area: As chairperson for the League of Women Voters community recycling committee in Estes Park, Little has worked on a number of projects, including the introduction of cardboard recycling, the promotion of reusable shopping bags, and a community recycling program in Bond Park.</p>
<p>The environmental stewardships awards have been given annually since 1995.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
