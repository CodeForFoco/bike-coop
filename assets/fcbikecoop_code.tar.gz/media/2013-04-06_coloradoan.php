<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.coloradoan.com/article/20130407/LIFESTYLE/304070018/Validity-Volunteering-Fort-Collins-cyclist-works-through-paralyzing-injury?fb_action_ids=4060785772859&fb_action_types=og.recommends&fb_ref=artsharetop&fb_source=other_multiline&action_object_map=[239546979525040]&action_type_map=[%22og.recommends%22]&action_ref_map=[%22artsharetop%22]">Original Story - 04-06-2013 - Coloradoan</a>
			<h1>Validity in Volunteering: Fort Collins cyclist works through paralyzing injury</h1>
			<p>By <a href="mailto:SNoblett@coloradoan.com">Sam Noblett</a></p>
			<div class="contents-image"><a href="http://fcbikecoop.org/media/images/2013-04-06_tim-anderson.jpg"><img src="http://fcbikecoop.org/media/images/2013-04-06_tim-anderson.jpg" alt="Tim Anderson teaches a student"></a>
				Tim Anderson, right, a volunteer at the Fort Collins Bike Co-Op, talks Friday with Natasha Shabalin as they fix the rear brake on her Trek Antelope during open shop hours. Anderson was forced into retirement by a bike accident that left his right side partially paralyzed. He volunteers at the co-op regularly and sits on the board. / Sam Noblett/The Coloradoan
			</div>
			<p>For Tim Anderson, life has been mostly hurdles as of late.</p>
			<p>Anderson, a bicycle enthusiast, was left with partial paralysis on his right side after a bike accident in 2009 that forced an early retirement from a 30-year career in dentistry. But despite his challenges, he keeps moving forward.</p>
			<p>Anderson can now be found each week working at all three of the Fort Collins Bike Co-Op's open-shop sessions, at 331 N. College Ave., where he helps people learn how to tinker with and fix bikes.</p>
			<div class="contents-image">
				Tim Anderson<br>
				. Age: 56<br>
				. Resides: Fort Collins<br>
				. Family: Wife, Pat; two sons, James, 25; and Jon, 22<br>
				. Can be found at: Fort Collins Bike Co-Op open shop sessions on Wednesdays, Fridays and Sundays
			</div>
			<p>As Anderson shuffles with his cane across the shop, sometimes balancing multiple client projects at a time, his personality leaps across the room much faster than he is he able to travel the distance by foot. At times, he makes quips about the music playing in the shop or fondly teases his shopmates.</p>
			<p>And despite challenges stemming from his involvement in bikes and bike racing, he holds no ill will toward the machine or the sport.</p>
			<p>"There is no resentment," he said. "You know when you enter a bike race? You sign the waiver saying I understand this is dangerous; it can cause serious injury or death. That's what I was taking a risk with."</p>
			<p>However, the path to where he stands today -- with heavy involvement in two biking nonprofits, the co-op and a separate organization he founded called Fort Collins VeloPark -- has been fraught with hardship. And through those challenges he emphasized he was not alone -- especially when it came to Pat, his wife of 27 years.</p>
			<p>"Pat, you know, she saved my life. She gave me a reason to keep living," he said. "You know my sons, the rest of my family, they were part of that".</p>
			<p>While Anderson uses a wheelchair at home, he is able to walk with the use of a cane and has even gotten his feet back on the pedals. He rides a customized recumbent tricycle from Rocky Mountain Recumbents in Fort Collins.</p>
			<p>He has also continued training with his cycling coach, Andy Clark, three days a week. Clark has worked with Anderson for more than a decade.</p>
			<p>"As a cycling coach, you can have some clients with great potential and watch them struggle to use it," Clark said. "Then I look at Tim, and his sacrifices have already been made. And he overcomes them."</p>
			<p>Through it all, Anderson has continued finding ways to give back to his community. At the co-op he has gained a reputation for being the most consistent volunteer during open-shop sessions, when volunteers put wrenches in riders' hands and show them how to fix their bikes.</p>
			<p>And during those sessions, Anderson uses the time to help others learn skills he has picked up over his life and through his passion for cycling.</p>
			<p>"For me, because of my disability, we are enabling," he said. "There is disabling and enabling. And that's important."</p>
			<p>Helping others to help themselves has also given Anderson the opportunity to give back after his accident.</p>
			<p>"When I got taken out of (dentistry), I became an invalid. I needed to do something to not only amuse myself, but also to recapture some validity," Anderson said. "Instead of being an invalid, you get back to being valid."</p>
			<p>His willingness to work with anyone, especially children, co-op shop manager Ben Gannon said, confirms his contribution to the community.</p>
			<p>"He's in a place where a lot of people would have given up, but he rebuilt his life around it," Clark said. "He's very inspirational."</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
