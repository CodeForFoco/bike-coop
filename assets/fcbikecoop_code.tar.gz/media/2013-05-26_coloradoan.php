<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.coloradoan.com/apps/pbcs.dll/article?AID=2013305270006">Original Story - 05-26-2013 - Coloradoan</a>
			<h1>Jones: Kids need to experience the adventure of biking, too</h1>
			<p>By <a href="mailto:mattjoneslovesenglish@gmail.com">Matt Jones</a></p>
			<p>Some of my fondest childhood memories involve a bicycle. At the risk of sounding cliche, my first bike sparked a new freedom in my life. Instead of being confined to the cul-de-sac, I could now venture two or even three blocks from my house.</p>
			<p>My bike was my steed to my quixotic quests. I spent hours riding the dirt roads behind my subdivision for, what I imagined, were huge distances. I understand now that I was probably never out of the sight of neighbors.</p>
			<p>For many in Fort Collins, bikes are synonymous with our city. However, that title has much to do with adults and bicycles. We assume that all kids will ride bikes, not realizing that there are kids that would love to have a bike, but can't get one.</p>
			<p>Trips for Kids is a national organization that was founded in 1986 outside of San Francisco by Marilyn Price. Marilyn had a vision of taking city kids into the mountains to experience challenge and nature. Since then the organization has grown to include chapters nationwide. This year, Fort Collins opened its own chapter through the Fort Collins Bike Co-op. I've had the pleasure of helping to build this program and feel its growing pains. Since last summer, we've been on five rides and served just over a dozen kids.</p>
			<p>Trips for Kids is just one of many organizations that attempt to connect kids with the outdoors. Overland Mountain Bike Club has its own "Take a Kid Mountain Biking Day," and other cycling groups have their own youth programs.</p>
			<p>The common thread in all of these groups is that each recognizes that the bicycle, though a useful tool, can be that and more to a kid.</p>
			<p>When you tell a kid, especially a young one, that you're going mountain biking, they get the same look I imagine I had when I was little. They imagine an adventure. The rides that we take young kids and most new cyclists on are pretty tame to a veteran cyclist, but by introducing them to a new environment with a new perceived risk, we create the feeling of adventure. This mental state is an awesome place to watch a kid explore and grow. Out on the trail, they experience real dirt, sun, thirst and sometimes, even real scrapes and bruises. From this place they come back with a new idea of what they can achieve.</p>
			<p>Kids don't have to go on an organized ride to learn to mountain bike, but they do need to have a safe place to do it. All of us who love cycling know the feeling of the exaggerated sense of self, the hubris felt with flying down a road or trail. As therapeutic as that is for us adults, imagine what that can do for an at-risk youth. A bike can be the tool that child uses to escape the mundane or even terrifying life he/she lives, if even for just an afternoon.</p>
			<p>Trips for Kids rides every other Saturday. Bikes, helmets and lunch are provided. Rides are free. Ages 8 to 18 are welcome. Sign up at <a href="http://tripsforkidsfoco.org">tripsforkidsfoco.org.</a></p>
			<p>Matt Jones volunteers on the board of directors for Trips for Kids and at the Fort Collins Bike Co-op, and is a coach for the Loveland Composite High School Mountain Bike Team. Trips for Kids is a member organization of the Bicycle and Pedestrian Education Coalition.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
