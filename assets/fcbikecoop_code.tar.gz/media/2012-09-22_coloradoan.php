<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<a href="http://www.coloradoan.com/article/20120922/NEWS01/309220017/Inaugural-Fortoberfest-gets-rolling-beer-bikes-bands">Original Story - 09-22-2012 - Coloradoan</a>
			<h1>Inaugural Fortoberfest gets rolling with beer, bikes, bands</h1>
			<p>By <a href="mailto:RobertAllen@coloradoan.com">Robert Allen</a></p>
			<p>Fort Collins pedaled out its own version of Oktoberfest on Saturday with community staples of beer, bikes and bands.</p>
			<p>The event was light on lederhosen but heavy on satisfying suds.</p>
			<p>"Anything that involves downtown and beer - how could you go wrong?" said Fortoberfest volunteer Brinda Hadeen after pouring a deep-brown pitcher of Sam Adams Chocolate Bock. "I love the chocolate"</p>
			<div class="contents-image"><a href="http://fcbikecoop.org/media/images/2012-09-22_1.jpg"><img src="http://fcbikecoop.org/media/images/2012-09-22_1.jpg" alt="Image1"></a>
				Lucas Mellinger, 8, peddles to power a blender at the Fortoberfest, Saturday, Sept. 22, 2012, in Fort Collins.<br>
			LENN STOUT / THE COLORADOAN
			</div>
			<p>She and Emily Molzahn, a Colorado State University grad student, poured beers from a large Odell Brewing Co. truck that contained about 14 kegs. Molzahn said she took part in the inaugural event to get outside on a nice day and chat with festivalgoers.</p>
			<p>Down Walnut Street, Crankenstein co-owner and head mechanic Evan Rau worked on a man's bicycle.</p>
			<p>"I'm just helping people out with whatever they need," he said, while turning parts on a shifter that had been sticking. "We try to bring a bike stand and tools wherever we go"</p>
			<div class="contents-image"><a href="http://fcbikecoop.org/media/images/2012-09-22_2.jpg"><img src="http://fcbikecoop.org/media/images/2012-09-22_2.jpg" alt="Image2"></a>
			Bryce Newman, left, along with his wife Romy and daughter Verona dress in costume at the Fortoberfest, Saturday, Sept. 22, 2012, in Fort Collins.<br>
			LENN STOUT / THE COLORADOAN
			</div>
			<p>Rau said he didn't expect the first-year event to draw much of a crowd, but there were more people than he expected.</p>
			<p>Fortoberfest ran from Friday evening to Saturday night and included beer sampling trays and brew-themed events. Live music from numerous local bands was delivered through multiple stages, and festivalgoers were encouraged to park their bikes on site.</p>
			<p>Other local breweries including New Belgium, Pateros Creek and Fort Collins Brewery among others offered a variety of selections on the streets closed to traffic in Old Town Fort Collins.</p>
			<div class="contents-image"><a href="http://fcbikecoop.org/media/images/2012-09-22_3.jpg"><img src="http://fcbikecoop.org/media/images/2012-09-22_3.jpg" alt="Image3"></a>
			Bryce Newman, left, along with his wife Romy and daughter Verona dress in costume at the Fortoberfest, Saturday, Sept. 22, 2012, in Fort Collins.<br>
			LENN STOUT / THE COLORADOAN
			</div>
			<div class="contents-image"><a href="http://fcbikecoop.org/media/images/2012-09-22_4.jpg"><img src="http://fcbikecoop.org/media/images/2012-09-22_4.jpg" alt="Image4"></a>
			Lead singer for Widow's Bane performs at the Fortoberfest, Saturday, Sept. 22, 2012, in Fort Collins.<br>
			LENN STOUT / THE COLORADOAN
			</div>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
