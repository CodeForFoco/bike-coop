<?php
// NOTE ALL CHANGES TO THIS FILE ALSO NEED TO BE MADE
// IN /var/www/fcbikecoop.org/root/blog/wp-content/themes/fcbikecoop/header.php
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">
 
<?php
	require_once('/var/www/fcbikecoop.org/root/recaptcha/recaptchalib.php');
	$mailhide_pubkey = '01YHgGOdqqceM8BoQAU6otaA==';
	$mailhide_privkey = 'D78EB9D13D3EED84068F44B3F0EDC1DC';
	include_once('/var/www/fcbikecoop.org/root/menu.php');
?>
<head>
	<meta name="verify-v1" content="f86i1xKZzknNTsy56CdemZq5E/maQQUmFTQsg8AlNG8=" />
	<meta http-equiv="Content-type" content="text/html; charset=iso-8859-1">
	<title><?php echo "$title"?></title> 
	<link rel="stylesheet" type="text/css" href="http://fcbikecoop.org/css/fcbikecoop.css">
	<script type="text/javascript">
		var _gaq = _gaq || [];
		_gaq.push(['_setAccount', 'UA-15197623-1']);
		_gaq.push(['_trackPageview']);

		(function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		})();
	</script>
</head>
<body>
	<div id="container">
		<img class="helpwanted" alt="Help Wanted!" src="http://fcbikecoop.org/images/help_wanted.png" width="150px" height="150px" usemap="#help_map">
		<map name="help_map">
			<area shape="poly" coords="0,0,150,0,150,150,0,0" href="http://fcbikecoop.org/programs/volunteer_action/help_wanted.php" alt="Help Wanted!">
		</map>
		<div id="header">Fort Collins Bicycle Co-op
			<div class="social_media">
				<a href="https://plus.google.com/101151928775447436307/about"><img src="http://fcbikecoop.org/images/google_plus.crush.png" height="24px" width="38px" alt="Recommend this on g+"></a>
				<a href="https://twitter.com/fcbikecoop"><img src="http://fcbikecoop.org/images/twitter.png" height="24px" width="38px" alt="Follow us on Twitter"></a>
				<a href="https://www.facebook.com/FortCollinsBikeCoOp"><img src="http://fcbikecoop.org/images/facebook.png" height="24px" width="38px" alt="Like us on Facebook"></a>
			</div>
		</div> 
		<div id="menu">
			<div class="menu-image"><a href="http://fcbikecoop.org/"><img width="120" height="120" src="http://fcbikecoop.org/images/fcbikecoop-120x120.png" alt="Co-op Logo" border="0"></a></div>
			<div class="<?php echo "$button1"?>"><a href="http://fcbikecoop.org/index.php">Mission</a></div>
			<div class="<?php echo "$button2"?>"><a href="http://fcbikecoop.org/blog">Blog</a></div>
			<div class="<?php echo "$button3"?>"><a href="http://fcbikecoop.org/programs/index.php">Programs</a></div>
			<div class="<?php echo "$button4"?>"><a href="http://fcbikecoop.org/calendar.php">Calendar/Hours</a></div>
			<div class="<?php echo "$button5"?>"><a href="http://fcbikecoop.org/sponsors.php">Sponsors/Links</a></div>
			<div class="<?php echo "$button0"?>"><a href="http://fcbikecoop.org/pictures/index.php">Videos/Photos</a></div>
			<div class="<?php echo "$button6"?>"><a href="http://fcbikecoop.org/volunteers.php">Volunteers</a></div>
			<div class="<?php echo "$button7"?>"><a href="http://fcbikecoop.org/faq.php">FAQ</a></div>
			<div class="<?php echo "$button8"?>"><a href="http://fcbikecoop.org/mail.php">Mailing List</a></div>
			<div class="<?php echo "$button10"?>"><a href="http://fcbikecoop.org/programs/bars/AbandonedBikeReport.php">Report a Found Bike</a></div>
			<div class="<?php echo "$button9"?>"><a href="http://fcbikecoop.org/contact.php">Contact</a></div>
			<a href="http://fcbikecoop.org/programs/grants/donations.php"><img src="http://fcbikecoop.org/images/btn_donate_LG.png" border="0" alt="Donate via Paypal" width="92px"  height="26px"></a>
			<!---<ul>
				<li><h2>Happenings</h2></li>
				<li><a href="http://fcbikecoop.org/blog/2013/10/womens-wrenching-nights-are-back/">Women's Night</a></li>
			</ul>--->
		</div>
		<div id="contents">
		<!-- Begin Dynamic Content -->
