<?php
// NOTE ALL CHANGES TO THIS FILE ALSO NEED TO BE MADE
// IN /var/www/fcbikecoop.org/root/blog/footer.html
?>
		<!-- End Dynamic Content -->
		</div>
		<div id="footer">1501 North College Avenue | Fort Collins, CO 80524 | (970)484-3804
		</div>
	</div>
</body>
</html>
