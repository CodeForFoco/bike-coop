<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">Frequently Asked Questions</div>
         <h2>Can I trade these parts for those parts?</h2>
	 No, but you're welcome to donate your parts, and buy other used parts at great prices.
         <h2>Do you want my 1978 Schwinn varsity/1983 stingray/old busted/rusted solid Bike?</h2>
	 Yes, we take all donations bike related.  Worst case we will send it to recycled bike heaven.
         <h2>What are the volunteers at the co-op up to these days?</h2>
	 Take a look at all of our <a href="http://fcbikecoop.org/programs/index.php">programs.</a>
         <h2>How do I volunteer?</h2>
	 Easy, <a href="http://fcbikecoop.org/volunteers.php">volunteers</a> info here.
         <h2>When is the co-op open?</h2>
	 See the shop <a href="http://fcbikecoop.org/calendar.php">hours.</a>
         <h2>Where do I take Donations?</h2>
	 See the <a href="http://www.fcbikecoop.org/programs/grants/donations.php">Donation Information Page</a>
         <h2>Where is the co-op?</h2>
	 Check out the <a href="http://fcbikecoop.org/contact.php">location</a> page.
         <h2>How do I get off the volunteer mailing list?</h2>
	 You just need to send an email to <?php echo recaptcha_mailhide_html ($mailhide_pubkey, $mailhide_privkey, "volunteers-leave@fcbikecoop.org"); ?> with the subject "Un-subscribe"
         <h2>How do I get on the volunteer mailing list?</h2>
	 First head over to the <a href="http://fcbikecoop.org/volunteers.php">Volunteers page</a> and fill out the volunteer form.  If you've done that but you still don't receive the emails then you can send an email to <?php echo recaptcha_mailhide_html ($mailhide_pubkey, $mailhide_privkey, "volunteers-join@fcbikecoop.org"); ?> with the subject "Subscribe"
         <h2>Where's the wiki?</h2>
	 Here's the <a href="http://www.bikecollectives.org/wiki/index.php?title=Fort_Collins_Bike_Coop">wiki</a>
         <h2>Can I get High resolution Co-op logo files?</h2>
	 Sure they're <a href="http://www.fcbikecoop.org/posters/logo/">over here.</a>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
