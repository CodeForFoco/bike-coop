<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">Welcome to the media archives</div>
	 <h2>Articles</h2>
	 <div class="contents-media"><a href="media/2015-01-29_collegian.php">The Fort Collins Bike Co-Op offers a accumulation of programs</a></div>
	 2015-01-29 - Collegian Central<br>
	 The Fort Collins Bike Co-Op, primarily started in a area garage, has blossomed into a community-centered, non-profit classification tailoring their actions to a contentment of a community.<br><br>
	 <div class="contents-media"><a href="media/2013-05-26_coloradoan.php">Jones: Kids need to experience the adventure of biking, too</a></div>
	 2013-05-26 - The Coloradoan<br>
	 Some of my fondest childhood memories involve a bicycle. At the risk of sounding cliche, my first bike sparked a new freedom in my life. Instead of being confined to the cul-de-sac, I could now venture two or even three blocks from my house.<br><br>
	 <div class="contents-media"><a href="media/2013-04-06_coloradoan.php">Validity in Volunteering: Fort Collins cyclist works through paralyzing injury</a></div>
	 2013-04-06 - The Coloradoan<br>
	 For Tim Anderson, life has been mostly hurdles as of late.<br>
	 Anderson, a bicycle enthusiast, was left with partial paralysis on his right side after a bike accident in 2009 that forced an early retirement from a 30-year career in dentistry. But despite his challenges, he keeps moving forward.<br><br>
	 <div class="contents-media"><a href="media/2012-09-22_coloradoan.php">Inaugural Fortoberfest gets rolling with beer, bikes, bands</a></div>
	 2012-09-22 - The Coloradoan<br>
	 Fort Collins pedaled out its own version of Oktoberfest on Saturday with community staples of beer, bikes and bands.  The event was light on lederhosen but heavy on satisfying suds.<br><br>
	 <div class="contents-media"><a href="media/2012-04-26_collegian.php">Fort Collins Bike Co-op rides on despite uncertain future</a></div>
	 2012-04-26 - The Rocky Mountain Collegian<br>
	 Nestled near an empty parking lot north of the summer crowds and busy shops of Old Town, the Fort Collins Bike Co-op awaits the onslaught of warm-weather cyclists, tourists and curious passersby -- at least for now.<br><br>
	 <div class="contents-media"><a href="media/2012-01-18_coloradoan.php">How safe is your bike?</a></div>
	 2012-01-18 - coloradoan.com<br>
	 As the number of Fort Collins bicycle thefts continues to rise year over year, many are asking ...<br>
	When John Eklund bought a Yeti mountain bike on Craigslist last year, he never thought he would be searching the same website a month later for the same bicycle.<br><br>
	 <div class="contents-media"><a href="media/2011-12-13_coloradoan.php">Larimer County recognizes environmental stewards</a></div>
	 2011-12-13 - coloradoan.com<br>
	 The Larimer County commissioners have announced the 2011 Larimer County Environmental Stewardship Awards:<br>
	 � The Fort Collins Bicycle Co-op for its comprehensive actions designed to make bicycles and bicycle riders sustainable: Those include safety education programs and refurbishing bikes that were abandoned and returning them to the community.<br><br>
	 <div class="contents-media"><a href="media/2011-11-07_coloradoan.php">McWhinney backs out of Block 23 deal</a></div>
	 2011-11-07 - coloradoan.com<br>
	 An entire city block in Old Town Fort Collins is back on the market.<br>
	 McWhinney, the Loveland development company that built Centerra, has pulled out of a contract to buy the underdeveloped block on North College Avenue between Maple and Cherry streets, also known as Block 23.<br><br>
	 <div class="contents-media"><a href="media/2011-11-06_9news.php">Time change creates hazards for commuters</a></div>
	 2011-11-06 - 9news.com<br>
	 Switching the clocks back from Daylight Saving Time to Standard Time in the fall requires an adjustment for everyone, including motorists, who have to get used to driving home when it's darker.<br><br>
	 <div class="contents-media"><a href="media/2011-09-15_reporterherald.php">McWhinney eyes huge Fort Collins project</a></div>
	 2011-09-15 - Reporter Herald<br>
	 Raising its stake in Northern Colorado's rental housing market, McWhinney plans a summer groundbreaking on an apartment project that consumes an entire city block in downtown Fort Collins.<br><br>
	 <div class="contents-media"><a href="media/2010-09-09_verve.php">
Creating a cycling culture: Old Town crew gives back to FoCo, Ghana</a></div>
	 2010-09-09 - Verve<br>
	 Just a brief jaunt from Old Town Fort Collins lays an unassuming shack on a patch of worn, crumbly asphalt.
	 In front, a small, quaint sign that reads "Bike Co-op" dangles gingerly, looking sorely out of place.<br><br>
	 <div class="contents-media"><a href="media/2010-04-27_collegian.php">Local cyclists vent complaints</a></div>
	 2010-04-27 - Collegian<br>
	 Rick Price logs 70 miles per week on his Cannondale commuter bike.
	 Price, 60, is a member of the Fort Collins Bike Co-op, a group that looks to further the interests of Choice City cyclists and ultimately hopes to make the CSU campus free from automobiles.
	 The organization hosted a meeting of about a dozen students and community members Tuesday to discuss the future of the cycling community in Fort Collins.<br><br>
	 <div class="contents-media"><a href="media/2010-04-25_coloradoan.php">Co-op donates bicycles to 60 Putnam School of Science kids</a></div>
	 2010-04-25 - Coloradoan<br>
	 For 7-year-old Anthony Fernandez, Saturday was a day to remember.  The first-grader at Putnam School of Science received his first bicycle Saturday afternoon, a cherry red model with two training wheels, courtesy of the Fort Collins Bike Co-op.<br><br>
	 <div class="contents-media"><a href="media/2010-02-18_coloradoan.php">Bike safety simplified for students</a></div>
	 2010-02-18 - Coloradoan<br>
 	 Bill Black, owner of the 1st Choice After School Kare, or ASK, program, decided to get a jump-start on spring and brought two experts to share their knowledge about bike safety to students at Liberty Common.<br><br>
	 <div class="contents-media"><a href="media/2009-12-14_coloradoan.php">Co-op cycles into new locale</a></div>
	 2009-12-14 - Coloradoan<br>
	 Question: What services does the Bike Co-op offer?<br>
	 Answer: The Bike Co-op does everything it can to keep our community bicycling, including those who can.t afford to buy a bike. We try to educate our neighbors in all things bike-related including bike maintenance, bicycle education and safety. We keep good bikes out of the landfill and recycle poorly built or unsafe bikes. We refurbish and donate bicycles for a wide variety of charity events and programs for those in need, including the Earn-a-Bike program.<br><br>
	 <div class="contents-media"><a href="media/2009-08-10_coloradoan.php">Bicyclists learn rules of the road</a></div>
	 2009-08-10 - Coloradoan<br>
	 The number of League of American Bicyclists trained instructors in Fort Collins is likely to more than double after a handful of residents participated in a weekend training to become certified to become certified to teach the community how to ride safely in traffic.<br><br>
	 <div class="contents-media"><a href="media/2009-06-01_coloradoan.php">Refurbished bikes aid people, environment</a></div>
	 2009-06-01 - Coloradoan<br>
	 As Albert Einstein once said, "Life is like riding a bicycle. To keep your balance, you must keep moving."<br><br>
	 <div class="contents-media"><a href="media/2009-05-24_coloradoan.php">Saved from landfill, bikes now Africa-bound</a></div>
	 2009-05-24 - Coloradoan<br>
	 Volunteers in Fort Collins on Saturday loaded hundreds of abandoned and donated bikes into a shipping container bound for Africa.<br><br>
	 <div class="contents-media"><a href="media/2009-05-05_coloradoan.php">Time to nurture our bicycle culture</a></div>
	 2009-05-05 - Coloradoan<br>
	 Richard Florida observed in the March Atlantic Monthly that recovering from our economic woes "will require a new kind of geography .... a new spatial fix for the next chapter of American economic history."<br><br>
	 <div class="contents-media"><a href="media/2009-04-06_coloradoan.php">Fort Collins bike co-op among finalists for grant</a></div>
	 2009-04-06 - Coloradoan<br>
	 The Fort Collins bike co-op is one of 10 finalists for a $10,000 grant to give free bike tours around Old Town and city bike paths to tourists and residents.<br><br>
	 <div class="contents-media"><a href="media/2008-12-08_coloradoan.php">Bike Co-op gift will go a long way</a></div>
	 2008-12-08 - Coloradoan<br>
	 Some don't have to wait for the holidays to find a gift.  Such is the case with the Fort Collins Bike Co-op, which last week received $10,000 from an anonymous donor.<br><br>
	 <div class="contents-media"><a href="media/2008-11-02_coloradoan.php">Bike library goes into winter mode, plans a big spring</a></div>
	 2008-11-02 - Coloradoan<br>
	 Fort Collins' bike library is about to start gearing down for the winter, but managers say they're planning for major expansion come spring.<br><br>
	 <div class="contents-media"><a href="media/2008-10-31_coloradoan.php">Fort Collins' bike library gearing up for big spring</a></div>
	 2008-10-31 - Coloradoan<br>
	 Fort Collins bike library is about to start gearing down for the winter, but managers say they're planning for major expansion come spring.<br><br>
	 <div class="contents-media"><a href="media/2008-10-10_denver_post.php">Pedals of empowerment</a></div>
	 2008-10-10 - denverpost.com<br>
	 Carla Quist slowly spins her pedals along the gravel driveway, testing her purple mountain bike.  It doesn't look like much, but the brakes are good. It shifts smoothly. The tires are new.<br><br>
	 <div class="contents-media"><a href="media/2008-10-06_coloradoan.php">Council has wisdom to pass bike plan revisions</a></div>
	 2008-10-06 - Coloradoan<br>
	 City Council on Tuesday will review the revision of the world-class 1995 City "Bicycle Program Plan." <br><br>
	 <div class="contents-media"><a href="media/2008-08-04_coloradoan.php">Decision to keep money local means Fort Collins' bike library short...</a></div>
	 2008-08-04 - Coloradoan<br>
	 The city's decision to refurbish old bicycles instead of buying new ones from China means the Fort Collins Bike Library is lagging well behind initial projections of having 220 bikes available to lend by the end of the summer.<br><br>
	 <div class="contents-media"><a href="media/2008-07-22_theage.php">Bicycle library popularity a turn up for the books</a></div>
	 2008-08-22 - theage.com.au<br>
	 THE price of petrol was a good enough reason for Amanda Gilson, a student at Colorado State University, to sell her SUV and jump on a bike - even if she only gets to ride it every other week.<br><br>
	 <div class="contents-media"><a href="media/2008-07-12_AP.php"> Free bike library service booming in Fort Collins</a></div>
	 2008-07-12 - AP (Coloradoan)<br>
	 The Fort Collins Bike Library plans to quadruple the number of bikes available to loan by next spring after finding itself dramatically and happily oversubscribed.<br><br>
	 <div class="contents-media"><a href="media/2008-07-10_coloradoan.php">Bike library's a positive contribution</a></div>
	 2008-07-10 - Coloradoan<br>
	 Libraries aren't just for books. They can be for bikes, too.<br><br>
	 <div class="contents-media"><a href="media/2008-05-19_denver_post.php">Check out Fort Collins atop a rebuilt cruiser</a></div>
	 2008-05-19 - Denver Post<br>
	 The Fort Collins Bike Library offers its members a way to get around town, enjoy the scenery or see if they're up to the challenge of leaving their car behind for free.<br><br>
	 <div class="contents-media"><a href="media/2008-04-25_9news.php">Take out a bike with a library card</a></div>
	 2008-04-25 - 9News (Denver)<br>
	 FORT COLLINS . Earlier this month, Fort Collins opened up a different type of library. Instead of handing out books, it hands out bikes.<br><br>
	 <div class="contents-media"><a href="media/2008-04-00_Scene.php">Bike Co-op Reopens in New Location</a></div>
	 2008-04-00 - Scene Magazine<br>
	 The Fort Collins populous will release a collective sigh of relief on April 5th when the Fort Collins Bike Co-op, formerly Bike Against, finally reopens in their new, city-funded location after being closed for almost a year.<br><br>
	 <div class="contents-media"><a href="media/2008-04-18_Collegian.php">Fort Collins Bike library promotes riding bikes to campus</a></div>
	 2008-04-18 - The Rocky Mountain Collegian<br>
	 CSU students and Fort Collins citizens have a new alternative to driving this week with the opening of a downtown bike library.<br><br>
	 <div class="contents-media"><a href="media/2008-04-07_7news.php">Forget Books, New Library Lends Bicycles</a></div>
	 2008-04-07 - 7News Denver<br>
	 FORT COLLINS, Colo. -- Fort Collins has a new lending library.  But this library doesn't lend out books, it lends out bicycles.<br><br>
	 <div class="contents-media"><a href="media/2008-04-06_Coloradoan.php"> Turn off engine and check out a free bike</a></div>
	 2008-04-03 - Coloradoan<br>
	 Dan and Ronnie Lipp came to Fort Collins for the first time in 1992 while on vacation.  The trip was only their second visit into Colorado.<br><br>
	 <div class="contents-media"><a href="media/2008-04-03_reporterherald.php">Check out these bikes</a></div>
	 2008-04-03 - Reporter Herald<br>
	 New York City. Paris. Amsterdam. Chicago. San Francisco.  "The bicycle library concept has been popping up in many of the chic cities" said Dave "DK" Kemp, the city of Fort Collins bicycle coordinator.<br><br>
	 <div class="contents-media"><a href="media/2008-03-28_Coloradoan.php">Fort Collins Bike Library opens April 5</a></div>
	 2008-03-28 - Coloradoan<br>
	 Fort Collins residents will soon be able to park in Old Town, borrow a bicycle and head to the Poudre River Trail - free of charge.<br><br>
	 <div class="contents-media"><a href="media/2008-03-17_Fortcollinsnow.php"> Checking Out Sweet Rides</a></div>
	 2008-03-17 - Fort Collins Now<br>
	 If given a choice between paying three dollars and rising for a gallon of gas or tooling around town on a free bicycle, which seems the most practical decision?<br><br>
	 <div class="contents-media"><a href="media/2008-01-13_Chronicle.php">COMMUNICATION TOOLS</a></div>
	 2008-01-13 - Rocky Mountain Chronicle<br>
	 Fort Collins' bike co-op tries to make good with miffed bike-shop owners.<br><br>
	 <div class="contents-media"><a href="media/2007-12-22_coloradoan.php">Council OKs bike co-op space.</a></div>
	 2007-12-22 - Coloradoan<br>
	 The Fort Collins Bike Co-op will pay $5 a year to lease prime downtown real estate, thanks to City Council.<br><br>
	 <div class="contents-media"><a href="media/2007-06-20_Chronicle.php">LIFE IN THE BIKE LANE</a></div>
	 2007-06-20 - Rocky Mountain Chronicle<br>
	 Fort Collins is becoming a sanctuary for bicyclists -- well, most of them<br><br>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
