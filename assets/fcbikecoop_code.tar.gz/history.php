<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">Our History</div>
	 <p>Formerly known as the Bike Against! collective, the Fort Collins Bicycle Co-op began in the spring of 2003 in a casual manner based out of a residential set up when all the key components necessary to start a community bike shop somehow came together at once.</p>
	 <p>During the first year we quickly realized an organization like this was really needed in Fort Collins as hundreds of people started to drop off donations of bikes, bike parts, tools, accessories, etc.  or dropped by to learn about bicycles and bicycling, performing maintenance and repairs on their own bikes assisted by experienced "bike neighbors"; all by word of mouth.</p>
	 <p>In the three following years the co-op experienced a growth of almost 100% each year  until it finally outgrew its original location.</p>
	 <p>In early 2007 an agreement was reached with the city of Fort Collins that would allow the Bike Co-op to operate out of a larger, donated, city owned space thanks to the city's transportation planning board, city council and the city's bicycle coordinator.</p>
	 <p>In February of that same year the bike co-op became a project affiliated with Bike Fort Collins and acquired Non-Profit status under their umbrella.</p>
	<p>These partnerships with the city and Bike Fort Collins were very helpful and moved the Co-op to the next level.  Once at that level the co-op continued to grow.  A board of directors was established and many of the co-op <a href="http://fcbikecoop.org/programs/">programs</a> were initiated with program coordinators to lead us forward.  The co-op began actively pursuing grants and other funding streams.</p>
	<p>Soon the co-op found that these partnerships that had once been so helpful brought with them some limitations.  While partnering with the city the co-op was unable to sell anything because of an agreement with local bike retailers.  Also, the bike library partnership was putting a significant drain on the co-op volunteer pool.  The Co-op needed to evolve yet again.  It applied and received its own 501c3 Non-profit status.  Then a lease was signed and the co-op moved into 331 North College on September 1st, 2009.  The co-op operated out of that space until 2015 when they purchased their current property at 1501 North College. The co-op moved from 331 to 1501 in October of 2015.</p>
	 <p>Since its inception, the Bike Co-op has kept thousands of  bikes out of the landfill and helped hundreds of people in the community learn to maintain and repair their own bikes.  In addition the Co-op has donated bicycles to socially and financially challenged individuals and families through several city, county, and private agencies.</p>
	 <p>Today, our volunteer run, community owned bicycle shop still holds close the same ideals and philosophy that gave birth to the project; "To create a space where people from all walks of life can learn a valuable skill in a fun, safe and embracing environment, a place where nothing is wasted and everything is for everyone."</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
