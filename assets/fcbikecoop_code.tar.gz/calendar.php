<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">Bike Co-op Hours</div>
	 <!---<p><font color="blue" size="5px"><b>The Co-op will be closed on July 4th</b></font></p>--->
	 <h2>1501 North College Avenue</h2>
	 <br>
	 <table width="80%" border="1px">
	 <tr><th width="20%">DAY</th><th>OPEN SHOP</th><th>VOLUNTEER WORK NIGHTS</th></tr>
	 <tr><td>Sunday</td><td>Public 12pm-6pm</td><td></td></tr>
	 <tr><td>Monday</td><td>Public 2pm-5pm</td><td>Volunteers 6pm-10pm</td></tr>
	 <tr><td>Tuesday</td><td>Closed</td><td></td></tr>
	 <tr><td>Wednesday</td><td>Public 2pm-5pm</td><td>Volunteers 6pm-10pm</td></tr>
	 <tr><td>Thursday</td><td>Closed</td><td></td></tr>
	 <tr><td>Friday</td><td>Public 2pm-5pm</td><td>Volunteers 6pm-10pm</td></tr>
	 <tr><td>Saturday</td><td>Closed</td><td></td></tr>
	 </table>
        <!---<div class="heading">Calendar</div><br>
	 <iframe src="http://www.google.com/calendar/embed?title=Co-op%20Events&amp;height=450&amp;wkst=1&amp;bgcolor=%23825127&amp;src=p0guq7apg924hk3nr6l08ikddk%40group.calendar.google.com&amp;color=%232952A3&amp;src=6f2at5n72kp8u13778n7iepqlc%40group.calendar.google.com&amp;color=%23A32929&amp;ctz=America%2FDenver" style=" border-width:0 " width="550" height="450" frameborder="0" scrolling="no"></iframe>
	 <br>
	 <br>
	 <iframe src="http://www.google.com/calendar/embed?title=Co-op%20Public%20Hours&amp;height=450&amp;wkst=1&amp;bgcolor=%23825127&amp;src=mg84652qrgklh8tgg6jrun1un0%40group.calendar.google.com&amp;color=%23125A12&amp;ctz=America%2FDenver" style=" border-width:0 " width="550" height="450" frameborder="0" scrolling="no"></iframe>---!>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
