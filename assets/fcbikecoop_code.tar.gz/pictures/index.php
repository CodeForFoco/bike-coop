<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         		<div class="heading">Videos</div><br>
			<iframe width="560" height="315" src="https://www.youtube.com/embed/5Ai-3EO5J38" frameborder="0" allowfullscreen></iframe><br><br>
			<iframe width="560" height="315" src="https://www.youtube.com/embed/FVyuDZbYHtM" frameborder="0" allowfullscreen></iframe><br><br>
			<iframe width="560" height="315" src="https://www.youtube.com/embed/YWY5sDNGlZ4" frameborder="0" allowfullscreen></iframe><br><br>
			<iframe width="420" height="315" src="https://www.youtube.com/embed/LQX-hxLLYjc" frameborder="0" allowfullscreen></iframe><br><br>
			<iframe width="420" height="315" src="https://www.youtube.com/embed/DR9nqAdoI2M" frameborder="0" allowfullscreen></iframe>
			<br><br>
         		<div class="heading">Photos</div><br>
	 		<div class="contents-pictures">
	 			<a href="http://fcbikecoop.org/pictures/ghana_2009/index1.html"><img src="http://fcbikecoop.org/pictures/ghana_2009/thumbs/100_3557.jpg-thumb.jpg" alt="Loading Ghana Bikes 2009"></a>
	 			<div class="contents-media"><a href="http://fcbikecoop.org/pictures/ghana_2009/index1.html">Ghana Bike Shipment 2009</a></div>
	 			Loading 450 bikes and boxes of parts into a shipping container bound for Ghana.
			</div>
	 		<div class="contents-pictures">
	 			<a href="http://fcbikecoop.org/pictures/feb_cleanup_2009/index1.html"><img src="http://fcbikecoop.org/pictures/feb_cleanup_2009/thumbs/img_1407.jpg-thumb.jpg" alt="February Shop Cleanup"></a>
	 			<div class="contents-media"><a href="http://fcbikecoop.org/pictures/feb_cleanup_2009/index1.html">Shop Spring Cleaning February 2009</a></div>
	 			With half of the shop at the Winter location there's no better time to clean the Laporte Ave. Shop.
			</div>
	 		<div class="contents-pictures">
	 			<a href="http://fcbikecoop.org/pictures/slf_2008/index1.html"><img src="http://fcbikecoop.org/pictures/slf_2008/thumbs/IMG_3499.jpg-thumb.jpg" alt="SLF Image"></a>
	 			<div class="contents-media"><a href="http://fcbikecoop.org/pictures/slf_2008/index1.html">Sustainable Living Fair 2008</a></div>
	 			This was our third year doing bike valet for the fair, parking over 1500 bikes.
			</div>
	 		<div class="contents-pictures">
	 			<a href="http://fcbikecoop.org/pictures/Salud_Health_Clinic_Block_Party/index1.html"><img src="http://fcbikecoop.org/pictures/Salud_Health_Clinic_Block_Party/thumbs/photo.jpg-thumb.jpg" alt="Salud Image"></a>
	 			<div class="contents-media"><a href="http://picasaweb.google.com/RecoveredBikes/SaludHealthClinicBlockParty#">Salud Health Clinic Block Party 2008</a></div>
	 			One of our main goals at the Co-op is to get kids riding.  At this celebration of health we gave away over 50 childrens bikes.
			</div>
	 		<div class="contents-pictures">
	 			<a href="http://fcbikecoop.org/pictures/garage_chains/index1.html"><img src="http://fcbikecoop.org/pictures/garage_chains/thumbs/Chains_4.jpg-thumb.jpg" alt="Shop Paint Image"></a>
	 			<div class="contents-media"><a href="http://fcbikecoop.org/pictures/garage_chains/index1.html">Shop Paint Job 2008</a></div>
	 			When we moved into 222 Laporte it needed some lovin'.  We put the art department to work immediately.
			</div>
	 		<div class="contents-pictures">
	 			<a href="http://fcbikecoop.org/pictures/New_Tools-Spring_08/index1.html"><img src="http://fcbikecoop.org/pictures/New_Tools-Spring_08/thumbs/imgp0942.jpg-thumb.jpg" alt="Spring Tool Image"></a>
				<div class="contents-media"><a href="http://fcbikecoop.org/pictures/New_Tools-Spring_08/index1.html">Tool Drive 2008</a></div>
	 			After a few months of collecting money at local bike shops we purchased our new tools.  A big thanks goes out to the Cycologist for picking up a large chunk of the bill.
	 		</div>
	 		<div class="contents-pictures">
	 			<a href="http://fcbikecoop.org/pictures/mikey/index1.html"><img src="http://fcbikecoop.org/pictures/mikey/thumbs/_MG_5903.jpg-thumb.jpg" alt="Mechanic Training Image"></a>
				<div class="contents-media"><a href="http://fcbikecoop.org/pictures/mikey/index1.html">Mechanic Training 2007/08</a></div>
	 			Rafael (El Jefe) leads future mechanics through our wrenching curiculum.  The co-op offers mechanic training regularly for our devoted volunteers.
	 		</div>
	 		&nbsp
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
