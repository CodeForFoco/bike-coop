<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">Building Community Through Bicycling</div>
	 <p>Fort Collins' City Manager, Darin Atteberry has best described our mission with the following words :</p>
	 <div class="contents-quote">"Bicycling is more than a mode of transportation or a recreational activity. It's a way of life, a part of who we are and what we value as a community. As a former city planner, I can tell you that the extent of bicycling (and walking) in a community is a good barometer of quality of life. Streets that are busy with bicyclists and walkers foster a sense of neighborhood and community."</div>
	 <h2>Bicycle Communities</h2>
	  We have many bike communities in Fort Collins:
	  <ul>
	   <li>Commuter cyclists, including those who bike to work, to shop and to run errands;</li>
	   <li>Recreational cyclists including the young and the elderly who pedal our bike paths;</li>
	   <li>Mountain bikers;</li>
	   <li>BMX cyclists;</li>
	   <li>Racing cyclists;</li>
	   <li>Children who bike to school;</li>
	  </ul> 
	  <p>The Bike Co-op helps to build all these communities and to keep all these bicyclists bicycling through encouragement and educational outreach.</p>
	  <p>The Bike Co-op itself is a community of cyclists who enjoy tinkering with bikes and who enjoy seeing the others discover the joys of cycling.</p>
	  <p>If you'd like to become a part of the Bike Co-op community, see our <a href="http://fcbikecoop.org/volunteers.php">Volunteers page.</a></p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
