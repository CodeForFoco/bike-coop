<?php
error_reporting(E_ALL ^ E_NOTICE);
// get the email checking code
include('../rfc3696.php');
// check ALL the POST variables
function checkSet(){
	return isset($_POST['bike_type'], $_POST['make'], $_POST['model'], $_POST['email']);
}
/**
 * This function can be used to check the sanity of variables
 *
 * @access private
 *
 * @param string $type  The type of variable can be bool, float, numeric, string, array, or object
 * @param string $string The variable name you would like to check
 * @param string $length The maximum length of the variable
 *
 * return bool
*/
function sanityCheck($string, $type, $length){
  // assign the type
  $type = 'is_'.$type;

  if(!$type($string))
    {
    return FALSE;
    }
  // now we see if there is anything in the string
  elseif(empty($string))
    {
    return FALSE;
    }
  // then we check how long the string is
  elseif(strlen($string) > $length)
    {
    return FALSE;
    }
  else
    {
    // if all is well, we return TRUE
    return TRUE;
		}
}
// check number is greater than 0 and $length digits long
// returns TRUE on success
function checkNumber($num, $length){
	if($num > 0 && strlen($num) == $length)
		{
		return TRUE;
		}
}
function checkEmail($email){
  return preg_match('/^\S+@[\w\d.-]{2,}\.[\w]{2,6}$/iU', $email) ? TRUE : FALSE;
}

session_start();
// Checks to see if the form has been submitted.
// If it hasn't, PHP ignores heaps of this code and display the form.
// If the form was submitted, it will create variables based on
// form field names and users answers.

// this will be the default message if the form accessed without POSTing
$error_msg.="Please fill in the form.<br />";

if (isset ($_POST['submit']))
	{
	foreach($_POST as $key=>$value)
		{
		$$key = $value;
		}

	// Create an empty error_msg
	$error_msg='';
	require_once('/var/www/fcbikecoop.org/root/recaptcha/recaptchalib.php');
	$privatekey = "6LcljgQAAAAAAPouSflWvq1dlfio5lRYJ4RvEsGt";
	$publickey = "6LcljgQAAAAAAL1T9O8K4Rv0n3at7RUhFQBsLnoG";
	$resp = recaptcha_check_answer ($privatekey,
				$_SERVER["REMOTE_ADDR"],
				$_POST["recaptcha_challenge_field"],
				$_POST["recaptcha_response_field"]);
	if (!$resp->is_valid)
		{
		$error = $resp->error;
		$error_msg.="* incorrect Captcha response<br />";
		}

	if(checkSet() != FALSE)
		{
		// check the POST variable bike_type is sane, and is not empty
		if(empty($_POST['bike_type'])==FALSE && sanityCheck($_POST['bike_type'], 'string', 25) != FALSE)
			{
			$bike_type = $_POST['bike_type'];
			}
		else
			{
			$error_msg.="* bike type is required.<br />";
			}

		// check the POST variable make is sane, and is not empty
		if(empty($_POST['make'])==FALSE && sanityCheck($_POST['make'], 'string', 25) != FALSE)
			{
			$make = ucwords($_POST['make']);
			}
		else
			{
			$error_msg.="* bike make name is required.<br />";
			}
		// check the POST variable model is sane, and is not empty
		if(empty($_POST['model'])==FALSE && sanityCheck($_POST['model'], 'string', 25) != FALSE)
			{
			$model = ucwords($_POST['model']);
			}
		else
			{
			$error_msg.="* bike model name is required.<br />";
			}
		// check for valid email address
		if(sanityCheck($_POST['email'], 'string', 50) != FALSE)
			{
			if (is_rfc3696_valid_email_address($_POST['email']) != FALSE)
    		{
				$email = $_POST['email'];
				}
			else
				{
				$error_msg.="* invalid Email address<br />";
				}
			}
		else
			{
			$error_msg.="* please provide an email address so we can contact you<br />";
			}
		// get the rest of the data
		$color = $_POST['color'];
		$other_color = $_POST['other_color'];
		$frame_size_inches = $_POST['frame_size_inches'];
		$frame_size_cm = $_POST['frame_size_cm'];
		$frame_material = $_POST['frame_material'];
		$suspension_front_fork = $_POST['$suspension_front_fork'];
		$wheel_size = $_POST['wheel_size'];
		$wheel_model = $_POST['wheel_model'];
		$wheel_brand = ucwords($_POST['wheel_brand']);
		$hub_brand = ucwords($_POST['hub_brand']);
		$hub_model = $_POST['hub_model'];
		$speeds = $_POST['speeds'];
		$front_derailleur_brand = ucwords($_POST['front_derailleur_brand']);
		$front_derailleur_model = $_POST['front_derailleur_model'];
		$rear_derailleur_brand = ucwords($_POST['rear_derailleur_brand']);
		$rear_derailleur_model = $_POST['rear_derailleur_model'];
		$brake_type = $_POST['brake_type'];
		$accessories = $_POST['accessories1'];
		$accessories .= ", ".$_POST['accessories2'];
		$accessories .= ", ".$_POST['accessories3'];
		$accessories .= ", ".$_POST['accessories4'];
		$accessories .= ", ".$_POST['accessories5'];
		$accessories .= ", ".$_POST['accessories6'];
		$accessories .= ", ".$_POST['accessories7'];
		$accessories .= ", ".$_POST['accessories8'];
		$accessories .= ", ".$_POST['accessories9'];
		$accessories .= ", ".$_POST['accessories10'];
		$accessories .= ", ".$_POST['accessories11'];
		$accessories .= ", ".$_POST['accessories12'];
		$accessories .= ", ".$_POST['accessories13'];
		$accessories .= ", ".$_POST['accessories14'];
		$condition = $_POST['condition'];
		$comments = $_POST['somments'];
		$price = $_POST['price'];
		$upload_image1 = $_POST['upload_image1'];
		$upload_image2 = $_POST['upload_image2'];
		$upload_image3 = $_POST['upload_image3'];
		$upload_image4 = $_POST['upload_image4'];
		$email = $_POST['email'];
		}
	}

// END BASIC ERROR CHECKING
// You need to create your own code to validate the information
// and allowed values - never send "unclean" user responses
// to a database without cleaning them up and
// checking for allowed answers.
// Google for "SQL injection" and "insecure contact form"

// Do this if no errors were detected AND form has been submitted
if ($error_msg == '' && isset($_POST['submit']))
	{
	//Close the session
	session_write_close();
	// Connect to the MySQL database
	// Include our login information
	include('../db_login.php');
	//Connect
	$db_error='There was a problem accessing our system.  Please try again later.';
	$connection = @mysql_connect($db_host, $db_username, $db_password) or die($db_error);
	// Select the database
	$db_select = @mysql_select_db($db_database) or die($db_error);

	// Build our query here and check each variable with mysql_real_escape_string()
	$query = sprintf("INSERT INTO BIKES4SALE (Type, Make, Model, Color, OtherColor, FrameSize, FrameMatl, Fork, WheelSize, WheelModel, WheelBrand, HubBrand, HubModel, Speeds, FrontDerailleurBrand, FrontDerailleurModel, RearDerailleurBrand, RearDerailleurModel, BrakeType, Accessories, Cond, Comments, Price, EntryDate) VALUES( '%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%d','%s','%s','%s','%s','%s','%s','%s','%s','%s',CURDATE())",

		mysql_real_escape_string($bike_type),
		mysql_real_escape_string($make),
		mysql_real_escape_string($model),
		mysql_real_escape_string($color),
		mysql_real_escape_string($other_color),
		mysql_real_escape_string($frame_size),
		mysql_real_escape_string($frame_material),
		mysql_real_escape_string($suspension_front_fork),
		mysql_real_escape_string($wheel_size),
		mysql_real_escape_string($wheel_model),
		mysql_real_escape_string($wheel_brand),
		mysql_real_escape_string($hub_brand),
		mysql_real_escape_string($hub_model),
		mysql_real_escape_string($speeds),
		mysql_real_escape_string($front_derailleur_brand),
		mysql_real_escape_string($front_derailleur_model),
		mysql_real_escape_string($rear_derailleur_brand),
		mysql_real_escape_string($rear_derailleur_model),
		mysql_real_escape_string($brake_type),
		mysql_real_escape_string($accessories),
		mysql_real_escape_string($condition),
		mysql_real_escape_string($comments),
		mysql_real_escape_string($price),
		mysql_real_escape_string($email));
	// run the query
//	$mysql_result = mysql_db_query ($query) or die($db_error);
	// run the query
	if(!mysql_query($query))
		{
		echo 'Query failed '.mysql_error();
		echo $query;
		exit();
		}
	// No errors were detected.
	// Send the Craigslist posting HTML file
//define the receiver of the email
$to = $email;
//define the subject of the email
$subject = 'Craigslist Posting'; 
// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\n";
$headers .= "Content-type:text/html;charset=iso-8859-1" . "\n";
$headers .= "From: webmaster@fcbikecoop.org";
$message = <<<MESSAGE
<h1>$frame_size cm $color and $other_color $make $model - $bike_type \$$price</h1>

<img src="http://fcbikecoop.org/images/craigslist/small.jpg" align="right" width="320px">
<font size="4" color="red"><b>Frame:</b></font><br />
$frame_size_cm cm \($frame_size_inches inches/) $frame_material frame $front_suspension_fork<br />
(See our <a href="http://fcbikecoop.org/craigslist/sizing.php">Frame sizing chart</a>.)<br /><br />

<font size="4" color="red"><b>Drivetrain:</b></font><br />
$speeds speeds, with $shifter_brand $shifter_model $shifter_type shifters.
$front_deraileur_brand $front_deraileur_model front deraileur.
$rear_deraileur_brand $rear_deraileur_model rear deraileur.
<br /><br />

<font size="4" color="red"><b>Wheels:</b></font><br />
$wheel_size\" $wheel_brand $wheel_model wheels with $hub_brand $hub_model hubs.<br /><br />

<font size="4" color="red"><b>Brakes:</b></font><br />
$brake_type<br /><br />

<font size="4" color="red"><b>Accessories:</b></font><br />
This bike has the following accessories:

<ul>
	<li> $accessories0</li>
	<li> $accessories1</li>
	<li> $accessories2</li>
	<li> $accessories3</li>
	<li> $accessories4</li>
	<li> $accessories5</li>
	<li> $accessories6</li>
	<li> $accessories7</li>
	<li> $accessories8</li>
	<li> $accessories9</li>
	<li> $accessories10</li>
	<li> $accessories11</li>
	<li> $accessories12</li>
	<li> $accessories13</li>
	<li> $accessories14</li>
</ul>

<font size="4" color="red"><b>Condition:</b></font><br />
This bike is in <b>$condition</b> condition.<br /><br />

<font size="4" color="red"><b>Price:</b></font><br />
<b>/$$price</b><br /><br />

<font size="4" color="red"><b>Additional Comments:</b></font><br />
$comments<br /><br />

<font size="4" color="red"><b>Pictures:</b></font><br />
<b>Click on the images below to view larger:</b>
<p><a href="http://fcbikecoop.org/images/craigslist/small.jpg"><img src="http://fcbikecoop.org/images/craigslist/large.jpg/"></a></p>
<hr size="5" noshade>
<p align="center"><b>Proceeds from the sale of this bike will benefit
<a href="http://fcbikecoop.org">The Fort Collins Bike Co-op</a>
and its <a href="http://fcbikecoop.org/programs.php">programs</a>.</p>

<p align="center"><b>To test ride this bike
<a href="http://fcbikecoop.org/contact.php">stop by our shop</a> during <a href="http://fcbikecoop.org/calendar.php">open hours</a><b></p>

<p align="center">
<table border="0" align="center">
<tr> <td colspan="3" bgcolor="black"></td></tr>
<tr> <td colspan="1" align="center"><a href="http://fcbikecoop.org"><img width="150px" height="150px" src="http://fcbikecoop.org/posters/logo/fcbikecoop-white.png"></a></td><td colspan="2" align="center"><b>Fort Collins Bike Co-op</b></br>"Building Community Through Bicycling"</td></tr>
<tr> <td colspan="3" bgcolor="black"></td></tr>
<tr> <td>Mon:</td> <td><b>CLOSED</b></td>
     <td rowspan="7" align="center" valign="middle"><b>We are located at:<br />
<a href="http://maps.google.com/maps?f=q&source=s_q&hl=en&geocode=&q=fort+collins+bike+coop&aq=&sll=37.0625,-95.677068&sspn=50.956929,89.560547&ie=UTF8&hq=fort+collins+bike+coop&hnear=&t=h&z=13&iwloc=A">1501 North College Ave.<br />
Fort Collins, CO 80524</a></b> </td></tr>
<tr> <td>Tue:</td> <td><b>CLOSED</b></td>   </tr>
<tr> <td>Wed:</td> <td><b>2pm-5pm</b></td>   </tr>
<tr> <td>Thu:</td> <td><b>CLOSED</b></td>   </tr>
<tr> <td>Fri:</td> <td><b>2pm-5pm</b></td>  </tr>
<tr> <td>Sat:</td> <td><b>CLOSED</b></td>   </tr>
<tr> <td>Sun:</td> <td><b>Noon-6pm</b></td> </tr>
<tr> <td colspan="3" bgcolor="black"></td></tr>
</table>
</p>

<hr size="5" noshade>

<h1 align="center">THIS POSTING WILL BE REMOVED WHEN THE BIKE IS SOLD.  IF YOU ARE INTERESTED IN THIS BIKE AND CANNOT FIND THIS POSTING AGAIN THE BIKE IS NO LONGER AVAILABLE.</h1>
MESSAGE;

//send the email
$mail_sent = @mail( $to, $subject, $message, $headers );
//if the message is sent successfully print "Mail sent". Otherwise print "Mail failed" 
echo $mail_sent ? "Mail sent" : "Mail failed";

//	$message = include('../../craigslist/craigs.php');
//	mail( $email,"Craigslist Posting",$message,"From: webmaster@fcbikecoop.org");

	// end of email to staff
	// Redirect to confirmation page.
//	header ("Location: http:volunteer_form_done.php");
	exit;
}

// If PHP is still reading this, it must be the first page visit,
// OR an error was detected.
// Display the HTML page and your signup form.
include_once('/var/www/fcbikecoop.org/root/header.php');

// If the form has been submitted,
// display the error messages above the form.
if(isset($_POST['submit']))
{
echo "<font color=\"yellow\" size=\"3\">The following problems were detected:<br><i>" .$error_msg ."</i></font><br>";
}
?>
<form method="POST" action="<?php echo $PHP_SELF;?>" enctype="multipart/form-data">
   <div class="heading">Craigslist Posting Generator</div></td>
<table border="0">
	<tr>
		<td></td>

		<td><input type="hidden" name="form[status]" id="status" value="block"  /><div class="formClr"></div></td>
		<td></td>
	</tr>
	<tr>
		<td>Bike&nbsp;Type&nbsp;: (required)</td>
		<td><select  name="bike_type"  id="bike_type"  ><option  value=" "> </option><option  value="Mountain">Mountain</option><option  value="Full Suspension Mountain">Full Suspension Mountain</option><option  value="Road">Road</option><option  value="Cruiser">Cruiser</option><option  value="Hybrid">Hybrid</option><option  value="Commuter">Commuter</option><option  value="Ladies">Ladies</option><option  value="Mixtie">Mixtie</option><option  value="Kids">Kids</option><option  value="BMX">BMX</option><option  value="Tandem">Tandem</option></select></td>

		<td></td>
	</tr>
	<tr>
		<td>Make : (required)</td>
		<td><input type="text" value="" size="20"  name="make" id="make" value="<?php echo $make ?>"> <b>**</b> </td>
		<td></td>
	</tr>
	<tr>

		<td>Model :</td>
		<td><input type="text" value="" size="20"  name="model" id="model" /></td>
		<td></td>
	</tr>
	<tr>
		<td>Color :</td>
		<td><select  name="color"  id="color"  ><option  value=""></option><option  value="Red">Red</option><option  value="Orange">Orange</option><option  value="Yellow">Yellow</option><option  value="Green">Green</option><option  value="Blue">Blue</option><option  value="Indigo">Indigo</option><option  value="Violet">Violet</option><option  value="Black">Black</option><option  value="Brown">Brown</option><option  value="Cream">Cream</option><option  value="Gold">Gold</option><option  value="Grey">Grey</option><option  value="Purple">Purple</option><option  value="Silver">Silver</option><option  value="Teal">Teal</option><option  value="White">White</option></select></td>

		<td></td>
	</tr>
	<tr>
		<td>Other Color :</td>
		<td><input type="text" value="" size="20"  name="other_color" id="other_color" /></td>
		<td></td>
	</tr>
	<tr>

		<td>Frame Size (in) :</td>
		<td><select  name="frame_size_inches"  id="frame_size_inches"  ><option  value=""></option><option  value="10 in">10 in</option><option  value="11 in">11 in</option><option  value="12 in">12 in</option><option  value="13 in">13 in</option><option  value="14 in">14 in</option><option  value="14.5 in">14.5 in</option><option  value="15 in">15 in</option><option  value="15.5 in">15.5 in</option><option  value="16 in">16 in</option><option  value="16.5 in">16.5 in</option><option  value="17 in">17 in</option><option  value="17.5 in">17.5 in</option><option  value="18 in">18 in</option><option  value="18.5 in">18.5 in</option><option  value="19 in">19 in</option><option  value="19.5 in">19.5 in</option><option  value="20 in">20 in</option><option  value="20.5 in">20.5 in</option><option  value="21 in">21 in</option><option  value="21.5 in">21.5 in</option><option  value="22 in">22 in</option><option  value="23 in">23 in</option></select></td>

		<td>You <strong>must</strong> enter a frame size!</td>
	</tr>
	<tr>
		<td>Frame Size (cm) :</td>
		<td><select  name="frame_size_cm"  id="frame_size_cm"  ><option  value=""></option><option  value="50 cm">50 cm</option><option  value="51 cm">51 cm</option><option  value="52 cm">52 cm</option><option  value="53 cm">53 cm</option><option  value="54 cm">54 cm</option><option  value="55 cm">55 cm</option><option  value="56 cm">56 cm</option><option  value="57 cm">57 cm</option><option  value="58 cm">58 cm</option><option  value="59 cm">59 cm</option><option  value="60 cm">60 cm</option><option  value="61 cm">61 cm</option><option  value="62 cm">62 cm</option><option  value="63 cm">63 cm</option><option  value="64 cm">64 cm</option></select></td>

		<td>See <a href="http://www.sheldonbrown.com/frame-sizing.html">Sheldon Brown's article on bicycle sizing</a> for more information.</td>
	</tr>
	<tr>
		<td>Frame material : (required)</td>
		<td><select  name="frame_material"  id="frame_material"  ><option  value=" "> </option><option  value="Steel">Steel</option><option  value="Aluminum">Aluminum</option><option  value="Titanium">Titanium</option><option  value="Carbon Fiber">Carbon Fiber</option></select></td>

		<td></td>
	</tr>
	<tr>
		<td></td>
		<td><input  name="suspension_front_fork" type="checkbox" value="with front suspension fork" id="suspension_front_fork0"  /><label for="suspension_front_fork0">with front suspension fork</label></td>
		<td></td>
	</tr>
	<tr>

		<td>Wheel Size : (required)</td>
		<td><select  name="wheel_size"  id="wheel_size"  ><option  value=" "> </option><option  value="10&quot;">10&quot;</option><option  value="12&quot;">12&quot;</option><option  value="16&quot;">16&quot;</option><option  value="20&quot;">20&quot;</option><option  value="24&quot;">24&quot;</option><option  value="26&quot; (decimal/ISO 559)">26&quot; (decimal/ISO 559)</option><option  value="26&quot; (fraction/ISO 590)">26&quot; (fraction/ISO 590)</option><option  value="27&quot;">27&quot;</option><option  value="650b">650b</option><option  value="700c">700c</option></select></td>

		<td>Wheel sizes can be confusing.  See <a href="http://www.sheldonbrown.com/tire_sizing.html">Sheldon Brown's article on bicycle tire sizing</a> for more information.</td>
	</tr>
	<tr>
		<td>Wheel Model :</td>
		<td><input type="text" value="" size="20"  name="wheel_model" id="wheel_model" /></td>
		<td></td>

	</tr>
	<tr>
		<td>Wheel Brand :</td>
		<td><input type="text" value="" size="20"  name="wheel_brand" id="wheel_brand" /></td>
		<td></td>
	</tr>
	<tr>
		<td>Hub Brand :</td>

		<td><input type="text" value="" size="20"  name="hub_brand" id="hub_brand" /></td>
		<td></td>
	</tr>
	<tr>
		<td>Hub Model :</td>
		<td><input type="text" value="" size="20"  name="hub_model" id="hub_model" /></td>
		<td></td>
	</tr>

	<tr>
		<td>Speeds : (required)</td>
		<td><select  name="speeds"  id="speeds"  ><option  value=""></option><option  value="1">1</option><option  value="3">3</option><option  value="5">5</option><option  value="6">6</option><option  value="7">7</option><option  value="8">8</option><option  value="9">9</option><option  value="10">10</option><option  value="12">12</option><option  value="14">14</option><option  value="16">16</option><option  value="18">18</option><option  value="20">20</option><option  value="21">21</option><option  value="24">24</option><option  value="27">27</option></select><div class="formClr"></div><span id="component196" class="formNoError">How many speeds does this bike have?</span></td>

		<td></td>
	</tr>
	<tr>
		<td>Shifter Type :</td>
		<td><select  name="shifter_type"  id="shifter_type"  ><option  value=" "> </option><option  value="single speed">single speed</option><option  value="trigger">trigger</option><option  value="grip">grip</option><option  value="thumb friction">thumb friction</option><option  value="thumb indexed">thumb indexed</option><option  value="friction on downtube">friction on downtube</option><option  value="friction on stem">friction on stem</option><option  value="integrated">integrated</option><option  value="nexus">nexus</option><option  value="bar end">bar end</option></select></td>

		<td></td>
	</tr>
	<tr>
		<td>Shifter Brand :</td>
		<td><input type="text" value="" size="20"  name="shifter_brand" id="shifter_brand" /></td>
		<td></td>
	</tr>
	<tr>

		<td>Shifter Model :</td>
		<td><input type="text" value="" size="20"  name="shifter_model" id="shifter_model" /></td>
		<td></td>
	</tr>
	<tr>
		<td>Front&nbsp;Derailleur&nbsp;Brand&nbsp;:</td>

		<td><input type="text" value="" size="20"  name="front_derailleur_brand" id="front_deraileur_brand" /></td>
		<td></td>
	</tr>
	<tr>
		<td>Front&nbsp;Derailleur&nbsp;Model&nbsp;:</td>
		<td><input type="text" value="" size="20"  name="front_derailleur_model" id="front_deraileur_model" /></td>
		<td></td>

	</tr>
	<tr>
		<td>Rear Derailleur Brand :</td>
		<td><input type="text" value="" size="20"  name="rear_derailleur_brand" id="rear_deraileur_brand" /></td>
		<td></td>
	</tr>
	<tr>
		<td>Rear Derailleur Model :</td>

		<td><input type="text" value="" size="20"  name="form[rear_derailleur_model]" id="rear_deraileur_model" /></td>
		<td></td>
	</tr>
	<tr>
		<td>Brake Type :</td>
		<td><select  name="brake_type"  id="brake_type"  ><option  value=" "> </option><option  value="V-Brake">V-Brake</option><option  value="Cantilever">Cantilever</option><option  value="Coaster">Coaster</option><option  value="Center Pull">Center Pull</option><option  value="Side Pull">Side Pull</option><option  value="Dual Pivot">Dual Pivot</option><option  value="Disc">Disc</option></select></td>

		<td></td>
	</tr>
	<tr>
		<td>Accessories :</td>
		<td><input  name="form[accessories][]" type="checkbox" value=" Rear Cargo Rack" id="accessories0"  /><label for="accessories0"> Rear Cargo Rack</label><br/><input  name="form[accessories][]" type="checkbox" value=" Front Basket/Rack" id="accessories1"  /><label for="accessories1"> Front Basket/Rack</label><br/><input  name="form[accessories][]" type="checkbox" value=" Bell (ding! ding!)" id="accessories2"  /><label for="accessories2"> Bell (ding! ding!)</label><br/><input  name="form[accessories][]" type="checkbox" value=" Water Bottle Cage(s)" id="accessories3"  /><label for="accessories3"> Water Bottle Cage(s)</label><br/><input  name="form[accessories][]" type="checkbox" value=" Kick Stand" id="accessories4"  /><label for="accessories4"> Kick Stand</label><br/><input  name="form[accessories][]" type="checkbox" value=" Fenders" id="accessories5"  /><label for="accessories5"> Fenders</label><br/><input  name="form[accessories][]" type="checkbox" value=" Headlight" id="accessories6"  /><label for="accessories6"> Headlight</label><br/><input  name="form[accessories][]" type="checkbox" value=" Taillight" id="accessories7"  /><label for="accessories7"> Taillight</label><br/><input  name="form[accessories][]" type="checkbox" value=" Frame Pump" id="accessories8"  /><label for="accessories8"> Frame Pump</label><br/><input  name="form[accessories][]" type="checkbox" value=" Rear View Mirror" id="accessories9"  /><label for="accessories9"> Rear View Mirror</label><br/><input  name="form[accessories][]" type="checkbox" value=" Pannier(s)" id="accessories10"  /><label for="accessories10"> Pannier(s)</label><br/><input  name="form[accessories][]" type="checkbox" value=" Saddle Bag" id="accessories11"  /><label for="accessories11"> Saddle Bag</label><br/><input  name="form[accessories][]" type="checkbox" value=" Computer" id="accessories12"  /><label for="accessories12"> Computer</label><br/><input  name="form[accessories][]" type="checkbox" value=" Chain Guard" id="accessories13"  /><label for="accessories13"> Chain Guard</label><br/><input  name="form[accessories][]" type="checkbox" value=" Skirt/Coat Guard" id="accessories14"  /><label for="accessories14"> Skirt/Coat Guard</label><br/><div class="formClr"></td>

		<td>Check all which apply.</td>
	</tr>
	<tr>
		<td>Condition : (required)</td>
		<td><select  name="condition"  id="condition"  ><option  value=" "> </option><option  value="Excellent">Excellent</option><option  value="Good">Good</option><option  value="Fair">Fair</option></select></td>
		<td></td>

	</tr>
	<tr>
		<td>Additional&nbsp;Notes&nbsp;:</td>
		<td><textarea cols="40" rows="8" name="comments" id="comments" ></textarea><div class="formClr"></div><span id="component207" class="formNoError"></span></td>
		<td>Give the bike some character.  Try and make it seem unique.  Suggest good uses for this particular bike, and use positive words.</td>
	</tr>

	<tr>
		<td>Price : $ (required)</td>
		<td><input type="text" value="" size="20"  name="price" id="price" /><div class="formClr"></div><span id="component208" class="formNoError">Please ad a price</span></td>
		<td></td>
	</tr>
	<tr>
		<td>Upload Image 1 : (required)</td>

		<td><input type="hidden" name="MAX_FILE_SIZE" value="20000000" /><input type="file" name="form[upload_image1]" id="upload_image1"  /></td>
		<td>You must include at least one picture of the bike.</td>
	</tr>
	<tr>
		<td>Upload Image 2 :</td>
		<td><input type="hidden" name="MAX_FILE_SIZE" value="20000000" /><input type="file" name="upload_image2" id="upload_image2"  /></td>
		<td>Images are now automatically re-sized for display on the web.</td>

	</tr>
	<tr>
		<td>Upload Image 3 :</td>
		<td><input type="hidden" name="MAX_FILE_SIZE" value="20000000" /><input type="file" name="upload_image3" id="upload_image3"  /></td>
		<td>When taking photos, make sure that the bike takes up the entire frame.</td>
	</tr>
	<tr>

		<td>Upload Image 4 :</td>
		<td><input type="hidden" name="MAX_FILE_SIZE" value="20000000" /><input type="file" name="form[upload_image4]" id="upload_image4"  /></td>
		<td>Use up to 3 additional photos to highlight special features of the bike.</td>
	</tr>
	<tr>
		<td>Your email : (required)</td>
		<td><input type="text" size="20"  name="email" id="email" /><div class="formClr"></div><span id="component213" class="formNoError">Please add a value for email</span></td>

		<td></td>
	</tr>
</table>

<p>Please type the 2 words that appear in the box below.  If you can't read them, click on the "get a new challenge" icon in the box to get a new pair of words.  Using this prevents spammers from getting into our web pages.<p>
<?php
require_once('/var/www/fcbikecoop.org/root/recaptcha/recaptchalib.php');
$publickey = "6LcljgQAAAAAAL1T9O8K4Rv0n3at7RUhFQBsLnoG";
echo recaptcha_get_html($publickey, $error);
?>
<br><br><input type="submit" value="Send" name="submit">
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
