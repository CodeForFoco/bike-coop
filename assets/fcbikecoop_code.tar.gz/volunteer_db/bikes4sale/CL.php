<?php
error_reporting(E_ALL ^ E_NOTICE);
// get the email checking code
include('../rfc3696.php');
// check ALL the POST variables
function checkSet(){
	return isset($_POST['bike_type'], $_POST['make'], $_POST['model'], $_POST['email']);
}
/**
 * This function can be used to check the sanity of variables
 *
 * @access private
 *
 * @param string $type  The type of variable can be bool, float, numeric, string, array, or object
 * @param string $string The variable name you would like to check
 * @param string $length The maximum length of the variable
 *
 * return bool
*/
function sanityCheck($string, $type, $length){
  // assign the type
  $type = 'is_'.$type;

  if(!$type($string))
    {
    return FALSE;
    }
  // now we see if there is anything in the string
  elseif(empty($string))
    {
    return FALSE;
    }
  // then we check how long the string is
  elseif(strlen($string) > $length)
    {
    return FALSE;
    }
  else
    {
    // if all is well, we return TRUE
    return TRUE;
		}
}

function checkEmail($email){
  return preg_match('/^\S+@[\w\d.-]{2,}\.[\w]{2,6}$/iU', $email) ? TRUE : FALSE;
}

/* Image uploading and resizing has been removed, but the code remains for posterity
function imageResize($filename)
	{
	#This script will take a given image file and create a web friendly size version of it with the name filename-small.extension

//	#first we set the filename
//	$filename = '/var/www/fcbikecoop.org/root/craigslist/images/test.gif';

	#test to verify that we actually have an image
	#This covers JPG PNG and GIF, perhaps more.
	if(!shell_exec("file $filename | grep -q \"image\""))
		{
		#we need to be concious of files called foo.jpg.bar.jpg while rare, these will trip up typical rename scripts
		#First explode the filename into segments divided by "."
		$exts = explode(".", $filename);
	
		#Count the number of segments that we exploded into
		$n = count($exts)-1;
		
		#Set $exts to the last segement of the above explode command
		$exts = $exts[$n]; 
		
		#Replace the last .$exts with -small.$exts 
		$newname = preg_replace("/\.$exts$/i", "-small.$exts", $filename);
		
		#Finally create a small image with no more than 307200 pixels (Typically 640x480 or 480X640)
		shell_exec("convert $filename -resize \"307200@>\" $newname");
		Echo "$filename converted";
		//shell_exec("convert -size 120x120 $filename -resize 307200@ +profile '*' $newname");

		#In the above command, the > symbol insures that we don't enlarge small images, however it still outputs an empty $newfile.

		#check for empty files and replace them with non-empty files
		if(filesize($newname) == 0)
			{
		if (!copy($filename, $newname))
				{
				#Proabaly a file permission mistake if we get here
    		echo "failed to copy $filename...";
				}
			}
		return $newname;
		}
	}
*/

session_start();
// Checks to see if the form has been submitted.
// If it hasn't, PHP ignores heaps of this code and display the form.
// If the form was submitted, it will create variables based on
// form field names and users answers.

// set the initial value for the speeds in order to control the appearance of the form
// $speeds = "1";

// this will be the default message if the form accessed without POSTing
$error_msg.="Please fill in the form.<br />";

if (isset ($_POST['submit']))
	{
	foreach($_POST as $key=>$value)
		{
		$$key = $value;
		}

	// Create an empty error_msg
	$error_msg='';

	if(checkSet() != FALSE)
		{
		// check the POST variable bike_type is sane, and is not empty
		if(empty($_POST['bike_type'])==FALSE && sanityCheck($_POST['bike_type'], 'string', 25) != FALSE)
			{
			$bike_type = $_POST['bike_type'];
			}
		else
			{
			$error_msg.="* bike type is required<br />";
			}

		// check the POST variable make is sane, and is not empty
		if(empty($_POST['make'])==FALSE && sanityCheck($_POST['make'], 'string', 25) != FALSE)
			{
			$make = ucwords($_POST['make']);
			}
		else
			{
			$error_msg.="* bike make name is required<br />Warning: filesize() [function.filesize]: stat failed";
			}
		// check the POST variable model is sane, and is not empty
		if(empty($_POST['model'])==FALSE && sanityCheck($_POST['model'], 'string', 25) != FALSE)
			{
			$model = ucwords($_POST['model']);
			}
		else
			{
			$error_msg.="* bike model name is required<br />";
			}
		// check the POST variable color
		if(empty($_POST['color'])==FALSE)
			{
			$color = $_POST['color'];
			}
		else
			{
			$error_msg.="* please specify the bike's color<br />";
			}
		// check for valid email address
		if(sanityCheck($_POST['email'], 'string', 50) != FALSE)
			{
			if (is_rfc3696_valid_email_address($_POST['email']) != FALSE)
    		{
				$email = $_POST['email'];
				}
			else
				{
				$error_msg.="* invalid Email address<br />";
				}
			}
		else
			{
			$error_msg.="* please provide an email address so we can contact you<br />";
			}
		// check the POST variable speeds
		if(empty($_POST['speeds'])==FALSE)
			{
			$speeds = $_POST['speeds'];
			}
		else
			{
			$error_msg.="* you must specify how many speeds the bike has<br />";
			}
		// check the POST variable frame_size
		if(empty($_POST['Size'])==FALSE)
			{
			$frame_size = $_POST['Size'];
			}
		else
			{
			$error_msg.="* you must enter a frame size<br />";
			}
		// check the POST variable frame_material
		if(empty($_POST['frame_material'])==FALSE)
			{
			$frame_material = $_POST['material'];
			}
		else
			{
			$error_msg.="* you must enter a frame material<br />";
			}
		// check the POST variable wheel_size.
		if(empty($_POST['wheel_size'])==FALSE)
			{
			$wheel_size = $_POST['wheel_size'];
			}
		else
			{
			$error_msg.="* you must enter a wheel size<br />";
			}
		// check the POST variable condition
		if(empty($_POST['condition'])==FALSE)
			{
			$condition = $_POST['condition'];
			}
		else
			{
			$error_msg.="* please specify the bike's condition<br />";
			}
		// check the POST variable price
		if(empty($_POST['price'])==FALSE)
			{
			$price = $_POST['price'];
			}
		else
			{
			$error_msg.="* please specify a price<br />";
			}
		// get the rest of the data
		$frame_material = $_POST['frame_material'];
		$suspension_front_fork = $_POST['suspension_front_fork'];
		$wheel_model = ucwords($_POST['wheel_model']);
		$wheel_brand = ucwords($_POST['wheel_brand']);
		// Concatenate the wheel attributes for the email.
		$wheel = $wheel_size." ".$wheel_brand." ".$wheel_model;
		$hub_brand = ucwords($_POST['hub_brand']);
		$hub_model = ucwords($_POST['hub_model']);
		// Concatenate the hub attributes (if specified) for the email.
		if(empty($_POST['hub_brand'])==FALSE)
			{
			$hubs = "with ".$hub_brand." ".$hub_model." hubs";
			}
		// if multi-speed bike, shifter and derailleur details are required
		if($speeds > 1)
			{
			$drivetrain = $speeds." speeds";
			if(empty($_POST['shifter_type'])==FALSE)
				{
				$shifter_type = $_POST['shifter_type'];
				$drivetrain .= ", with ".$shifter_type;
				if(empty($_POST['shifter_brand'])==FALSE)
					{
					$shifter_brand = ucwords($_POST['shifter_brand']);
					$drivetrain .= " ".$shifter_brand;
					if(empty($_POST['shifter_model'])==FALSE)
						{
						$shifter_model = ucwords($_POST['shifter_model']);
						$drivetrain .= " ".$shifter_model;
						}
					}
				$drivetrain .= " shifters";
				if(empty($_POST['front_derailleur_brand'])==FALSE)
					{
					$front_derailleur_brand = ucwords($_POST['front_derailleur_brand']);
					$drivetrain .= ", ".$front_derailleur_brand;
					if(empty($_POST['front_derailleur_model'])==FALSE)
						{
						$front_derailleur_model = ucwords($_POST['front_derailleur_model']);
						$drivetrain .= " ".$front_derailleur_model;
						}
					$drivetrain .= " front derailleur";
					}
				if(empty($_POST['rear_derailleur_brand'])==FALSE)
					{
					$rear_derailleur_brand = ucwords($_POST['rear_derailleur_brand']);
					$drivetrain .= " and ".$rear_derailleur_brand;
					if(empty($_POST['rear_derailleur_model'])==FALSE)
						{
						$rear_derailleur_model = ucwords($_POST['rear_derailleur_model']);
						$drivetrain .= " ".$rear_derailleur_model;
						}
					$drivetrain .= " rear derailleur";
					}
				}
			}
		else
			{
			$drivetrain = "single speed";
			}

		$brake_type = $_POST['brake_type'];
		if ($_POST['acc1'] == 1) {$accessories = "Rear Cargo Rack";}
		if ($_POST['acc2'] == 1) {$accessories .= ", Front Basket/Rack";}
		if ($_POST['acc3'] == 1) {$accessories .= ", Bell";}
		if ($_POST['acc4'] == 1) {$accessories .= ", Water Bottle Cage(s) ";}
		if ($_POST['acc5'] == 1) {$accessories .= ", Kick Stand";}
		if ($_POST['acc6'] == 1) {$accessories .= ", Fenders";}
		if ($_POST['acc7'] == 1) {$accessories .= ", Headlight";}
		if ($_POST['acc8'] == 1) {$accessories .= ", Taillight";}
		if ($_POST['acc9'] == 1) {$accessories .= ", Frame Pump";}
		if ($_POST['acc10'] == 1) {$accessories .= ", Rear View Mirror";}
		if ($_POST['acc11'] == 1) {$accessories .= ", Pannier(s)";}
		if ($_POST['acc12'] == 1) {$accessories .= ", Saddle Bag";}
		if ($_POST['acc13'] == 1) {$accessories .= ", Computer";}
		if ($_POST['acc14'] == 1) {$accessories .= ", Chain Guard";}
		if ($_POST['acc15'] == 1) {$accessories .= ", Skirt/Coat Guard ";}
		$accessories = ltrim($accessories, ", ");
		$condition = $_POST['condition'];
		$comments = $_POST['comments'];
		$price = $_POST['price'];
		}
	}
/* Image uploade and resize has been removed from this file, but the code is left so it can be stolen later
// Now check for the uploaded image file(s)
// Do this if no errors were detected AND form has been submitted
if ($error_msg == '' && isset($_POST['submit']))
	{
	// Where the file is going to be placed 
	$target_path = "/var/www/fcbikecoop.org/root/volunteer_db/bikes4sale/images/";
	// see if the first image was specified (it's required)
	if (empty($_FILES['upload_image1']['name'])==FALSE)
		{
		//strip non alpha-numeric characters from $make and $model
		$make_clean = preg_replace("/[^a-zA-Z0-9]/", "", $make);
		$model_clean = preg_replace("/[^a-zA-Z0-9]/", "", $model);
		// get the file extension
		$ext = pathinfo($_FILES['upload_image1']['name'], PATHINFO_EXTENSION);
		// set the filename
		$filename1 = date("ymd")."_".$make_clean."_".$model_clean."_1".".".$ext;
		// Add the filename to our target path.  
		// Result is ".../images/filename.extension"
		$file_path_1 = $target_path.$filename1; 
		if (move_uploaded_file($_FILES['upload_image1']['tmp_name'], $file_path_1)==FALSE)
			{
			$error_msg.="* There was an error uploading the file ".  basename( $_FILES['upload_image1']['name']).", please try again!<br />";
			}
		else
			{
			$image1 = "fcbikecoop.org/volunteer_db/bikes4sale/images/".$filename1;
			$smallImage1 = substr(imageResize($file_path_1),29);
			}
		}
	else {$error_msg.="* You must upload at least one image<br />";}
	if (empty($_FILES['upload_image2']['name'])==FALSE)
		{
		// get the file extension
		$ext = pathinfo($_FILES['upload_image2']['name'], PATHINFO_EXTENSION);
		// set the filename
		$filename2 = date("ymd")."_".$make_clean."_".$model_clean."_2".".".$ext;
		// Add the filename to our target path.  
		//Result is "images/filename.extension"
		$file_path_2 = $target_path.$filename2; 
		if (move_uploaded_file($_FILES['upload_image2']['tmp_name'], $file_path_2)==FALSE)
			{
			$error_msg.="* There was an error uploading the file ".  basename( $_FILES['upload_image2']['name']).", please try again!<br />";
			}
		else
			{
			$image2 = "fcbikecoop.org/volunteer_db/bikes4sale/images/".$filename2;
			$smallImage2 = substr(imageResize($file_path_2),29);
			}
		}
	if (empty($_FILES['upload_image3']['name'])==FALSE)
		{
		// get the file extension
		$ext = pathinfo($_FILES['upload_image3']['name'], PATHINFO_EXTENSION);
		// set the filename
		$filename3 = date("ymd")."_".$make_clean."_".$model_clean."_3".".".$ext;
		// Add the filename to our target path.  
		//Result is "images/filename.extension"
		$file_path_3 = $target_path.$filename3; 
		if (move_uploaded_file($_FILES['upload_image3']['tmp_name'], $file_path_3)==FALSE)
			{
			$error_msg.="* There was an error uploading the file ".  basename( $_FILES['upload_image3']['name']).", please try again!<br />";
			}
		else
			{
			$image3 = "fcbikecoop.org/volunteer_db/bikes4sale/images/".$filename3;
			$smallImage3 = substr(imageResize($file_path_3),29);

			}
		}
	if (empty($_FILES['upload_image4']['name'])==FALSE)
		{
		// get the file extension
		$ext = pathinfo($_FILES['upload_image4']['name'], PATHINFO_EXTENSION);
		// set the filename
		$filename4 = date("ymd")."_".$make_clean."_".$model_clean."_4".".".$ext;
		// Add the filename to our target path.  
		// Result is "images/filename.extension"
		$file_path_4 = $target_path.$filename4; 
		if (move_uploaded_file($_FILES['upload_image4']['tmp_name'], $file_path_4)==FALSE)
			{
			$error_msg.="* There was an error uploading the file ".  basename( $_FILES['upload_image4']['name']).", please try again!<br />";
			}
		else
			{
			$image4 = "fcbikecoop.org/volunteer_db/bikes4sale/images/".$filename4;
			$smallImage4 = substr(imageResize($file_path_4),29);

			}
		}
	}
*/

// END BASIC ERROR CHECKING
// You need to create your own code to validate the information
// and allowed values - never send "unclean" user responses
// to a database without cleaning them up and
// checking for allowed answers.
// Google for "SQL injection" and "insecure contact form"

// Do this if no errors were detected AND form has been submitted
if ($error_msg == '' && isset($_POST['submit']))
	{
	//Close the session
	session_write_close();
	// Connect to the MySQL database
	// Include our login information
	include('../db_login.php');
	//Connect
	$db_error='There was a problem accessing our system.  Please try again later.';
	$connection = @mysql_connect($db_host, $db_username, $db_password) or die($db_error);
	// Select the database
	$db_select = @mysql_select_db($db_database) or die($db_error);

	// Build our query here and check each variable with mysql_real_escape_string()
	$query = sprintf("INSERT INTO BIKES4SALE (Type, Make, Model, Color, OtherColor, FrameSize, FrameMatl, Fork, WheelSize, WheelModel, WheelBrand, HubBrand, HubModel, Speeds, ShifterType, ShifterBrand, ShifterModel, FrontDerailleurBrand, FrontDerailleurModel, RearDerailleurBrand, RearDerailleurModel, BrakeType, Accessories, Cond, Comments, Price, EntryDate) VALUES( '%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%d','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',CURDATE())",

		mysql_real_escape_string($bike_type),
		mysql_real_escape_string($make),
		mysql_real_escape_string($model),
		mysql_real_escape_string($color),
		mysql_real_escape_string($other_color),
		mysql_real_escape_string($frame_size),
		mysql_real_escape_string($frame_material),
		mysql_real_escape_string($suspension_front_fork),
		mysql_real_escape_string($wheel_size),
		mysql_real_escape_string($wheel_model),
		mysql_real_escape_string($wheel_brand),
		mysql_real_escape_string($hub_brand),
		mysql_real_escape_string($hub_model),
		mysql_real_escape_string($speeds),
		mysql_real_escape_string($shifter_type),
		mysql_real_escape_string($shifter_brand),
		mysql_real_escape_string($shifter_model),
		mysql_real_escape_string($front_derailleur_brand),
		mysql_real_escape_string($front_derailleur_model),
		mysql_real_escape_string($rear_derailleur_brand),
		mysql_real_escape_string($rear_derailleur_model),
		mysql_real_escape_string($brake_type),
		mysql_real_escape_string($accessories),
		mysql_real_escape_string($condition),
		mysql_real_escape_string($comments),
		mysql_real_escape_string($price),
		mysql_real_escape_string($email));
	// run the query
//	$mysql_result = mysql_db_query ($query) or die($db_error);
	// run the query
	if(!mysql_query($query))
		{
		echo 'Query failed '.mysql_error();
		echo $query;
		exit();
		}

	// No errors were detected.
	// check the POST variable other_color
		if(empty($_POST['other_color'])==FALSE)
			{
			$other_color = "and ".$_POST['other_color'];
			}
	// Send the Craigslist posting HTML file
//define the receiver of the email
$to = $email;
//define the subject of the email
$subject = 'Craigslist Posting'; 
// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\n";
$headers .= "Content-type:text/html;charset=iso-8859-1" . "\n";
$headers .= "From: webmaster@fcbikecoop.org";
$message = <<<MESSAGE
$frame_size cm $color $other_color $make $model - $bike_type Bike \$$price
<h4>FRAME:</h4>
<ul><li>$frame_size $frame_material frame $suspension_front_fork</li>
<li>Frame Sizing Info - http://fcbikecoop.org/volunteer_db/bikes4sale/sizing.php</li></ul>
<h4>DRIVETRAIN:</h4>
<ul><li>$drivetrain</li></ul>
<h4>WHEELS:</h4>
<ul><li>$wheel wheels $hubs</li></ul>
<h4>BRAKES:</h4>
<ul><li>$brake_type</li></ul>
<h4>ACCESSORIES:</h4>
<ul><li>$accessories</li></ul>
<h4>CONDITION:</h4>
This bike is in <b>$condition</b> condition.  It has been professionally refurbished and finely tuned.<br>
<h4>ADDITIONAL COMMENTS:</h4>
$comments<br><br>
<hr size="5" noshade>
Proceeds from the sale of this bike will benefit <b>The Fort Collins Bike Co-op</b> and its programs.<br>
<b>http://fcbikecoop.org</b><br><br>

To test ride this bike, stop by our open shop hours.
<ul><li>Mon: 2pm-5pm</li>
<li>Tue: CLOSED</li>
<li>Wed: 2pm-5pm</li>
<li>Thu: CLOSED</li>
<li>Fri: 2pm-5pm</li>
<li>Sat: CLOSED</li>
<li>Sun: Noon-6pm</li>
</ul>
<h3>We are located at:</h3>
1501 North College Ave.<br>
Fort Collins, CO 80524<br>
Directions - https://www.google.com/maps/search/1501+N+College+Ave,+Fort+Collins,+CO+80524/<br><br>
<hr size="5" noshade>
<h4>ALL SALES ARE LOCAL - WE DO NOT SHIP BIKES UNDER ANY CIRCUMSTANCES</h4>
MESSAGE;

//send the email
$mail_sent = @mail( $to, $subject, $message, $headers );
//if the message is sent successfully print "Mail sent". Otherwise print "Mail failed" 
echo $mail_sent ? "Mail sent to ".$email."<br>POSTING DIRECTIONS:<br>- Go to <a href=\"https://accounts.craigslist.org/login/home\" target=\"_blank\">Fort Collins Craigslist</a><br>- Login<br>- In the Upper Right, Click on \"go\" to create a new posting<br>- Select for sale by dealer, then bicycles<br>- Go to your email and open the mail you were sent<br>- Hit Ctrl+U and you will see a page of code<br>- Copy from &ltH4&gtFrame...... down through CIRCUMSTANCES&lt&#47H4&gt<br>- Paste that into the \"posting body\"<br>- The line above the &ltH4&gt has the posting title, copy and paste that<br>- Make sure to put in a price, Location \"FC Bike Co-op\" and zip 80524<br>- <b>Put in lots of pictures.  They're free, and they sell bikes!</b><br>- At the very least put in an image of the entire drive side of the bike.<br>- Post and enjoy" : "Mail failed";

//	$message = include('../../craigslist/craigs.php');
//	mail( $email,"Craigslist Posting",$message,"From: webmaster@fcbikecoop.org");

	// end of email to staff
	// Redirect to confirmation page.
//	header ("Location: http:volunteer_form_done.php");
	exit;
}

// If PHP is still reading this, it must be the first page visit,
// OR an error was detected.
// Display the HTML page and your signup form.
include_once('/var/www/fcbikecoop.org/root/header.php');

// If the form has been submitted,
// display the error messages above the form.
if(isset($_POST['submit']))
{
echo "<font color=\"yellow\" size=\"3\">The following problems were detected:<br><i>" .$error_msg ."</i></font><br>";
}
?>

			<form name="CL" method="POST" action="<?php echo $PHP_SELF;?>" enctype="multipart/form-data">
				<div class="heading">Craigslist Posting Generator</div>
				<b>Fields marked with ** are required.</b>
				<table width="625px">
					<tr>
						<td width="145px">Bike Type: <b>**</b></td>
						<td width="175px"><select name="bike_type" id="bike_type"><option value="<?php echo $bike_type ?>" selected="selected"><?php echo $bike_type ?></option><option value="Mountain">Mountain</option><option value="Full Suspension Mountain">Full Suspension Mountain</option><option value="Road">Road</option><option value="Cruiser">Cruiser</option><option value="Hybrid">Hybrid</option><option value="Commuter">Commuter</option><option value="Ladies">Ladies</option><option value="Mixtie">Mixtie</option><option value="Kids">Kids</option><option value="BMX">BMX</option><option value="Tandem">Tandem</option></select></td>
					</tr>
					<tr>
						<td>Make: <b>**</b></td>
						<td><input type="text" size="15" name="make" id="make" value="<?php echo $make ?>"></td>
					</tr>
					<tr>
						<td>Model: <b>**</b></td>
						<td><input type="text" size="15"  name="model" id="model" value="<?php echo $model ?>"/></td>
					</tr>
					<tr>
						<td>Color: <b>**</b></td>
						<td><select  name="color"  id="color"><option value="<?php echo $color ?>" selected="selected"><?php echo $color ?></option><option value="Red">Red</option><option value="Orange">Orange</option><option value="Yellow">Yellow</option><option value="Green">Green</option><option value="Blue">Blue</option><option value="Indigo">Indigo</option><option value="Violet">Violet</option><option value="Black">Black</option><option value="Brown">Brown</option><option value="Cream">Cream</option><option value="Gold">Gold</option><option value="Grey">Grey</option><option value="Purple">Purple</option><option value="Silver">Silver</option><option value="Teal">Teal</option><option value="White">White</option></select></td>
						<td>Other Color:</td>
						<td width="130px"><input type="text" size="20"  name="other_color" id="other_color" value="<?php echo $other_color ?>"/></td>
					</tr>
<script language="javascript">
function SelectFrameSize(){
// ON selection of units this function will work
	removeAllOptions(document.CL.Size);
	addOption(document.CL.Size, "", "Size", "");

	if(document.CL.Units.value == 'in'){
		addOption(document.CL.Size,"10 in", "10 in");
		addOption(document.CL.Size,"11 in", "11 in");
		addOption(document.CL.Size,"12 in", "12 in");
		addOption(document.CL.Size,"13 in", "13 in");
		addOption(document.CL.Size,"14 in", "14 in");
		addOption(document.CL.Size,"14.5 in", "14.5 in");
		addOption(document.CL.Size,"15 in", "15 in");
		addOption(document.CL.Size,"15.5 in", "15.5 in");
		addOption(document.CL.Size,"16 in", "16 in");
		addOption(document.CL.Size,"16.5 in", "16.5 in");
		addOption(document.CL.Size,"17 in", "17 in");
		addOption(document.CL.Size,"17.5 in", "17.5 in");
		addOption(document.CL.Size,"18 in", "18 in");
		addOption(document.CL.Size,"18.5 in", "18.5 in");
		addOption(document.CL.Size,"19 in", "19 in");
		addOption(document.CL.Size,"19.5 in", "19.5 in");
		addOption(document.CL.Size,"20 in", "20 in");
		addOption(document.CL.Size,"20.5 in", "20.5 in");
		addOption(document.CL.Size,"21 in", "21 in");
		addOption(document.CL.Size,"21.5 in", "21.5 in");
		addOption(document.CL.Size,"22 in", "22 in");
		addOption(document.CL.Size,"23 in", "23 in");
	}
	if(document.CL.Units.value == 'cm'){
		addOption(document.CL.Size,"43 cm", "43 cm");
		addOption(document.CL.Size,"44 cm", "44 cm");
		addOption(document.CL.Size,"45 cm", "45 cm");
		addOption(document.CL.Size,"46 cm", "46 cm");
		addOption(document.CL.Size,"47 cm", "47 cm");
		addOption(document.CL.Size,"48 cm", "48 cm");
		addOption(document.CL.Size,"49 cm", "49 cm");
		addOption(document.CL.Size,"50 cm", "50 cm");
		addOption(document.CL.Size,"51 cm", "51 cm");
		addOption(document.CL.Size,"52 cm", "52 cm");
		addOption(document.CL.Size,"53 cm", "53 cm");
		addOption(document.CL.Size,"54 cm", "54 cm");
		addOption(document.CL.Size,"55 cm", "55 cm");
		addOption(document.CL.Size,"56 cm", "56 cm");
		addOption(document.CL.Size,"57 cm", "57 cm");
		addOption(document.CL.Size,"58 cm", "58 cm");
		addOption(document.CL.Size,"59 cm", "59 cm");
		addOption(document.CL.Size,"60 cm", "60 cm");
		addOption(document.CL.Size,"61 cm", "61 cm");
		addOption(document.CL.Size,"62 cm", "62 cm");
		addOption(document.CL.Size,"63 cm", "63 cm");
		addOption(document.CL.Size,"64 cm", "64 cm");
		addOption(document.CL.Size,"65 cm", "65 cm");
		addOption(document.CL.Size,"66 cm", "66 cm");
	}
}

function removeAllOptions(selectbox)
{
	var i;
	for(i=selectbox.options.length-1;i>=0;i--)
	{
		//selectbox.options.remove(i);
		selectbox.remove(i);
	}
}

function addOption(selectbox, value, text )
{
	var optn = document.createElement("OPTION");
	optn.text = text;
	optn.value = value;

	selectbox.options.add(optn);
}
</script>
					<tr height="50px">
						<td colspan="4">See <a href="http://www.sheldonbrown.com/frame-sizing.html">Sheldon Brown's article on Frame sizing</a> for more information.</td>
					</tr>
					<tr>
					<tr>
						<td>Frame Size: <b>**</b></td>
						<td><select name="Units" id="Units" onChange="SelectFrameSize();" ><option value="">units</option><option value="in">inches</option><option value="cm">centimeters</option></select><select id="Size" name="Size"><option value="<?php echo $frame_size ?>" selected="selected"><?php echo $frame_size ?></option></select></td>
					</tr>
						<td>Frame material: <b>**</b></td>
						<td><select  name="frame_material"  id="frame_material"  ><option value="<?php echo $frame_material ?>" selected="selected"><?php echo $frame_material ?></option><option value="Steel">Steel</option><option value="Aluminum">Aluminum</option><option value="Titanium">Titanium</option><option value="Carbon Fiber">Carbon Fiber</option></select></td>
					</tr>
					<tr>
						<td></td>
						<td><input type=checkbox name="suspension_front_fork" value="with front suspension fork"<?php echo $suspension_front_fork ?>>front suspension fork</td>
					</tr>
					</tr>
					<tr height="50px">
						<td colspan="4">See <a href="http://www.sheldonbrown.com/tire_sizing.html">Sheldon Brown's article on wheel sizing</a> for more information.</td>
					</tr>
					<tr>
						<td>Wheel Size: <b>**</b></td>
						<td><select  name="wheel_size"  id="wheel_size"  ><option value="<?php echo $wheel_size ?>" selected="selected"><?php echo $wheel_size ?> </option><option value="10in">10&quot;</option><option value="12in">12&quot;</option><option value="16in">16&quot;</option><option value="20in">20&quot;</option><option value="24in">24&quot;</option><option value="26in (decimal/ISO 559)">26&quot; (decimal/ISO 559)</option><option value="26in (fraction/ISO 590)">26&quot; (fraction/ISO 590)</option><option value="27in">27&quot;</option><option value="650b">650b</option><option value="700c">700c</option></select></td>
					</tr>
					<tr>
						<td>Wheel Brand:</td>
						<td> <input type="text" value="<?php echo $wheel_brand ?>" size="20" name="wheel_brand" id="wheel_brand" /></td>
						<td>Wheel Model:</td>
						<td><input type="text" value="<?php echo $wheel_model ?>" size="20" name="wheel_model" id="wheel_model" /></td>
					</tr>
					<tr>
						<td>Hub Brand:</td>
						<td><input type="text" value="<?php echo $hub_brand ?>" size="20" name="hub_brand" id="hub_brand" /></td>
						<td>Hub Model:</td>
						<td><input type="text" value="<?php echo $hub_model ?>" size="20" name="hub_model" id="hub_model" /></td>
					</tr>
					<tr>
						<td>Speeds: <b>**</b></td>
						<td> <select  name="speeds" id="speeds" onchange="if (this.value == '1') document.getElementById('shifterInfo').style.display = 'none'; else document.getElementById('shifterInfo'		#Replace the last .$exts with -small.$exts 
		$newname = preg_replace("/\.$exts$/i", "-small.$exts", $filename);).style.display = '';" >><option value="<?php echo $speeds ?>" selected="selected"><?php echo $speeds ?></option><option value="1">1</option><option value="3">3</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option><option value="12">12</option><option value="14">14</option><option value="16">16</option><option value="18">18</option><option value="20">20</option><option value="21">21</option><option value="24">24</option><option value="27">27</option></select></td>
					</tr>
				</table>
					<div id="shifterInfo"<?php if ($speeds == '1') echo "style='display: none'"; ?>>
						<table width="625px">
							<tr>
								<td width="145px">Shifter Type:</td>
								<td width="175px"><select  name="shifter_type"  id="shifter_type" onchange="if (this.value == 'single speed') document.getElementById('shifterInfo').style.display = 'none'; else document.getElementById('shifterInfo').style.display = '';" ><option value="<?php echo $shifter_type ?>" selected="selected"><?php echo $shifter_type ?> </option><option value="single speed">single speed</option><option value="trigger">trigger</option><option value="grip">grip</option><option value="thumb friction">thumb friction</option><option value="thumb indexed">thumb indexed</option><option value="friction on downtube">friction on downtube</option><option value="friction on stem">friction on stem</option><option value="integrated">integrated</option><option value="nexus">nexus</option><option value="bar end">bar end</option></select></td>
							</tr>
							<tr>
								<td>Shifter Brand:</td>
								<td><input type="text" value="<?php echo $shifter_brand ?>" size="20" name="shifter_brand" id="shifter_brand" /></td>
								<td>Shifter Model:</td>
								<td width="130px"><input type="text" value="<?php echo $shifter_model ?>" size="20" name="shifter_model" id="shifter_model" /></td>
							</tr>
							<tr>
								<td>Front Derailleur Brand:</td>
								<td><input type="text" value="<?php echo $front_derailleur_brand ?>" size="20" name="front_derailleur_brand" id="front_derailleur_brand" /></td>
								<td>Front Deraileur Model:</td>
								<td><input type="text" value="<?php echo $front_derailleur_model ?>" size="20" name="front_derailleur_model" id="front_derailleur_model" /></td>
							</tr>
							<tr>
								<td>Rear Derailleur Brand:</td>
								<td><input type="text" value="<?php echo $rear_derailleur_brand ?>" size="20" name="rear_derailleur_brand" id="rear_derailleur_brand" /></td>
								<td>Rear Deraileur Model:</td>
								<td><input type="text" value="<?php echo $rear_derailleur_model ?>" size="20" name="rear_derailleur_model" id="rear_deraileur_model" /></td>
							</tr>
						</table>
					</div>
				<table width="625px">
					<tr>
						<td width="145px">Brake Type:</td>
						<td width="175px"><select  name="brake_type" id="brake_type"><option value="<?php echo $brake_type ?>" selected="selected"><?php echo $brake_type ?> </option><option value="V-Brake">V-Brake</option><option value="Cantilever">Cantilever</option><option value="Coaster">Coaster</option><option value="Center Pull">Center Pull</option><option value="Side Pull">Side Pull</option><option value="Dual Pivot">Dual Pivot</option><option value="Disc">Disc</option></select></td>
						<td></td>
						<td width ="130px"></td>
					</tr>
					<tr height="50px">
						<td colspan="4"><h2>Accessories (Check all which apply.):</h2></td>
					</tr>
					<tr>
						<td><input type=hidden name="acc1" value="0"><input type=checkbox name="acc1" value="1"<?php if ($acc1=="1") { echo 'checked'; } ?>>Rear Cargo Rack</td>
					
						<td><input type=hidden name="acc2" value="0"><input type=checkbox name="acc2" value="1"<?php if ($acc2=="1") { echo 'checked'; } ?>>Front Basket/Rack</td>
					</tr>
					<tr>
						<td><input type=hidden name="acc3" value="0"><input type=checkbox name="acc3" value="1"<?php if ($acc3=="1") { echo 'checked'; } ?>>Bell (ding! ding!)</td>
						<td><input type=hidden name="acc4" value="0"><input type=checkbox name="acc4" value="1"<?php if ($acc4=="1") { echo 'checked'; } ?>>Bottle Cage(s)</td>
					</tr>
					<tr>
						<td><input type=hidden name="acc5" value="0"><input type=checkbox name="acc5" value="1"<?php if ($acc5=="1") { echo 'checked'; } ?>>Kick Stand</td>
						<td><input type=hidden name="acc6" value="0"><input type=checkbox name="acc6" value="1"<?php if ($acc6=="1") { echo 'checked'; } ?>>Fenders</td>
					</tr>
					<tr>
						<td><input type=hidden name="acc7" value="0"><input type=checkbox name="acc7" value="1"<?php if ($acc7=="1") { echo 'checked'; } ?>>Headlight</td>
						<td><input type=hidden name="acc8" value="0"><input type=checkbox name="acc8" value="1"<?php if ($acc1=="1") { echo 'checked'; } ?>>Taillight</td>
					</tr>
					<tr>
						<td><input type=hidden name="acc9" value="0"><input type=checkbox name="acc9" value="1"<?php if ($acc9=="1") { echo 'checked'; } ?>>Frame Pump</td>
						<td><input type=hidden name="acc10" value="0"><input type=checkbox name="acc10" value="1"<?php if ($acc10=="1") { echo 'checked'; } ?>>Rear View Mirror</td>
					</tr>
					<tr>
						<td><input type=hidden name="acc11" value="0"><input type=checkbox name="acc11" value="1"<?php if ($acc10=="1") { echo 'checked'; } ?>>Pannier(s)</td>
						<td><input type=hidden name="acc12" value="0"><input type=checkbox name="acc12" value="1"<?php if ($acc11=="1") { echo 'checked'; } ?>>Saddle Bag</td>
					</tr>
					<tr>
						<td><input type=hidden name="acc13" value="0"><input type=checkbox name="acc13" value="1"<?php if ($acc12=="1") { echo 'checked'; } ?>>Computer</td>
						<td><input type=hidden name="acc14" value="0"><input type=checkbox name="acc14" value="1"<?php if ($acc13=="1") { echo 'checked'; } ?>>Chain Guard</td>
					</tr>
					<tr>
						<td><input type=hidden name="acc15" value="0"><input type=checkbox name="acc15" value="1"<?php if ($acc15=="1") { echo 'checked'; } ?>>Skirt/Coat Guard</td>
					</tr>
					<tr>
						<td>Condition: <b>**</b></td>
						<td><select  name="condition" id="condition"><option value="<?php echo $condition ?>" selected="selected"><?php echo $condition ?> </option><option value="Excellent">Excellent</option><option value="Good">Good</option><option value="Fair">Fair</option></select></td>
					</tr>
					<tr>
						<td>Price: <b>**</b></td>
						<td>$<input type="text" value="<?php echo $price ?>" size="7" name="price" id="price" /></td>
					</tr>
					<tr height="50px">
						<td colspan="4"><h2>Additional Notes:</h2></td>
					</tr>
					<tr>
						<td colspan="4"><i>Give the bike some character.  Try and make it seem unique.  Suggest good uses for this particular bike, and use positive words.</i></td>
					</tr>
					<tr>
						<td colspan="4"><textarea rows="8" name="comments" id="comments" value="<?php echo $comments ?>" style="width:100%"></textarea></td>
					</tr>

<?php /* Image upload removed.  CL isn't as friendly about allowing image href links.  So storing large versions and thumbnails on our site isn't what it used to be.k
					<tr>
						<td>Upload Image 1: <b>**</b></td>
						<td colspan ="2"><input type="hidden" name="MAX_FILE_SIZE" value="20000000" /> <input type="file" name="upload_image1" id="upload_image1"  /></td>
					</tr>
					<tr>
						<td colspan="4"><i>You must include at least one picture of the bike.</i></td>
					</tr>
					<tr>
						<td>Upload Image 2:</td>
						<td colspan ="2"><input type="hidden" name="MAX_FILE_SIZE" value="20000000" /> <input type="file" name="upload_image2" id="upload_image2"  /></td>
					</tr>
					<tr>
						<td colspan="4"><i>Images are automatically re-sized for display on the web.</i></td>
					</tr>
					<tr>
						<td>Upload Image 3:</td>
						<td colspan ="2"><input type="hidden" name="MAX_FILE_SIZE" value="20000000" /> <input type="file" name="upload_image3" id="upload_image3"  /></td>
					</tr>
					<tr>
						<td colspan="4"><i>When taking photos, make sure that the bike takes up the entire frame.</i></td>
					</tr>
					<tr>
						<td>Upload Image 4:</td>
						<td colspan ="2"><input type="hidden" name="MAX_FILE_SIZE" value="20000000" /> <input type="file" name="upload_image4" id="upload_image4"  /></td>
					</tr>
					<tr>
						<td colspan="4"><i>Use up to 3 additional photos to highlight special features of the bike.</i></td>
					</tr>
					<tr>
*/?>
						<td>Your email: <b>**</b></td>
						<td colspan ="2"><input type="text" size="20"  name="email" id="email" value="<?php echo $email ?>"/></td>
					</tr>
				</table>

<br><br><input type="submit" value="Send" name="submit">
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
