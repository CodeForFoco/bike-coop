<?php
session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
// get the variable that will let us get back
$origin = $_SESSION['origin'];
if ($origin == "bars")
	{
	$link_back = "<a href='./index.php'>B.A.R.S.</a>";
	}
if ($origin == "bars_admin")
	{
	$link_back = "<a href='./bars_admin/index.php'>B.A.R.S. Admin</a>";
	}
$list = $_SESSION['list'];
if ($list == "SearchBike")
	{
	$list_link_back = "<a href='./SearchStolen.php'>Search Stolen Bikes</a>";
	}
else {$list_link_back = "<a href='./ListBikes.php'>List of Recovered Bikes</a>";}
?>
<?php

//Connect to the Bike Co-op database
// Include our login information
include('../db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
	die ("Could not connect to the database: <br />". mysql_error());
	}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
	die ("Could not select the database: <br />". mysql_error());
	}
// get the case number of the bike to be checked
	$pcase = $_GET['Case_No'];

include_once('/var/www/fcbikecoop.org/root/header.php');
?>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <?php echo $link_back;?> <b>&raquo;</b> <?php echo $list_link_back;?> <b>&raquo;</b> Edit Recovered Bike Information</td>
				</tr>
			</table>
			<div class="heading">Stolen Bike Information</div>
<table>
<?php
//Assign the query
	$fcps = mysql_query("SELECT * FROM `FCPS` WHERE `Case_No` = '".$pcase."'");
	if (!fcps){
	die ("Could not query the database: <br />". mysql_error());
	}
//Fetch & display the results
	while ($fcps_row = mysql_fetch_array($fcps, MYSQL_ASSOC))
	{
	$pcase = $fcps_row["Case_No"];
	$pdate = $fcps_row["Date"];
	$vpdate = date("m/d/Y",strtotime($pdate));
	$pserial = $fcps_row["Serial_No"];
	$pbrand = $fcps_row["Brand"];
	$pmodel = $fcps_row["Model"];
	$pcolor = $fcps_row["Color"];
	$pdesc = $fcps_row["Description"];
	echo "Case: ".$pcase."<br>";
	echo "Date Reported: ".$vpdate."<br>";
	echo "Brand: ".$pbrand."<br>";
	echo "Model: ".$pmodel."<br>";
	echo "Color: ".$pcolor."<br>";
	echo "Serial Number: ".$pserial."<br>";
	echo "Description: ".$pdesc."<br>";
	echo "<br>";
	}
?>

</table>
<?php
// Close the connection
mysql_close($connection);
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
