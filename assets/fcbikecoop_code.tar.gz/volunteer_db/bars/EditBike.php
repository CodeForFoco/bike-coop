<?php
/**
	*	EditBikes.php - part of the Fort Collins Bike Co-op system for tracking recovered bikes
	*
	* This script presents the page for displaying details of a recovered bike so that the user
	* can update the record.
	*/

	session_start();
	$current_page = htmlentities($_SERVER['PHP_SELF']);
/**
	*	The script assumes that session variables have been set by the calling script.
	* That variable is used to build the "breadcrumb" list that helps the user navigate back.
	*/
// get the variables that will let us get back
	$origin = $_SESSION['origin'];
	if ($origin == "bars")
		{
		$link_back = "<a href='./index.php'>B.A.R.S.</a>";
		}
	if ($origin == "bars_admin")
		{
		$link_back = "<a href='../bars_admin/index.php'>B.A.R.S. Admin</a>";
		}
	if ($origin == "EAB")
		{
		$link_back = "<a href='../eab/index.php'>EAB</a>";
		}
	$list = $_SESSION['list'];
	$list_link_back = "<a href='./ListBikes.php'>List of Recovered Bikes</a>";
	if ($list == "SendPS")
		{
		$list_link_back = "<a href='../bars_admin/SendPS.php'>Bikes to PS</a>";
		}
	elseif ($list == "MatchStolen")
		{
		$list_link_back = "<a href='../bars_admin/MatchStolen.php'>Stolen Bike Match</a>";
		}
	elseif ($list == "CheckPostable")
		{
		$list_link_back = "<a href='../bars_admin/CheckPostable.php'>Check for Postable Bikes</a>";
		}
	elseif ($list == "SearchBike")
		{
		$list_link_back = "<a href='./SearchBike.php'>Search Recovered Bikes</a>";
		}
	elseif ($list == "ReleaseBike")
		{
		$list_link_back = "<a href='../bars_admin/ReleaseBike.php'>Release Bikes</a>";
		}
	elseif ($list == "BikeReport")
		{
		$list_link_back = "<a href='../bars_admin/BikeReport.php'>Recovered Bike Report</a>";
		}
	elseif ($list == "EABbikes")
		{
		$list_link_back = "<a href='../eab/EABbikes.php'>EAB Bikes</a>";
		}

//Connect to the Bike Co-op database
require_once "../../db_connect.php";
$db = db_connect ();

// get the ID of the bike to be edited
	$bike = $_GET['BikeID'];
	
//Assign the query
	$query = $db->prepare("SELECT * FROM `RECOVEREDBIKES` WHERE `BikeID`=?");
	$query->bindValue(1, $bike, PDO::PARAM_INT);
	$query->execute();

//Fetch & display the results
	while($result_row = $query->fetch(PDO::FETCH_ASSOC))
		{
		$biketype = $result_row["Type"];
		$rdate = $result_row["RecoveredDate"];
		$serial = $result_row["Serial"];
		$brand = $result_row["Brand"];
		$model = $result_row["Model"];
		$color = $result_row["Color"];
		$description = $result_row["Description"];
		$sentPS = $result_row["SentPS"];
		$manifest = $result_row["ToPurchasing"];
		$cleared = $result_row["DateCleared"];
		$disposition = $result_row["Disposition"];
		$dispDate = $result_row["DispDate"];
		$volunteer = $result_row["Volunteer"];
		$contact = $result_row["Contact"];
		$location = $result_row["Location"];
		$phone = $result_row["Phone"];
		$status = $result_row["Status"];
		}
// Change the date format for display purposes.
if ($rdate > '0000-00-00') {$v_rdate = date("m/d/Y",strtotime($rdate));}
if ($sentPS > '0000-00-00') {$v_sentPS = date("m/d/Y",strtotime($sentPS));$status="logged";}
if ($manifest > '0000-00-00') {$v_manifest = date("m/d/Y",strtotime($manifest));$status="manifest";}
if ($cleared > '0000-00-00') {$v_cleared = date("m/d/Y",strtotime($cleared));$status="cleared";}
if ($dispDate > '0000-00-00') {$v_dispDate = date("m/d/Y",strtotime($dispDate));$status="complete";}

// Do this if form has been submitted
	if (isset ($_POST['Send']))
		{
		foreach($_POST as $key=>$value)
			{
			$$key = $value;
			}
		// convert stuff to initial caps (also handles "loud" text)
		$serial=strtoupper(trim($_POST['serial']));
		$brand=strtoupper(trim($_POST['brand']));
		// fix case of brand name, but allow for 3 or less letter names like "KHS"
		if (strlen($brand)>3) $brand=ucwords(strtolower(trim($_POST['brand'])));
		$model=ucwords(trim($_POST['model']));
		$color=strtolower(trim($_POST['color']));
		$description = $_POST['description'];
		if ($manifest > '0000-00-00') {$manifest = date('Y-m-d', strtotime($_POST['manifest']));}
		if ($cleared > '0000-00-00') {$cleared = date('Y-m-d', strtotime($_POST['cleared']));}
		$disposition = $_POST['disposition'];
		if ($disposition > '0000-00-00') {$dispDate = date('Y-m-d', strtotime($_POST['dispDate']));}
		$status = $_POST['status'];
		$query = $db->prepare("UPDATE RECOVEREDBIKES Set RecoveredDate=:rdate, 
									Serial=:serial, 
									Brand=:brand,
									Model=:model, 
									Color=:color, 
									Description=:description, 
									ToPurchasing=:manifest, 
									DateCleared=:cleared, 
									Disposition=:disposition, 
									DispDate=:dispDate,
									Status=:status
						WHERE BikeID=:bike");
		$query->bindValue(':rdate', $rdate, PDO::PARAM_STR);
		$query->bindValue(':serial', $serial, PDO::PARAM_STR);
		$query->bindValue(':brand', $brand, PDO::PARAM_STR);
		$query->bindValue(':model', $model, PDO::PARAM_STR);
		$query->bindValue(':color', $color, PDO::PARAM_STR);
		$query->bindValue(':description', $description, PDO::PARAM_STR);
		$query->bindValue(':manifest', $manifest, PDO::PARAM_STR);
		$query->bindValue(':cleared', $cleared, PDO::PARAM_STR);
		$query->bindValue(':disposition', $disposition, PDO::PARAM_STR);
		$query->bindValue(':dispDate', $dispDate, PDO::PARAM_STR);
		$query->bindValue(':status', $status, PDO::PARAM_STR);
		$query->bindValue(':bike', $bike, PDO::PARAM_INT);
		try
			{
			// run the query
			$query->execute();
			}
		catch (PDOException $e)
			{
			print ("The statement failed.\n");
			print ("getCode: ". $e->getCode () . "\n");
			print ("getMessage: ". $e->getMessage () . "\n");
			}
echo "<script>opener.location.reload();window.close();</script>";
			exit();

		// No errors were detected.
	}

// If PHP is still reading this, it must be the first page visit,
// OR an error was detected.
// Get the standard Co-op page header.
	include_once($_SERVER['DOCUMENT_ROOT'].'header.php');
?>
<link rel="stylesheet" href="/css/jquery-ui.min.css" type="text/css" media="all" />
<!-- jQuery routines are used for data validation. -->
<script type='text/javascript' src='/js/jquery.min.js'></script>
<script type='text/javascript' src='/js/jquery.validate.min.js'></script>
<script type='text/javascript' src='/js/jquery-ui.min.js'></script>
<script type='text/javascript' src='EditBike.js'></script>
<style>
.ui-datepicker { font-size: 62.5%; }
html{
    width:100%;
    height:100%;
}
body{
    width:100%;
    height:100%;
 }
$.datepicker.setDefaults({
  showOn: "both",
  buttonImageOnly: true,
  buttonImage: "/images/calendar.gif",
  buttonText: "Calendar"
});
</style>
<script type="text/javascript">
  $(document).ready(function() {
    $('.datepicker').datepicker({
      showOn: "button",
      buttonImage: "/images/calendar.gif",
      buttonImageOnly: true,
      buttonText: "Select date"
    });
  });
</script>
	<div class="heading">Recovered Bike Information</div>
	<form method="POST" enctype="multipart/form-data">
	<h3>Log #: <?php echo $bike ?> Type: <?php echo $biketype ?></h3>
	<p>Enter the information and click on submit.</p>
	<p>
	Brand: <input type="text" id="brand" name="brand" size=15 value="<?php echo $brand ?>">
	Model: <input type="text" name="model" size=15 value="<?php echo $model ?>">
	Color: <input type="text" name="color" size=10 value="<?php echo $color ?>">
	<p>
	Serial Number: <input type="text" name="serial" size=20 value="<?php echo $serial ?>">
	Logged by: <input type="text" name="volunteer" size=20 value="<?php echo $volunteer ?>" readonly="readonly">
	<p>
	Description: <input type="textarea" name="description" size=50 value="<?php echo $description ?>">
	<p>
	Contact: <input type="text" name="contact" size=15 value="<?php echo $contact ?>" readonly="readonly">
	Location: <input type="text" name="where" size=20 value="<?php echo $location ?>" readonly="readonly">
	Phone: <input type="text" name="phone" size=10 value="<?php echo $phone ?>" readonly="readonly">
<?php
// If the form is being used by the BARS administrator the disposition fields are editable.
if ($origin == "bars_admin"){$showDivFlag=true;}
else {$showDivFlag=false;}
?>
<div id="admin" <?php if ($showDivFlag===false){?>style="display:none"<?php } ?>>
	<p>
	Sent to P.S.: <input type="text" name="sentPS" size=8 value="<?php echo $v_sentPS ?>" readonly="readonly">
<?php if ($biketype == "recovery") { ?>
	Sent to Purchasing: <input type="text" name="manifest" size=8 id="manifest" class="datepicker" value="<?php echo $v_manifest ?>">
<?php } ?>
<?php if ($manifest > '0000-00-00' || $biketype == "donation" || $biketype == "FCPS") { ?>
	Cleared: <input type="text" name="cleared" size=8 id="cleared" class="datepicker" value="<?php echo $v_cleared ?>">
<?php } ?>
<p>
<?php if ($cleared > '0000-00-00') { ?>
<!-- Build the fields for a recovered bike. -->
	Disposition: <input type="text" list=disps id="disposition" name="disposition" autocomplete="off" value="<?php echo $disposition ?>">
    <datalist id=disps >
		<option> as-is
		<option> EAB
		<option> recycle
		<option> retail
		<option> volunteer
		<option> returned 
	</datalist>
	Date: <input type="text" name="dispDate" size=8 id="dispDate" class="datepicker" value="<?php echo $v_dispDate ?>" />
<?php } ?>
	Status: <input type="text" name="status" size=15 value="<?php echo $status ?>" readonly="readonly">
</div>
<input type="submit" name="Send" value="submit">
<?php
// Free used resources
//	$result->closeCursor();
	$db = null;
// Get the standard Bike Co-op page footer.
	include_once($_SERVER['DOCUMENT_ROOT'].'footer.php');
?>
