<?php
/**
	*	SearchStolen.php - part of the Fort Collins Bike Co-op system for tracking recovered bikes
	*
	* This script presents the page for allowing the user to enter criteria for searching the 
	* table of stolen bikes sent to us by FC Police Services.
	*/

session_start();
/**
	*	The script assumes that a session variable has been set by the calling script.
	* That variable is used to build the "breadcrumb" list that helps the user navigate back.
	*/
// get the variables that will let us get back
$origin = $_SESSION['origin'];
if ($origin == "bars")
	{
	$link_back = "<a href='./index.php'>B.A.R.S.</a>";
	}
if ($origin == "bars_admin")
	{
	$link_back = "<a href='../bars_admin/index.php'>B.A.R.S. Admin</a>";
	}
$_SESSION['list']="SearchStolen";
$HTTP_SESSION_VARS ["list"] = "SearchStolen";

$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once($_SERVER['DOCUMENT_ROOT'].'header.php');
?>
<!-- We will be using JQuery functions and a JavaScript for processing the form. -->
<script type='text/javascript' src='/js/jquery.min.js'></script>
<script type='text/javascript' src='/js/jquery.tablesorter.min.js'></script>
<script type='text/javascript' src='/js/Tables.js'></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <?php echo $link_back;?> <b>&raquo;</b>Search Stolen Bikes</td>
				</tr>
			</table>

			<div class="heading">Search Stolen</div>
<?php
//Connect to the Bike Co-op database
require_once "../../db_connect.php";
$db = db_connect ();
?>
<form method="post" action="<?php echo $PHP_SELF;?>">
<!-- Build the fields for a stolen bike. -->
Type your search string(s) and click on submit.  You can type any part of the information in the field(s) you want to search on.  You can also type a series of characters separated by comma to do a "wildcard" search.
<p>
<table>
	<tr>
		<td>Brand:</td><td><input type="text" name = "brand" size=15 value="<?php echo $_POST['brand'] ?>"></td>
		<td>Model:</td><td><input type="text" name = "model" size=15 value="<?php echo $_POST['model'] ?>"></td>
		<td>Color:</td><td><input type="text" name = "color" size=10 value="<?php echo $_POST['color'] ?>"></td>
	</tr>
	<tr>
		<td nowrap>Serial Number:</td><td colspan=2><input type="text" name = "serial" size=20 value="<?php echo $_POST['serial'] ?>"></td>
	</tr>
	<tr>
		<td>Description:</td><td colspan=3><input type="text" name = "description" size=40 value="<?php echo $_POST['description'] ?>"></td>
	</tr>
</table>
<input type="submit" name="Submit" value="submit">
</form> 

<?php
// If form has been submitted, search the Stolen Bikes (FCPS) table.
if(isset($_POST['Submit']))
	{
	$serial=$_POST['serial'];
	$brand=$_POST['brand'];
	$model=$_POST['model'];
	$color=$_POST['color'];
	$description=$_POST['description'];
	//First check to see if a possible match
	try
		{
		$stmt = $db->prepare("SELECT * FROM FCPS WHERE Serial_No LIKE ? AND Brand LIKE ? AND Model LIKE ? AND Color LIKE ? AND Description LIKE ?");
		$stmt->bindValue(1, "%$serial%", PDO::PARAM_STR);
		$stmt->bindValue(2, "%$brand%", PDO::PARAM_STR);
		$stmt->bindValue(3, "%$model%", PDO::PARAM_STR);
		$stmt->bindValue(4, "%$color%", PDO::PARAM_STR);
		$stmt->bindValue(5, "%$description%", PDO::PARAM_STR);
		$stmt->execute();
	   }
	catch (PDOException $e)
		{
		print ("The statement failed.\n");
		echo "boo-boo";
		echo "getMessage(): " . $e->getMessage () . "\n";
		}
	$count = $stmt->rowCount();
	if ($count == 0) 
		{
		echo "<center><b>** No Match Found **</b></center>";
		}
	else 
		{
		// Close PHP so we can output the header info.
		?>
			<h2 style='margin-bottom:0px'>Possible Matching Bikes</h2>
<i>
			<p style="margin: 0px;">Click on Case number to see details.
			<br>List can be sorted by clicking on the column headers.
</i>
			<table border=2 id="dataTable" class="tablesorter">
				<thead>
						<th style='width:50px'>Case</th><th>Agency</th><th>Date</th><th class="sorttable_alpha">Serial No.</th><th>Brand</th><th>Model</th><th>Color</th><th class="sorttable_nosort">Description</th>
				</thead>
				<tbody>
		<?php
		// Re-open PHP so we can output the results.
		}

	//Fetch & display the results
	while($row = $stmt->fetch(PDO::FETCH_ASSOC))
		{
		$agency = $row['Agency'];
		$case = $row['Case_No'];
		$rdate = $row['Date'];
		$serial = $row["Serial_No"];
		$brand = $row["Brand"];
		$model = $row["Model"];
		$color = $row["Color"];
		$descr = $row["Description"];
		$vrdate = date("m/d/Y",strtotime($rdate));
		echo "<tr onclick='SelectRow(1)' id='.$case.' style='font-size:10px'><td><a href=\"ShowStolenBike.php?Case_No=".$case."\">$case</td><td>$agency</td><td>$vrdate</td><td>$serial</td><td>$brand</td><td>$model</td><td>$color</td><td>$descr</td>";		echo "</tr>";
		echo "\n";
		}
	?>
		</tbody>
	</table>
	<?php
	// Close the connection and release resources.
	$db = NULL;
	}

include_once($_SERVER['DOCUMENT_ROOT'].'footer.php');
?>
