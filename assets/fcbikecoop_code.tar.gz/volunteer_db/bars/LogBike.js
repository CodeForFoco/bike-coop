// $(document).ready(function()
$(function()
	{
		var _logref = $('input[name=type]');
		if(_logref.attr("checked") != "undefined" && _logref.attr("checked") != "checked") 
			{
       	$("#donation").slideUp("fast"); //Slide Down Effect   
		$("#recovered").slideUp("fast"); //Slide Up Effect
			};
	$('input:radio[name=type]').click(function(){
    	if ($('input[name=type]:checked').val() == "recovery" ) {
        	$("#recovered").slideDown("fast"); //Slide Down Effect   
        } else {
            $("#recovered").slideUp("fast");	//Slide Up Effect
        }
       })
   $('input:radio[name=type]').click(function(){
    	if ($('input[name=type]:checked').val() == "donation" ) {
        	$("#donation").slideDown("fast"); //Slide Down Effect   
        } else {
            $("#donation").slideUp("fast");	//Slide Up Effect
        }
       })
    $('input:radio[name=type]').click(function(){
    	if ($('input[name=type]:checked').val() == "police" ) {
            $("#recovered").slideUp("fast");	//Slide Up Effect
            $("#donation").slideUp("fast");	//Slide Up Effect
        }
       });

	});
