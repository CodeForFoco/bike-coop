<?php
// Turn off all error reporting
error_reporting(0);
//Connect to the Bike Co-op database
require_once "../../db_connect.php";
$db = db_connect ();
// initialize the optional fields
$contact="";
$location="";
$type=$_GET['btype'];
$serial=strtoupper(trim($_GET['serial']));
$brand=strtoupper(trim($_GET['brand']));
// fix case of brand name, but allow for 3 or less letter names like "KHS"
if (strlen($brand)>3) $brand=ucwords(strtolower(trim($_GET['brand'])));
$model=$_GET['model'];
$color=strtolower(trim($_GET['color']));
$description=$_GET['description'];
$volunteer=ucwords($_GET['volunteer']);
$rdate=date('Y-m-d');
$insert = $db->prepare("INSERT INTO RECOVEREDBIKES (Type, RecoveredDate, Serial, Brand, Model, Color, Description, Volunteer) VALUES  (:type, :rdate, :serial, :brand, :model, :color, :description, :volunteer)");
	$insert->bindValue(':type', $type, PDO::PARAM_STR);
	$insert->bindValue(':rdate', $rdate, PDO::PARAM_STR);
	$insert->bindValue(':serial', $serial, PDO::PARAM_STR);
	$insert->bindValue(':brand', $brand, PDO::PARAM_STR);
	$insert->bindValue(':model', $model, PDO::PARAM_STR);
	$insert->bindValue(':color', $color, PDO::PARAM_STR);
	$insert->bindValue(':description', $description, PDO::PARAM_STR);
	$insert->bindValue(':volunteer', $volunteer, PDO::PARAM_STR);
try
	{
	// run the query
	$insert->execute();
	$log = $db->lastInsertId();
	}
catch (PDOException $e)
	{
	echo "The statement failed.\n";
	echo "getCode: ". $e->getCode () . "\n";
	echo "getMessage: ". $e->getMessage () . "\n";
	}

// Create a record in the LeadsOnline system
// Set up the WebService connection.
// use the following for testing
//	$wsdl = 'https://sandbox.leadsonline.com/leads/ws/pawn/ticketWS.asmx?wsdl';
// use the following for production
	$wsdl = 'https://www.leadsonline.com/leads/ws/pawn/ticketWS.asmx?wsdl';
// build the SOAP call parameter array
$soap_user_params = array(
 	'login' => array(
//		'storeId' => '50164',	// use for testing
 		'storeId' => '41662',	// use for production
 		'userName' => 'fcbikecoop',
 		'password' => 'fcbcw52101'
 		),
	'ticket' => array(
		'key' => array(
			'ticketType' => 'Unknown',
			'ticketnumber' => $log,
			'ticketDateTime' => $rdate
			),
		'customer' => array(
			'name' => 'Fort Collins Bike Co-op',
			'weight' => '',
			'height' => ''
			),
		'items' => array(
			'Item' => array(
				'make' => $brand,
				'model' => $model,
				'serialNumber' => $serial,
				'description' => $color." bike ".$description,
				'amount' => '0.0',
				'itemType' => 'Other',
				'itemStatus' => $type,
				'isVoid' => false,
				'employee' => $volunteer
				),
			),
		'isVoid' => false,
		)
	);	

try
	{
	// Initialize the webservice
	$trace = true;
	$exceptions = true;
	$client = new SoapClient($wsdl, array('soap_version' => SOAP_1_2, 'trace' => $trace, 'exceptions' => $exceptions));	
	// Invoke webservice method: SubmitTransaction
	$response = $client->__soapCall("SubmitTransaction", array($soap_user_params));
	// Print webservice response for testing
//	var_dump($response);
	}
catch (Exception $e)
	{
	echo "Error!";
	echo $e -> getMessage ();
	echo 'Last response: '. $client->__getLastResponse();
	}
// Set things up for the acknowledgement alert
$biketype = ucfirst($type);
if($type == "FCPS") $biketype = "Police";
$tagcolor = "WHITE";
if($type == "recovery") $tagcolor = "GREEN";
echo $biketype." bike ".$color." ".$brand." ".$model." logged as # ".$log.".\nWrite #".$log." and ".date('n/j/y')." on a ".$tagcolor." tag and attach it to the bike.";
?>
