<?php
// Add a volunteer to the BARS table
session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b><a href='./index.php'> B.A.R.S.</a><b>&raquo;</b> Add to BARS List</td>
				</tr>
			</table>
			<div class="heading">BARS Volunteers</div>

<?php
// Connect to the MySQL database
// Include our login information
include('../db_login.php');
//Connect
$db_error='There was a problem accessing our system.  Please try again later.';
$connection = @mysql_connect($db_host, $db_username, $db_password) or die($db_error);
// Select the database
$db_select = @mysql_select_db($db_database) or die($db_error);
//Get the volunteer names from the database
// SELECT CONCAT("FirstName",' ',"LastName") AS "Name", "VolID" FROM "VOLUNTEERS" AS "VOLUNTEERS" ORDER BY "Name" ASC
$select = ' SELECT ';
$column = ' `Name`, `VolID` ';
$from = ' FROM ';
$tables = ' `Names` ';
$where = '  ';
$query = $select.$column.$from.$tables.$where;
//Execute the query
$result = mysql_query( $query );
if (!result){
die ("Could not query the database: <br />". mysql_error());
}
//Fetch & display the results
$options="";
while ($row=mysql_fetch_assoc($result))
	{
	$volid=$row["VolID"];
	$volname = $row["Name"];
	$options.="<OPTION VALUE=\"$volid\">$volname</option>";
	}
?>
<form method="post" action="<?php echo $PHP_SELF;?>">
<br>
Find the name in the drop-down list and then click on the Select button.
<br>Names are listed alphabetically by first name (as entered on the volunteer application).
<br>If your name is not on the list, please <a href="volunteer_form.php">submit a volunteer application</a>.
<br>
<SELECT NAME="volunteer">
<OPTION VALUE="\"$volid\">Choose a Name</option>"
<OPTION SELECTED VALUE = "\"$volid\">
<?=$options?>
</SELECT>
<input type="submit" name="Select" value="Select">

<?php
// If form has been submitted
if(isset($_POST['Select']))
	{
	$volid = $_POST['volunteer'];
	//Assign the query
	$result = mysql_query('SELECT * FROM `VOLUNTEERS` WHERE `VolID` = '.$volid);
	if (!result){
		die ("Could not query the database: <br />". mysql_error());
		}
	// Get the volunteer's name
	$row = mysql_fetch_row($result);
	$volname = $row[2].' '.$row[3];
	// Add the volunteer to the BARS table.
	$sql = "INSERT INTO BARS (Volunteer, VolID) VALUES ('".$volname."', ".$volid.")";
	$result = mysql_query($sql);
	if (!result){
		echo "result: ".$result;
		die ("Could not query the database: <br />". mysql_error());
		}
	}
// Display the List
echo "<table>";
$result = mysql_query('SELECT * FROM `BARS`');
//Fetch & display the results
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$volunteer = $result_row["Volunteer"];
	echo "<td>$volunteer</td>";
	echo "</tr>";
	echo "\n";
	}
// Close the connection
mysql_close($connection);
?>
	</table>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
