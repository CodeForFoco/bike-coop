$(document).ready(function()
	{
	$(".datepick").datepicker(
		{showOn: 'both',
		 showButtonPanel: true,
		 buttonImage: '../iconCalendar.gif',
		 buttonImageOnly: true 
		});
	});
