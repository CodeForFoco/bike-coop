<?php
// Turn off all error reporting
error_reporting(0);
//Connect to the Bike Co-op database
require_once($_SERVER['DOCUMENT_ROOT'].'db_connect.php');
$db = db_connect ();
//Get the list of BARS volunteers
try
	{
	$query = $db->prepare("SELECT * FROM BARS");
	$query->execute();
//    $query->setAttribute(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING);
	}
catch (PDOException $e)
	{
	print ("The statement failed.\n");
	echo "boo-boo";
	echo "getMessage(): " . $e->getMessage () . "\n";
	}
//Fetch the names for use in the volunteer selection list
$options="";
echo "<option value=\"\">Please select a volunteer ...</option>";
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$volname = $result_row["Volunteer"];
	echo "<option value='".$volname."'>".$volname."</option>\n";
	}
?>
