<?php
/**
	*	LogBike.php - part of the Fort Collins Bike Co-op system for tracking recovered bikes
	*
	* This script presents the page for logging a recovered bike and then re-displays the page
	* with the updated list of recovered bikes. Bikes are logged to our database and to the 
	* LeadsOnline system.
	*/

session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once($_SERVER['DOCUMENT_ROOT'].'header.php');
?>
<!-- jQuery -->
<script src="/js/jquery.min.js"></script>
<script src="/js/jquery-ui.min.js"></script>
<!--[if lt IE 9]>
    <script src="/js/html5shiv.min.js"></script>
<![endif]-->
<!-- jQuery Validate 
<script src="/js/jquery.validate.min.js" type="text/javascript"></script>
-->
<script src="gen_validatorv4.js" type="text/javascript"></script>

 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>B.A.R.S.</a> <b>&raquo;</b>Log Bike(s)</td>
				</tr>
			</table>

			<div class="heading">Log Bike(s)</div>
<?php
//Connect to the Bike Co-op database
include_once($_SERVER['DOCUMENT_ROOT'].'db_connect.php');
$db = db_connect ();

?>
<!-- capitalize field data -->
<style>
#brand, #model, #donor, #contact {text-transform: capitalize;}
#serial {text-transform: uppercase;}
#color {text-transform: lowercase;}
</style>
<form method="post" id="LogBike" action="<?php echo $_SERVER['PHP_SELF'];?>?xxx=1">
<!-- Build the fields for a recovered bike. -->
Enter the information and click on submit.
<br><i>All fields are required.</i></p>

	<?php
	//Get the list of BARS volunteers
	try
		{
		$query = $db->prepare("SELECT * FROM BARS");
		$query->execute();
		}
	catch (PDOException $e)
		{
		print ("The statement failed.\n");
		echo "boo-boo";
		echo "getMessage(): " . $e->getMessage () . "\n";
		}
	//Fetch the names for use in the volunteer selection list
	$options="";
	while($result_row = $query->fetch(PDO::FETCH_ASSOC))
		{
		$volname = $result_row["Volunteer"];
		$options.="<OPTION VALUE=\"$volname\">$volname</option>";
		}
	?>
<label for='volunteer'>Volunteer: </label>
<select id="volunteer" name="volunteer">
				<option value="000" selected>Choose a Name</option>"
				<?=$options?>
			</select>
<br><i><small>Note: If your name does not appear on the drop-down list of volunteers, go back to the previous page and click on "Add Volunteer to BARS List".</i></small>
<p>
<label for='type'></label><Input type = 'Radio' Name ='type' value= 'recovery' class='required'>Recovered
<Input type = 'Radio' Name ='type' value= 'donation'>Donated
<Input type = 'Radio' Name ='type' value= 'FCPS'>FCPS
<br>
<div class="ui-widget">
<label for='brand'>Brand: </label><input type="text" id="brand" name="brand" size=15>
<label for='model'>Model: </label><input type="text" id="model" name="model" size=15>
<label for='color'>Color: </label><input type="text" id="color" name="color" size=10>
</div>
<p>
<label for='serial'>Serial Number: </label><input type="text" id="serial" name="serial" size=20>
<p>
Description: <input type="textarea" name="description" size=50>
<p>
<p><input type="submit" name="Submit" value="submit">
</form> 
<script  type="text/javascript">
 var frmvalidator = new Validator("LogBike");
 frmvalidator.addValidation("type","selone","Please specify whether the bike was a recovery, a donation or from Police Services.");
 frmvalidator.addValidation("volunteer","dontselect=000","Please select your name from the Volunteer drop-down list");
 frmvalidator.addValidation("brand","req","Please enter a brand");
 frmvalidator.addValidation("model","req","Please enter a model");
 frmvalidator.addValidation("color","req","Please enter a color");
 frmvalidator.addValidation("serial","req","Please enter a serial number or \"unknown\"");
 frmvalidator.addValidation("description","req","Please enter a description");
 frmvalidator.EnableMsgsTogether();
</script>
<?php
// If form has been submitted, post the bike to the RECOVEREDBIKES table.
if(isset($_POST['Submit']))
	{
	$type=$_POST['type'];
	$serial=strtoupper(trim($_POST['serial']));
	$brand=strtoupper(trim($_POST['brand']));
	// fix case of brand name, but allow for 3 or less letter names like "KHS"
	if (strlen($brand)>3) $brand=ucwords(strtolower(trim($_POST['brand'])));
	$model=ucwords(trim($_POST['model']));
	$color=strtolower(trim($_POST['color']));
	$description=$_POST['description'];
	$volunteer=ucwords($_POST['volunteer']);
	$rdate=date('Y-m-d');
	$insert = $db->prepare("INSERT INTO RECOVEREDBIKES (Type, RecoveredDate, Serial, Brand, Model, Color, Description, Volunteer) VALUES  (:type, :rdate, :serial, :brand, :model, :color, :description, :volunteer)");
	$insert->bindValue(':type', $type, PDO::PARAM_STR);
	$insert->bindValue(':rdate', $rdate, PDO::PARAM_STR);
	$insert->bindValue(':serial', $serial, PDO::PARAM_STR);
	$insert->bindValue(':brand', $brand, PDO::PARAM_STR);
	$insert->bindValue(':model', $model, PDO::PARAM_STR);
	$insert->bindValue(':color', $color, PDO::PARAM_STR);
	$insert->bindValue(':description', $description, PDO::PARAM_STR);
	$insert->bindValue(':volunteer', $volunteer, PDO::PARAM_STR);

	try
		{
		// run the query
		$insert->execute();
		$log = $db->lastInsertId();
		}
	catch (PDOException $e)
		{
		echo "The statement failed.\n";
		echo "getCode: ". $e->getCode () . "\n";
		echo "getMessage: ". $e->getMessage () . "\n";
		unset($_POST['submit']); // reset since the insert failed
		exit();
		}

	// Create a record in the LeadsOnline system
	// Set up the WebService connection.
// use the following for testing
//	$wsdl = 'https://sandbox.leadsonline.com/leads/ws/pawn/ticketWS.asmx?wsdl';
// use the following for production
	$wsdl = 'https://www.leadsonline.com/leads/ws/pawn/ticketWS.asmx?wsdl';
	// build the SOAP call parameter array
	$soap_user_params = array(
 		'login' => array(
// 			'storeId' => '50164',	// use for testing
 			'storeId' => '41662',	// use for production
 			'userName' => 'fcbikecoop',
 			'password' => 'fcbcw52101'
 			),
		'ticket' => array(
			'key' => array(
				'ticketType' => 'Unknown',
				'ticketnumber' => $log,
				'ticketDateTime' => $rdate
				),
			'customer' => array(
				'name' => 'Fort Collins Bike Co-op',
				'weight' => '',
				'height' => ''
				),
			'items' => array(
				'Item' => array(
					'make' => $brand,
					'model' => $model,
					'serialNumber' => $serial,
					'description' => $color." bike ".$description,
					'amount' => '0.0',
					'itemType' => 'Other',
					'itemStatus' => $type,
					'isVoid' => false,
					'employee' => $volunteer
					),
				),
			'isVoid' => false,
			)
		);	

	try
		{
		// Initialize the webservice
		$trace = true;
		$exceptions = true;
		$client = new SoapClient($wsdl, array('soap_version' => SOAP_1_1, 'trace' => $trace, 'exceptions' => $exceptions, 'encoding' => 'UTF-8'));	
		// Invoke webservice method: SubmitTransaction
		$response = $client->__soapCall("SubmitTransaction", array($soap_user_params));
		// Print webservice response for testing
//		var_dump($response);
		// Set things up for the acknowledgement alert
		$biketype = ucfirst($type);
		if($type == "FCPS") $biketype = "Police";
		$tagcolor = "WHITE";
		if($type == "recovery") $tagcolor = "GREEN";
		echo "<p style='padding:6px; color: #513419; background-color: #FFCC33; border: black 2px solid'>".$biketype." bike ".$color." ".$brand." ".$model." logged as # ".$log.".<br>Write #".$log." and ".date('n/j/y')." on  a ".$tagcolor." tag and attach it to the bike.</p>";
		}
	catch (Exception $e)
		{
		echo "Error!";
		echo $e -> getMessage ();
		echo 'Last response: '. $client->__getLastResponse();
		}
	}
?>
<!-- Display the list of recovered bikes -->
<h2>Last Five Recovered Bikes</h2>
<font size=1>
<table border=2 id="dataTable">
	<thead>
		<tr>
			<th></th><th>Log</th><th>Date Recovered</th><th>Serial #</th><th>Brand</th><th>Model</th><th>Color</th><th>Description</th>
		</tr>
	</thead>
	<tbody>
<?php
// List the last five logged bikes.
try
	{
	$query = $db->prepare("SELECT * FROM RECOVEREDBIKES ORDER BY BikeID DESC LIMIT 5");
	$query->execute();
	}
catch (PDOException $e)
	{
	print ("The statement failed.\n");
	echo "boo-boo";
	echo "getMessage(): " . $e->getMessage () . "\n";
	}
//Fetch & display the results
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$bike = $result_row["BikeID"];
	$log = $result_row["Log"];
	// Instead of using a Co-op "case number", which is confusing because we also have a FCPS case
	//	number, we switched to using the automatically generated record ID (Bike_ID) as the identity for
	// a recovered bike. So, if Co-op case number is blank, use record ID.  
	if (empty($log)) {$log = $bike;}
	$type = $result_row["Type"];
	$rdate = $result_row["RecoveredDate"];
	$serial = $result_row["Serial"];
	$brand = $result_row["Brand"];
	$model = $result_row["Model"];
	$color = $result_row["Color"];
	$description = $result_row["Description"];
	// Shorten "type" to a single letter
	if ($type == "donation") {$type = "D";}
	elseif ($type == "FCPS") {$type = "P";}
	else {$type = "R";}
	$v_rdate = date("m/d/Y",strtotime($rdate));
	echo "<tr>";
	echo "<td>$type</td><td>$log</td><td>$v_rdate</td><td>$serial</td><td>$brand</td><td>$model</td><td>$color</td><td>$description</td>";
	echo "</tr>";
	echo "\n";
	}
// Free used resources
// $result->closeCursor();
$db = null;
?>
	</tbody>
</table>
<?php
// Get the standard Bike Co-op page footer.
include_once($_SERVER['DOCUMENT_ROOT'].'footer.php');
?>
