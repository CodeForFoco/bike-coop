<?php
/**
	*	ListBikes.php - part of the Fort Collins Bike Co-op system for tracking recovered bikes
	*
	* This script presents the page for listing all bikes
	*/

session_start();
$_SESSION['list']="ListBikes";
$HTTP_SESSION_VARS ["list"] = "ListBikes";

// get the variable that will let us get back
$origin = $_SESSION['origin'];
if ($origin == "bars")
	{
	$link_back = "<a href='./index.php'>B.A.R.S.</a>";
	}
if ($origin == "bars_admin")
	{
	$link_back = "<a href='../bars_admin/index.php'>B.A.R.S. Admin</a>";
	}
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once($_SERVER['DOCUMENT_ROOT'].'header.php');

?>
<script type='text/javascript' src='../jquery-1.7.1.min.js'></script>
<script type='text/javascript' src='../jquery.tablesorter.min.js'></script>
<script type='text/javascript' src='../Tables.js'></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b><?php echo $link_back;?><b>&raquo;</b> List of Recovered Bikes</td>
				</tr>
			</table>

			<div class="heading">Recovered Bikes</div>
<b>Type codes</b>:
<br><u>D</u>onated, <u>R</u>ecovered, from <u>P</u>olice<br>
<b>Status codes</b>:
<br><u>L</u>ogged, <u>R</u>eported to PS, sent to <u>P</u>urchasing, <u>C</u>leared, <u>D</u>isposed, <u>S</u>tolen, <u>U</u>nusable/recycled
<br>Note:  list can be sorted by clicking on the column headers.
<font size=1>
<table border=2 id="dataTable" class="tablesorter">
	<thead>
		<tr>
			<th>Log</th><th>Type</th><th>Recovered</th><th class="sorttable_alpha">Serial #</th><th>Brand</th><th class="sorttable_alpha">Model</th><th>Color</th><th>Volunteer</th><th>Status</th><th>...</th>
			</tr>
	</thead>
	<tbody>

<?php
// Connect to the Bike Co-op database.
require_once "../../db_connect.php";
$db = db_connect ();
// Get the list of bikes.
try
	{
	$query = $db->prepare("SELECT * FROM RECOVEREDBIKES ORDER BY BikeID DESC");
	$query->execute();
	}
catch (PDOException $e)
	{
	print ("The statement failed.\n");
	echo "boo-boo";
	echo "getMessage(): " . $e->getMessage () . "\n";
	}

//Fetch & display the results
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$bike = $result_row["BikeID"];
	$type = $result_row["Type"];
	$log = $result_row["Log"];
	// Instead of using a Co-op "case number", which is confusing because we also have a FCPS case 
	// number, we are switching to using the automatically generated record ID (BikeID) as the 
	// identity for a recovered bike. So, if Co-op case number is blank, use record ID.  
	if (empty($log)) $log = $bike;
	$rdate = $result_row["RecoveredDate"];
	$rdate = $result_row["RecoveredDate"];
	$volunteer = $result_row["Volunteer"];
	$brand = trim(strtoupper($result_row["Brand"]));
	// fix case of brand name, but allow for 3 or less letter names like "KHS"
	if (strlen($brand)>3) $brand=ucwords(strtolower($result_row["Brand"]));
	$model = $result_row["Model"];
	$color = $result_row["Color"];
	$serial = $result_row["Serial"];
	$description = $result_row["Description"];
	$contact = $result_row["Contact"];
	$dispDate = $result_row["DispDate"];
	$dateCleared = $result_row["DateCleared"];
	$toPurchasing = $result_row["ToPurchasing"];
	$sentPS = $result_row["SentPS"];
	$class = $result_row["Class"];
	// "calculate" the status of the bike
	$status = " ";
	if ($class=="recycle"){$status="U";}
	elseif ($dispDate>'0000-00-00'){$status="D";}
	elseif ($dateCleared>'0000-00-00'){$status="C";}
	elseif ($toPurchasing>'0000-00-00'){$status="P";}
	elseif ($sentPS>'0000-00-00'){$status="R";}
	elseif ($rdate>'0000-00-00'){$status="L";}
	// Shorten "type" to a single letter
	if ($type == "donated") {$type = "D";}
	elseif ($type == "FCPS") {$type = "P";}
	else {$type = "R";}
	// Change the date format for display purposes.
	$vrdate = date("m/d/Y",strtotime($rdate));
	echo "<tr>";
	echo "<td><a href=\"./EditBike.php?BikeID=".$bike."\">$log</td><td>$type</td><td>$vrdate</td><td>$serial</td><td>$brand</td><td>$model</td><td>$color</td><td>$volunteer</td><td>$status</td><td><input type=\"checkbox\" name=".$bike."\" />&nbsp;</td>";
	echo "</tr>";
	echo "\n";
	}
?>
	</tbody>
</table>
<?php
// Free used resources
// $result->closeCursor();
$db = null;
include_once($_SERVER['DOCUMENT_ROOT'].'footer.php');
?>
