<?php
/**
	*	LogBike.php - part of the Fort Collins Bike Co-op system for tracking recovered bikes
	*
	* This script presents the page for logging a recovered bike and then re-displays the page
	* with the updated list of recovered bikes. Bikes are logged to our database and to the 
	* LeadsOnline system.
	*/

session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once($_SERVER['DOCUMENT_ROOT'].'header.php');
?>
<script type='text/javascript' src='../jquery-1.7.1.min.js'></script>
<script type='text/javascript' src='../jquery.tablesorter.min.js'></script>
<script type='text/javascript' src='../Tables.js'></script>
<script src="gen_validatorv4.js" type="text/javascript"></script>
<script type='text/javascript' src='./LogBike.js'></script>

 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>B.A.R.S.</a> <b>&raquo;</b>Log Bike(s)</td>
				</tr>
			</table>

			<div class="heading">Log Bike(s)</div>
<?php
//Connect to the Bike Co-op database
require_once "../../db_connect.php";
$db = db_connect ();

// Get the ID of the last bike entered and add 1 to it for the next Log number
if(isset($_POST['Submit']))
	{
	$log = $_SESSION['log'] + 1;
	}
else
	{
	$query = $db->prepare("SELECT MAX(BikeID) AS MAXIMUM FROM RECOVEREDBIKES");
	$query->execute();
	$maxid = $query->fetchColumn();
	$log = $maxid + 1;
	}
$_SESSION['log']= $log;
?>
<form method="post" id="LogBike" action="<?php echo $_SERVER['PHP_SELF'];?>?xxx=1">
<!-- Build the fields for a recovered bike. -->
Enter the information and click on submit.
<p>
Log: <input type="text" name="log" size=6 value="<?php echo $log ?>" readonly="readonly">
	<?php
	//Get the list of BARS volunteers
	try
		{
		$query = $db->prepare("SELECT * FROM BARS");
		$query->execute();
		}
	catch (PDOException $e)
		{
		print ("The statement failed.\n");
		echo "boo-boo";
		echo "getMessage(): " . $e->getMessage () . "\n";
		}
	//Fetch the names for use in the volunteer selection list
	$options="";
	while($result_row = $query->fetch(PDO::FETCH_ASSOC))
		{
		$volname = $result_row["Volunteer"];
		$options.="<OPTION VALUE=\"$volname\">$volname</option>";
		}
	?>
<label for='volunteer'>Volunteer: </label>
<select id="volunteer" name="volunteer">
				<option value="000" selected>Choose a Name</option>"
				<?=$options?>
			</select>
<br><i><small>Note: If your name does not appear on the drop-down list of volunteers, go back to the previous page and click on "Add Volunteer to BARS List".</i></small>
<p>
<label for='type'></label><Input type = 'Radio' Name ='type' value= 'recovery' class='required'>Recovered
<Input type = 'Radio' Name ='type' value= 'donated'>Donated
<Input type = 'Radio' Name ='type' value= 'FCPS'>FCPS
<br>
<label for='brand'>Brand: </label><input type="text" id="brand" name="brand" size=15>
<label for='model'>Model: </label><input type="text" id="model" name="model" size=15>
<label for='color'>Color: </label><input type="text" id="color" name="color" size=10>
<br><i><small>Brand, Model and Color are required fields.</i></small>
<p>
<label for='serial'>Serial Number: </label><input type="text" id="serial" name="serial" size=20>
<p>
Description: <input type="textarea" name="description" size=50>
<p>
<!-- the following set of fields is used for recovered bikes -->
<fieldset id="recovered" style='border:0'>
Please enter the contact information for a recovered bike.
<div>
<label for="contact">Contact: </label><input type="text" id="contact" name="contact" size=15>
<label for="location">Location: </label><input type="text" id="location" name="location" size=15>
<label for="phone">Phone: </label><input type="text" id="phone" name="phone" size=10>
</div>
</fieldset>
<!-- the following set of fields is used for donated bikes -->
<fieldset id="donation" style='border:0'>
Please enter donor's name and the state and last four digits of their driver's license or ID.
<div>
<label for="donor">Donor: </label><input type="text" id="donor" name="donor" size=25>
<label for="donorID">ID: </label><input type="text" id="donorID" name="donorID" size=15>
</div>
</fieldset>
<!-- for bikes picked up from the police, the neither of the above two sets of fields are used -->
<p><input type="submit" name="Submit" value="submit">
</form> 
<script  type="text/javascript">
 var frmvalidator = new Validator("LogBike");
 frmvalidator.addValidation("type","selone","Please specify whether the bike was a recovery, a donation or from Police Services.");
 frmvalidator.addValidation("volunteer","dontselect=000","Please select your name from the Volunteer drop-down list");
 frmvalidator.addValidation("brand","req","Please enter a brand");
 frmvalidator.addValidation("model","req","Please enter a model");
 frmvalidator.addValidation("color","req","Please enter a color");

 frmvalidator.EnableMsgsTogether();
</script>
<?php
// If form has been submitted, post the bike to the RECOVEREDBIKES table.
if(isset($_POST['Submit']))
	{
	$type=$_POST['type'];
	$serial=$_POST['serial'];
	$brand=strtoupper($_POST['brand']);
	// fix case of brand name, but allow for 3 or less letter names like "KHS"
	if (strlen($brand)>3) $brand=ucwords(strtolower($_POST['brand']));
	$model=$_POST['model'];
	$color=strtolower($_POST['color']);
	$description=$_POST['description'];
	if ($type == "recovery") {
		$contact=ucwords($_POST['contact']);
		$location=$_POST['location'];
		$phone=$_POST['phone'];}
	if ($type == "donated") {
		$contact=ucwords($_POST['donor']);
		$location=$_POST['donorID'];
		$phone="";}
	if ($type == "FCPS") {
		$contact="";
		$location="";
		$phone="";}
	$volunteer=ucwords($_POST['volunteer']);
	$rdate=date('Y-m-d');
/*
	// First check to see if it's in the FCPS (stolen bikes) table.
	try
		{
		$query = $db->prepare("SELECT * FROM FCPS WHERE Serial_No Like ?");
		$query->bindValue(1, "%$serial%", PDO::PARAM_STR);
		$query->execute();
		while($result_row = $query->fetch(PDO::FETCH_ASSOC)){
			$case = $result_row['Case_No'];
			Print "<h3>Serial number ".$serial." found in stolen bikes list - case number ".$case."</h3>";
			die;
			}
		}
	catch (PDOException $e)
		{
		print ("The statement failed.\n");
		echo "boo-boo";
		echo "getMessage(): " . $e->getMessage () . "\n";
		}
*/
	$insert = $db->prepare("INSERT INTO RECOVEREDBIKES (Type, RecoveredDate, Serial, Brand, Model, Color, Description, Contact, Location, Phone, Volunteer, SentPS) VALUES  (:type, :rdate, :serial, :brand, :model, :color, :description, :contact, :location, :phone, :volunteer, :sentPS)");
	$insert->bindValue(':type', $type, PDO::PARAM_STR);
	$insert->bindValue(':rdate', $rdate, PDO::PARAM_STR);
	$insert->bindValue(':serial', $serial, PDO::PARAM_STR);
	$insert->bindValue(':brand', $brand, PDO::PARAM_STR);
	$insert->bindValue(':model', $model, PDO::PARAM_STR);
	$insert->bindValue(':color', $color, PDO::PARAM_STR);
	$insert->bindValue(':description', $description, PDO::PARAM_STR);
	$insert->bindValue(':contact', $contact, PDO::PARAM_STR);
	$insert->bindValue(':location', $location, PDO::PARAM_STR);
	$insert->bindValue(':phone', $phone, PDO::PARAM_STR);
	$insert->bindValue(':volunteer', $volunteer, PDO::PARAM_STR);
	// since bikes are logged into LeadsOnline, the SentPS date is the same are the log date
	$insert->bindValue(':sentPS', $rdate, PDO::PARAM_STR);

	try
		{
		// run the query
		$insert->execute();
		}
	catch (PDOException $e)
		{
		echo "The statement failed.\n";
		echo "getCode: ". $e->getCode () . "\n";
		echo "getMessage: ". $e->getMessage () . "\n";
		unset($_POST['submit']); // reset since the insert failed
		exit();
		}

	// Create a record in the LeadsOnline system
	// get the record number as the LeadsOnline ticket number
	$query = $db->prepare("SELECT LAST_INSERT_ID() FROM RECOVEREDBIKES");
	$query->execute();
	$ticket_no = $query->fetchColumn();

	// Set up the WebService connection.
// use the following for testing
//	$wsdl = 'https://sandbox.leadsonline.com/leads/ws/pawn/ticketWS.asmx?wsdl';
// use the following for production
	$wsdl = 'https://www.leadsonline.com/leads/ws/pawn/ticketWS.asmx?wsdl';
	// build the SOAP call parameter array
	$soap_user_params = array(
 		'login' => array(
// 			'storeId' => '50164',	// use for testing
 			'storeId' => '41662',	// use for production
 			'userName' => 'fcbikecoop',
 			'password' => 'fcbcw52101'
 			),
		'ticket' => array(
			'key' => array(
				'ticketType' => 'Unknown',
				'ticketnumber' => $ticket_no,
				'ticketDateTime' => $rdate
				),
			'customer' => array(
				'name' => 'Fort Collins Bike Co-op',
				'weight' => '',
				'height' => ''
				),
			'items' => array(
				'Item' => array(
					'make' => $brand,
					'model' => $model,
					'serialNumber' => $serial,
					'description' => $color." bike ".$description,
					'amount' => '0.0',
					'itemType' => 'Other',
					'itemStatus' => $type,
					'isVoid' => false,
					'employee' => $volunteer
					),
				),
			'isVoid' => false,
			)
		);	

	try
		{
		// Initialize the webservice
		$trace = true;
		$exceptions = true;
		$client = new SoapClient($wsdl, array('soap_version' => SOAP_1_2, 'trace' => $trace, 'exceptions' => $exceptions));	
		// Invoke webservice method: SubmitTransaction
		$response = $client->__soapCall("SubmitTransaction", array($soap_user_params));
		// Print webservice response for testing
//		var_dump($response);
		}
	catch (Exception $e)
		{
		echo "Error!";
		echo $e -> getMessage ();
		echo 'Last response: '. $client->__getLastResponse();
		}
	}

?>
<!-- Display the list of recovered bikes -->
<h2>Recovered Bikes</h2>
Note:  list can be sorted by clicking on the column headers.
<font size=1>
<table border=2 id="dataTable" class="tablesorter">
	<thead>
		<tr>
			<th></th><th>Log</th><th>Date Recovered</th><th class="sorttable_alpha">Serial #</th><th>Brand</th><th>Model</th><th>Color</th><th>Description</th>
		</tr>
	</thead>
	<tbody>
<?php
// Get the list of bikes.
try
	{
	$query = $db->prepare("SELECT * FROM RECOVEREDBIKES ORDER BY BikeID DESC");
	$query->execute();
	}
catch (PDOException $e)
	{
	print ("The statement failed.\n");
	echo "boo-boo";
	echo "getMessage(): " . $e->getMessage () . "\n";
	}
//Fetch & display the results
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$bike = $result_row["BikeID"];
	$log = $result_row["Log"];
	// Instead of using a Co-op "case number", which is confusing because we also have a FCPS case
	//	number, we switched to using the automatically generated record ID (Bike_ID) as the identity for
	// a recovered bike. So, if Co-op case number is blank, use record ID.  
	if (empty($log)) {$log = $bike;}
	$type = $result_row["Type"];
	$rdate = $result_row["RecoveredDate"];
	$serial = $result_row["Serial"];
	$brand = $result_row["Brand"];
	$model = $result_row["Model"];
	$color = $result_row["Color"];
	$description = $result_row["Description"];
	// Shorten "type" to a single letter
	if ($type == "donated") {$type = "D";}
	elseif ($type == "FCPS") {$type = "P";}
	else {$type = "R";}
	$v_rdate = date("m/d/Y",strtotime($rdate));
	echo "<tr>";
	echo "<td>$type</td><td>$log</td><td>$v_rdate</td><td>$serial</td><td>$brand</td><td>$model</td><td>$color</td><td>$description</td>";
	echo "</tr>";
	echo "\n";
	}
// Free used resources
// $result->closeCursor();
$db = null;
?>
	</tbody>
</table>
<?php
// Get the standard Bike Co-op page footer.
include_once($_SERVER['DOCUMENT_ROOT'].'footer.php');
?>
