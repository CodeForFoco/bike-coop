/*************************************************************************
* This file (mLogBike.js) contains Javascript code and is included in the
* mLogBikes.html page.
* It contains routines to do field validation, make Ajax calls to
* ajax-getVols.php to populate the Volunteers selection dialog, and to
* ajax-logBike.php to create a record in the RECOVEREDBIKES table and
* display the logged bike info in an alert box to the user.
*/

$(document).ready(function(){
	$.validator.setDefaults({
		submitHandler: function() {
			sendToServer(); // send the data to the MySQL server if fields are valid
		}
	});
	// validate the form and submit
	$("#logBike").validate({
		ignore: ".ignore",
		rules: {			// define the field validation rules
			volunteer: "required",
			brand: "required",
			model: "required",
			color: "required",
			serial: "required",
			description: "required",
			btype: "required"
		},
		messages: {
			volunteer: "select a volunteer",
			brand: "brand is required",
			model: "model is required",
			color: "color is required",
			serial: "serial number is required",
			description: "description is required",
			btype: "you must select one"
		},
		
		errorPlacement: function (error, element) {
			if (element.is('select')) {
				error.insertAfter(element.parents('div.ui-select'));
			} 
			else if ( element.is(":radio") ) {
				error.appendTo( element.parent() );
			}
			else {
				error.insertAfter($(element).parent());  // default placement
			}
		}
	});
	$('input:radio').change(function (event, ui) {
		$('#logBike').validate().form();
	})
});

// Get the list of volunteers
//var list_target_id = 'list-target'; //first select list ID
var target_html = '<option value="" name="volunteer">Please select a volunteer ...</option>'; //Initial prompt for target select
$('#volunteer').html(target_html); //Give the target select the prompt option
//Display 'loading' status in the target select list
//$('#volunteer').html('<option value="">Loading...</option>');
//Make AJAX request
$.ajax({url: './ajax-getVols.php',
	success: function(output) {
		$('#volunteer').html(output);
		},
	error: function (xhr, ajaxOptions, thrownError) {
		alert(xhr.status + " "+ thrownError);
		}
});
// Set up the hide/show for the fields associated with the Type radio buttons
$(function() {
          var $divs = $('#divs > div');
          $divs.hide()
          $('input[type=radio]').on('change',function() {
                  $divs.hide();
                  $divs.eq( $('input[type=radio]').index( this ) ).show();
           });
});
// Call ajax-logBike.php to create the database record and display the acknowledgement alert. 
function sendToServer() {
	var form_data = $("form").serialize();	// get the form data fields
	var params = form_data.replace(/[^&]+=\.?(?:&|$)/g, ''); // strip out empty fields
	// Log the bike in the database
	//Make AJAX request
	$.ajax({url: './ajax-logBike.php?' + params,
		type: "POST",
		success: function(output) {
		alert(output);
		// clear the form fields
		// volunteer, type and donor fields are not cleared to facilitate logging multiple bikes.
		$('#brand').val('');
		$('#model').val('');
		$('#color').val('');
		$('#serial').val('');
		$('#description').val('');
		},
		error: function (xhr, ajaxOptions, thrownError) {
		alert(xhr.status + " "+ thrownError);
		}
	});
};
