<?php
// This script presents the B.A.R.S. main page
session_start();
// set the variable that will let us get back
// session_register("origin");
$_SESSION['origin']="bars";
$HTTP_SESSION_VARS ["origin"] = "bars";
// set up the variable used for tracking the bike log number
// session_register("log");
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>

<div class="heading">B.A.R.S.</div>
<p>To log a recovered bike, click on "Log a Recovered Bike", fill in the fields and click the "Submit" button. The bike you just logged should appear at the top of the list which appears at the bottom of the form.  <i>Please note that what we used to call a "case number" is now called a "log number" and it is automatically assigned.</i>
<p>If you want to check if a bike has already been logged, click on "List all Bikes" or "Search Recovered Bikes".
<p>If your name does not appear on the list of BARS volunteers in the Log Bike(s) form, click on "Add Volunteer to BARS List" and select your name from the drop-down list.
<p>
<a href="http:./LogBike.php">Log a Recovered Bike</a><br>
<a href="http:./ListBikes.php">List Recovered Bikes</a><br>
<a href="http:./SearchBike.php">Search Recovered Bikes</a><br>
<a href="http:./SearchStolen.php">Search Stolen Bikes</a><br>
<a href="http:./AddToBARS.php">Add Volunteer to BARS List</a><br>

<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
