<?php
// get the email checking code
include('rfc3696.php');
// check ALL the POST variables
function checkSet(){
	return isset($_POST['firstname'], $_POST['lastname'], $_POST['phone'], $_POST['email'], $_POST['address']);
}
/**
 * This function can be used to check the sanity of variables
 *
 * @access private
 *
 * @param string $type  The type of variable can be bool, float, numeric, string, array, or object
 * @param string $string The variable name you would like to check
 * @param string $length The maximum length of the variable
 *
 * return bool
*/
function sanityCheck($string, $type, $length){
  // assign the type
  $type = 'is_'.$type;

  if(!$type($string))
    {
    return FALSE;
    }
  // now we see if there is anything in the string
  elseif(empty($string))
    {
    return FALSE;
    }
  // then we check how long the string is
  elseif(strlen($string) > $length)
    {
    return FALSE;
    }
  else
    {
    // if all is well, we return TRUE
    return TRUE;
		}
}
// check number is greater than 0 and $length digits long
// returns TRUE on success
function checkNumber($num, $length){
	if($num > 0 && strlen($num) == $length)
		{
		return TRUE;
		}
}
function checkEmail($email){
  return preg_match('/^\S+@[\w\d.-]{2,}\.[\w]{2,6}$/iU', $email) ? TRUE : FALSE;
}

session_start();
// Checks to see if the form has been submitted.
// If it hasn't, PHP ignores heaps of this code and display the form.
// If the form was submitted, it will create variables based on
// form field names and users answers.

// this will be the default message if the form accessed without POSTing
$error_msg.="Please fill in the form.<br />";
// check to see if the form has already been successfully submitted
if (isset ($_POST['volid']))
	{
	$error_msg="You've already successfully submitted your application - thank you<br />";
	}
if (isset ($_POST['submit']))
	{
	foreach($_POST as $key=>$value)
		{
		$$key = $value;
		}

	// Create an empty error_msg
	$error_msg='';
	require_once('/var/www/fcbikecoop.org/root/recaptcha/recaptchalib.php');
	$privatekey = "6LcljgQAAAAAAPouSflWvq1dlfio5lRYJ4RvEsGt";
	$publickey = "6LcljgQAAAAAAL1T9O8K4Rv0n3at7RUhFQBsLnoG";
	$resp = recaptcha_check_answer ($privatekey,
				$_SERVER["REMOTE_ADDR"],
				$_POST["recaptcha_challenge_field"],
				$_POST["recaptcha_response_field"]);
	if (!$resp->is_valid)
		{
		$error = $resp->error;
		$error_msg.="* incorrect Captcha response<br />";
		}
	if(checkSet() != FALSE)
		{
		// check the POST variable firstname is sane, and is not empty
		if(empty($_POST['firstname'])==FALSE && sanityCheck($_POST['firstname'], 'string', 25) != FALSE)
			{
			$firstname = ucwords($_POST['firstname']);
			}
		else
			{
			$error_msg.="* first name is not set.<br />";
			}
		// check the POST variable lastname is sane, and is not empty
		if(empty($_POST['lastname'])==FALSE && sanityCheck($_POST['lastname'], 'string', 25) != FALSE)
			{
			$lastname = ucwords($_POST['lastname']);
			}
		else
			{
			$error_msg.="* last name is not set.<br />";
			}
		// check for valid email address
		if(sanityCheck($_POST['email'], 'string', 50) != FALSE)
			{
			if (is_rfc3696_valid_email_address($_POST['email']) != FALSE)
    		{
				$email = $_POST['email'];
				}
			else
				{
				$error_msg.="* invalid Email address<br />";
				}
			}
		else
			{
			$error_msg.="* please provide an email address so we can contact you<br />";
			}
		// check the sanity of the zipcode and that it is greater than zero and 5 digits long - it can be left blank
		$zip = substr($_POST['zip'],0,5);
		if(sanityCheck(substr($_POST['zip'],0,5), 'numeric', 5) != FALSE && checkNumber(substr($_POST['zip'],0,5), 5) == TRUE)
			{
			$zip = substr($_POST['zip'],0,5);
			}
		else
			{
			$zip='';
			}
		//check the date of birth
		if(empty($_POST['dateofbirth'])==FALSE)
			{
			$dt=$_POST['dateofbirth'];
			$arr=preg_split("/[\/]/",$dt); // splitting the array
			$mm=str_pad($arr[0],2,"0",STR_PAD_LEFT); // first element of the array is month
			$dd=str_pad($arr[1],2,"0",STR_PAD_LEFT); // second element is date
			$yy=str_pad($arr[2],4,"19",STR_PAD_LEFT); // third element is year
			if(!checkdate($mm,$dd,$yy))
				{
				$error_msg.="* invalid date of birth; please use mm/dd/yyyy format<br />";
				}
			else
				{
				$dateofbirth = $mm."/".$dd."/".$yy;
				}
			}
		else
			{
			$error_msg.="* please provide your date of birth<br />";
			}
		// convert stuff to initial caps
		$address = ucwords(strtolower($_POST['address']));
		$city = ucwords(strtolower($_POST['city']));
		$emer_name = ucwords(strtolower($_POST['emer_name']));
		$state = ucwords(strtolower($_POST['state']));
		$phone = $_POST['phone'];
		$emer_phone = $_POST['emer_phone'];
		$relationship = $_POST['relationship'];
		$how_learn = $_POST['how_learn'];
		$experience = $_POST['experience'];
		$other_skills = $_POST['other_skills'];
		$skill = $_POST['skill'];
		$greeter = $_POST['greeter'];
		$mechanic = $_POST['mechanic'];
		$recycling = $_POST['recycling'];
		$bars = $_POST['bars'];
		$cleaning = $_POST['cleaning'];
		$handyman = $_POST['handyman'];
		$newsletter = $_POST['newsletter'];
		$art = $_POST['art'];
		$fundraising = $_POST['fundraising'];
		$community = $_POST['community'];
		$local_events = $_POST['local_events'];
		$safety = $_POST['safety'];
		$expectations = $_POST['expectations'];
		$concerns = $_POST['concerns'];
		}
	}

// END BASIC ERROR CHECKING
// You need to create your own code to validate the information
// and allowed values - never send "unclean" user responses
// to a database without cleaning them up and
// checking for allowed answers.
// Google for "SQL injection" and "insecure contact form"

// Do this if no errors were detected AND form has been submitted
if ($error_msg == '' && isset($_POST['submit']))
	{
	//Close the session
	session_write_close();
	// Connect to the MySQL database
	// Include our login information
	include('db_login.php');
//Connect
	$dsn = "mysql:host=$db_host;dbname=".$db_database;
	$opt = array(
    // any occurring errors wil be thrown as PDOException
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    // an SQL command to execute when connecting
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'UTF8'"
		);
	$db = new PDO($dsn, $db_username, $db_password, $opt);
	//Connect
//	$db_error='There was a problem accessing our system.  Please try again later.';
//	$connection = @mysql_connect($db_host, $db_username, $db_password) or die($db_error);
//	// Select the database
//	$db_select = @mysql_select_db($db_database) or die($db_error);
	// fix up the date for MySQL
	$birth = strftime("%Y-%m-%d",strtotime($dateofbirth));
//	$birth = str_replace("-","",$birth);
	$appdate = 
		$query = $db->prepare("INSERT INTO VOLUNTEERS (FirstName, LastName, Address, City, State, Zip, Email, Phone, DOB, EmergencyContact, EmergencyPhone, Relationship, HowLearn, Experience, OtherSkills, Level, Greeter, Mechanic, Recycling, BARS, Clean, Handyman, Newsletter, Art, Fund, Outreach, Events, BikeSafety, Expectations, Comments, AppDate) 
		VALUES (:fname, :lname, :address, :city, :state, :zip, :email, :phone, :dob, :econtact, :ephone, :rel, 
:howlearn, :experience, :otherskills, :skill, :greeter, :mechanic, :recycling, :bars, :cleaning, 
:handyman, :newsletter, :art, :fundraising, :community, :events, :safety, :expectations, :concerns, CURDATE())");
		$query->bindValue(':fname', $firstname, PDO::PARAM_STR);
		$query->bindValue(':lname', $lastname, PDO::PARAM_STR);
		$query->bindValue(':address', $address, PDO::PARAM_STR);
		$query->bindValue(':city', $city, PDO::PARAM_STR);
		$query->bindValue(':state', $state, PDO::PARAM_STR);
		$query->bindValue(':zip', $zip, PDO::PARAM_STR);
		$query->bindValue(':email', $email, PDO::PARAM_STR);
		$query->bindValue(':phone', $phone, PDO::PARAM_STR);
		$query->bindValue(':dob', $birth, PDO::PARAM_STR);
		$query->bindValue(':econtact', $emer_name, PDO::PARAM_STR);
		$query->bindValue(':ephone', $emer_phone, PDO::PARAM_STR);
		$query->bindValue(':rel', $relationship, PDO::PARAM_STR);
		$query->bindValue(':howlearn', $howlearn, PDO::PARAM_STR);
		$query->bindValue(':experience', $experience, PDO::PARAM_STR);
		$query->bindValue(':otherskills', $other_skills, PDO::PARAM_STR);
		$query->bindValue(':skill', $skill, PDO::PARAM_STR);
		$query->bindValue(':greeter', $greeter, PDO::PARAM_STR);
		$query->bindValue(':mechanic', $mechanic, PDO::PARAM_STR);
		$query->bindValue(':recycling', $recycling, PDO::PARAM_STR);
		$query->bindValue(':bars', $bars, PDO::PARAM_STR);
		$query->bindValue(':cleaning', $cleaning, PDO::PARAM_STR);
		$query->bindValue(':handyman', $handyman, PDO::PARAM_STR);
		$query->bindValue(':newsletter', $newsletter, PDO::PARAM_STR);
		$query->bindValue(':art', $art, PDO::PARAM_STR);
		$query->bindValue(':fundraising', $fundraising, PDO::PARAM_STR);
		$query->bindValue(':community', $community, PDO::PARAM_STR);
		$query->bindValue(':events', $local_events, PDO::PARAM_STR);
		$query->bindValue(':safety', $safety, PDO::PARAM_STR);
		$query->bindValue(':expectations', $expectations, PDO::PARAM_STR);
		$query->bindValue(':concerns', $concerns, PDO::PARAM_STR);
		try
			{
			// run the query
			$query->execute();
			}
		catch (PDOException $e)
			{
			echo"The statement failed.\n";
			echo "getCode: ". $e->getCode () . "\n";
			echo "getMessage: ". $e->getMessage () . "\n";
			}	
	// Build our query here and check each variable with mysql_real_escape_string()

	// No errors were detected.
	$volid = mysql_insert_id();
	// Send new volunteer notification.
// The next line is for testing and should be commented out when in production.
//	mail("paullugo@yahoo.com", "Subscribe", "Subscribe", "From: $email");
// The next line is for production and should be commented out when in test.
	mail("volunteers-join@fcbikecoop.org", "Subscribe", "Subscribe", "From: $email");
	// Send notice email to interested staff
// The next line is for testing and should be commented out when in production.
//	$mail_to = 'fcbc.paul@gmail.com';

// The following "mail_to" lines are for production and should be commented out when in test. 
	$mail_to = 'vac@fcbikecoop.org';
    $interests = array();
	if($greeter == 1)
	    {
	    $mail_to .= ', ben@fcbikecoop.org';
	    $interests[] = 'Greeter';
	    }
	if($mechanic == 1 && $skill > 4)
	    {
	    $mail_to .= ', Dr.Tim@fcbikecoop.org';
	    $interests[] = 'Bike Mechanic';
	    }
	if($recycling == 1)
	    {
	    $interests[] = 'Recycling';
	    }
	if($bars == 1)
	    {
	    $mail_to .= ', bars@fcbikecoop.org';
	    $interests[] = 'Bike Retrieval';
	    }
	if($cleaning == 1)
	    {
	    $interests[] = 'Cleaning/Organizing the Shop';
	    }
	if($handyman == 1 && $skill > 4)
	    {
	    $mail_to .= ', cuttercrew@gmail.com';
	    $interests[] = 'Handyman/Construction';
	    }
	if($newsletter == 1)
	    {
	    $mail_to .= ', pr@fcbikecoop.org';
	    $interests[] = 'Newsletter';
	    }
	if($art == 1)
	    {
      $mail_to .= ', art@fcbikecoop.org';
	    $interests[] = 'Art Contributions';
	    }
	if($fundraising == 1)
	    {
	    $mail_to .= ', grants@fcbikecoop.org';
	    $interests[] = 'Fundraising';
        }
	if($community == 1 || $local_events == 1)
	    {
	    $mail_to .= ', outreach@fcbikecoop.org';
	    $interests[] = 'Helping with Community Outreach';
	    }
	if($safety == 1)
	    {
	    $mail_to .= ', rick@experienceplus.com';
	    $interests[] = 'BikeSafety';
	    }
	if($kidtrips == 1)
    	{
	    $mail_to .= ', sam.vazquez@gmail.com';
	    $interests[] = 'Trips for Kids';
        }
    $interests = implode(", ", $interests);
    
	mail( $mail_to,"[fcbikecoop] New Volunteer - $lastname, $firstname",
	"This volunteer is interested in your program!
	New Volunteer Info

	$lastname, $firstname
	$address
	$city, $state
	$zip
	$email
	$phone
	Born: $dateofbirth

	Emergency Contact
	$emer_name
	$emer_phone
	$relationship

	How did they learn about the Co-op?
	$how_learn

	Prior Experience
	$experience

	Other Skills
	$other_skills

	Tool Skill Level (1-10)
	$skill

	Interests as a volunteer
	$interests

	What are the Volunteer's expectations from the Co-op?
	$expectations

	Other questions, comments, or concerns.
	$concerns",


	"From: webmaster@fcbikecoop.org");
	// end of email to staff
	// Send welcome email to new volunteer.
	$message=
"We have a regular volunteer orientation on the first Wednesday of the month at 6:30 pm at the Co-op.

The orientation is focused on open shop and work nights - two of our biggest programs. We take a tour of the shop, talk about some of our other programs, and give you a general overview of volunteering at the coop. It lasts about an hour.

If you want to get started right away, you don't have to wait for the orientation. Please come by the shop during public hours and talk to us.

We are trying to expand our volunteer opportunities for people who may not want to work on bikes. Some ideas are leading bike rides, planning social events, and grant writing. If you are interested or have other ideas, please let us know.
    
Depending on how you filled out the volunteer application you may be contacted directly by a program director who is interested in working with you.

If you are under 18 years of age you need to fill out our Youth Agreement Form. Please bring a parent or guardian with you to the orientation.

If you want to work off public service hours do not need to attend the orientation. You can work off those hours during our work nights MWF 6-10pm. Please bring any paperwork you have.

Hope to see you soon,
Mike

You received this message because you (or someone using your email address) filled out our volunteer application at http://fcbikecoop.org/volunteer_db/volunteer_form.php.";
    // In case any of our lines are larger than 70 characters, we should use wordwrap()
//    $message = wordwrap($message, 70, "\r\n");
    $headers   = array();
    $headers[] = "MIME-Version: 1.0";
    $headers[] = "Content-type: text/plain; charset=iso-8859-1";
    $headers[] = "From: vac@fcbikecoop.org";
    $headers[] = "CC: fcbc.paul@gmail.com";
    $headers[] = "Reply-To: vac@fcbikecoop.org";
    $headers[] = "Subject: Welcome to the Bike Co-op";
    $headers[] = "X-Mailer: PHP/".phpversion();

    mail($email, "Welcome to the Bike Co-op", $message, implode("\r\n", $headers));
	// end of email to volunteer
    
	// Redirect to confirmation page.
	header ("Location: http:volunteer_form_done.php");
	exit;
}

// If PHP is still reading this, it must be the first page visit,
// OR an error was detected.
// Display the HTML page and your signup form.
include_once('/var/www/fcbikecoop.org/root/header.php');

// If the form has been submitted,
// display the error messages above the form.
if(isset($_POST['submit']))
{
echo "<font color=\"yellow\" size=\"3\">The following problems were detected:<br><i>" .$error_msg ."</i></font><br>";
}
?>
<form method="POST" action="<?php echo $PHP_SELF;?>" enctype="multipart/form-data">
   <div class="heading">FC Bike Co-op Volunteer Application</div></td>

<table width="550">
	<tr>
	<td align=left colspan="2">This application will let us know of your intent to volunteer and we'll get you plugged into the co-op via email.  After you're tied in and get some volunteer hours under your belt you will be eligible for volunteer privileges.  <b>Fields marked with ** are required.</b>
	</tr>
	<tr>
		<td align=right width="25%">First Name:</td>
		<td align=left><input name="firstname" type="text" id="firstname" size="35" maxlength="25" value="<?php echo $firstname ?>"> <b>**</b>
	</tr>
	<tr>
		<td align=right width="25%">Last Name:</td>
		<td align=left><input name="lastname" type="text" id="lastname" size="35" maxlength="25" value="<?php echo $lastname ?>"> <b>**</b>
	</tr>
	<tr>
		<td align=right width="25%">Phone:</td>
		<td align=left><input name="phone" type="text" id="phone" size="35" maxlength="15" value="<?php echo $phone ?>">
	</tr>
	<tr>
		<td align=right width="25%">Email Address:</td>
		<td align=left><input name="email" type="text" id="email" size="35" maxlength="50" value="<?php echo $email ?>"> <b>**</b>
	</tr>
	<tr>
		<td align=right width="25%">Date of Birth:</td>
		<td align=left><input name="dateofbirth" type="text" id="dateofbirth" size="10" maxlength="10" value="<?php echo $dateofbirth ?>"> (MM/DD/YYYY) <b>**</b>
	</tr>
	<tr>
		<td align=right width="25%">Address:</td>
		<td align=left><input name="address" type="text" id="address" size="35" maxlength="100" value="<?php echo $address ?>">
	</tr>
	<tr>
		<td align=right width="25%">City:</td>
		<td align=left><input name="city" type="text" id="city" size="35" maxlength="25" value="<?php echo $city ?>">
	</tr>
	<tr>
		<td align=right width="25%">State:</td>
		<td align=left><select name="state" id="state">
			<option value="<?php echo $state ?>" selected="selected"><?php echo $state ?></option>
			<option value="CO">Colorado</option>
			<option value="WY">Wyoming</option>			
			<option value="AL">Alabama</option>
			<option value="AK">Alaska</option>
			<option value="AZ">Arizona</option>
			<option value="AR">Arkansas</option>
			<option value="CA">California</option>
			<option value="CT">Connecticut</option>
			<option value="DC">District of Columbia</option>
			<option value="DE">Delaware</option>
			<option value="FL">Florida</option>
			<option value="GA">Georgia</option>
			<option value="HI">Hawaii</option>
			<option value="ID">Idaho</option>
			<option value="IL">Illinois</option>
			<option value="IN">Indiana</option>
			<option value="IA">Iowa</option>
			<option value="KS">Kansas</option>
			<option value="KY">Kentucky</option>
			<option value="LA">Louisiana</option>
			<option value="ME">Maine</option>
			<option value="MD">Maryland</option>
			<option value="MA">Massachusetts</option>
			<option value="MI">Michigan</option>
			<option value="MN">Minnesota</option>
			<option value="MS">Mississippi</option>
			<option value="MO">Missouri</option>
			<option value="MT">Montana</option>
			<option value="NE">Nebraska</option>
			<option value="NV">Nevada</option>
			<option value="NH">New Hampshire</option>
			<option value="NJ">New Jersey</option>
			<option value="NM">New Mexico</option>
			<option value="NY">New York</option>
			<option value="NC">North Carolina</option>
			<option value="ND">North Dakota</option>
			<option value="OH">Ohio</option>
			<option value="OK">Oklahoma</option>
			<option value="OR">Oregon</option>
			<option value="PA">Pennsylvania</option>
			<option value="RI">Rhode Island</option>
			<option value="SC">South Carolina</option>
			<option value="SD">South Dakota</option>
			<option value="TN">Tennessee</option>
			<option value="TX">Texas</option>
			<option value="UT">Utah</option>
			<option value="VT">Vermont</option>
			<option value="VA">Virginia</option>
			<option value="WA">Washington</option>
			<option value="WV">West Virginia</option>
			<option value="WI">Wisconsin</option>
		</select>
	</tr>
	<tr>
		<td align=right width="25%">Zip Code:</td>
		<td align=left><input name="zip" type="text" id="zip" size="6" maxlength="5" value="<?php echo $zip ?>">
	</tr>
	<tr>
		<td align=left colspan="2"><h2>Emergency Contact</h2></td>
	</tr>
	<tr>
		<td align=right width="25%">Name:</td>
		<td align=left><input name="emer_name" type="text" id="emer_name" size="35" maxlength="50" value="<?php echo $emer_name ?>">
	</tr>
	<tr>
		<td align=right width="25%">Phone:</td>
		<td align=left><input name="emer_phone" type="text" id="emer_phone" size="35" maxlength="15" value="<?php echo $emer_phone ?>">
	</tr>
	<tr>
		<td align=right width="25%">Relationship:</td>
		<td align=left><input name="relationship" type="text" id="relationship" size="35" maxlength="25" value="<?php echo $relationship ?>">
	</tr>
	<tr>
		<td align=left colspan="2"><h2>Experience</h2></td>
	</tr>
	<tr>
		<td align=left colspan="2">How did you learn about the Co-op?</td>
	</tr>
		<td align=left colspan="2"><input type=hidden name="how_learn" value="NULL"><textarea name="how_learn" rows="5" cols="65" wrap="virtual"><?php echo $how_learn ?></textarea>
	</tr>
	<tr>
		<td align=left colspan="2">Do you have any prior experience fixing bikes? Explain...</td>
	</tr>
		<td align=left colspan="2"><input type=hidden name="experience" value="NULL"><textarea name="experience" rows="5" cols="65" wrap="virtual"><?php echo $experience ?></textarea>
	</tr>
	<tr>
		<td align=left colspan="2">Do you have any other skills that may help the Co-op?</td>
	</tr>
		<td align=left colspan="2"><input type=hidden name="other_skills" value="NULL"><textarea name="other_skills" rows="5" cols="65" wrap="virtual"><?php echo $other_skills ?></textarea>
	</tr>
	<tr>
		<td align=left colspan="2">How skilled are you with tools?</td>
	</tr>
	<tr>
		<td align=left colspan="2"><select name="skill">
		<option value="<?php echo $skill ?>" selected="selected"><?php echo $skill ?></option>
		<option value="0">0</option>
		<option value="1">1</option>
		<option value="2">2</option>
		<option value="3">3</option>
		<option value="4">4</option>
		<option value="5">5</option>
		<option value="6">6</option>
		<option value="7">7</option>
		<option value="8">8</option>
		<option value="9">9</option>
		<option value="10">10</option></select></td>
	</tr>
   </table>

   <table width="550">
	<tr>
		<td colspan="2"><h2>Interests as a volunteer.</h2>(Move your mouse over an item to see a description.)
	</tr>
	<tr>
		<td width="50% align="right"><input type=hidden name="greeter" value="0"><input type=checkbox name="greeter" value="1"<?php if ($greeter=="1") { echo 'checked'; } ?>><a href="#" style="color:#FFCC33">Front Desk / Retail / Greeter<span>Assist during open shop and retail hours at the co-op.  Greet people, answer questions, sell items and help run the show!</span></a>
		<td width="50% align="right"><input type=hidden name="mechanic" value="0"><input type=checkbox name="mechanic" value="1"<?php if ($mechanic=="1") { echo 'checked'; } ?>><a href="#" style="color:#FFCC33">Bike Mechanic<span>Our bike mechanics work on sorting donations, building/fixing bikes and teaching people during open shop. You will need to have demonstrable bike mechanic skills to do this work.</span></a>
	</tr>
	<tr>
		<td align="left"><input type=hidden name="recycling" value="0"><input type=checkbox name="recycling" value="1"<?php if ($recycling=="1") { echo 'checked'; } ?>><a href="#" style="color:#FFCC33">Recycling<span>With all of the bikes and parts that come through the Co-op, there are a lot of parts that are broken or junk. Somebody has to go through it all.</span></a>
		<td width="50% align="right"><input type=hidden name="bars" value="0"><input type=checkbox name="bars" value="1"<?php if ($bars=="1") { echo 'checked'; } ?>><a href="#" style="color:#FFCC33">Bike Retrieval<span>Respond to public reports of lost and abandoned bikes to coordinate retrieval; work with Police Services in tracking found bikes and returning them to their owners. </span></a>
	</tr>
	<tr>
		<td align="left"><input type=hidden name="cleaning" value="0"><input type=checkbox name="cleaning" value="1"<?php if ($cleaning=="1") { echo 'checked'; } ?>>Cleaning/Organizing the Shop
		<td width="50% align="right"><input type=hidden name="handyman" value="0"><input type=checkbox name="handyman" value="1"<?php if ($handyman=="1") { echo 'checked'; } ?>><a href="#" style="color:#FFCC33">Handyman/Construction<span>Projects range from installing sinks, running low voltage and 110vac wiring, replacing a staircase, building partition walls etc.  Will work with construction leader to complete a variety of projects.</span></a>
	</tr>
	<tr>
		<td align="left"><input type=hidden name="newsletter" value="0"><input type=checkbox name="newsletter" value="1"<?php if ($newsletter=="1") { echo 'checked'; } ?>>Newsletter Drafting/PR
		<td align="left"><input type=hidden name="art" value="0"><input type=checkbox name="art" value="1"<?php if ($art=="1") { echo 'checked'; } ?>>Art Contributions / Graphic Design
	</tr>
	<tr>
		<td align="left"><input type=hidden name="fundraising" value="0"><input type=checkbox name="fundraising" value="1"<?php if ($fundraising=="1") { echo 'checked'; } ?>>Fundraising / Grant Writing
		<td width="50% align="right"><input type=hidden name="community" value="0"><input type=checkbox name="community" value="1"<?php if ($community=="1") { echo 'checked'; } ?>>Helping with Community Outreach
	</tr>
	<tr>
		<td align="left"><input type=hidden name="local_events" value="0"><input type=checkbox name="local_events" value="1"<?php if ($local_events=="1") { echo 'checked'; } ?>>Assist With Local Bike Events
		<td width="50% align="right"><input type=hidden name="kidtrips" value="0"><input type=checkbox name="kidtrips" value="1"<?php if ($kidtrips=="1") { echo 'checked'; } ?>><a href="#" style="color:#FFCC33">Trips for Kids<span>Trips for Kids a program that takes underprivileged kids aged 10-15 out on mountain bike rides on Saturday mornings. We need mechanics and ride volunteers.</span></a>
	</tr>
	<tr>
		<td width="50% align="right"><input type=hidden name="safety" value="0"><input type=checkbox name="safety" value="1"<?php if ($safety=="1") { echo 'checked'; } ?>><a href="#" style="color:#FFCC33">Bike Safety Education<span>Help educate our community on bicycle safety and smart cycling based on the vehicular cycling principles of the League of American Bicyclists.  Work with the Co-op’s Smart Cycling coordinator to teach classes to kids and adults, including bike skills workshops (also called “bike rodeos”).  We hope to eventually lead smart cycling rides in town to demonstrate the principles that we teach.</span></a>

	</tr>
	<tr>
		<td><hr>
	</tr>
	<tr>
		<td align=left colspan="2">What are your expectations out of volunteering for the Co-op?</td>
	</tr>
	<tr>
		<td align=left colspan="2"><input type=hidden name="expectations" value="NULL"><textarea name="expectations" rows="5" cols="65" wrap="virtual"><?php echo $expectations ?></textarea>
	</tr>
	<tr>
		<td align=left colspan="2">Any other questions, comments, or concerns?</td>
	</tr>
	<tr>
		<td align=left colspan="2"><input type=hidden name="concerns" value="NULL"><textarea name="concerns" rows="5" cols="65" wrap="virtual"><?php echo $concerns ?></textarea>
	</tr>
</table>
<h3>This is not an application for the Earn-a-Bike program. Stop by during <a href="http://fcbikecoop.org/calendar.php">public hours</a> to start the Earn-a-Bike Program.</h3>
<h3>You do not need this form for community service. Stop by during <a href="http://fcbikecoop.org/calendar.php">public hours</a> to learn about serving community service at the Bike Co-op.</h3>

<p>Please type the 2 words that appear in the box below.  If you can't read them, click on the "get a new challenge" icon in the box to get a new pair of words.  Using this prevents spammers from getting into our web pages.
<p>
<?php
require_once('/var/www/fcbikecoop.org/root/recaptcha/recaptchalib.php');
$publickey = "6LcljgQAAAAAAL1T9O8K4Rv0n3at7RUhFQBsLnoG";
echo recaptcha_get_html($publickey, $error);
?>
<br><br><input type="submit" value="Send" name="submit">
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
