<?php
/**
	*	AddToEABvols.php - part of the Fort Collins Bike Co-op system for managing the Earn-A-Bike program.
	*
	* This script lets you select a volunteer from the list of volunteers and add them to the list 
	* of volunteers who log EAB data.
	*/


// Add a volunteer to the EABvols table
session_start();
$_SESSION['list']="AddToEABvols";
$HTTP_SESSION_VARS ["list"] = "AddToEABvols";

$current_page = htmlentities($_SERVER['PHP_SELF']);
// Set up values for this script.
$caller="AddToEABvols";
$page="EAB Volunteers";
$program="AddToEABvols";

// Include the standard code for setting up the session.
require_once "./session_setup.php";

//Get the volunteer names from the database
$query = $db->prepare("SELECT Name, VolID FROM Names");
$query->execute();

//Fetch & display the results
$options="";
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$volid=$result_row["VolID"];
	$volname = $result_row["Name"];
	$options.="<OPTION VALUE=\"$volid\">$volname</option>";
	}
?>
<form method="post" action="<?php echo $PHP_SELF;?>">
<br>
Find the name in the drop-down list and then click on the Select button.
<br>Names are listed alphabetically by first name (as entered on the volunteer application).
<br>If your name is not on the list, please <a href="volunteer_form.php">submit a volunteer application</a>.
<br>
<SELECT NAME="volunteer">
<OPTION VALUE="\"$volid\">Choose a Name</option>"
<OPTION SELECTED VALUE = "\"$volid\">
<?=$options?>
</SELECT>
<input type="submit" name="Select" value="Select">

<?php
// If form has been submitted
if(isset($_POST['Select']))
	{
	$volid = $_POST['volunteer'];
	//Assign the query
	$query = $db->prepare("SELECT * FROM Names WHERE VolID=:volid");
	$query->bindParam(":volid", $volid);
	try
	{
	// run the query
	$query->execute();
	}
	catch (PDOException $e)
		{
    var_dump($e->getMessage());
    var_dump($db->errorInfo());
    die('....');
		}

	// Get the volunteer's name
	while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	$volname = $result_row["Name"];
	// Add the volunteer to the EAB volunteers table.
	$query = $db->prepare("INSERT INTO EABvols (Volunteer, VolID) VALUES (:volname, :volid)");
	$query->bindParam(":volname", $volname);
	$query->bindParam(":volid", $volid);
	try
		{
		// run the query
		$query->execute();
		}
	catch (PDOException $e)
		{
    	var_dump($e->getMessage());
    	var_dump($db->errorInfo());
    	die('....');
		}
	}
// Display the List
echo "<table>";
$query = $db->prepare("SELECT * FROM EABvols");
try
	{
	// run the query
	$query->execute();
	}
catch (PDOException $e)
	{
	var_dump($e->getMessage());
    var_dump($db->errorInfo());
    die('....');
	}

//Fetch & display the results
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$volunteer = $result_row["Volunteer"];
	echo "<td>$volunteer</td>";
	echo "</tr>";
	echo "\n";
	}
echo "</table>";
// Free used database resources.
$db = null;
// Finish the page.
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
