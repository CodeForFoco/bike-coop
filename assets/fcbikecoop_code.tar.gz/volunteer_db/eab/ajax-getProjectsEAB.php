<?php
// Turn off all error reporting
error_reporting(0);
//Connect to the Bike Co-op database
require_once($_SERVER['DOCUMENT_ROOT'].'db_connect.php');
$db = db_connect ();
//Get the list of bikes available for EAB projects.
try
	{
	$query = $db->prepare("SELECT * FROM RECOVEREDBIKES WHERE Disposition LIKE 'EAB' AND (Status = 'project' OR Status = 'complete') ORDER BY Status DESC, BikeID DESC");
	$query->execute();
	}
catch (PDOException $e)
	{
	print ("The statement failed.\n");
	echo "boo-boo";
	echo "getMessage(): " . $e->getMessage () . "\n";
	}
//Fetch the log numbers for use in the bike selection list
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$bikeid = $result_row["BikeID"];
	$type = $result_row["Type"];
	$brand = $result_row["Brand"];
	$model = $result_row["Model"];
	$color = $result_row["Color"];
	$status = $result_row["Status"];
	$btncolor = "ui-btn-g";
	if ($status == "complete") {$btncolor="ui-btn-g";}
	else {$btncolor="ui-btn-a";}
	echo "<li><a data-role='button' class='ui-btn ".$btncolor." ui-btn-icon-right ui-icon-carat-r' data-ajax='false' href = '#bike?bikeid=".$bikeid."'>#".$bikeid." ".$color." ".$brand." ".$model."</a></li>";
	}
?>
