<?php
/**
	*	EABsignup.php - part of the Fort Collins Bike Co-op system for managing the Earn-A-Bike program.
	*
	* This script is for recording an Earn-a-Bike (EAB) application.
	* There are two kinds of EAB candidates: (1) those referred by a social services agency and (2)
	* those who simply want to earn a bike by doing community service.  Individuals in the first case
	* need to complete 10 hours of service, whereas those in the second case need 20 hours.
	* At the present time, we are limiting the number of applications accepted to ten in any given month.
	* However, if an application becomes "inactive", it can be replaced with another.
*/
$current_page = htmlentities($_SERVER['PHP_SELF']);

// Connect to the Bike Co-op database.
require_once "../../db_connect.php";
$db = db_connect ();
// Run the query to get a count of the active applications in the current month. 
// If an application was cancelled (status=C) then the app form number can go above 15.
$query = $db->prepare("SELECT COUNT(*) AS count FROM EAB WHERE YEAR(TSdate)=YEAR(CURDATE()) AND MONTH(TSdate)=MONTH(CURDATE()) AND (Status='A' OR Status='B')");
$query->execute();
$count = $query->fetchColumn();

if ($count == '15')
	{
	echo "<script>alert('We have already accepted $count applications for this month.')</script>";
	exit;
	}
// Count the total applications in the current month, including any marked inactive (Status = C).
$query = $db->prepare("SELECT COUNT(*) AS count FROM EAB WHERE YEAR(TSdate)=YEAR(CURDATE()) AND MONTH(TSdate)=MONTH(CURDATE())");
$query->execute();
$count = $query->fetchColumn();

// Calculate the timesheet form number: YYYYMM##, where ## is the next sequential number for the month.
$TSnum =  $count + 1;
$TSnum =  str_pad($TSnum,2,'0', STR_PAD_LEFT);
$today = date("Y-m");;
$timesheet = $today."-".$TSnum;

// Do this if form has been submitted
if(isset($_POST['Submit']))
	{
	$tsdate=date('Y-m-d');
	$volunteer=ucwords($_POST['volunteer']);
	$type=$_POST['type'];
	$owner=ucwords($_POST['owner']);
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	$height=$_POST['height'];
	$agency=$_POST['agency'];
	$referrer=$_POST['referrer'];
	$status="A";
	$insert = $db->prepare("INSERT INTO EAB (timesheet, TSdate, EnteredBy, Type, Owner, Email, Phone, Height, Agency, AgencyID, Status) VALUES (:timesheet, :tsdate, :volunteer, :type, :owner, :email, :phone, :height, :agency, :referrer, :status)");
	$insert->bindValue(':timesheet', $timesheet, PDO::PARAM_STR);
	$insert->bindValue(':tsdate', $tsdate, PDO::PARAM_STR);
	$insert->bindValue(':volunteer', $volunteer, PDO::PARAM_STR);
	$insert->bindValue(':type', $type, PDO::PARAM_STR);
	$insert->bindValue(':owner', $owner, PDO::PARAM_STR);
	$insert->bindValue(':email', $email, PDO::PARAM_STR);
	$insert->bindValue(':phone', $phone, PDO::PARAM_STR);
	$insert->bindValue(':height', $height, PDO::PARAM_STR);
	$insert->bindValue(':agency', $agency, PDO::PARAM_STR);
	$insert->bindValue(':referrer', $referrer, PDO::PARAM_STR);
	$insert->bindValue(':status', $status, PDO::PARAM_STR);
	try
		{
		// run the insert
		$insert->execute();
		}
	catch (PDOException $e)
		{
		echo "The statement failed.\n";
		echo "getCode: ". $e->getCode () . "\n";
		echo "getMessage: ". $e->getMessage () . "\n";
		}
	// No errors were detected - go back to the EAB home page.
	header("Location:index.php");
	exit();
	}
// If PHP is still reading this, it must be the first page visit,
// OR an error was detected.

// Display the HTML page and the signup form.
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<link rel="stylesheet" href="form.css" type="text/css" media="screen" charset="utf-8"/>
<!-- We will be using JQuery functions and JavaScript for processing the form. -->
<script type='text/javascript' src='../jquery-1.7.1.min.js'></script>
<script type='text/javascript' src='../jquery.validate.min.js'></script>
<script type='text/javascript' src='./EABsignup.js'></script>

<!-- Set up the "breadcrumb" list that helps the user navigate back. -->
<table cellpadding='5'>
	<tr>
		<td style='width:0%; white-space:nowrap'>
		<td><a href='./index.php'>EAB</a> <b>&raquo;</b> EAB Sign Up</td>
	</tr>
</table>
<div class="heading">Earn A Bike Application Data Sheet</div>
<form id="appForm" method="POST" action="<?php echo $PHP_SELF;?>" enctype="multipart/form-data">
<h3>Timesheet Form Number: <?php echo $timesheet ?></h3>
<?php
// Fetch the names for use in the volunteer selection list.
try
	{
	$query = $db->prepare("SELECT * FROM EABvols");
	$query->execute();
	}
catch (PDOException $e)
	{
	print ("The statement failed.\n");
	echo "boo-boo";
	echo "getMessage(): " . $e->getMessage () . "\n";
	}
// Build the selection list.
$options="";
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$volname = $result_row["Volunteer"];
	$options.="<OPTION VALUE=\"$volname\">$volname</option>";
	}
?>
<label for='volunteer'>Logged by: </label>
<select id="volunteer" name="volunteer">
				<option value="000" selected>Choose a Name</option>"
				<?=$options?>
			</select>
<br><i><small>Note: If your name does not appear on the drop-down list of volunteers, go back to the previous page and click on "Add Volunteer to EAB List".</i></small>

<fieldset>
<legend>Applicant Information</legend>
<Input type = 'Radio' Name ='type' class='required' value= 'EAB'<?PHP print $eab_type; ?>>EAB
<Input type = 'Radio' Name ='type' value= 'Referral'<?PHP print $ref_type; ?>>Referral
<div>
<label for="owner">Name: </label><input type="text" id="owner" name="owner" size=25>
</div>
<div>
<label for="email">Email: </label><input type="text" id="email" name="email" size=15>
</div>
<div>
<label for="phone">Phone: </label><input type="text" id="phone" name="phone" size=12>
</div>
<div>
<label for="height">Height: </label><input type="text" id="height" name="height" size=5>
</div></fieldset>
<fieldset id="referral">
<legend>Referral Information</legend>
<div>
<!-- HTML5 added a "combox" like object so we can preload the most frequently used agencies -->
<label for="agency">Agency: </label><input type=text list=agencies id="agency" name="agency">
<datalist id=agencies >
		<option> Halfway House/LCCC
		<option> Murphy Center
		<option> Catholic Charities
		<option> Salvation Army
</datalist>
</div>
<div>
<label for="referrer">Referrer: </label><input type="text" id="referrer" name="referrer" size=15>
</div>
</fieldset>
<p>
<input type="submit" name="Submit" value="submit">
Enter the information and click on submit.
</form>
<?php
// Finish the page.
include_once('/var/www/fcbikecoop.org/root/footer.php');
// Free used database resources.
$result->closeCursor();
$db = null;
?>
