<?php
/**
	*	EABHoursByOrg.php - part of the Fort Collins Bike Co-op system for managing the Earn-A-Bike program.
	*
	* This script presents the page showing hours of community service performed at a
	* selected organization
	*/

session_start();
$_SESSION['list']="EABHoursByOrg";
$HTTP_SESSION_VARS ["list"] = "EABHoursByOrg";

$current_page = htmlentities($_SERVER['PHP_SELF']);
// Set up values for this script.
$caller="EABHoursByOrg";
$page="Hours By Organization";
$program="EABHoursByOrg.php";

// Include the standard code for setting up the session.
require_once "./session_setup.php";

// Run the query to get the list  of organizations.
$query = $db->prepare("SELECT DISTINCT Org1 AS orgs FROM EAB where Org1 is not null
UNION
SELECT DISTINCT Org2 AS orgs FROM EAB where Org2 is not null
UNION
SELECT DISTINCT Org3 AS orgs FROM EAB where Org3 is not null
UNION
SELECT DISTINCT Org4 AS orgs FROM EAB where Org4 is not null
order by orgs");
$query->execute();

$options="";
//Fetch the names for use in the organization selection list
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$orgname = $result_row["orgs"];
	$options.="<OPTION VALUE=\"$orgname\">$orgname</option>";
	}
?>
<form method="post" action="<?php echo $PHP_SELF;?>">
<!-- Build the fields for a recovered bike. -->
Select the organization name.
<p>
<select id="org" name="org">
				<option value="000" selected>Choose an Orgnization</option>"
				<?=$options?>
			</select>
<p>
<input type="submit" name="Submit" value="submit">
</form> 
<table border=2 id="dataTable" class="tablesorter" style="font-size:14px;">
	<thead>
		<tr>
			<th>Type</th><th>Year</th><th>Qtr</th><th>Clients</th><th>Hours
		</tr>
	</thead>
	<tbody>
<?php
// If form has been submitted, search the EAB table.
if(isset($_POST['Submit']))
	{
	$org=$_POST['org'];
	$arg=$org."%";
	$query = $db->prepare("SELECT Type,YEAR(BikeDate) AS Year, QUARTER(BikeDate) AS Qtr, 
		COUNT(*) AS Clients, SUM(Hours1 + Hours2 + Hours3 + Hours4) AS Hours FROM EAB 
		WHERE (UPPER(Org1) Like UPPER(:arg) OR UPPER(Org2) Like UPPER(:arg)
		 OR UPPER(Org3) Like UPPER(:arg) OR UPPER(Org4) Like UPPER(:arg)) 
		GROUP BY Year,Qtr,Type ORDER BY Type DESC,Year DESC,Qtr DESC");
	$query->bindParam(":arg", $arg);
	try
		{
		// run the query
		$query->execute();
		}
	catch (PDOException $e)
		{
    var_dump($e->getMessage());
    var_dump($db->errorInfo());
    die('....');
		}

// Show the organization name
	echo "<font size=2>Hours volunteered at ".$org;
// Fetch & display the results
	while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$type = $result_row["Type"];
	$year = $result_row["Year"];
	$qtr = $result_row["Qtr"];
	$clients = $result_row["Clients"];
	$hours = $result_row["Hours"];
	echo "<td>$type</td><td>$year</td><td align=center>$qtr</td><td align=right>$clients</td><td align=right>$hours</td>";
	echo "</tr>";
	echo "\n";
		}
	}
?>
	</tbody>
</table>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
