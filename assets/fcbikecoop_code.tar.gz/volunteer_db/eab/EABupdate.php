<?php
/**
	*	EABupdate.php - part of the Fort Collins Bike Co-op system for managing the Earn-A-Bike program.
	*
	* This script presents the page for displaying and modifying the status of an EAB application.
	* The number of the application is passed by the calling script in the "TS" (Timesheet) session
	* variable.
	* Once the user enters the information and presses Submit, the data is validated and, if no errors are
	* found, the database record is updated and the user is returned to the list from which this script
	* was called.
	*/
	
session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
/**
	*	The script assumes that session variables have been set by the calling script.
	* Those variable is used to build the "breadcrumb" list that helps the user navigate back.
	*/
// Get the variables that will let us get back to previous pages.
$list = $_SESSION['list'];
// Build the appropriate "breadcrumb" list.
if ($list == "EABlist")
	{
	$list_link_back = "<a href='./EABlist.php'>EAB Applications</a>";
	}
elseif ($list == "EABactive")
	{
	$list_link_back = "<a href='./EABactive.php'>Active EAB Applications</a>";
	}
else
	{
	// Set up some defaults in case the session variable didn't get set correctly.
	$list = "EABactive";
	$list_link_back = "<a href='./EABactive.php'>Active EAB Applications</a>";
	}

// get the application to be edited
$timesheet = $_GET['TS'];
// Connect to the Bike Co-op database.
require_once "../../db_connect.php";
$db = db_connect ();
// Get the timesheet to be edited.
$query = $db->prepare("SELECT * FROM `EAB` WHERE `Timesheet`=?");
$query->bindValue(1, $timesheet, PDO::PARAM_INT);
	try
		{
		// run the query
		$query->execute();
		}
	catch (PDOException $e)
		{
    	var_dump($e->getMessage());
    	var_dump($db->errorInfo());
    	die('....');
		}
//Fetch & display the results
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$timesheet = $result_row["Timesheet"];
	// Change the date format for display purposes.
	$TSdate = $result_row["TSdate"];
	$v_TSdate = date("m/d/Y",strtotime($TSdate));
	$volunteer = $result_row["EnteredBy"];
	$owner = $result_row["Owner"];
	$email = $result_row["Email"];
	$phone = $result_row["Phone"];
	$type = $result_row["Type"];
		if ($type == "EAB")
			{$eab_button = "checked";}
		else
			{$eab_button = "";}
		if ($type == "Referral")
			{$ref_button = "checked";}
		else
		{	$ref_button = "";}
	$wk2call = $result_row["2wkCall"];
	$wk2caller = $result_row["2wkCaller"];
	$wk4call = $result_row["4wkCall"];
	$wk4caller = $result_row["4wkCaller"];
	$comments = $result_row["Comments"];
	$agency = $result_row["Agency"];
	$referrer = $result_row["AgencyID"];
	$status = $result_row["Status"];
	if ($status == "A")	{$active_button = "checked";}
	else {$active_button = "";}
	if ($status == "C")	{$cancel_button = "checked";}
	else {$cancel_button = "";}
	if ($status == "B")	{$bike_button = "checked";}
	else {$bike_button = "";}
	// Change the date format for display purposes.
	if ($wk2call > '0000-00-00') {$v_wk2call = date("m/d/Y",strtotime($wk2call));}
	if ($wk4call > '0000-00-00') {$v_wk4call = date("m/d/Y",strtotime($wk4call));}
	}
// Do this if form has been submitted
if(isset($_POST['Submit']))
	{
	$volunteer=ucwords($_POST['volunteer']);
	$TSdate=$_POST['TSdate'];
	$type=$_POST['type'];
	$owner=$_POST['owner'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	$agency=$_POST['agency'];
	$referrer=$_POST['referrer'];
	if(isset($_POST['wk2call'])) {$wk2call = date('Y-m-d', strtotime($_POST['wk2call']));}
    else {$wk2call = '';}
	$wk2caller=$_POST['wk2caller'];
	if(isset($_POST['wk4call'])) {$wk4call = date('Y-m-d', strtotime($_POST['wk4call']));}
        else {$wk4call = '';}
	$wk4caller=$_POST['wk4caller'];
	$comments=$_POST['comments'];
	$status=$_POST['status'];
	// Build the SQL statement.
	$update = $db->prepare("UPDATE EAB SET Type=:type, Owner=:owner, Email=:email, Phone=:phone, Agency=:agency, AgencyID=:referrer, Comments=:comments, Status=:status, 2WkCall=:wk2call, 2WkCaller=:wk2caller, 4WkCall=:wk4call, 4WkCaller=:wk4caller WHERE Timesheet = :timesheet");
	$update->bindValue(':type', $type, PDO::PARAM_STR);
	$update->bindValue(':owner', $owner, PDO::PARAM_STR);
	$update->bindValue(':email', $email, PDO::PARAM_STR);
	$update->bindValue(':phone', $phone, PDO::PARAM_STR);
	$update->bindValue(':agency', $agency, PDO::PARAM_STR);
	$update->bindValue(':referrer', $referrer, PDO::PARAM_STR);
	$update->bindValue(':comments', $comments, PDO::PARAM_STR);
	$update->bindValue(':status', $status, PDO::PARAM_STR);
	$update->bindValue(':wk2call', $wk2call, PDO::PARAM_STR);
	$update->bindValue(':wk2caller', $wk2caller, PDO::PARAM_STR);
	$update->bindValue(':wk4call', $wk4call, PDO::PARAM_STR);
	$update->bindValue(':wk4caller', $wk4caller, PDO::PARAM_STR);
	$update->bindValue(':timesheet', $timesheet, PDO::PARAM_STR);
	try
		{
		// run the update
		$update->execute();
		}
	catch (PDOException $e)
		{
    var_dump($e->getMessage());
    var_dump($db->errorInfo());
    die('....');
		}
// Return to the calling list
	header("Location:".$list.".php");
	exit();
	}

// If PHP is still reading this, it must be the first page visit,
// OR an error was detected.

include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.8.18/themes/base/jquery-ui.css" type="text/css" media="all" />
<link rel="stylesheet" href="form.css" type="text/css" media="screen" charset="utf-8"/>
<!-- Include the JQuery routines for doing data validation. -->
<!--
<script type='text/javascript' src='../jquery-1.7.1.min.js'></script>
<script type='text/javascript' src='../jquery.validate.min.js'></script>
<script type='text/javascript' src='//ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js'></script>

-->
<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<script type='text/javascript' src='../jquery.validate.min.js'></script>
<script type='text/javascript' src='EABupdate.js'></script>

 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
  			<td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>EAB</a> <b>&raquo;</b> <a href='./EABactive.php'>Active EAB Applications</a> <b>&raquo; EAB Update</b></td>
				</tr>
			</table>
<script src="../sorttable.js"></script>
<div class="heading">Update Earn A Bike Application Status</div>

<form id="appForm" method="POST" action="<?php echo $PHP_SELF;?>" enctype="multipart/form-data">
<h3>Timesheet Form Number: <?php echo $timesheet ?></h3>
<p>
<label for="TSdate">Application Date: </label><input type="text" id="TSdate" name="TSdate" size=8 value="<?php echo $v_TSdate ?>" readonly="readonly" />
<fieldset>
<legend>Applicant Information</legend>
<Input type = 'Radio' Name ='type' class='eabref' value= 'EAB' <?php echo $eab_button ?>>EAB
<Input type = 'Radio' Name ='type' class='eabref' value= 'Referral' <?php echo $ref_button ?>>Referral
<div>
<label for="volunteer">Logged by: </label><input type="text" id="volunteer" name="volunteer" size=15 value="<?php echo $volunteer ?>" readonly="readonly" />
</div>
<div>
<label for="owner">Owner's Name: </label><input type="text" id="owner" name="owner" size=15 value="<?php echo $owner ?>" />
</div>
<div>
<label for="email">Email: </label><input type="text" class="contact" id="email" name="email" size=15 value="<?php echo $email ?>" />
</div>
<div>
<label for="phone">Phone: </label><input type="text" class="contact" id="phone" name="phone" size=10 value="<?php echo $phone ?>" />
</div>
</fieldset>
<fieldset id="referral">
<legend>Referral Information</legend>
<div>
<label for="agency">Agency: </label><input type="text" id="agency" name="agency" size=15 value="<?php echo $agency ?>" />
</div>
<div>
<label for="referrer">Referrer: </label><input type="text" id="referrer" name="referrer" size=15 value="<?php echo $referrer ?>" />
</div>
</fieldset>
<fieldset>
<legend>Status</legend>
<div>
<Input type = 'Radio' Name ='status' class='required' value= 'A' <?php echo $active_button ?>>Active
<Input type = 'Radio' Name ='status' class='required' value= 'C' <?php echo $cancel_button ?>>Cancelled
</div>
<div>
<label for="wk2call">2-week followup: </label><input type="text" class="datepick" id="wk2call" name="wk2call" size=8 value="<?php echo $v_wk2call ?>" />
Logged by: <input type="text" id="wk2caller" name="wk2caller" size=15 value="<?php echo $wk2caller ?>" />
</div>
<div>
<label for="wk4call">4-week followup: </label><input type="text" class="datepick" id="wk4call" name="wk4call" size=8 value="<?php echo $v_wk4call ?>" />
Logged by: <input type="text" id="wk4caller" name="wk4caller" size=15 value="<?php echo $wk4caller ?>" />
</div>
<div>
<label>Comments: <textarea name="comments" cols="50">
<?php echo $comments ?>
</textarea></label>
</div>
</fieldset>
<p>
<input type="submit" name="Submit" value="submit">
Enter the information and click on submit.
</form>
<?php
// Free used database resources.
$db = null;
// Finish the page.
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
