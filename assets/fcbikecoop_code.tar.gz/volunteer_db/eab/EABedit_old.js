$(document).ready(function()
	{
	$(".datepick").datepicker(
		{showOn: 'both',
		 showButtonPanel: true,
		 buttonImage: '../iconCalendar.gif',
		 buttonImageOnly: true 
		});

	jQuery.validator.addMethod("phoneUS", function(phone_number, element) 
		{
		phone_number = phone_number.replace(/\s+/g, ""); 
		return this.optional(element) || phone_number.length > 6 &&
		phone_number.match(/^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/);
		}, "Please specify a valid phone number");
	$("#appForm").validate(
		{
		rules: 
			{
			volunteer: 
				{
				required: true
				},
			owner: 
				{
				required: true
				},
			email: 
				{
				email: true
				},
			phone: 
				{
				phoneUS: true
				},
			agency: 
				{
				required: true
				},
			referrer: 
				{
				required: true
				}
			}

		});
	});
