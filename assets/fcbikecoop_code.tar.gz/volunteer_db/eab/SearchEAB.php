<?php
/**
	*	SearchEAB.php - part of the Fort Collins Bike Co-op system for managing the Earn-A-Bike program.
	*
	* This script presents the page for searching EAB applications. From the displayed list, you
	* can click on the Timesheet number, which will call EABedit.php with the Timesheet number passed as 
	* the argument "TS".
	*/

// Set up values for this script.
$caller="SearchEAB";
$page="Search EAB";
$program="SearchEAB.php";

// Include the standard code for setting up the session.
require_once "./session_setup.php";

?>

<form method="POST" action="<?php echo $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data">
 
Type your search string(s) and click on submit.  You can type any part of the information in the field(s) you want to search on.  You can also type a series of characters separated by comma to do a "wildcard" search.
<p>
<table>
	<tr>
		<td>Timesheet:</td><td><input type="text" name = "timesheet" size=15 value="<?php echo $_POST['timesheet'] ?>"></td>
		<td>Owner:</td><td><input type="text" name = "owner" size=15 value="<?php echo $_POST['owner'] ?>"></td>
		<td>Agency:</td><td><input type="text" name = "agency" size=15 value="<?php echo $_POST['agency'] ?>"></td>
	</tr>
</table>
<p>
<input type="submit" name="Submit" value="submit">
</form> 

<h2>Matching Records</h2>

Note:  list can be sorted by clicking on the column headers.
<div>
<font size=1>
<table border=2 id="dataTable" class="tablesorter" style="font-size:14px;">
	<thead>
		<th>Timesheet</th><th>Owner</th><th>Earned</th><th>Serial #</th><th>Brand</th><th>Model</th><th>Color</th><th>Volunteer</th><th>Type</th>

	</thead>
	<tbody>
<?php
// If form has been submitted, search the EAB table.
if(isset($_POST['Submit']))
	{
	$timesheet=$_POST['timesheet'];
	$arg0="%".str_replace(",",'%',$timesheet)."%";
	$owner=$_POST['owner'];
	$arg1="%".str_replace(",",'%',$owner)."%";
	$agency=$_POST['agency'];
	$arg2="%".$agency."%";
//First check to see if a possible match
	$query = $db->prepare("SELECT * FROM EAB WHERE (Timesheet IS NULL OR Timesheet LIKE :arg0) AND (Owner IS NULL OR Owner LIKE :arg1) AND (Agency IS NULL OR Agency LIKE :arg2) ORDER BY Owner");
	$query->bindParam(":arg0", $arg0);
	$query->bindParam(":arg1", $arg1);
	$query->bindParam(":arg2", $arg2);
	try
		{
		// run the query
		$query->execute();
		}
	catch (PDOException $e)
		{
    var_dump($e->getMessage());
    var_dump($db->errorInfo());
    die('....');
		}

// Fetch & display the results of the query.
	while($result_row = $query->fetch(PDO::FETCH_ASSOC))
		{
		$ID = $result_row["ID"];
		$timesheet = $result_row["Timesheet"];
		$owner = $result_row["Owner"];
		$bikedate = $result_row["BikeDate"];
		$serial = $result_row["Serial"];
		$brand = $result_row["Brand"];
		$model = $result_row["Model"];
		$color = $result_row["Color"];
		$volunteer = $result_row["EnteredBy"];
		$type = $result_row["Type"];
		// Change the date format for display purposes.
		if (isset($bikedate))
			{$v_bikedate = date("m/d/Y",strtotime($bikedate));}
		if ($bikedate == "0000-00-00")
			{$v_bikedate="";}
		echo "<td><a href=\"./EABedit.php?TS=".$timesheet."\">$timesheet</td><td>$owner</td><td>$v_bikedate</td><td>$serial</td><td>$brand</td><td>$model</td><td>$color</td><td>$volunteer</td><td>$type</td>";
		echo "</tr>";
		echo "\n";
		}
	}
?>
	</tbody>
</table>
<?php
// Free used database resources.
$db = null;
// Finish the page.
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
