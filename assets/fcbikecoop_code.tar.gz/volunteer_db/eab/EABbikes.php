<?php
// This script presents the page for listing all EAB
session_start();
$_SESSION['list']="ListEAB";
$HTTP_SESSION_VARS ["list"] = "ListEAB";
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');

//Connect to the Bike Co-op database
// Include our login information
include('../db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
die ("Could not connect to the database: <br />". mysql_error());
}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
die ("Could not select the database: <br />". mysql_error());
}

$result = mysql_query('SELECT * FROM `EAB` ORDER BY `ID` DESC');

?>
<script type='text/javascript' src='../jquery-1.7.1.min.js'></script>
<script type='text/javascript' src='../jquery.tablesorter.min.js'></script>
<script type='text/javascript' src='../Tables.js'></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
  			<td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>EAB</a> <b>&raquo;</b> EAB List</td>
				</tr>
			</table>		
<div class="heading">EAB Bikes Awarded</div>
Note:  list can be sorted by clicking on the column headers.
<font size=1>
<table border=2 id="dataTable" class="tablesorter">
	<thead>
		<tr>
			<th>Owner</th><th>Type</th><th>Entered</th><th>Earned</th><th class="sorttable_alpha">Serial #</th><th>Brand</th><th class="sorttable_alpha">Model</th><th>Color</th><th>Volunteer</th>
		</tr>
	</thead>
	<tbody>
<?php
//Fetch & display the results
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$owner = $result_row["Owner"];
	$returndate = $result_row["ReturnedDate"];
	$bikedate = $result_row["BikeDate"];
	$serial = $result_row["Serial"];
	$brand = $result_row["Brand"];
	$model = $result_row["Model"];
	$color = $result_row["Color"];
	$volunteer = $result_row["EnteredBy"];
	$type = $result_row["Type"];
	// Change the date format for display purposes.
	$v_returndate = date("m/d/Y",strtotime($returndate));
	$v_bikedate = date("m/d/Y",strtotime($bikedate));
	echo "<td>$owner</td><td>$type</td><td>$v_returndate</td><td>$v_bikedate</td><td>$serial</td><td>$brand</td><td>$model</td><td>$color</td><td>$volunteer</td>";
	echo "</tr>";
	echo "\n";
	}
?>
	</tbody>
</table>
<?php
// Close the connection to the database
mysql_close($connection);

include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
