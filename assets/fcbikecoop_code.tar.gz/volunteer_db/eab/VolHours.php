<?php
// This script presents the page for listing all EAB volunteer hours
session_start();
$_SESSION['list']="VolHours";
$HTTP_SESSION_VARS ["list"] = "VolHours";
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<script src="../sorttable.js"></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
  			<td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>EAB</a> <b>&raquo;</b> EAB Volunteer Hours</td>
				</tr>
			</table>			<div class="heading">EAB Volunteer Hours</div>
<?php
//Connect to the Bike Co-op database
// Include our login information
include('../db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
die ("Could not connect to the database: <br />". mysql_error());
}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
die ("Could not select the database: <br />". mysql_error());
}

$result = mysql_query('SELECT * FROM `EAB` ORDER BY `DateEarned` DESC');
?>
<br>Note:  list can be sorted by clicking on the column headers.
<font size=1>
<table border=2 class="sortable">
	<thead>
		<tr>
			<th>ID</th><th>Owner</th><th>Earned</th><th>Org</th><th>Hours</th><th>Org</th><th>Hours</th><th>Org</th><th>Hours</th><th>Org</th><th>Hours</th><th>Type</th><th>....</th>
			</tr>
	</thead>
	<tbody style='height:300px; overflow:auto;'>
<?php
//Fetch & display the results
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$ID = $result_row["ID"];
	$owner = $result_row["Owner"];
	$earndate = $result_row["DateEarned"];
	$org1 = $result_row["Org1"];
	$hours1 = $result_row["Hours1"];
	$org2 = $result_row["Org2"];
	$hours2 = $result_row["Hours2"];
	$org3 = $result_row["Org3"];
	$hours3 = $result_row["Hours3"];
	$org4 = $result_row["Org4"];
	$hours4 = $result_row["Hours4"];
	$type = $result_row["Type"];
	// Change the date format for display purposes.
	$v_earndate = date("m/d/Y",strtotime($earndate));
	echo "<td><a href=\"./EditEAB.php?ID=".$ID."\">$ID</td><td>$owner</td><td>$v_earndate</td><td>$org1</td><td>$hours1</td><td>$org2</td><td>$hours2</td><td>$org3</td><td>$hours3</td><td>$org4</td><td>$hours4</td><td>$type</td>";
	echo "</tr>";
	echo "\n";
	}
?>
	</tbody>
</table>
<?php
// Close the connection to the database
mysql_close($connection);

include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
