<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);

//Connect to the Bike Co-op database
// Include our login information
include('../db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
	die ("Could not connect to the database: <br />". mysql_error());
	}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
	die ("Could not select the database: <br />". mysql_error());
	}

// Get the pending EAB applications list.
$select = ' SELECT ';
$column = ' * ';
$from = ' FROM ';
$table = ' `EAB` ';
$where = ' WHERE `Timesheet` <> "" AND `Status` = "A"';
$order = ' ORDER BY `Timesheet` DESC';
$query = $select.$column.$from.$table.$where.$order;
$result = mysql_query( $query );
if (!$result)
	{
	die ("Could not query the database: <br />". mysql_error());
	}

include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<!-- We will be using JQuery functions and a JavaScript for processing the form. -->
<script type='text/javascript' src='../jquery-1.7.1.min.js'></script>
<script type='text/javascript' src='../jquery.tablesorter.min.js'></script>
<script type='text/javascript' src='../Tables.js'></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
  			<td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>EAB</a> <b>&raquo;</b> EAB Applications</td>
				</tr>
			</table>
<script type="text/javascript"> 
<!-- BEGIN HIDING

//Here's the code you need
//with the onclick event the
//user will be set to another
// location of your choice. 

document.onclick = function(_radio)
{ _radio = _radio ? _radio : window.event;
var _target = _radio.target ? _radio.target : _radio.srcElement; 

if (( _target.name ) && ( _target.name == 'nav' ) && ( _target.checked )) { window.location = _target.value; 
  }
} 
// DONE HIDING -->
</script>
<div class="heading">Active EAB Applications</div>
<font size=1>
<br>Note:  list can be sorted by clicking on the column headers.
<table border=2 id="dataTable" class="tablesorter">
	<thead>
		<tr>
			<th>Timesheet</th><th>Entered</th><th>Owner</th><th>Type</th><th>2wk</th><th>4wk</th><th>Comments</th>
		</tr>
	</thead>
	<tbody>
<?php
//Fetch & display the results
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$timesheet = $result_row["Timesheet"];
	// Change the date format for display purposes.
	$TSdate = $result_row["TSdate"];
	$v_TSdate = date("m/d/Y",strtotime($TSdate));
	$owner = $result_row["Owner"];
	$type = $result_row["Type"];
	$wk2call = $result_row["2wkCall"];
	$wk4call = $result_row["4wkCall"];
	$comments = $result_row["Comments"];
	// set the appropriate status image for the 2-week call
	$wk2 = "whtpearl.gif";
	if ($wk2call > '0000-00-00') {$wk2="tick.gif";}
	else
		{
		$now = time();
		$your_date = strtotime($TSdate);
		$datediff = $now - strtotime($TSdate);
		$diff = floor($datediff/(60*60*24));
		if ($diff > 14) {$wk2="cross.gif";} // greater than 14 days, use the cross image
		}
	// set the appropriate status image for the 4-week call
	$wk4 = "whtpearl.gif";
	if ($wk4call > '0000-00-00') {$wk4="tick.gif";}
	else
		{
		$now = time();
		$your_date = strtotime($TSdate);
		$datediff = $now - strtotime($TSdate);
		$diff = floor($datediff/(60*60*24));
		if ($diff > 28) {$wk4="cross.gif";} // greater than 14 days, use the cross image
		}

	echo "<td><a href=\"./EABedit.php?TS=".$timesheet."\">$timesheet</td><td>$v_TSdate</td><td>$owner</td><td>$type</td><td align=\"center\"><a href=\"./EABupdate.php?TS=".$timesheet."\">
<img src=\"".$wk2."\" alt=\"2wk call\" />
</a></td>
<td align=\"center\"><a href=\"./EABupdate.php?TS=".$timesheet."\">
<img src=\"".$wk4."\" alt=\"4wk call\" />
</a></td><td>$comments</td>";
	echo "</tr>";
	echo "\n";
	}

?>
	</tbody>
</table>
<script type="text/javascript" src="stripy_tables.js"></script>
<?php
// Close the connection
mysql_close($connection);
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
