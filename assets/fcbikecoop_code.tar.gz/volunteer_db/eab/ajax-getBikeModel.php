<?php
// Turn off all error reporting
error_reporting(0);
//Connect to the Bike Co-op database
require_once($_SERVER['DOCUMENT_ROOT'].'db_connect.php');
$db = db_connect ();
//Get the brand from ajax
$brand = $_GET['brand'];
//Get the list of model
try
	{
	$query = $db->prepare("SELECT DISTINCT(Model) AS Model FROM RECOVEREDBIKES WHERE DispDate > '0000-00-00' AND (Disposition = 'EAB' OR Disposition = 'as-is') AND Status='' AND Brand LIKE ? ORDER BY Model");
	$query->bindValue(1, "%$brand%", PDO::PARAM_STR);
	$query->execute();
	}
catch (PDOException $e)
	{
	print ("The statement failed.\n");
	echo "boo-boo";
	echo "getMessage(): " . $e->getMessage () . "\n";
	}
//Fetch the log numbers for use in the bike selection list
echo "<option value=\"\">Please select a model ...</option>";
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$model = $result_row["Model"];
	echo "<option  value='".$model."'>".$model."</option>\n";
	}
?>
