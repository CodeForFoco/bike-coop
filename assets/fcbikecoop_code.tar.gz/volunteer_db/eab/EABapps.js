$(document).ready(function()
	{
	$("#appsTable").tablesorter();
	$("td:empty").html("&nbsp;");
	}
); 
