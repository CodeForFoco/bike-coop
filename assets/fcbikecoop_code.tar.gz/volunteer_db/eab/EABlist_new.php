<?php
/**
	*	EABlist.php - part of the Fort Collins Bike Co-op system for managing the Earn-A-Bike program.
	*
	* This script presents the page for listing all EAB applications. 
	* From the displayed list, you can click on the Timesheet number which will call EABedit.php with 
	* the Timesheet number passed as the argument "TS".
	* You can also click in the Status column which will call EABupdate.php with the Timesheet number 
	* passed as the argument "TS".
	*/

// Set up values for this script.
$caller="EABlist";
$page="EAB List";
$program="EABlist.php";
$col_hdr="<th>Timesheet</th><th>Owner</th><th>Type</th><th>Status</th><th>Application</th><th>Returned</th><th>Bike Given</th>";

// Include the standard code for setting up the session.
require_once "./session_setup.php";

// Run the query to get the list of applications.
$query = $db->prepare("SELECT * FROM EAB ORDER BY Timesheet DESC");
$query->execute();

// Fetch & display the results of the query.
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$timesheet = $result_row["Timesheet"];
	$owner = $result_row["Owner"];
	$appdate = $result_row["TSdate"];
	$returndate = $result_row["ReturnedDate"];
	$bikedate = $result_row["BikeDate"];
	$type = $result_row["Type"];
	$status = $result_row["Status"];
	// Change the date format for display purposes.
	$v_appdate = date("m/d/Y",strtotime($appdate));
	$v_returndate="";
	if (isset($returndate))
		{$v_returndate = date("m/d/Y",strtotime($returndate));}
	if ($returndate == "0000-00-00")
		{$v_returndate="";}
	$v_bikedate="";
	if (isset($bikedate))
		{$v_bikedate = date("m/d/Y",strtotime($bikedate));}
	if ($bikedate == "0000-00-00")
		{$v_bikedate="";}
	// Display the table row.
	echo "<tr>";
	echo "<td><a href=\"./EABedit.php?TS=".$timesheet."\">$timesheet</td><td>$owner</td><td>$type</td><td align=\"center\"><a href=\"./EABupdate.php?TS=".$timesheet."\">$status</a></td><td>$v_appdate</td><td>$v_returndate</td><td>$v_bikedate</td>";
	echo "</tr>";
	echo "\n";
	}
?>
	</tbody>
</table>
</div>
<?php
// Finish the page.
include_once('/var/www/fcbikecoop.org/root/footer.php');
// Free used database resources.
$result->closeCursor();
$db = null;
?>
