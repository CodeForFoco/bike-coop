<?php
/**
	*   session_setup.php - part of the Fort Collins Bike Co-op system for managing the Earn-A-Bike program.
	*
	* This script is called by the rest of the EAB-related scripts to perform setup funtions that are
	* common to all of them. 	
	*/

// Set a session variable so that a called script can set up the link-back list.
session_start();
$_SESSION['list']=$caller;
$HTTP_SESSION_VARS ["list"]=$caller;
$current_page = htmlentities($_SERVER['PHP_SELF']);

// Connect to the Bike Co-op database.
require_once "../../db_connect.php";
$db = db_connect ();

// Set up the standard Co-op page header.
include_once($_SERVER['DOCUMENT_ROOT'].'header.php');
?>
<!-- Use the JQuery table sorter routines to let the user sort the displayed table by 
     clicking on any column heading. -->
<script type='text/javascript' src='../jquery-1.7.1.min.js'></script>
<script type='text/javascript' src='../jquery.tablesorter.min.js'></script>
<script type='text/javascript' src='../Tables.js'></script>
<!-- Start building the page. 
	 Set up a "breadcrumb" trail so the user can navigate back to previous pages. -->
<table cellpadding='5'>
	<tr>
		<td style='width:0%; white-space:nowrap'>
		<td> <b>&raquo;</b> <a href='./index.php'>EAB</a> <b>&raquo;</b> <?php echo $page;?></td>
	</tr>
</table>		
<div class="heading"><?php echo $page;?></div>

<?php
