<?php
/**
	*	EABedit.php - part of the Fort Collins Bike Co-op system for managing the Earn-A-Bike program.
	*
	* This script presents the page for displaying and modifying an EAB application.  The number of the
	* application is passed by the calling script in the "TS" (Timesheet) session variable.
	* Once the user enters the information and presses Submit, the data is validated and, if no errors are
	* found, the database record is updated and the user is returned to the list from which this script
	* was called.
	*/

session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
/**
	*	The script assumes that session variables have been set by the calling script.
	* Those variable is used to build the "breadcrumb" list that helps the user navigate back.
	*/
// Get the variables that will let us get back to previous pages.
$list = $_SESSION['list'];
// Build the appropriate "breadcrumb" list.
if ($list == "SearchEAB")
	{
	$list_link_back = "<a href='./SearchEAB.php'>Search EAB Records</a>";
	}
elseif ($list == "EABstats")
	{
	$list_link_back = "<a href='./EABstats.php'>EAB Statistics</a>";
	}
elseif ($list == "EABhours")
	{
	$list_link_back = "<a href='./EABhours.php'>EAB Volunteer Hours</a>";
	}
elseif ($list == "EABlog")
	{
	$list_link_back = "<a href='./EABlog.php'>Record EAB</a>";
	}
elseif ($list == "EABlist")
	{
	$list_link_back = "<a href='./EABlist.php'>EAB Applications</a>";
	}
elseif ($list == "EABactive")
	{
	$list_link_back = "<a href='./EABactive.php'>Active EAB Applications</a>";
	}
else
	{
	// Set up some defaults in case the session variable didn't get set correctly.
	$list = "EABactive";
	$list_link_back = "<a href='./EABactive.php'>Active EAB Applications</a>";
	}

// Get the number of the timesheet to be edited.
$timesheet = $_GET['TS'];
// Connect to the Bike Co-op database.
require_once "../../db_connect.php";
$db = db_connect ();
// Get the timesheet to be edited.
$query = $db->prepare("SELECT * FROM EAB WHERE Timesheet=?");
$query->bindValue(1, $timesheet, PDO::PARAM_INT);
$query->execute();
//Fetch & display the results
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$returndate = $result_row['ReturnedDate'];
	$volunteer = $result_row['LoggedBy'];
	$type = $result_row['Type'];
	if ($type == "EAB")
		{$eab_button = "checked";}
	else
		{$eab_button = "";}
	if ($type == "Referral")
		{$ref_button = "checked";}
	else
		{$ref_button = "";}
	$owner = $result_row['Owner'];
	$email = $result_row['Email'];
	$phone = $result_row['Phone'];
	$height = $result_row['Height'];
	$agency = $result_row['Agency'];
	$referrer = $result_row['AgencyID'];
	$org1 = $result_row['Org1'];
	$org1phone = $result_row['Org1Phone'];
	$hours1 = $result_row['Hours1'];
	$ver1 = $result_row['VerifiedBy1'];
	$org2 = $result_row['Org2'];
	$org2phone = $result_row['Org2Phone'];
	$hours2 = $result_row['Hours2'];
	$ver2 = $result_row['VerifiedBy2'];
	$org3 = $result_row['Org3'];
	$org3phone = $result_row['Org3Phone'];
	$hours3 = $result_row['Hours3'];
	$ver3 = $result_row['VerifiedBy3'];
	$org4 = $result_row['Org4'];
	$org4phone = $result_row['Org4Phone'];
	$hours4 = $result_row['Hours4'];
	$ver4 = $result_row['VerifiedBy4'];
	$timesheet = $result_row["Timesheet"];
	$bikedate = $result_row['BikeDate'];
	$hours = $result_row['HoursReq'];
	$serial = $result_row["Serial"];
	$brand = $result_row["Brand"];
	$model = $result_row["Model"];
	$color = $result_row["Color"];
	$description = $result_row["Description"];
	}
// Change the date format for display purposes.
if ($returndate > '0000-00-00') {$v_returndate = date("m/d/Y",strtotime($returndate));}
if ($bikedate > '0000-00-00') {$v_bikedate = date("m/d/Y",strtotime($bikedate));}

// If form has been submitted, post the record to the EAB table.
if(isset($_POST['Submit']))
	{
	$returndate=date('Y-m-d', strtotime($_POST['returndate']));
	$volunteer=ucwords($_POST['volunteer']);
	$type=$_POST['type'];
	$agency=$_POST['agency'];
	$referrer=$_POST['referrer'];
	$org1=$_POST['org1'];
	$org1phone=$_POST['org1phone'];
	$hours1=$_POST['hours1'];
	$ver1=$_POST['ver1'];
	$org2=$_POST['org2'];
	$org2phone=$_POST['org2phone'];
	$hours2=$_POST['hours2'];
	$ver2=$_POST['ver2'];
	$org3=$_POST['org3'];
	$org3phone=$_POST['org3phone'];
	$hours3=$_POST['hours3'];
	$ver3=$_POST['ver3'];
	$org4=$_POST['org4'];
	$org4phone=$_POST['org4phone'];
	$hours4=$_POST['hours4'];
	$ver4=$_POST['ver4'];
	$bikedate=date('Y-m-d', strtotime($_POST['bikedate']));
	$hours=$_POST['hours'];
	$serial=$_POST['serial'];
	$brand=strtoupper($_POST['brand']);
	// fix case of brand name, but allow for 3 or less letter names like "KHS"
	if (strlen($brand)>3) $brand=ucwords(strtolower($_POST['brand']));
	$model=$_POST['model'];
	$color=strtolower($_POST['color']);
	$description=$_POST['description'];
	if (isset($serial)) $status = "B";
	if ($serial=='') $status = "A";
	// Build the SQL statement.
	$update = $db->prepare("UPDATE EAB SET ReturnedDate=:returndate, LoggedBy=:volunteer,
	 Type=:type, Agency=:agency, AgencyID=:referrer, 
	 Org1=:org1, Org1Phone=:org1phone, Hours1=:hours1, VerifiedBy1=:ver1, 
	 Org2=:org2, Org2Phone=:org2phone, Hours2=:hours2, VerifiedBy2=:ver2, 
	 Org3=:org3, Org3Phone=:org3phone, Hours3=:hours3, VerifiedBy3=:ver3, 
	 Org4=:org4, Org4Phone=:org4phone, Hours4=:hours4, VerifiedBy4=:ver4, 
	 BikeDate=:bikedate, HoursReq=:hours, Serial=:serial, Brand=:brand, Model=:model, Color=:color, Description=:description, Status=:status WHERE Timesheet = :timesheet");
	$update->bindValue(':timesheet', $timesheet, PDO::PARAM_STR);
	$update->bindValue(':returndate', $returndate, PDO::PARAM_STR);
	$update->bindValue(':volunteer', $volunteer, PDO::PARAM_STR);
	$update->bindValue(':type', $type, PDO::PARAM_STR);
	$update->bindValue(':agency', $agency, PDO::PARAM_STR);
	$update->bindValue(':referrer', $referrer, PDO::PARAM_STR);
	$update->bindValue(':org1', $org1, PDO::PARAM_STR);
	$update->bindValue(':org1phone', $org1phone, PDO::PARAM_STR);
	$update->bindValue(':hours1', $hours1, PDO::PARAM_STR);
	$update->bindValue(':ver1', $ver1, PDO::PARAM_STR);
	$update->bindValue(':org2', $org2, PDO::PARAM_STR);
	$update->bindValue(':org2phone', $org2phone, PDO::PARAM_STR);
	$update->bindValue(':hours2', $hours2, PDO::PARAM_STR);
	$update->bindValue(':ver2', $ver2, PDO::PARAM_STR);
	$update->bindValue(':org3', $org3, PDO::PARAM_STR);
	$update->bindValue(':org3phone', $org3phone, PDO::PARAM_STR);
	$update->bindValue(':hours3', $hours3, PDO::PARAM_STR);
	$update->bindValue(':ver3', $ver3, PDO::PARAM_STR);
	$update->bindValue(':org4', $org4, PDO::PARAM_STR);
	$update->bindValue(':org4phone', $org4phone, PDO::PARAM_STR);
	$update->bindValue(':hours4', $hours4, PDO::PARAM_STR);
	$update->bindValue(':ver4', $ver4, PDO::PARAM_STR);
	$update->bindValue(':bikedate', $bikedate, PDO::PARAM_STR);
	$update->bindValue(':hours', $hours, PDO::PARAM_STR);
	$update->bindValue(':serial', $serial, PDO::PARAM_STR);
	$update->bindValue(':brand', $brand, PDO::PARAM_STR);
	$update->bindValue(':model', $model, PDO::PARAM_STR);
	$update->bindValue(':color', $color, PDO::PARAM_STR);
	$update->bindValue(':description', $description, PDO::PARAM_STR);
	$update->bindValue(':status', $status, PDO::PARAM_STR);
	try
		{
		// run the update
		$update->execute();
		}
	catch (PDOException $e)
		{
    var_dump($e->getMessage());
    var_dump($db->errorInfo());
    die('....');
		}
// Return to the calling list
	header("Location:".$list.".php");
	exit();
	}
// If PHP is still reading this, it must be the first page visit,
// OR an error was detected.
// Display the HTML page.

include_once('/var/www/fcbikecoop.org/root/header.php');

?>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.8.18/themes/base/jquery-ui.css" type="text/css" media="all" />
<!-- <link rel="stylesheet" href="/css/jquery-ui.css" type="text/css" media="all" /> -->
<link rel="stylesheet" href="form.css" type="text/css" media="screen" charset="utf-8"/>
<!-- jQuery routines are used for data validation. -->
<script type='text/javascript' src='/js/jquery.min.js'></script>
<script type='text/javascript' src='/js/jquery.validate.min.js'></script>
<script type='text/javascript' src='/js/jquery-ui.min.js'></script>
<script type='text/javascript' src='EABedit.js'></script>
<!-- "breadcrumbs" -->
<table cellpadding='5'>
	<tr>
		<td style='width:0%; white-space:nowrap'>
		<td> <b>&raquo;</b> <a href='./index.php'>EAB</a> <b>&raquo;</b> <?php echo $list_link_back;?> <b>&raquo;</b>  Edit EAB Record</td>
	</tr>
</table>

<?php
//Get the list of EAB volunteers
try
	{
	$query = $db->prepare("SELECT * FROM EABvols");
	$query->execute();
	}
catch (PDOException $e)
	{
	print ("The statement failed.\n");
	echo "boo-boo";
	echo "getMessage(): " . $e->getMessage () . "\n";
	}
//Fetch the names for use in the volunteer selection list
$options="";
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$volname = $result_row["Volunteer"];
	$options.="<OPTION VALUE=\"$volname\">$volname</option>";
	}
?>
<form id="editForm" method="POST" action="<?php echo $PHP_SELF;?>" enctype="multipart/form-data">
<h3>Timesheet Form Number: <?php echo $timesheet ?></h3>
Date Returned: <input type="text" name="returndate" size=8 id="returndate" class="datepick" value="<?php echo $v_returndate ?>" />
<Input type = 'Radio' id='type' name ='type' <?php echo $eab_button ?> value='EAB'>EAB
<Input type = 'Radio' id='type' name ='type' <?php echo $ref_button ?> value='Referral'>Referral
<fieldset>
    <legend>Applicant Information</legend>
    Name: <input type="text" id="owner" name="owner" size=10 value="<?php echo $owner ?>" readonly>
    Email: <input type="text" id="email" name="email" size=10 value="<?php echo $email ?>" readonly>
    Phone: <input type="text" id="phone" name="phone" size=8 value="<?php echo $phone ?>" readonly>
    Height: <input type="text" id="height" name="height" size=2 value="<?php echo $height ?>" readonly>
</fieldset>
<fieldset id="referral">
    <legend>Referral Information</legend>
	<!-- HTML5 added a "combox" like object so we can preload the most frequently used agencies -->
	Agency: <input type=text list=agencies id="agency" name="agency" value="<?php echo $agency ?>">
	<datalist id=agencies >
		<option> Halfway House/LCCC
		<option> Murphy Center
		<option> Catholic Charities
		<option> Salvation Army
	</datalist>
   Referrer: <input type="text" id="referrer" name="referrer" size=15 value="<?php echo $referrer ?>">
</fieldset>
<fieldset id="service">
    <legend>Service Information</legend>
    Org: <input type="text" list=orgs id="org1" name="org1" size=12 value="<?php echo $org1 ?>">
    <datalist id=orgs >
		<option> ARC Fort Collins
		<option> ARC Loveland
		<option> Catholic Charities
		<option> FC Rescue Mission
	</datalist>

    Phone: <input type="text" id="org1phone" name="org1phone" size=4 value="<?php echo $org1phone ?>">
    Hours: <input type="text" name="hours1" size=1 value="<?php echo $hours1 ?>"">
    Verified by:
    <select id="ver1" name="ver1" style="width: 125px;">
		<option value="<?php echo $ver1 ?>" selected><?php if ($ver1){echo $ver1;} else{echo "Choose a Name";} ?></option>"
		<?=$options?>
	</select>
    <br>
    Org: <input type="text" list=orgs id="org2" name="org2" size=12 value="<?php echo $org2 ?>">
    Phone: <input type="text" id="org2phone" name="org2phone" size=4 value="<?php echo $org2phone ?>">
    Hours: <input type="text" name="hours2" size=1 value="<?php echo $hours2 ?>"">
    Verified by:
    <select id="ver2" name="ver2" style="width: 125px;">
		<option value="<?php echo $ver2 ?>" selected><?php if ($ver2){echo $ver2;} else{echo "Choose a Name";} ?></option>"
		<?=$options?>
	</select>
    <br>
    Org: <input type="text" list=orgs id="org3" name="org3" size=12 value="<?php echo $org3 ?>">
    Phone: <input type="text" id="org3phone" name="org3phone" size=4 value="<?php echo $org3phone ?>">
    Hours: <input type="text" name="hours3" size=1 value="<?php echo $hours3 ?>"">
    Verified by:
    <select id="ver3" name="ver3" style="width: 125px;">
		<option value="<?php echo $ver3 ?>" selected><?php if ($ver3){echo $ver3;} else{echo "Choose a Name";} ?></option>"
		<?=$options?>
	</select>
    <br>
    Org: <input type="text" list=orgs id="org4" name="org4" size=12 value="<?php echo $org4 ?>">
    Phone: <input type="text" id="org4phone" name="org4phone" size=4 value="<?php echo $org4phone ?>">
    Hours: <input type="text" name="hours4" size=1 value="<?php echo $hours4 ?>"">
    Verified by:
    <select id="ver4" name="ver4" style="width: 125px;">
		<option value="<?php echo $ver4 ?>" selected><?php if ($ver4){echo $ver4;} else{echo "Choose a Name";} ?></option>"
		<?=$options?>
	</select>
</fieldset>
<fieldset id="bike">
    <legend>Bike Information</legend>
	Date Given: <input type="text" name="bikedate" size=8 id="bikedate" class="datepick" value="<?php echo $v_bikedate ?>">
    <p>
    Brand: <input type="text" id="brand" name="brand" size=6 value="<?php echo $brand ?>">
    Model: <input type="text" name="model" size=6 value="<?php echo $model ?>">
    Color: <input type="text" name="color" size=2 value="<?php echo $color ?>">
    Serial Number: <input type="text" name="serial" size=10 value="<?php echo $serial ?>">
    <p>
    Description: <input type="textarea" name="description" size=50 value="<?php echo $description ?>">
    <p>
    Logged by:
    <select id="volunteer" name="volunteer">
	    <option value="<?php echo $volunteer ?>" selected><?php if ($volunteer){echo $volunteer;} else{echo "Choose a Name";} ?></option>"
	    <?=$options?>
    </select>
    <i><small>Note: If your name does not appear on the drop-down list of volunteers, go back to the previous page and click on "Add Volunteer to EAB List".</i></small>
</fieldset>
<p>
<input type="submit" name="Submit" value="submit">
</form>
<?php
	if ($type == "EAB") {
	?>
	<script type="text/javascript">$('#referral').hide()</script>
	<?php
	};

// Free used resources
$result->closeCursor();
$db = null;
// Get the standard Bike Co-op page footer.
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
