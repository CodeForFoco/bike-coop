<?php
// Fort Collins Bike Co-op Earn-a-Bike (EAB) online system.
/* 
This script (EABadd.php) is used to make an entry into the EAB table for a previous month. This is needed to handle cases that were processed before the current onlin e system was implemented or to handle any missed ones.

This next section is used to set up the navigation line at the top of the web page to facilitate moving through the various EAB pages.
*/
session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);

//Connect to the Bike Co-op database
include('../db_login.php'); // Include our login information
$connection = mysql_connect($db_host, $db_username, $db_password); //Connect
if (!$connection){
	die ("Could not connect to the database: <br />". mysql_error());
	}
$db_select = mysql_select_db($db_database); // Select the database
if (!$db_select){
	die ("Could not select the database: <br />". mysql_error());
	}
// get the timesheet to be edited
	$timesheet = $_GET['ID'];

// Do this if form has been submitted
// If form has been submitted, post the record to the EAB table.
if(isset($_POST['Submit']))
	{
	$formdate=$_POST['formdate'];
	$timesheet=$_POST['month']."-".$_POST['seq'];
	$returndate=$_POST['returndate'];
	$volunteer=ucwords($_POST['volunteer']);
	$type=$_POST['type'];
	$owner=$_POST['owner'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	$agency=$_POST['agency'];
	$referrer=$_POST['referrer'];
	$status=$_POST['status'];
	$org1=$_POST['org1'];
	$org1phone=$_POST['org1phone'];
	$hours1=$_POST['hours1'];
	$ver1=$_POST['ver1'];
	$org2=$_POST['org2'];
	$org2phone=$_POST['org2phone'];
	$hours2=$_POST['hours2'];
	$ver2=$_POST['ver2'];
	$org3=$_POST['org3'];
	$org3phone=$_POST['org3phone'];
	$hours3=$_POST['hours3'];
	$ver3=$_POST['ver3'];
	$org4=$_POST['org4'];
	$org4phone=$_POST['org4phone'];
	$hours4=$_POST['hours4'];
	$ver4=$_POST['ver4'];
	$bikedate=$_POST['bikedate'];
	$hours=$_POST['hours'];
	$serial=$_POST['serial'];
	$brand=strtoupper($_POST['brand']);
	// fix case of brand name, but allow for 3 or less letter names like "KHS"
	if (strlen($brand)>3) $brand=ucwords(strtolower($_POST['brand']));
	$model=$_POST['model'];
	$color=strtolower($_POST['color']);
	$description=$_POST['description'];
// Build our query here and check each variable with mysql_real_escape_string()
	$query = "INSERT INTO EAB SET TSdate=STR_TO_DATE('".$formdate."', '%m/%d/%Y'),
														Timesheet='".$timesheet."',
														ReturnedDate=STR_TO_DATE('".$returndate."', '%m/%d/%Y'),
														EnteredBy='".$volunteer."', 
														LoggedBy='".$volunteer."', 
														Type='".$type."', 
														Owner='".$owner."', 
														Email='".$email."', 
														Phone='".$phone."',
														Agency='".$agency."', 
														AgencyID='".$referrer."', 
														Org1='".$org1."', 
														Org1Phone='".$org1phone."', 
														Hours1='".$hours1."', 
														VerifiedBy1='".$ver1."', 
														Org2='".$org2."', 
														Org2Phone='".$org2phone."', 
														Hours2='".$hours2."', 
														VerifiedBy2='".$ver2."', 
														Org3='".$org3."', 
														Org3Phone='".$org3phone."', 
														Hours3='".$hours3."', 
														VerifiedBy3='".$ver3."', 
														Org4='".$org4."', 
														Org4Phone='".$org4phone."', 
														Hours4='".$hours4."', 
														VerifiedBy4='".$ver4."', 
														BikeDate=STR_TO_DATE('".$bikedate."', '%m/%d/%Y'),
														HoursReq='".$hours."', 
														Serial='".$serial."', 
														Brand='".$brand."', 
														Model='".$model."', 
														Color='".$color."', 
														Description='".$description."',
														Status='".$status."'";
	// run the query
	if(!mysql_query($query))
		{
		echo 'Query failed '.mysql_error();
		echo $query;
		exit();
		}
	// No errors were detected.
}

// Start of the page html.
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.8.18/themes/base/jquery-ui.css" type="text/css" media="all" />
<link rel="stylesheet" href="form.css" type="text/css" media="screen" charset="utf-8"/>

<script type='text/javascript' src='../jquery-1.7.1.min.js'></script>
<script type='text/javascript' src='../jquery.validate.min.js'></script>
<script type='text/javascript' src='https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js'></script>
<script type='text/javascript' src='EABadd.js'></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
  			<td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>EAB</a><b>&raquo;</b>  Add EAB Record</td>
				</tr>
			</table>
<!-- Start of the form section of the page. -->
<form method="POST" enctype="multipart/form-data">
<h3>Application Form Number:
<input type="text" id="month" name="month" size=8 class="monthPicker" value="click here"> - 
<input type="text" id="seq" name="seq" size=2" value="nn"></h3>
Date of Form: <input type="text" name="formdate" size=8 id="formdate" class="datepick" value="<?php echo $v_formdate ?>">
<br>
Date Returned: <input type="text" name="returndate" size=8 id="returndate" class="datepick" value="<?php echo $v_returndate ?>">
<?php
//Get the list of EAB volunteers
$result = mysql_query('SELECT * FROM `EABvols`');
if (!result){
die ("Could not query the database: <br />". mysql_error());
}
//Fetch the names for use in the volunteer selection list
$options="";
while ($row=mysql_fetch_assoc($result))
	{
	$volname = $row["Volunteer"];
	$options.="<OPTION VALUE=\"$volname\">$volname</option>";
	}
?>
Logged by: 
<select id="volunteer" name="volunteer">
				<option value="000" selected>Choose a Name</option>"
				<?=$options?>
			</select>
<Input type = 'Radio' Name ='type' <?php echo $eab_button ?> value='EAB'>EAB
<Input type = 'Radio' Name ='type' <?php echo $ref_button ?> value='Referral'>Referral
<br><i><small>Note: If your name does not appear on the drop-down list of volunteers, go back to the previous page and click on "Add Volunteer to EAB List".</i></small>
<fieldset>
<legend>Applicant Information</legend>
Name: <input type="text" id="owner" name="owner" size=15 value="<?php echo $owner ?>">
Email: <input type="text" id="email" name="email" size=15 value="<?php echo $email ?>">
Phone: <input type="text" id="phone" name="phone" size=10 value="<?php echo $phone ?>">
</fieldset>
<fieldset id="referral">
<legend>Referral Information</legend>
Agency: <input type="text" id="agency" name="agency" size=15 value="<?php echo $agency ?>">
Referrer: <input type="text" id="referrer" name="referrer" size=15 value="<?php echo $referrer ?>">
</fieldset>
<fieldset>
<legend>Status</legend>
<Input type = 'Radio' Name ='status' class='required' value= 'A' <?php echo $active_button ?>>Active
<Input type = 'Radio' Name ='status' class='required' value= 'C' <?php echo $cancel_button ?>>Cancelled
<Input type = 'Radio' Name ='status' class='required' value= 'B' <?php echo $bike_button ?>>Bike Earned
</fieldset>
<fieldset id="service">
<legend>Service Information</legend>
Org: <input type="text" id="org1" name="org1" size=15 value="<?php echo $org1 ?>">
Phone: <input type="text" id="org1phone" name="org1phone" size=10 value="<?php echo $org1phone ?>">
Hours: <input type="text" name="hours1" size=2 value="<?php echo $hours1 ?>"">
Verified: <input type="text" name="ver1" size=15 value="<?php echo $ver1 ?>"">
<br>
Org: <input type="text" id="org1" name="org2" size=15 value="<?php echo $org2 ?>">
Phone: <input type="text" id="org2phone" name="org2phone" size=10 value="<?php echo $org2phone ?>">
Hours: <input type="text" name="hours2" size=2 value="<?php echo $hours2 ?>"">
Verified: <input type="text" name="ver2" size=15 value="<?php echo $ver2 ?>"">
<br>
Org: <input type="text" id="org3" name="org3" size=15 value="<?php echo $org3 ?>">
Phone: <input type="text" id="org3phone" name="org3phone" size=10 value="<?php echo $org3phone ?>">
Hours: <input type="text" name="hours3" size=2 value="<?php echo $hours3 ?>"">
Verified: <input type="text" name="ver3" size=15 value="<?php echo $ver3 ?>"">
<br>
Org: <input type="text" id="org4" name="org4" size=15 value="<?php echo $org4 ?>">
Phone: <input type="text" id="org4phone" name="org4phone" size=10 value="<?php echo $org4phone ?>">
Hours: <input type="text" name="hours4" size=2 value="<?php echo $hours4 ?>"">
Verified: <input type="text" name="ver4" size=15 value="<?php echo $ver4 ?>"">
</fieldset>
<fieldset id="bike">
<legend>Bike Information</legend>
<label for="bikedate">Date Earned: </label><input type="text" name="bikedate" size=8 id="bikedate" class="datepick" value="<?php echo $v_bikedate ?>" />
<p>
Brand: <input type="text" id="brand" name="brand" size=8 value="<?php echo $brand ?>">
Model: <input type="text" name="model" size=8 value="<?php echo $model ?>">
Color: <input type="text" name="color" size=4 value="<?php echo $color ?>">
Serial Number: <input type="text" name="serial" size=15 value="<?php echo $serial ?>">
<p>
Description: <input type="textarea" name="description" size=50 value="<?php echo $description ?>">
</fieldset>
<p>
<input type="submit" name="Submit" value="submit">
<?php
// Close the connection
mysql_close($connection);
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
