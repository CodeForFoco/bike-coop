<?php
// Turn off all error reporting
error_reporting(0);
//Connect to the Bike Co-op database
require_once "../../db_connect.php";
$db = db_connect ();
//Get the BikeID from ajax
$bike=($_GET['bikeID']);
$description=($_GET['description']);
$status=($_GET['status']);
$dispdate=date('Y-m-d');
$sql = "UPDATE `RECOVEREDBIKES` SET `Disposition`='EAB',`DispDate`='".$dispdate."',`Description`='".$description."',`Status`='".$status."' WHERE BikeID='".$bike."'";
$update = $db->prepare($sql);
try
	{
	// run the query
	$update->execute();
	}
catch (PDOException $e)
	{
	echo "The statement failed.\n";
	echo "getCode: ". $e->getCode () . "\n";
	echo "getMessage: ". $e->getMessage () . "\n";
	}
// echo "Bike #".$bike." logged as ".$disposition." project.";
?>
