<?php
// This script presents the page for showing EAB statistics
session_start();
$_SESSION['list']="EABstats";
$HTTP_SESSION_VARS ["list"] = "EABstats";
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<script src="../sorttable.js"></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
  			<td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>EAB</a> <b>&raquo;</b> EAB Stats</td>
				</tr>
			</table>			<div class="heading">EAB Stats</div>
<?php
//Connect to the Bike Co-op database
// Include our login information
include('../db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
die ("Could not connect to the database: <br />". mysql_error());
}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
die ("Could not select the database: <br />". mysql_error());
}

$result = mysql_query('SELECT `ID`,`Owner`,`ReturnedDate`,`BikeDate`,DATEDIFF(`BikeDate`,`ReturnedDate`) AS `Delay` FROM `EAB` WHERE YEAR(BikeDate)=YEAR(CURDATE()) ORDER BY `BikeDate`');
?>
<img src="EABgraph.php">
<p>Note:  list can be sorted by clicking on the column headers.
<font size=1>
<table border=2 class="sortable">
	<thead>
		<tr>
			<th>ID</th><th>Owner</th><th>Returned</th><th>Bike Given</th><th>Delay</th>
			</tr>
	</thead>
	<tbody>
<?php
//Fetch & display the results
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$ID = $result_row["ID"];
	$owner = $result_row["Owner"];
	$enterdate = $result_row["ReturnedDate"];
	$earndate = $result_row["BikeDate"];
	$delay = $result_row["Delay"];
	$diff = abs(strtotime($earndate) - strtotime($enterdate));
	$years = floor($diff / (365*60*60*24));
	$months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
	$days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
	// Change the date format for display purposes.
	$v_enterdate = date("m/d/Y",strtotime($enterdate));
	$v_earndate = date("m/d/Y",strtotime($earndate));
	echo "<tr>";
	echo "<td><a href=\"./EditEAB.php?ID=".$ID."\">$ID</td><td>$owner</td><td>$v_enterdate</td><td>$v_earndate</td><td align='right'>$delay</td>";
	echo "</tr>";
	echo "\n";
	}
?>
	</tbody>
</table>
<?php
// Close the connection to the database
mysql_close($connection);

include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
