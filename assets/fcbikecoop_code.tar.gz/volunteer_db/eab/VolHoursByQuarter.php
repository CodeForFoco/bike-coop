<?php
// This script presents the page for listing all EAB
$current_page = htmlentities($_SERVER['PHP_SELF']);

include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<script src="../sorttable.js"></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
  			<td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>EAB</a> <b>&raquo;</b> EAB Volunteer Hours by Quarter</td>
				</tr>
			</table>			<div class="heading">EAB Volunteer Hours by Quarter</div>
<?php
//Connect to the Bike Co-op database
// Include our login information
include('../db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
die ("Could not connect to the database: <br />". mysql_error());
}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
die ("Could not select the database: <br />". mysql_error());
}

$result = mysql_query('SELECT `Type`,YEAR(`DateEarned`) AS Year, QUARTER(`DateEarned`) AS Qtr, COUNT(*) AS Clients, SUM(`Hours1` + `Hours2` + `Hours3` + `Hours4`) AS Hours FROM EAB WHERE (`Hours1` | `Hours2` | `Hours3` | `Hours4`> 0) GROUP BY `Type`,Year,Qtr ORDER BY `Type`,Year,Qtr');
?>
<p>Note:  list can be sorted by clicking on the column headers.
<font size=1>
<table border=2 class="sortable">
	<thead>
		<tr>
			<th>Type</th><th>Year</th><th>Qtr</th><th>Clients</th><th>Hours<th>....</th>
			</tr>
	</thead>
	<tbody style='height:300px; overflow:auto;'>
<?php
//Fetch & display the results
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$type = $result_row["Type"];
	$year = $result_row["Year"];
	$qtr = $result_row["Qtr"];
	$clients = $result_row["Clients"];
	$hours = $result_row["Hours"];
	echo "<td>$type</td><td>$year</td><td align=center>$qtr</td><td align=right>$clients</td><td align=right>$hours</td>";
	echo "</tr>";
	echo "\n";
	}
?>
	</tbody>
</table>
<?php
// Close the connection to the database
mysql_close($connection);

include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
