<?php
/**
	*	EABlist.php - part of the Fort Collins Bike Co-op system for managing the Earn-A-Bike program.
	*
	* This script presents the page for listing all active EAB applications. From the displayed list, you
	* can click on the Timesheet number, which will call EABedit.php with the Timesheet number passed as 
	* the argument "TS". You can also click on the icon in the "2wk" or "4wk" column to call EABupdate.php
	* to update the status of the application.
	*/
	
// Set up values for this script.
$caller="EABactive";
$page="Active EAB Applications";
$program="EABactive.php";

// Include the standard code for setting up the session.
require_once "./session_setup.php";
?>
Click in the Timesheet column to update/complete an application.</br>
Click in the 2wk/4wk column to record follow-up calls or cancellation.</br>
Note:  list can be sorted by clicking on the column headers.
<table border=2 id="dataTable" class="tablesorter" style="font-size:14px;">
	<thead>
		<tr>
			<th>Timesheet</th><th>Entered</th><th>Owner</th><th>Type</th><th>2wk</th><th>4wk</th><th>Comments</th>
		</tr>
	</thead>
	<tbody>
<?php
// Run the query to get the list of pending EAB applications.
$query = $db->prepare("SELECT * FROM EAB WHERE Timesheet <> '' AND Status='A' ORDER BY Timesheet DESC");
$query->execute();

// Fetch & display the results of the query.
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$timesheet = $result_row["Timesheet"];
	// Change the date format for display purposes.
	$TSdate = $result_row["TSdate"];
	$v_TSdate = date("m/d/Y",strtotime($TSdate));
	$owner = $result_row["Owner"];
	$type = $result_row["Type"];
	$wk2call = $result_row["2wkCall"];
	$wk4call = $result_row["4wkCall"];
	$comments = $result_row["Comments"];
	// set the appropriate status image for the 2-week call
	$wk2 = "whtpearl.gif";
	if ($wk2call > '0000-00-00') {$wk2="tick.gif";}
	else
		{
		$now = time();
		$your_date = strtotime($TSdate);
		$datediff = $now - strtotime($TSdate);
		$diff = floor($datediff/(60*60*24));
		if ($diff > 14) {$wk2="cross.gif";} // greater than 14 days, use the cross image
		}
	// set the appropriate status image for the 4-week call
	$wk4 = "whtpearl.gif";
	if ($wk4call > '0000-00-00') {$wk4="tick.gif";}
	else
		{
		$now = time();
		$your_date = strtotime($TSdate);
		$datediff = $now - strtotime($TSdate);
		$diff = floor($datediff/(60*60*24));
		if ($diff > 28) {$wk4="cross.gif";} // greater than 14 days, use the cross image
		}

	echo "<td><a href=\"./EABedit.php?TS=".$timesheet."\">$timesheet</td><td>$v_TSdate</td><td>$owner</td><td>$type</td><td align=\"center\"><a href=\"./EABupdate.php?TS=".$timesheet."\">
<img src=\"".$wk2."\" alt=\"2wk call\" />
</a></td>
<td align=\"center\"><a href=\"./EABupdate.php?TS=".$timesheet."\">
<img src=\"".$wk4."\" alt=\"4wk call\" />
</a></td><td>$comments</td>";
	echo "</tr>";
	echo "\n";
	}

?>
	</tbody>
</table>
</div>

<?php
// Free used database resources.
$db = null;
// Finish the page.
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
