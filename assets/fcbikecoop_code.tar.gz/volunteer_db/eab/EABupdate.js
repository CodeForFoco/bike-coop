$(document).ready(function()
	{
		var _eabref = $('input[name=type]');
		if(_eabref.attr("checked") != "undefined" && _eabref.attr("checked") == "checked") 
			{
       	$("#referral").slideDown("fast"); //Slide Down Effect   
			}
		else
			{
				if ($('input[name=type]:checked').val() == "EAB")
				{
					$("#referral").slideUp("fast");	//Slide Up Effect
				}
			};
    $('input:radio[name=type]').click(function(){
    	if ($('input[name=type]:checked').val() == "Referral" ) {
        	$("#referral").slideDown("fast"); //Slide Down Effect   
        } else {
            $("#referral").slideUp("fast");	//Slide Up Effect
        }
     });
	$(".datepick").datepicker(
		{showOn: 'both',
		 showButtonPanel: true,
		 buttonImage: '../iconCalendar.gif',
		 buttonImageOnly: true 
		});
	jQuery.validator.addMethod("phoneUS", function(phone_number, element) 
		{
		phone_number = phone_number.replace(/\s+/g, ""); //remove whitespace
		return this.optional(element) || phone_number.length > 6 &&
//		phone_number.match(/^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/);
		phone_number.match(/^(1?(-?\d{3})-?)?(\d{3})(-?\d{4})$/);
		}, "Please specify a valid phone number");
	$("#appForm").validate(
		{
		submitHandler: function(form) 
			{
			form.submit();
			},
		rules: 
			{
			volunteer: 
				{
				required: true
				},
			owner: 
				{
				required: true
				},
			email: 
				{
				email: true
				},
			phone: 
				{
				phoneUS: true
				},
			agency: 
				{
				required: 
					{
					depends: function()
						{
						return $('input[name=type]:checked').val() == "Referral";
						}
					}
				},
			referrer: 
				{
				required:
					{
					depends: function()
						{
						return $('input[name=type]:checked').val() == "Referral";
						}
					}
				}
			}

		});
	});
