<?php
/**
	*	EABhours.php - part of the Fort Collins Bike Co-op system for managing the Earn-A-Bike program.
	*
	* This script presents the page showing hours of community service performed. 
	* From the displayed list, you can click on the Timesheet number, which will call EABedit.php with
	* the Timesheet number passed as the argument "TS".
	*/

// Set up values for this script.
$caller="EABhours";
$page="EAB Community Service Hours";
$program="EABhours.php";

// Include the standard code for setting up the session.
require_once "./session_setup.php";

// Run the query to get the list of EAB applications.
$query = $db->prepare("SELECT * FROM EAB ORDER BY BikeDate DESC");
$query->execute();
?>
<table border=2 id="dataTable" class="tablesorter" style="font-size:14px;">
	<thead>
		<th>Timesheet</th><th>Owner</th><th>Type</th><th>Earned</th><th>Hours</th>

	</thead>
	<tbody>
<?php
// Fetch & display the results of the query.
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$timesheet = $result_row["Timesheet"];
	$owner = $result_row["Owner"];
	$earndate = $result_row["BikeDate"];
	$org1 = $result_row["Org1"];
	$hours1 = $result_row["Hours1"];
	$org2 = $result_row["Org2"];
	$hours2 = $result_row["Hours2"];
	$org3 = $result_row["Org3"];
	$hours3 = $result_row["Hours3"];
	$org4 = $result_row["Org4"];
	$hours4 = $result_row["Hours4"];
	$type = $result_row["Type"];
	// add up the hours
	$hours = $hours1 + $hours2 + $hours3 + $hours4;
	// Change the date format for display purposes.
	$v_earndate = date("m/d/Y",strtotime($earndate));
	echo "<tr>";
	echo "<td><a href=\"./EABedit.php?TS=".$timesheet."\">$timesheet</td><td>$owner</td><td>$type</td><td>$v_earndate</td><td>$hours</td>";
	echo "</tr>";
	echo "\n";
	}
?>
	</tbody>
</table>
</div>
<?php
// Free used database resources.
$db = null;
// Finish the page.
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
