<?php
// Turn off all error reporting
error_reporting(0);
//Connect to the Bike Co-op database
require_once($_SERVER['DOCUMENT_ROOT'].'db_connect.php');
$db = db_connect ();
//Get the brand & model from ajax
$brand = $_GET['brand'];
$model = $_GET['model'];
//Get the list of bikes
try
	{
	$query = $db->prepare("SELECT DISTINCT(Color) AS Color FROM RECOVEREDBIKES WHERE DispDate > '0000-00-00' AND (Disposition = 'EAB' OR Disposition = 'as-is') AND Status='' AND Brand LIKE ? AND Model LIKE ? ORDER BY Color");
	$query->bindValue(1, "%$brand%", PDO::PARAM_STR);
	$query->bindValue(2, "%$model%", PDO::PARAM_STR);
	$query->execute();
	}
catch (PDOException $e)
	{
	print ("The statement failed.\n");
	echo "boo-boo";
	echo "getMessage(): " . $e->getMessage () . "\n";
	}
//Fetch the log numbers for use in the bike selection list
echo "<option value=\"\">Please select a color ...</option>";
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$color = $result_row["Color"];
	echo "<option  value='".$color."'>".$color."</option>\n";
	}
?>
