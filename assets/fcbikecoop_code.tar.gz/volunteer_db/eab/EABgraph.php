<?php
// This script presents the page for showing EAB statistics
session_start();
$_SESSION['list']="EABstats";
$HTTP_SESSION_VARS ["list"] = "EABstats";
$current_page = htmlentities($_SERVER['PHP_SELF']);
//include_once('/var/www/fcbikecoop.org/root/header.php');
//Connect to the Bike Co-op database
// Include our login information
include('../db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
die ("Could not connect to the database: <br />". mysql_error());
}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
die ("Could not select the database: <br />". mysql_error());
}
$query = "SELECT `BikeDate`,AVG(DATEDIFF(`ReturnedDate`,`BikeDate`)) AS `Delay` FROM `EAB` WHERE YEAR(BikeDate)=YEAR(CURDATE()) GROUP BY MONTH(`BikeDate`)";
$result = mysql_query($query) or die(mysql_error());

while ($myrow=mysql_fetch_array($result,MYSQL_ASSOC))
	{
   $datax[] = date("My",strtotime($myrow["BikeDate"]));
   $datay[] = abs($myrow["Delay"]);
	}

require_once ('../jpgraph/jpgraph.php');
require_once ('../jpgraph/jpgraph_line.php');
require_once ('../jpgraph/jpgraph_date.php');

// Formatting function to translate the timestamps into human readable labels
function formatDate(&$aVal) {
    $aVal = date('M y',$aVal);
}
 
// Apply this format to all time values in the data to prepare it to be display
//array_walk($datax,'formatDate');

// Create the graph. These two calls are always required
$graph = new Graph(600,400);	
$graph->SetScale("textlin");
$graph->img->SetMargin(50,50,40,70);
$graph->title->Set("Average EAB Delay");
$graph->yaxis->title->SetFont(FF_FONT1,FS_BOLD);
$graph->xaxis->title->SetFont(FF_FONT1,FS_BOLD);

$graph->xaxis->title->Set('DATE EARNED','high');
$graph->yaxis->title->Set('DAYS');
$graph->xaxis->SetTickLabels($datax);
// Set the angle for the labels to 90 degrees
$graph->xaxis->SetLabelAngle(90);
$graph->xaxis->SetTitleMargin(40);
$graph->yaxis->SetTitleMargin(30);

// Create the linear plot
$lineplot = new LinePlot($datay);
//$lineplot=new LinePlot($datay);
$lineplot->SetColor("blue");
//$lineplot->SetStepStyle();
$lineplot->mark->SetType(MARK_CIRCLE);
$lineplot->value->Show();

// Add the plot to the graph
$graph->Add($lineplot);

// Display the graph
$graph->Stroke();

// Close the connection to the database
mysql_close($connection);
?>
