<?php
session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
// get the variables that will let us get back
$list = $_SESSION['list'];

$list_link_back = "<a href='./ListEAB.php'>EAB List</a>";
if ($list == "SearchEAB")
	{
	$list_link_back = "<a href='./SearchEAB.php'>Search EAB Records</a>";
	}
elseif ($list == "EABstats")
	{
	$list_link_back = "<a href='./EABstats.php'>EAB Statistics</a>";
	}
elseif ($list == "VolHours")
	{
	$list_link_back = "<a href='./VolHours.php'>EAB Volunteer Hours</a>";
	}
elseif ($list == "EABlog")
	{
	$list_link_back = "<a href='./EABlog.php'>Record EAB</a>";
	}

//Connect to the Bike Co-op database
// Include our login information
include('../db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
	die ("Could not connect to the database: <br />". mysql_error());
	}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
	die ("Could not select the database: <br />". mysql_error());
	}
// get the timesheet to be edited
	$id = $_GET['ID'];
// Do this if form has been submitted
// If form has been submitted, post the record to the EAB table.
if(isset($_POST['Submit']))
	{
	$returndate=$_POST['returndate'];
	$volunteer=ucwords($_POST['volunteer']);
	$type=$_POST['type'];
	$owner=$_POST['owner'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	$news=$_POST['news'];
	$agency=$_POST['agency'];
	$referrer=$_POST['referrer'];
	$org1=$_POST['org1'];
	$org1phone=$_POST['org1phone'];
	$hours1=$_POST['hours1'];
	$ver1=$_POST['ver1'];
	$org2=$_POST['org2'];
	$org2phone=$_POST['org2phone'];
	$hours2=$_POST['hours2'];
	$ver2=$_POST['ver2'];
	$org3=$_POST['org3'];
	$org3phone=$_POST['org3phone'];
	$hours3=$_POST['hours3'];
	$ver3=$_POST['ver3'];
	$org4=$_POST['org4'];
	$org4phone=$_POST['org4phone'];
	$hours4=$_POST['hours4'];
	$ver4=$_POST['ver4'];
	$bikedate=$_POST['bikedate'];
	$hours=$_POST['hours'];
	$serial=$_POST['serial'];
	$brand=strtoupper($_POST['brand']);
	// fix case of brand name, but allow for 3 or less letter names like "KHS"
	if (strlen($brand)>3) $brand=ucwords(strtolower($_POST['brand']));
	$model=$_POST['model'];
	$color=strtolower($_POST['color']);
	$description=$_POST['description'];
// Build our query here and check each variable with mysql_real_escape_string()
	$query = "UPDATE EAB Set ReturnedDate=STR_TO_DATE('".$returndate."', '%m/%d/%Y'),
														EnteredBy='".$volunteer."', 
														Type='".$type."', 
														Owner='".$owner."', 
														Email='".$email."', 
														Phone='".$phone."', 
														News='".$news."', 
														Agency='".$agency."', 
														AgencyID='".$referrer."', 
														Org1='".$org1."', 
														Org1Phone='".$org1phone."', 
														Hours1='".$hours1."', 
														VerifiedBy1='".$ver1."', 
														Org2='".$org2."', 
														Org2Phone='".$org2phone."', 
														Hours2='".$hours2."', 
														VerifiedBy2='".$ver2."', 
														Org3='".$org3."', 
														Org3Phone='".$org3phone."', 
														Hours3='".$hours3."', 
														VerifiedBy3='".$ver3."', 
														Org4='".$org4."', 
														Org4Phone='".$org4phone."', 
														Hours4='".$hours4."', 
														VerifiedBy4='".$ver4."', 
														BikeDate=STR_TO_DATE('".$bikedate."', '%m/%d/%Y'),
														HoursReq='".$hours."', 
														Serial='".$serial."', 
														Brand='".$brand."', 
														Model='".$model."', 
														Color='".$color."', 
														Description='".$description."'
						WHERE ID=".$id;
	// run the query
	if(!mysql_query($query))
		{
		echo 'Query failed '.mysql_error();
		echo $query;
		exit();
		}
	// No errors were detected.
}

//Assign the query
	$result = mysql_query('SELECT * FROM `EAB` WHERE `ID` = '.$id);
	if (!$result){
	die ("Could not query the database: <br />". mysql_error());
	}
//Fetch & display the results
	while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$returndate = $result_row['ReturnedDate'];
	$volunteer = $result_row['EnteredBy'];
	$type = $result_row['Type'];
	if ($type == "EAB")
		{$eab_button = "checked";}
	else
		{$eab_button = "";}
	if ($type == "Referral")
		{$ref_button = "checked";}
	else
		{$ref_button = "";}
	$owner = $result_row['Owner'];
	$email = $result_row['Email'];
	$phone = $result_row['Phone'];
	$news = $result_row['News'];
	if ($news == "1")
		{$yes_button = "checked";}
	else
		{$yes_button = "";}
	if ($news == "0")
		{$no_button = "checked";}
	else
		{$no_button = "";}
	$agency = $result_row['Agency'];
	$referrer = $result_row['AgencyID'];
	$org1 = $result_row['Org1'];
	$org1phone = $result_row['Org1Phone'];
	$hours1 = $result_row['Hours1'];
	$ver1 = $result_row['VerifiedBy1'];
	$org2 = $result_row['Org2'];
	$org2phone = $result_row['Org2Phone'];
	$hours2 = $result_row['Hours2'];
	$ver2 = $result_row['VerifiedBy2'];
	$org3 = $result_row['Org3'];
	$org3phone = $result_row['Org3Phone'];
	$hours3 = $result_row['Hours3'];
	$ver3 = $result_row['VerifiedBy3'];
	$org4 = $result_row['Org4'];
	$org4phone = $result_row['Org4Phone'];
	$hours4 = $result_row['Hours4'];
	$ver4 = $result_row['VerifiedBy4'];
	$timesheet = $result_row["timesheet"];
	$bikedate = $result_row['BikeDate'];
	$hours = $result_row['HoursReq'];
	$serial = $result_row["Serial"];
	$brand = $result_row["Brand"];
	$model = $result_row["Model"];
	$color = $result_row["Color"];
	$description = $result_row["Description"];
	}
	// Change the date format for display purposes.
	$v_returndate = date("m/d/Y",strtotime($returndate));
	$v_bikedate = date("m/d/Y",strtotime($bikedate));
// If PHP is still reading this, it must be the first page visit,
// OR an error was detected.
// Display the HTML page and your signup form.

include_once('/var/www/fcbikecoop.org/root/header.php');
?>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
  			<td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>EAB</a> <b>&raquo;</b> <?php echo $list_link_back;?> <b>&raquo;</b>  Edit EAB Record</td>
				</tr>
			</table>
<SCRIPT LANGUAGE="JavaScript" SRC="../CalendarPopup.js"></SCRIPT>
			<div class="heading">Earn-A-Bike Community Service Time Sheet</div>

<form method="POST" enctype="multipart/form-data">
<SCRIPT LANGUAGE="JavaScript" ID="js1">
var cal1 = new CalendarPopup();
</SCRIPT>
<p>
Date Returned: <input type="text" name="returndate" size=8 id="returndate" value="<?php echo $v_returndate ?>">
Logged by: <input type="text" name="volunteer" size=15 value="<?php echo $volunteer ?>">
<Input type = 'Radio' Name ='type' <?php echo $eab_button ?> value='EAB'>EAB
<Input type = 'Radio' Name ='type' <?php echo $ref_button ?> value='Referral'>Referral
<p>
Owner's Name: <input type="text" id="owner" name="owner" size=15 value="<?php echo $owner ?>">
Email: <input type="text" id="email" name="email" size=15 value="<?php echo $email ?>">
Phone: <input type="text" id="phone" name="phone" size=10 value="<?php echo $phone ?>">
<p>Newsletter?<Input type = 'Radio' Name ='news' <?php echo $yes_button ?> value= '1'<?PHP print $news; ?>>Yes
<Input type = 'Radio' Name ='news' <?php echo $no_button ?> value= '0'<?PHP print $news; ?>>No
<h2>Referral Information</h2>
Agency: <input type="text" id="agency" name="agency" size=15 value="<?php echo $agency ?>">
Referrer: <input type="text" id="referrer" name="referrer" size=15 value="<?php echo $referrer ?>">
<h2>Service Information</h2>
Org: <input type="text" id="org1" name="org1" size=15 value="<?php echo $org1 ?>">
Phone: <input type="text" id="org1phone" name="org1phone" size=10 value="<?php echo $org1phone ?>">
Hours: <input type="text" name="hours1" size=2 value="<?php echo $hours1 ?>"">
Verified: <input type="text" name="ver1" size=15 value="<?php echo $ver1 ?>"">
<br>
Org: <input type="text" id="org1" name="org2" size=15 value="<?php echo $org2 ?>">
Phone: <input type="text" id="org2phone" name="org2phone" size=10 value="<?php echo $org2phone ?>">
Hours: <input type="text" name="hours2" size=2 value="<?php echo $hours2 ?>"">
Verified: <input type="text" name="ver2" size=15 value="<?php echo $ver2 ?>"">
<br>
Org: <input type="text" id="org3" name="org3" size=15 value="<?php echo $org3 ?>">
Phone: <input type="text" id="org3phone" name="org3phone" size=10 value="<?php echo $org3phone ?>">
Hours: <input type="text" name="hours3" size=2 value="<?php echo $hours3 ?>"">
Verified: <input type="text" name="ver3" size=15 value="<?php echo $ver3 ?>"">
<br>
Org: <input type="text" id="org4" name="org4" size=15 value="<?php echo $org4 ?>">
Phone: <input type="text" id="org4phone" name="org4phone" size=10 value="<?php echo $org4phone ?>">
Hours: <input type="text" name="hours4" size=2 value="<?php echo $hours4 ?>"">
Verified: <input type="text" name="ver4" size=15 value="<?php echo $ver4 ?>"">
<h2>Bike Information</h2>
<SCRIPT LANGUAGE="JavaScript" ID="js2">
var cal2 = new CalendarPopup();
</SCRIPT>
Date Earned: <input type="text" name="bikedate" size=8 id="bikedate" value="<?php echo $v_bikedate ?>">
<A HREF="#" onClick="cal2.select(document.forms[0].bikedate,'anchor2','MM/dd/yyyy'); return false;" TITLE="cal2.select(document.forms[0].bikedate,'anchor2','MM/dd/yyyy'); return false;" NAME="anchor2" ID="anchor2"><input type="image" src="../iconCalendar.gif"></A>
Hours Required: <input type="text" id="hours" name="hours" size=4 value="<?php echo $hours ?>">
<p>
Brand: <input type="text" id="brand" name="brand" size=8 value="<?php echo $brand ?>">
Model: <input type="text" name="model" size=8 value="<?php echo $model ?>">
Color: <input type="text" name="color" size=4 value="<?php echo $color ?>">
Serial Number: <input type="text" name="serial" size=15 value="<?php echo $serial ?>">
<p>
Description: <input type="textarea" name="description" size=50 value="<?php echo $description ?>">
<p>
<input type="submit" name="Submit" value="submit">
<?php
// Close the connection
mysql_close($connection);
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
