<?php
/**
	*	EABreport.php - part of the Fort Collins Bike Co-op system for tracking recovered bikes
	*
	* This script presents the page for allowing the user to enter a date range for generating a
	* list of Earn-A-Bike activity.
	*/
// Set up values for this script.
$caller="EABreport";
$page="EAB Report";
$program="EABreport.php";

// Include the standard code for setting up the session.
require_once "./session_setup.php";

?>
<!-- We will be using JQuery functions and a JavaScript for processing the form. -->
<link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/themes/humanity/jquery-ui.css" />
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js" ></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<style type="text/css">
.ui-widget { font-family: Lucida Grande, Lucida Sans, Arial, sans-serif; font-size: 0.6em; }
</style>
<script>
$.datepicker.setDefaults({
	autoSize: true,
	showOn: "both",
	buttonImageOnly: true,
	buttonImage: "../iconCalendar.gif",
	buttonText: "Calendar"
});
   $(function() {
     $("#date1").datepicker({dateFormat: 'yy-mm-dd'});
     $("#date2").datepicker({dateFormat: 'yy-mm-dd'});
   });
 </script>
<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
<!-- Build the fields. -->
Select a start and end date from the dropdown calendars and click on Submit.
<p>Start Date:<input type="text" name="StartDate" id="date1">
	End Date:<input type="text" name="EndDate" id="date2">
<p><input type="submit" name="Submit" value="submit">
</form> 
<?php
// If form has been submitted, search the EAB table.
if(isset($_POST['Submit']))
	{
	$startdate=$_POST['StartDate'];
//	$startdate = date("Y-m-d", $start);
	$enddate=$_POST['EndDate'];
//	$enddate = date("Y-m-d", $end);
	// Close PHP so we can output the header info.
	?>
	<p>
	<table border=2 id="dataTable" class="tablesorter">
		<thead>
			<tr>
				<th>Year</th><th>Owner</th><th>Type</th><th>Agency</th><th>Agency ID</th><th>Org</th><th>Hours</th>
			</tr>
		</thead>
		<tbody>
	<?php
	// Re-open PHP so we can output the results.
	//Assign the query
	$query = $db->prepare("SELECT YEAR(BikeDate) AS Year,
	Owner, Type, Agency, AgencyID, TRIM(BOTH ' ' FROM CONCAT_WS(', ', NULLIF(Org1, ''), NULLIF(Org2, ''), NULLIF(Org3, ''), NULLIF(Org4, ''))) AS Orgs, Hours1 + Hours2 + Hours3 + Hours4 AS Hours FROM EAB 
	WHERE (BikeDate > :startdate && BikeDate <= :enddate) && (Hours1 | Hours2 | Hours3 | Hours4> 0) 
	GROUP BY Owner 
	ORDER BY YEAR(BikeDate)");
	$query->bindValue(':startdate', $startdate, PDO::PARAM_STR);
	$query->bindValue(':enddate', $enddate, PDO::PARAM_STR);
	$query->execute();
	// Fetch & display the results of the query.
	while($result_row = $query->fetch(PDO::FETCH_ASSOC))
		{
		$year = $result_row["Year"];
		$owner = $result_row["Owner"];
		$type = $result_row["Type"];
		// Shorten Referral type
		if ($type == "Referral") {$type = "Ref";}
		$agency = $result_row["Agency"];
		$agencyID = $result_row["AgencyID"];
		$orgs = $result_row["Orgs"];
//		$hours1 = $result_row["Hours1"];
//		$org2 = $result_row["Org2"] ;
//		$hours2 = $result_row["Hours2"];
//		$org3 = $result_row["Org3"];
//		$hours3 = $result_row["Hours3"];
//		$org4 = $result_row["Org4"];
//		$hours4 = $result_row["Hours4"];
		$hours = $result_row["Hours"];
		echo "<tr>";
		echo"<td>$year</td><td>$owner</td><td align=center>$type</td><td>$agency</td><td>$agencyID</td><td>$orgs</td><td>$hours</td>";
		echo "</tr>";
		echo "\n";
		}
	?>
	</tbody>
	</table>
	<?php
// Free used resources
	$query->closeCursor();
	$db = null;
// Get the standard Bike Co-op page footer.
	}
include_once($_SERVER['DOCUMENT_ROOT'].'footer.php');
?>
