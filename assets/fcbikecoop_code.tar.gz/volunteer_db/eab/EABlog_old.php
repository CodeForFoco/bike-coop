<?php
session_start();
$_SESSION['list']="EABlog";
$HTTP_SESSION_VARS ["list"] = "EABlog";
$current_page = htmlentities($_SERVER['PHP_SELF']);

//Connect to the Bike Co-op database
// Include our login information
include('../db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
	die ("Could not connect to the database: <br />". mysql_error());
	}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
	die ("Could not select the database: <br />". mysql_error());
	}

// Do this if form has been submitted
// If form has been submitted, post the record to the EAB table.
if(isset($_POST['Submit']))
	{
	$volunteer=ucwords($_POST['volunteer']);
	$type=$_POST['type'];
	$owner=$_POST['owner'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	$news=$_POST['news'];
	$agency=$_POST['agency'];
	$referrer=$_POST['referrer'];
	$org1=$_POST['org1'];
	$org1phone=$_POST['org1phone'];
	$hours1=$_POST['hours1'];
	$ver1=$_POST['ver1'];
	$org2=$_POST['org2'];
	$org2phone=$_POST['org2phone'];
	$hours2=$_POST['hours2'];
	$ver2=$_POST['ver2'];
	$org3=$_POST['org3'];
	$org3phone=$_POST['org3phone'];
	$hours3=$_POST['hours3'];
	$ver3=$_POST['ver3'];
	$org4=$_POST['org4'];
	$org4phone=$_POST['org4phone'];
	$hours4=$_POST['hours4'];
	$ver4=$_POST['ver4'];
	$earndate=$_POST['earndate'];
	$serial=$_POST['serial'];
	$brand=strtoupper($_POST['brand']);
	// fix case of brand name, but allow for 3 or less letter names like "KHS"
	if (strlen($brand)>3) $brand=ucwords(strtolower($_POST['brand']));
	$model=$_POST['model'];
	$color=strtolower($_POST['color']);
	$description=$_POST['description'];

	$result = mysql_query("INSERT INTO `EAB` (`DateEntered`, `EnteredBy`, `Type`, `Owner`, `Email`, `Phone`, `News`, `Agency`, `AgencyID`, `Org1`, `Org1Phone`, `Hours1`, `VerifiedBy1`, `Org2`, `Org2Phone`, `Hours2`, `VerifiedBy2`, `Org3`, `Org3Phone`, `Hours3`, `VerifiedBy3`, `Org4`, `Org4Phone`, `Hours4`, `VerifiedBy4`, `DateEarned`, `Serial`, `Brand`, `Model`, `Color`, `Description`)  VALUES (CURDATE(), '$volunteer', '$type',  '$owner', '$email', '$phone', '$news', '$agency', '$referrer', '$org1', '$org1phone', '$hours1', '$ver1', '$org2', '$org2phone', '$hours2', '$ver2', '$org3', '$org3phone', '$hours3', '$ver3', '$org4', '$org4phone', '$hours4', '$ver4', STR_TO_DATE('$earndate', '%m/%d/%Y'), '$serial', '$brand', '$model', '$color', '$description')");

	if (!$result)
		{
		die ("Could not insert the record in the database: <br />". mysql_error());
		}
	}


// If PHP is still reading this, it must be the first page visit,
// OR an error was detected.
// Display the HTML page and your signup form.

include_once('/var/www/fcbikecoop.org/root/header.php');
?>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
  			<td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>EAB</a> <b>&raquo;</b> Record EAB</td>
				</tr>
			</table>
<script src="../sorttable.js"></script>
<SCRIPT LANGUAGE="JavaScript" SRC="../CalendarPopup.js"></SCRIPT>
			<div class="heading">Earn A Bike Volunteer Data Sheet</div>

<form method="POST" action="<?php echo $PHP_SELF;?>" enctype="multipart/form-data">
<SCRIPT LANGUAGE="JavaScript" ID="js1">
var cal1 = new CalendarPopup();
</SCRIPT>
<p>
Date Entered: <input type="text" name="entryDate" size=8 id="entrydate">
<A HREF="#" onClick="cal1.select(document.forms[0].entrydate,'anchor1','MM/dd/yyyy'); return false;" TITLE="cal1.select(document.forms[0].entrydate,'anchor1','MM/dd/yyyy'); return false;" NAME="anchor1" ID="anchor1"><input type="image" src="../iconCalendar.gif"></A>
Logged by: <input type="text" name="volunteer" size=15>
<Input type = 'Radio' Name ='type' value= 'EAB'>EAB
<Input type = 'Radio' Name ='type' value= 'Referral'>Referral
<p>
Owner's Name: <input type="text" id="owner" name="owner" size=15>
Email: <input type="text" id="email" name="email" size=15>
Phone: <input type="text" id="phone" name="phone" size=10>
<p>Newsletter?<Input type = 'Radio' Name ='news' value= '1'>Yes
<Input type = 'Radio' Name ='news' value= '0'>No
<h2>Referral Information</h2>
Agency: <input type="text" id="agency" name="agency" size=15>
Referrer: <input type="text" id="referrer" name="referrer" size=15>
<h2>Service Information</h2>
Org: <input type="text" id="org1" name="org1" size=15>
Phone: <input type="text" id="org1phone" name="org1phone" size=10>
Hours: <input type="text" name="hours1" size=2>
Verified: <input type="text" name="ver1" size=15>
<br>
Org: <input type="text" id="org1" name="org2" size=15>
Phone: <input type="text" id="org2phone" name="org2phone" size=10>
Hours: <input type="text" name="hours2" size=2>
Verified: <input type="text" name="ver2" size=15>
<br>
Org: <input type="text" id="org3" name="org3" size=15>
Phone: <input type="text" id="org3phone" name="org3phone" size=10>
Hours: <input type="text" name="hours3" size=2>
Verified: <input type="text" name="ver3" size=15>
<br>
Org: <input type="text" id="org4" name="org4" size=15>
Phone: <input type="text" id="org4phone" name="org4phone" size=10>
Hours: <input type="text" name="hours4" size=2>
Verified: <input type="text" name="ver4" size=15>
<h2>Bike Information</h2>
<SCRIPT LANGUAGE="JavaScript" ID="js2">
var cal2 = new CalendarPopup();
</SCRIPT>
Date Earned: <input type="text" name="earndate" size=8 id="earndate">
<A HREF="#" onClick="cal2.select(document.forms[0].earndate,'anchor2','MM/dd/yyyy'); return false;" TITLE="cal2.select(document.forms[0].earndate,'anchor2','MM/dd/yyyy'); return false;" NAME="anchor2" ID="anchor2"><input type="image" src="../iconCalendar.gif"></A>
Hours Required: <input type="text" id="hours" name="hours" size=4>
<p>
Brand: <input type="text" id="brand" name="brand" size=8>
Model: <input type="text" name="model" size=8>
Color: <input type="text" name="color" size=4>
Serial Number: <input type="text" name="serial" size=15>
<p>
Description: <input type="textarea" name="description" size=50>
<p>
<input type="submit" name="Submit" value="submit">
Enter the information and click on submit.
</form>
<?php
// Get the EAB list.
$select = ' SELECT ';
$column = ' * ';
$from = ' FROM ';
$table = ' `EAB` ';
$order = ' ORDER BY `DateEntered` DESC';
$query = $select.$column.$from.$table.$order;
$result = mysql_query( $query );
if (!$result)
	{
	die ("Could not query the database: <br />". mysql_error());
	}
?>

<h2>EAB</h2>
Note:  list can be sorted by clicking on the column headers.
<font size=1>
<table border=2 class="sortable">
	<thead>
		<tr>
			<th>ID</th><th>Entered</th><th>Owner</th><th>Earned</th><th>Serial #</th><th>Brand</th><th>Model</th><th>Color</th><th>Description</th><th>....</th>
		</tr>
	</thead>
	<tbody style='height:200px; overflow:auto;'>
<?php
//Fetch & display the results
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$ID = $result_row["ID"];
	$enterdate = $result_row["DateEntered"];
	$owner = $result_row["Owner"];
	$earndate = $result_row["DateEarned"];
	$serial = $result_row["Serial"];
	$brand = $result_row["Brand"];
	$model = $result_row["Model"];
	$color = $result_row["Color"];
	$description = $result_row["Description"];

	echo "<td><a href=\"./EditEAB.php?ID=".$ID."\">$ID</td><td>$enterdate</td><td>$owner</td><td>$earndate</td><td>$serial</td><td>$brand</td><td>$model</td><td>$color</td><td>$description</td>";
	echo "</tr>";
	echo "\n";
	}

?>
	</tbody>
</table>
<?php
// Close the connection
mysql_close($connection);
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
