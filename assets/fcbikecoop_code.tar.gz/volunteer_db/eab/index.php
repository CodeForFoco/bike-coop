<?php
// This script presents the EAB main page
session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>

<div class="heading">Earn-a-Bike</div>
<p>
<a href="http:./EABsignup.php">EAB Sign Up</a><br>
<a href="http:./EABlist.php">EAB Applications</a><br>
<a href="http:./EABactive.php">Active EAB Applications</a><br>
<a href="http:./AddToEABvols.php">Add Volunteer to EAB List</a><br>
<a href="http:./SearchEAB.php">Search EAB</a><br>
<a href="http:./EABhours.php">List EAB Community Service Hours</a><br>
<a href="http:./EABHoursByQuarter.php">List EAB Community Service Hours by Quarter</a><br>
<a href="http:./EABHoursByOrg.php">List EAB Community Service Hours by Organization</a><br>
<a href="http:./EABstats.php">EAB Statistics</a><br>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
