/*************************************************************************
* This file (EABbike.js) contains Javascript code and is included in the
* EABbike.html page.
* It contains routines to make Ajax calls to
* ajax-getAvailEAB.php to populate the bike selection dialog, and to
* ajax-EABproject.php to update a record in the RECOVEREDBIKES table and
* display the bike info in an alert box to the user.
*/
"use strict";
$.ajaxSetup({ cache:false });
$(document).on('pageinit', function() {
 // Get the list of bikes
 getBikes();
 }); //END document pageinit
 // Whenever the EAB Project Bike page is shown, get the information for the page.
 $(document).on("pagecontainershow", function (e, ui) {
  // if we are coming from the EAB Projects page (we are doing an update), get the bike log number
  var activePage = $.mobile.activePage[0].id;
  if (activePage == "bike") {
   $.urlParam = function(name){
    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
    if (results==null){
     return null;
     }
    else{
     return results[1] || 0;
     }
    };
   }
  // if we are doing an update, get the bike data
  if (activePage == "bike" && $.urlParam('bikeid')) {getBikeInfo($.urlParam('bikeid'));}
  // fill in the form fields from the data stored
  document.getElementById("bikeid").innerHTML=sessionStorage.getItem("bikeid");
  document.getElementById("serial").innerHTML=sessionStorage.getItem("serial");
  document.getElementById("brand").innerHTML=sessionStorage.getItem("brand");
  document.getElementById("model").innerHTML=sessionStorage.getItem("model");
  document.getElementById("color").innerHTML=sessionStorage.getItem("color");
  document.getElementById("description").innerHTML=sessionStorage.getItem("description");
//document.getElementById("status").innerHTML=sessionStorage.getItem("status");
  });
$(document).on( "pageshow", "#list", function(event){
 getProjectBikes();
 });
$(document).on( "pageshow", "#select", function(event){
 getBikes();
 });
// Get the list of bikes that are available for EAB
function getBikes(){
 // load thd selection list
 var target_html = '<option value="" name="bikeID">pick a bike ...</option>';
 $('#bikeID').html(target_html); //Give the target select the prompt option
 $.ajax({url: './ajax-getAvailEAB.php', // AJAX request to get list of cleared bikes
  success: function(output) {
   $('#bikeID').html(output);
   },
  error: function (xhr, ajaxOptions, thrownError) {
   alert("in getBikes" + xhr.status + " "+ thrownError);
   }
  }); //END ajax
 } //END getBikes
function EABproject(){
 var bikeID = $("#bikeID").val();
 getBikeInfo(bikeID);
   $.mobile.changePage($("#bike"));
 } // end EABproject
// Get the info for the bike and store it in the browser's storage
function getBikeInfo(ID) {
 window.sessionStorage.clear(); // clear all local storage
 if (ID === undefined) {var ID = document.getElementById("bikeID").value;}
 $.ajax({
  url: './ajax-getBike.php?bikeID=' + ID,
  type: 'post',
  success: function(response) {
   // Parse the jSON that is returned
   // Using conditions here would probably apply
   // incase nothing is returned
   var Vals = JSON.parse(response);
   // store the data
   sessionStorage.setItem("bikeid", ID);
   sessionStorage.setItem("bikeid", Vals.bikeid);
   sessionStorage.setItem("serial", Vals.serial);
   sessionStorage.setItem("brand", Vals.brand);
   sessionStorage.setItem("model", Vals.model);
   sessionStorage.setItem("color", Vals.color);
   sessionStorage.setItem("description", Vals.description);
   sessionStorage.setItem("status", Vals.status);
   // add the data to the form in the DOM
   $("input[name='bikeid']").val(Vals.bikeid);
   $("input[name='serial']").val(Vals.serial);
   $("input[name='brand']").val(Vals.brand);
   $("input[name='model']").val(Vals.model);
   $("input[name='color']").val(Vals.color);
   $("textarea[name='description']").val(Vals.description);
   // reset the status radio buttons
   $("[name='btnstatus']").prop( "checked", false ).checkboxradio( "refresh" );
   if (Vals.status == "complete")
    {$("#complete").prop("checked",true).checkboxradio( "refresh" );}
   else 
    {$("#project").prop("checked",true).checkboxradio( "refresh" );}
   }, //END success fn
  error: function (xhr, ajaxOptions, thrownError) {
   alert("in getBike" + xhr.status + " "+ thrownError);
   },
  statusCode: {200: function (response) {debugger;}}
  }); //END $.ajax
 } //END getBikeInfo
// Get the list of project bikes
function getProjectBikes(){
 //Display 'loading' status in the target select list
 //$('#bikeID').html('<option value="">Loading...</option>');
 //Make AJAX request to get list of cleared bikes
 $.ajax({url: './ajax-getProjectsEAB.php',
  success: function(output) {
   $('#bikelist').html(output);
   },
  error: function (xhr, ajaxOptions, thrownError) {
   alert("in getCleared" + xhr.status + " "+ thrownError);
   }
  }); //END ajax
 } //END getProjectBikes
function EABupdate() {
 // Call ajax-EABproject.php to update the database record
 //Make AJAX request
 var bikeID = $("#bikeid").val();
 var description = $("#description").val();
 var status = $("#status :radio:checked").val();
 var params = 'bikeID='+bikeID+'&description='+description+'&status='+ status;
 $.ajax({url: './ajax-EABproject.php?'+params,
  type: "POST",
  cache: false,
  success: function(output) {
// alert(output);
// },
//error: function (xhr, ajaxOptions, thrownError) {
// alert("in disposeBike" + xhr.status + " "+ thrownError);
   }
  }); //END ajax
 $.mobile.changePage($("#list"));
} //END EABupdate
