<?php
/**
	*	EABHoursByQuarter.php - part of the Fort Collins Bike Co-op system for managing the Earn-A-Bike program.
	*
	* This script presents the page showing hours of community service performed by quarter.
	*/

// Set up values for this script.
$caller="Hours by Quarter";
$page="EAB Community Service Hours by Quarter";
$program="EABhoursByQuarter.php";

// Include the standard code for setting up the session.
require_once "./session_setup.php";
?>
<table border=2 id="dataTable" class="tablesorter" style="font-size:14px;">
	<thead>
		<th>Type</th><th>Year</th><th>Quarter</th><th>Clients</th><th>Hours</th>

	</thead>
	<tbody>

<?php
// Run the query.
$result = $db->query('SELECT `Type`, YEAR(`BikeDate`) AS Year, QUARTER(`BikeDate`) AS Qtr, COUNT(*) AS Clients, SUM(`Hours1` + `Hours2` + `Hours3` + `Hours4`) AS Hours FROM EAB WHERE (`Hours1` | `Hours2` | `Hours3` | `Hours4`> 0) GROUP BY Type,Year,Qtr ORDER BY Year DESC,Qtr DESC,Type');

// Fetch & display the results of the query.
foreach($result as $result_row)
	{
	$type = $result_row["Type"];
	$year = $result_row["Year"];
	$qtr = $result_row["Qtr"];
	$clients = $result_row["Clients"];
	$hours = $result_row["Hours"];
	echo "<td>$type</td><td>$year</td><td align=center>$qtr</td><td align=right>$clients</td><td align=right>$hours</td>";
	echo "</tr>";
	echo "\n";
	}
?>
	</tbody>
</table>
<?php
// Free used database resources.
$result->closeCursor();
$db = null;
// Finish the page.
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
