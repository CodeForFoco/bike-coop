<?php
session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
// Get the value that will tell us which form to load next.
if (!$action = $_GET[action])
	{
	$action = $_SESSION['action'];
	}
else
	{
	$_SESSION['action'] = $action;
	}
if ($action == "./volunteer_only/vol_hours.php")
	{
	$link_back = "<a href='./volunteer_only/index.php'>Volunteer Only Area</a>";
	}
if ($action == "./restricted/vol_edit.php")
	{
	$link_back = "<a href='./restricted/index.php'>Volunteer Management</a>";
	}
if ($action == "./restricted/vol_report.php")
	{
	$link_back = "<a href='./restricted/index.php'>Volunteer Management</a>";
	}
?>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
  			<td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <?php echo $link_back;?><b>&raquo;</b> Select Volunteer</td>
				</tr>
			</table>
			<div class="heading">Add/Report Volunteer Hours</div>
<?php

// Include our login information
include('db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
die ("Could not connect to the database: <br />". mysql_error());
}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
die ("Could not select the database: <br />". mysql_error());
}
//Get the volunteer names from the database
// SELECT CONCAT("FirstName",' ',"LastName") AS "Name", "VolID" FROM "VOLUNTEERS" AS "VOLUNTEERS" ORDER BY "Name" ASC
$select = ' SELECT ';
$column = ' `Name`, `VolID` ';
$from = ' FROM ';
$tables = ' `Names` ';
$where = '  ';
$query = $select.$column.$from.$tables.$where;
//Execute the query
$result = mysql_query( $query );
if (!result){
die ("Could not query the database: <br />". mysql_error());
}
//Fetch & display the results
$options="";

while ($row=mysql_fetch_assoc($result))
	{
	$volid=$row["VolID"];
	$volname = $row["Name"];
	$options.="<OPTION VALUE=\"$volid\">$volname</option>";
	}
$_SESSION['volid'] = "";
echo "<form method=\"post\" action=".$action.">"
?>
<br>
Find your name in the drop-down list and then click on the Select button.
<br>Names are listed alphabetically by first name (as entered on the volunteer application).
<br>If your name is not on the list, please <a href="volunteer_form.php">submit a volunteer application</a>.
<br>
<SELECT NAME="volunteer">
<OPTION VALUE="\"$volid\">Choose a Name</option>"
<OPTION SELECTED VALUE = "\"$volid\">
<?=$options?>
</SELECT>
<input type="submit" name="Select" value="Select">
<?php
// Write out the variables into the session and close it
$_SESSION['volid'] = $volid;
// session_write_close();
// Close the connection;
mysql_close($connection);
?>
</table>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
