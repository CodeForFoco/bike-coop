$(document).ready(function()
	{
	$("#dataTable").tablesorter();
	$("td:empty").html("&nbsp;");
	}
); 
