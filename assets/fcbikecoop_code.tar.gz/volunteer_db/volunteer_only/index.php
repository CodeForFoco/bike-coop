<?php
session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>

<div class="heading">Volunteers Only Area</div>
<h2>Event Sign-ups</h2>
<ul>
	<li><a href="http://www.signupgenius.com/go/open138">Weekday Open Shop Sign-up</a></li>
	<li><a href="http://www.signupgenius.com/go/sunday405">Sunday Open Shop Sign-up</a></li>
	<li><a href="http://www.signupgenius.com/go/open137">Weekday Worknights Sign-up</a></li>
</ul>
<h2>Database Options</h2>
<ul>
	<li><a href="http:../vol_select.php?action=./volunteer_only/vol_hours.php">Log Volunteer Hours</a><br></li>
</ul>
<h2>Tools</h2>
<ul>
	<li><a href="http:../bikes4sale/CL.php">Craigslist Bike Posting</a><br></li>
</ul>

<h2>Co-op Documents</h2>
<ul>
	<li><a href="http://fcbikecoop.org/documents/Flyer_2009_september.pdf">Current half page flyer</a></li>
	<li><a href="http://fcbikecoop.org/documents/WelcomeSheet_v07exp.pdf">Shop Welcome Sheet</a></li>
	<li><a href="http://fcbikecoop.org/documents/shop_usage.pdf">Shop Usage Forms</a></li>
	<li><a href="http://fcbikecoop.org/documents/Quick_Start_Guide.pdf">Volunteer Quick Start Guide</a> <a href="http://fcbikecoop.org/documents/Quick_Start_Guide.docx">(.docx)</a></li>
	<li><a href="http://fcbikecoop.org/documents/Youth_Agreement.pdf">Youth Volunteer Agreement</a> <a href="http://fcbikecoop.org/documents/Youth_Agreement.docx">(.docx)</a></li>
	<li><a href="http://fcbikecoop.org/documents/Donation_forms.pdf">Donation Forms</a></li>
	<li><a href="http://fcbikecoop.org/documents/FCBC-LetterheadTemplate.doc">FCBC Letterhead</a></li>
	<li><a href="http://fcbikecoop.org/documents/Found_or_abandoned_form.pdf">Found and Abandoned Green Tags</a></li>
	<li><a href="http://fcbikecoop.org/posters/logo/">Logo Images</a></li>
<!-- <li><a href="http://fcbikecoop.org/programs/earnabike/eab_volunteer_time_sheets/eab_volunteer_time_sheet-2013-02-28.pdf">Earn-a-bike Time Sheet</a><a href="http://fcbikecoop.org/programs/earnabike/eab_volunteer_time_sheets/eab_volunteer_time_sheet-2013-02-28.doc"> (.doc)</a></li> -->
	<li><a href="http://fcbikecoop.org/programs/grants/dailytrackingsheet.xls">Daily Patron Tracking Sheets</a></li>
	<li><a href="http://fcbikecoop.org/programs/bars/Bike_Alliance_Retrieving_Squad_Protocol.doc">Bike Retrieval Squad Protocol</a></li>
</ul>
<h2>Media Archive</h2>
<ul>
	<li><a href="http://fcbikecoop.org/media.php">Stories about the Co-op</a></li>
	<li><a href="http://simla.colostate.edu/~matthewb/fcbikecoop-index.html">Student media project</a></li>
</ul>
<h2>Admin Options</h2>
<ul>
	<li><a href="http://fcbikecoop.org/volunteer_db/restricted/">Admin Area</a></li>
</ul>


<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
