<?php
session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>

 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
  			<td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>Volunteer Only Area</a> <b>&raquo;</b> <a href='../vol_select.php'>Select Volunteer</a> <b>&raquo;</b>Volunteer Hours</td>
				</tr>
			</table>
			<div class="heading">Volunteer Hours</div>
<script src="../CalendarPopup.js" type="text/javascript"></script>
<script LANGUAGE="JavaScript" ID="js1">
var cal1 = new CalendarPopup();
</script>
<?php
// Include our login information
include('../db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
die ("Could not connect to the database: <br />". mysql_error());
}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
die ("Could not select the database: <br />". mysql_error());
}
?>
<form method="post" action="<?php echo $current_page;?>">
<!-- Build the fields for adding hours. -->
<p>Click on the calendar icon to select a date or enter a date (in mm/dd/yyyy format), select hours and/or minutes, select the project worked on and click on submit.</p>
Date:  
<input type="text" name="volDate" size=8 id="volDate">
<a href="#" onClick="cal1.select(document.forms[0].volDate,'anchor1','MM/dd/yyyy'); return false;" title="Click on the calendar icon to select a date." name="anchor1" id="anchor1"><input type="image" src="http://fcbikecoop.org/script/iconCalendar.gif"></a>
 Hours:   
<select id='volHrs' name='volHrs'>
<option value='00'>00</option>
<option value='01'>01</option>
<option value='02'>02</option>
<option value='03'>03</option>
<option value='04'>04</option>
<option value='05'>05</option>
<option value='06'>06</option>
<option value='07'>07</option>
<option value='08'>08</option>
<option value='09'>09</option>
<option value='10'>10</option>
<option value='11'>11</option>
<option value='12'>12</option>
<option value='13'>13</option>
<option value='14'>14</option>
<option value='15'>15</option>
<option value='16'>16</option>
<option value='17'>17</option>
<option value='18'>18</option>
<option value='19'>19</option>
<option value='20'>20</option>
<option value='21'>21</option>
<option value='22'>22</option>
<option value='23'>23</option>
</select>
:
<select id='volMin' name='volMin'>
<option value='00'>00</option>
<option value='25'>15</option>
<option value='50'>30</option>
<option value='75'>45</option>
</select>
Project:
<select id='program' name='program'>
<option value='admin'>Administrative</option>
<option value='art'>Art Committee Work</option>
<option value='BARS'>Bike Retrieval</option>
<option value='safety'>Bike Safety</option>
<option value='valet'>Bike Valet</option>
<option value='outreach'>Community Outreach</option>
<option value='EAB'>Earn-a-Bike</option>
<option value='fundraising'>Fundraising</option>
<option value='greeter'>Representative</option>
<option value='recycle'>Recycling</option>
<option value='retail'>Retail</option>
<option value='maint'>Shop Maintenance/Construction</option>
<option value='shop'>Shop Work (not wrenching)</option>
<option value='fixing'>Wrenching</option>
</select>
<br><br>
<input type="submit" name="Submit" value="submit">
<br>
</form>
<?php
if(isset($_POST['volunteer']))
	{
	$volid = $_POST['volunteer'];
	$_SESSION['volid'] = $volid;
	}
else
	{
	$volid = $_SESSION['volid'];
	}
// If form has been submitted, post the hours to the TIMECARDS table.
if(isset($_POST['Submit']))
	{
	$volHrs = $_POST['volHrs'];
	$volMin = $_POST['volMin'];
	$volHours = $volHrs.".".$volMin;
	$project = $_POST['program'];
	// make sure hours/minutes were specified
	if($volHours > 0)
		{
		$volDate = $_POST['volDate'];
		$result = mysql_query("INSERT HIGH_PRIORITY INTO `TIMECARDS`(`VolID`,`vDate`,`Elapsed`,`Program`) VALUES( '$volid', STR_TO_DATE('$volDate', '%m/%d/%Y'), '$volHours', '$project')");
		if (!$result)
			{
			die ("Could not insert the record in the database: <br />". mysql_error());
			}
		}
	}
// Get the volunteer's name
$result = mysql_query('SELECT * FROM `VOLUNTEERS` WHERE `VolID` = '.$volid);
$row = mysql_fetch_row($result);
$volname = $row[2].' '.$row[3];
// Get the total hours for this volunteer
$result = mysql_query('SELECT sum(Elapsed) AS total_hours FROM `TIMECARDS` WHERE `VolID` = '.$volid);
$row = mysql_fetch_row($result);
$tothours = $row[0];
echo "<br>Total Hours for ".$volname.":  ".$tothours."\n";
// Get the total hours in the last year for this volunteer
$result = mysql_query('SELECT sum(Elapsed) AS total_hours FROM `TIMECARDS` WHERE `VolID` = '.$volid.' AND (DATEDIFF(CURDATE(),vDate) < 365)');
$row = mysql_fetch_row($result);
$tothours = $row[0];
echo "<br>Total Hours in the last 365 days:  ".$tothours." (award qualifying period).\n";
// Show award level(s)
$next_award = "<br>At 20 hours you will be eligible for a volunteer t-shirt and shop access.";
if ($tothours >= 20) 
	{
	echo "<br>-You've earned a volunteer t-shirt and shop access for volunteering 20 hours.";
	$next_award = "<br>At 40 hours you will be eligible for access to our inventory of used bicycle components.";
	}
if ($tothours >= 40) 
	{
	echo "<br>-You qualify for access to our inventory of used bicycle components for volunteering 40 hours. Need something in particular? Just ask.";
	$next_award = "<br>At 60 hours you may qualify for a \"project bike\"";
	}
if ($tothours >= 60) 
	{
	echo "<br>-You may qualify for a \"project bike\" for volunteering 60 hours. If you need a bike, talk to a volunteer coordinator.";
	$next_award = "<br>At 80 hours you will be eligible to order from our wholesale catalogs";
	}
if ($tothours >= 80) 
	{
	echo "<br>-You are now eligible to order from our wholesale catalogs.";
	$next_award = "";
	}
echo $next_award;

// Get the timecard data for the volunteer selected
$select = ' SELECT ';
$column = ' * ';
$from = ' FROM ';
$table = ' `TIMECARDS` ';
$where = ' WHERE VolID = ';
$order = ' ORDER BY vDate DESC, "In" ASC';
$query = $select.$column.$from.$table.$where.$volid.$order;
$result = mysql_query( $query );
if (!$result)
	{
	die ("Could not query the database: <br />". mysql_error());
	}
// Set up to display the hours log
echo "<h2>Hours Log</h2>\n";
echo "			<table border=2>
				<tr>
				<th>Date</th><th>Hours</th><th>Date</th><th>Hours</th><th>Date</th><th>Hours</th><th>Date</th><th>Hours</th>
				</tr>";
//Fetch & display the results
echo "				<tr>";
$i = 1;
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$vdate = date("m/d/Y",strtotime($result_row["vDate"]));
	$vhours = $result_row["Elapsed"];
	echo "<td>$vdate</td><td align='right'>$vhours</td>";
	if ($i > "3")
		{
		echo "</tr>";
		echo "\n";
		echo "				<tr>";
		$i = 0;
		}
		$i=$i+1;
	}
echo "</tr>";

// Close the connection
mysql_close($connection);
?>
			</table>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
