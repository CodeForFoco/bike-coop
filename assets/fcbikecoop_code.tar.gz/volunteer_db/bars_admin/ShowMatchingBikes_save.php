<?php
session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
// get the variable that will let us get back
$origin = $_SESSION['origin'];
if ($origin == "bars")
	{
	$link_back = "<a href='./bars/index.php'>B.A.R.S.</a>";
	}
if ($origin == "bars_admin")
	{
	$link_back = "<a href='./index.php'>B.A.R.S. Admin</a>";
	}
$list = $_SESSION['list'];
if ($list == "SendPS")
	{
	$list_link_back = "<a href='./bars_admin/SendPS.php'>Bikes to PS</a>";
	}
if ($list == "MatchStolen")
	{
	$list_link_back = "<a href='./MatchStolenBikes.php'>Stolen Bike Match</a>";
	}
else {$list_link_back = "<a href='./ListBikes.php'>List of Recovered Bikes</a>";}
?>
<?php

//Connect to the Bike Co-op database
// Include our login information
include('../db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
	die ("Could not connect to the database: <br />". mysql_error());
	}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
	die ("Could not select the database: <br />". mysql_error());
	}
// get the ID & case number of the bike to be checked
	$bike = $_GET['BikeID'];
	$pcase = $_GET['Case_No'];
//Assign the query
	$result = mysql_query('SELECT * FROM `RECOVEREDBIKES` WHERE `BikeID` = '.$bike);
	if (!result){
	die ("Could not query the database: <br />". mysql_error());
	}
//Fetch & display the results
	while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$bin = $result_row["Bin"];
	$rdate = $result_row["RecoveredDate"];
	$vrdate = date("m/d/Y",strtotime($rdate));
	$serial = $result_row["Serial"];
	$brand = $result_row["Brand"];
	$model = $result_row["Model"];
	$color = $result_row["Color"];
	$description = $result_row["Description"];
	$sentPS = $result_row["SentPS"];
	$vsentPS = date("m/d/Y",strtotime($sentPS));
	$toPurchasing = $result_row["ToPurchasing"];
	$vtoPurchasing = date("m/d/Y",strtotime($toPurchasing));
	$cleared = $result_row["DateCleared"];
	$vcleared = date("m/d/Y",strtotime($cleared));
	$disposition = $result_row["Disposition"];
	$class = $result_row["Class"];
	$dispDate = $result_row["DispDate"];
	$vdispDate = date("m/d/Y",strtotime($dispDate));
	}

include_once('/var/www/fcbikecoop.org/root/header.php');
?>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <?php echo $link_back;?> <b>&raquo;</b> <?php echo $list_link_back;?> <b>&raquo;</b> Edit Recovered Bike Information</td>
				</tr>
			</table>

			<div class="heading">Recovered Bike Information</div>

<table>
<tr>
	<td>Bin:</td><td><?php echo $bin ?></td> 
	<td nowrap>Class:</td><td><?php echo $class ?></td>
</tr>
<tr>
Date Recovered: <?php echo $vrdate ?><br>
Brand: <?php echo $brand ?><br>
Model: <?php echo $model ?><br>
Color: <?php echo $color ?><br>
Serial Number: <?php echo $serial ?><br>
Description: <?php echo $description ?><br>
<br>
</tr>
<tr>
	<td>Sent to P.S.:</td><td><?php echo $vsentPS ?></td>
	<td>Sent to Purchasing:</td><td><?php echo $vtoPurchasing ?></td>
</tr>
<tr>
	<td>Cleared:</td><td><?php echo $vcleared ?></td>
	<td>Disposition:</td><td><?php echo $disposition ?></td>
	<td>Date:</td><td><?php echo $vdispDate ?></td>
</tr>
</table>
<?php
//Assign the query
	$fcps = mysql_query("SELECT * FROM `FCPS` WHERE `Case_No` = '".$pcase."'");
	if (!fcps){
	die ("Could not query the database: <br />". mysql_error());
	}
//Fetch & display the results
	while ($fcps_row = mysql_fetch_array($fcps, MYSQL_ASSOC))
	{
	$pcase = $fcps_row["Case_No"];
	$pdate = $fcps_row["Date"];
	$vpdate = date("m/d/Y",strtotime($pdate));
	$pserial = $fcps_row["Serial_No"];
	$pbrand = $fcps_row["Brand"];
	$pmodel = $fcps_row["Model"];
	$pcolor = $fcps_row["Color"];
	$pdescription = $fcps_row["Description"];
	}
?>
			<div class="heading">Stolen Bike Information</div>
<table>
Date Reported: <?php echo $vpdate ?><br>
Brand: <?php echo $pbrand ?><br>
Model: <?php echo $pmodel ?><br>
Color: <?php echo $pcolor ?><br>
Serial Number: <?php echo $pserial ?><br>
Description: <?php echo $pdescription ?><br>
<br>
Case: <?php echo $pcase ?><br>
</table>
<?php
// Close the connection
mysql_close($connection);
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
