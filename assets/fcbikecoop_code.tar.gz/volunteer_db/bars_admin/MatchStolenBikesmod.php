<?php
// This script presents the page for the list of possible matches for stolen bikes
session_start();
$_SESSION['list']="MatchStolen";
$HTTP_SESSION_VARS ["list"] = "MatchStolen";

$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<script src="../sorttable.js"></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>B.A.R.S. Admin</a> <b>&raquo;</b>Stolen Bike Match</td>
				</tr>
			</table>

			<div class="heading">Stolen Bike Match</div>

<?php
//Connect to the Bike Co-op database
// Include our login information
include('../db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
die ("Could not connect to the database: <br />". mysql_error());
}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
die ("Could not select the database: <br />". mysql_error());
}

?>

Note:  list can be sorted by clicking on the column headers (except for Description).
<font size=1>
<table border=2 class="sortable">
	<thead>
		<tr>
			<th>Case</th><th>Date</th><th>Log</th><th>Recovered</th><th class="sorttable_alpha">Serial #</th><th class="sorttable_alpha">Brand</th><th class="sorttable_alpha">Model</th><th>Color</th><th class="sorttable_nosort">Description</th><th>....</th>
		</tr>
	</thead
	<tbody overflow:auto; overflow-x: hidden;'>
<?php
// Get the list
$result = mysql_query('SELECT * FROM `FCPS` ORDER BY `Date` DESC');
//Fetch & display the results
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$case = $result_row["Case_No"];
	$sdate = $result_row["Date"];
	$serial = $result_row["Serial_No"];
	$brand = $result_row["Brand"];
	$model = $result_row["Model"];
	$color = $result_row["Color"];
	$col = substr($color,0,3);
	$description = $result_row["Description"];
// shorten the description for display purposes
	$descr = substr($description,0,10);
	//Check to see if there's a possible match in RECOVEREDBIKES
	if ($serial<>"" && rtrim($serial)>" ")
		{
		$sql = "SELECT * FROM `RECOVEREDBIKES` WHERE `Serial`='".rtrim($serial)."' AND `Class` <> 'returned'";
		$query = mysql_query( $sql ) or die("Couldn’t execute query.".mysql_error());
		while ($query_row = mysql_fetch_array($query, MYSQL_ASSOC))
			{
			$bike = $query_row['BikeID'];
			$log = $query_row['Log'];
			$rdate = $query_row['RecoveredDate'];
			// Instead of using a Co-op "case number", which is confusing because we also have a FCPS case number, we 
			// are switching to using the automatically generated record ID (Bike_ID) as the identity for a recovered bike.
			// So, if Co-op case number is blank, use record ID.  
			if (empty($log)) $log = $bike;
			echo "<tr><td><a href=\"./ShowMatchingBikes.php?BikeID=".$log."&Case_No=".$case."\">$case</td><td>$sdate</td><td><a href=\"./ShowMatchingBikes.php?BikeID=".$bike."&Case_No=".$case."\">$log</td><td>$rdate</td><td>$serial</td><td>$brand</td><td>$model</td><td>$color</td><td>$description</td>";
			echo "</tr>";
			echo "\n";
			}
		}
	else if ($brand<>"" && $color<>"" && $model<>"")
		{
		$sql = "SELECT * FROM `RECOVEREDBIKES` WHERE `Brand`='".$brand."' AND `Color` LIKE '".$col."' AND `Model`=\'".$model."\'";
		$sql = sprintf("SELECT * FROM RECOVEREDBIKES WHERE RecoveredDate > '%s' AND Brand = '%s' AND Color LIKE '%s' AND Model = '%s'",
						mysql_real_escape_string($sdate),
						mysql_real_escape_string($brand),
						mysql_real_escape_string($col),
						mysql_real_escape_string($model));
		$query = mysql_query( $sql ) or die("Couldn’t execute query.".mysql_error());
		while ($query_row = mysql_fetch_array($query, MYSQL_ASSOC))
			{
			$bike = $query_row['BikeID'];
			$log = $query_row['Log'];
			$rdate = $query_row['RecoveredDate'];
			// Instead of using a Co-op "case number", which is confusing because we also have a FCPS case number, we 
			// are switching to using the automatically generated record ID (Bike_ID) as the identity for a recovered bike.
			// So, if Co-op case number is blank, use record ID.  
			if (empty($log)) $log = $bike;
			echo "<tr><td><a href=\"./ShowMatchingBikes.php?BikeID=".$bike."&Case_No=".$case."\">$case</td><td>$sdate</td><td><a href=\"./ShowMatchingBikes.php?BikeID=".$bike."&Case_No=".$case."\">$log</td><td>$rdate</td><td>$serial</td><td>$brand</td><td>$model</td><td>$color</td><td>$description</td>";
			echo "</tr>";
			echo "\n";
			}
		}
	}
?>
	</tbody>
</table>
<?php
// Close the connection to the database
mysql_close($connection);

include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
