<?php
// This script presents the page for checking "postable" bikes
session_start();
$_SESSION['list']="CheckPostable";
$HTTP_SESSION_VARS ["list"] = "CheckPostable";

$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>

<script src="../restricted/sorttable.js"></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>B.A.R.S. Admin</a> <b>&raquo;</b>Check for Postable Bikes</td>
				</tr>
			</table>

			<div class="heading">Postable Bikes</div>
<?php
//Connect to the Bike Co-op database
// Include our login information
include('../db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
die ("Could not connect to the database: <br />". mysql_error());
}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
die ("Could not select the database: <br />". mysql_error());
}

//Check to see if any recovered bikes are "postable" (held for 30+ days and not yet posted)
$result = mysql_query('SELECT * FROM `RECOVEREDBIKES` WHERE `SentPS`>0000-00-00 AND (DATEDIFF(CURDATE(),`SentPS`) > 30) AND `ToPurchasing`=0000-00-00 AND `Log` = "" AND `Class`!="returned" ORDER BY `RecoveredDate` DESC');
?>

Note:  list can be sorted by clicking on the column headers.
<font size=1>
			<table border=2 class="sortable">
				<tr>
				<th>Description</th><th>Serial #</th><th>Log</th><th>Bin</th>
				</tr>
<?php
//Fetch & display the results
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$bike = $result_row["BikeID"];
	$bin = $result_row["Bin"];
	$log = $result_row["Log"];
// Instead of using a Co-op "case number", which is confusing because we also have a FCPS case number, we 
// are switching to using the automatically generated record ID (Bike_ID) as the identity for a recovered bike.
// So, if Co-op case number is blank, use record ID.  
	if (empty($log)) $log = $bike;
	$rdate = $result_row["RecoveredDate"];
	$serial = $result_row["Serial"];
	$brand = $result_row["Brand"];
	$model = $result_row["Model"];
	$color = $result_row["Color"];
	$description = $result_row["Description"];
	$contact = $result_row["Contact"];
	$location = $result_row["Location"];
	$phone = $result_row["Phone"];
	$volunteer = $result_row["Volunteer"];
// shorten the description for display purposes
	$descr = substr($description,0,15)." ...";
	echo "<td>$brand $model $color $description</td><td>$serial</td><td><a href=\"../EditBike.php?BikeID=".$bike."\">$log</td><td>$bin</td>";
	echo "</tr>";
	echo "\n";
	}
?>
			</table>
<?php
// Close the connection to the database
mysql_close($connection);

include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
