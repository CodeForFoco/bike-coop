<?php
// Turn off all error reporting
error_reporting(0);
//Connect to the Bike Co-op database
require_once($_SERVER['DOCUMENT_ROOT'].'db_connect.php');
$db = db_connect ();
//Get the BikeID from ajax
$bike = $_GET['bikeID'];
try
	{
	$query = $db->prepare("SELECT * FROM RECOVEREDBIKES WHERE BikeID LIKE ?");
	$query->bindValue(1, "%$bike%", PDO::PARAM_STR);
	$query->execute();
	}
catch (PDOException $e)
	{
	print ("The statement failed.\n");
	echo "boo-boo";
	echo "getMessage(): " . $e->getMessage () . "\n";
	}

//Fetch & display the results
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$type = $result_row["Type"];
	$brand = $result_row["Brand"];
	$model = $result_row["Model"];
	$color = $result_row["Color"];
	}
echo json_encode(array("brand"=>$brand,"model"=>$model,'color'=>$color));
?>

