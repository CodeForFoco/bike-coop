<?php
/**
	*	MatchStolenBikes.php - part of the Fort Collins Bike Co-op system for tracking recovered bikes
	*
	* This script presents the page for the list of possible matches for stolen bikes.
	*/

session_start();
$_SESSION['list']="MatchStolen";
$HTTP_SESSION_VARS ["list"] = "MatchStolen";

$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once($_SERVER['DOCUMENT_ROOT'].'header.php');
?>
<script type='text/javascript' src='/js/jquery.min.js'></script>
<script type='text/javascript' src='/js/jquery.tablesorter.min.js'></script>
<script type='text/javascript' src='/js/Tables.js'></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>B.A.R.S. Admin</a> <b>&raquo;</b>Stolen Bike Match</td>				</tr>
			</table>

			<div class="heading">Stolen Bike Match</div>

Note:  list can be sorted by clicking on the column headers (except for Description).
<font size=1>
<table border=2 id="dataTable" class="tablesorter">
	<thead>
		<tr>
			<th>Case</th><th>Date</th><th class="sorttable_alpha">Serial #</th><th>Log</th><th>Recovered</th><th class="sorttable_alpha">Serial #</th><th class="sorttable_alpha">Brand</th><th class="sorttable_alpha">Model</th><th>Color</th><th class="sorttable_nosort">Description</th><th>....</th>
		</tr>
	</thead
	<tbody overflow:auto; overflow-x: hidden;'>
<?php
//Connect to the Bike Co-op database
require_once "../../db_connect.php";
$db = db_connect ();

// Get the list of stolen bikes
try
	{
	$query = $db->prepare("SELECT * FROM FCPS ORDER BY Date DESC");
	$query->execute();
	}
catch (PDOException $e)
	{
	print ("The statement failed.\n");
	echo "boo-boo";
	echo "getMessage(): " . $e->getMessage () . "\n";
	}

// Fetch each record and then check to see if there is a matching recovered bike (or bikes).
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$case = $result_row["Case_No"];
	$sdate = $result_row["Date"];
	$serial = strtoupper($result_row["Serial_No"]);
	$brand = $result_row["Brand"];
	$model = $result_row["Model"];
	$color = $result_row["Color"];
	$col = substr($color,0,3);
	$description = $result_row["Description"];
// shorten the description for display purposes
	$descr = substr($description,0,10);
	//Check to see if there's a possible match in RECOVEREDBIKES
	// First check to see if there is a serial number
	if ($serial<>"" && rtrim($serial)>" ")
		{
		$serial = upper($serial);
		// If there is a serial number, see if there is a matching recovered bike.
		try
			{
			$query = $db->prepare("SELECT * FROM RECOVEREDBIKES WHERE Serial= ? AND Status <> 'returned'");
			$query->bindValue(1, "%$serial%", PDO::PARAM_STR);
			$query->execute();
			}
		catch (PDOException $e)
			{
			print ("The statement failed.\n");
			echo "boo-boo";
			echo "getMessage(): " . $e->getMessage () . "\n";
			}
		while($result_row = $query->fetch(PDO::FETCH_ASSOC))
			{
			$bike = $query_row['BikeID'];
			$log = $query_row['Log'];
			$rdate = $query_row['RecoveredDate'];
			// Instead of using a Co-op "case number", which is confusing because we also have a FCPS case number, we 
			// are switching to using the automatically generated record ID (Bike_ID) as the identity for a recovered bike.
			// So, if Co-op case number is blank, use record ID.  
			if (empty($log)) $log = $bike;
			echo "<tr><td><a href=\"./ShowMatchingBikes.php?BikeID=".$log."&Case_No=".$case."\">$case</td><td>$sdate</td><td>$serial</td><td><a href=\"./ShowMatchingBikes.php?BikeID=".$bike."&Case_No=".$case."\">$log</td><td>$rdate</td><td>$sn</td><td>$brand</td><td>$model</td><td>$color</td><td>$description</td>";
			echo "</tr>";
			echo "\n";
			}
		}
	// If no match on serial number, see if there is a match on brand and model.
	else if ($brand<>"" && $color<>"" && $model<>"")
		{
		try
		{
		$query = $db->prepare("SELECT * FROM RECOVEREDBIKES WHERE RecoveredDate > ? AND Brand = ? AND Model = ? AND Color = ? AND Status <> 'returned'");
		$query->bindValue(1, "%$sdate%", PDO::PARAM_STR);
		$query->bindValue(1, "%$brand%", PDO::PARAM_STR);
		$query->bindValue(1, "%$model%", PDO::PARAM_STR);	
		$query->bindValue(1, "%$color%", PDO::PARAM_STR);	
		$query->execute();
		}
		catch (PDOException $e)
			{
			print ("The statement failed.\n");
			echo "boo-boo";
			echo "getMessage(): " . $e->getMessage () . "\n";
			}
		while($result_row = $query->fetch(PDO::FETCH_ASSOC))
			{
			$bike = $query_row['BikeID'];
			$log = $query_row['Log'];
			$rdate = $query_row['RecoveredDate'];
			$sn = $query_row['Serial'];
			// Instead of using a Co-op "case number", which is confusing because we also have a FCPS case number, we 
			// are switching to using the automatically generated record ID (Bike_ID) as the identity for a recovered bike.
			// So, if Co-op case number is blank, use record ID.  
			if (empty($log)) $log = $bike;
			// Change the date format for siplay purposes.
			$vrdate = date("m/d/Y",strtotime($rdate));
			$vsdate = date("m/d/Y",strtotime($sdate));
			echo "<tr><td><a href=\"./ShowMatchingBikes.php?BikeID=".$bike."&Case_No=".$case."\">$case</td><td>$vsdate</td><td>$serial</td><td><a href=\"./ShowMatchingBikes.php?BikeID=".$bike."&Case_No=".$case."\">$log</td><td>$vrdate</td><td>$sn</td><td>$brand</td><td>$model</td><td>$color</td><td>$description</td>";
			echo "</tr>";
			echo "\n";
			}
		}
	}
?>
	</tbody>
</table>
<?php
// Close the connection to the database
mysql_close($connection);

include_once($_SERVER['DOCUMENT_ROOT'].'footer.php');
?>
