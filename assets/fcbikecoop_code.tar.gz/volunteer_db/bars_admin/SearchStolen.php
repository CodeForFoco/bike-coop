<?php
session_start();
// get the variables that will let us get back
$origin = $_SESSION['origin'];
if ($origin == "bars")
	{
	$link_back = "<a href='./index.php'>B.A.R.S.</a>";
	}
if ($origin == "bars_admin")
	{
	$link_back = "<a href='../bars_admin/index.php'>B.A.R.S. Admin</a>";
	}
$_SESSION['list']="SearchBike";
$HTTP_SESSION_VARS ["list"] = "SearchBike";

$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<script src="../sorttable.js"></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <?php echo $link_back;?> <b>&raquo;</b>Search Stolen Bikes</td>
				</tr>
			</table>

			<div class="heading">Search Stolen</div>
<?php
//Connect to the Bike Co-op database
// Include our login information
include('../db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
	die ("Could not connect to the database: <br />". mysql_error());
	}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
	die ("Could not select the database: <br />". mysql_error());
	}
?>
<form method="post" action="<?php echo $PHP_SELF;?>">
<!-- Build the fields for a recovered bike. -->
Type your search string(s) and click on submit.
<table>
	<tr>
		<td>Brand:</td><td><input type="text" name = "brand" size=15 value="<?php echo $_POST['brand'] ?>"></td>
		<td>Model:</td><td><input type="text" name = "model" size=15 value="<?php echo $_POST['model'] ?>"></td>
		<td>Color:</td><td><input type="text" name = "color" size=10 value="<?php echo $_POST['color'] ?>"></td>
	</tr>
	<tr>
		<td nowrap>Serial Number:</td><td colspan=2><input type="text" name = "serial" size=20 value="<?php echo $_POST['serial'] ?>"></td>
	</tr>
	<tr>
		<td>Description:</td><td colspan=3><input type="text" name = "description" size=40 value="<?php echo $_POST['description'] ?>"></td>
	</tr>
</table>
<input type="submit" name="Submit" value="submit">
</form> 

<h2>Possible Matching Bikes</h2>
<p>Note:  list can be sorted by clicking on the column headers.
<font size=1>
<table border=2 class="sortable">
	<thead>
		<tr>
			<th>Case</th><th>Agency</th><th>Date</th><th class="sorttable_alpha">Serial #</th><th>Brand</th><th>Model</th><th>Color</th><th class="sorttable_nosort">Description</th>
		</tr>
	</thead>
	<tbody style='height:300px; overflow:auto; overflow-x: hidden;'>
<?php
// If form has been submitted, search the RECOVEREDBIKES table.

if(isset($_POST['Submit']))
	{
	$serial=$_POST['serial'];
	$arg1="\"%".str_replace(",",'%',$serial)."%\"";
	$brand=$_POST['brand'];
	$arg2="\"%".$brand."%\"";
	$model=$_POST['model'];
	$arg3="\"%".$model."%\"";
	$color=$_POST['color'];
	$arg4="\"%".$color."%\"";
	$description=$_POST['description'];
	$arg5="\"%".$description."%\"";
//First check to see if a possible match
	if (!$result = mysql_query('SELECT * FROM `FCPS` WHERE `Serial_No` LIKE '.$arg1.' AND `Brand` Like '.$arg2.' AND `Model` Like '.$arg3.' AND `Color` Like '.$arg4.' AND `Description` Like '.$arg5))
		{
		Print "no match found";
		}
//Fetch & display the results
	while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
		{
		$agency = $result_row["Agency"];
		$case = $result_row["Case_No"];
		$rdate = $result_row["Date"];
		$serial = $result_row["Serial_No"];
		$brand = $result_row["Brand"];
		$model = $result_row["Model"];
		$color = $result_row["Color"];
		$description = $result_row["Description"];
		$vrdate = date("m/d/Y",strtotime($rdate));
		echo "<tr onclick='SelectRow(1)' id='.$case.'><td>$case</td><td>$agency</td><td>$vrdate</td><td>$serial</td><td>$brand</td><td>$model</td><td>$color</td><td>$descr</td>";		echo "</tr>";
		echo "\n";
		}

	// Close the connection
	mysql_close($connection);
	}
?>
	</tbody>
</table>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
