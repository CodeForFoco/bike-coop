<?php

/**
	*	LogFCPS.php - part of the Fort Collins Bike Co-op system for tracking recovered bikes
	*
	* This script ...
	*/

session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
	if (isset($_GET['agency'])) {
		$agency = $_GET['agency'];
		$case = $_GET['case'];
		$date = $_GET['date'];
		$serial = $_GET['serial'];
		$brand = $_GET['brand'];
		$model = $_GET['model'];
		$color = $_GET['color'];
		$descr = $_GET['descr'];
		}
	else $php_var = "<br />js_var is not set!";

//Connect to the Bike Co-op database
require_once "../../db_connect.php";
$db = db_connect ();

// Get the ID of the last bike entered and add 1 to it for the next Log number
	$query = $db->prepare("SELECT MAX(ID) AS MAXIMUM FROM FCPS");
	$query->execute();
	$maxid = $query->fetchColumn();
	$log = $maxid + 1;
	$insert = $db->prepare("INSERT INTO FCPS (Agency,Case_No,Date,Serial_No,Brand,Model,Color,Description) VALUES  (:agency,:case,:date,:serial,:brand,:model,:color,:description)");
	$insert->bindValue(':agency', $agency, PDO::PARAM_STR);
	$insert->bindValue(':case', $case, PDO::PARAM_STR);
	$insert->bindValue(':date', date('Y-m-d', strtotime($date)), PDO::PARAM_STR);
	$insert->bindValue(':serial', $serial, PDO::PARAM_STR);
	$insert->bindValue(':brand', $brand, PDO::PARAM_STR);
	$insert->bindValue(':model', $model, PDO::PARAM_STR);
	$insert->bindValue(':color', $color, PDO::PARAM_STR);
	$insert->bindValue(':description', $descr, PDO::PARAM_STR);

	try
		{
		// run the query
		$insert->execute();
		}
	catch (PDOException $e)
		{
		echo "The statement failed.\n";
		echo "getCode: ". $e->getCode () . "\n";
		echo "getMessage: ". $e->getMessage () . "\n";
		unset($_POST['submit']); // reset since the insert failed
		exit();
		}
exit();

?>

