/*************************************************************************
* This file (mBikeDisposition.js) contains Javascript code and is included in the
* mBikeDisposition.html page.
* It contains routines to make Ajax calls to
* ajax-getCleared.php to populate the bike selection dialog, and to
* ajax-DisposeBike.php to update a record in the RECOVEREDBIKES table and
* display the disposed bike info in an alert box to the user.
*/
$(document).ready(function() {
	// Get the list of bikes
	getBikes();
	// Set up the form submit
	$(document).on('submit', '#dispose', function()
	{
	// Call ajax-disposeBike.php to create the database record and display the 
	// acknowledgement alert. 
	//Make AJAX request
	var bikeID = $("#bikeID").val();
	var disposition = $('#disposition').val();
	if (disposition == "other") {
		var disposition = prompt("Please enter the disposition (e.g., Donation to ...)","");
		} 
	var data = "bikeID="+bikeID+"&disposition="+encodeURIComponent(disposition);
	var test = confirm("Log bike #"+bikeID+" a "+$('#color').val()+" "+$('#brand').val()+" "+$('#model').val()+" as "+disposition+"?");
	if (test == true) {
		$.ajax({url: './ajax-disposeBike.php?' + data,
			type: "POST",
			success: function(output) {
			alert(output);
//			},
//			error: function (xhr, ajaxOptions, thrownError) {
//			alert("in disposeBike" + xhr.status + " "+ thrownError);
			}
		}); //END ajax
	}
	// clear the form fields
	$('#bikeID').val('');
	$('#brand').val('');
	$('#model').val('');
	$('#color').val('');
	$('#disposition').val('');
	// reload the form
	location.reload();
	});
}); //END document.ready

// Get the list of bikes
function getBikes(){
	var target_html = '<option value="" name="bikeID">Please select a bike ...</option>'; //Initial prompt for target select
	$('#bikeID').html(target_html); //Give the target select the prompt option
	//Display 'loading' status in the target select list
	//$('#bikeID').html('<option value="">Loading...</option>');
	//Make AJAX request to get list of cleared bikes
	$.ajax({url: './ajax-getCleared.php',
		success: function(output) {
			$('#bikeID').html(output);
			},
		error: function (xhr, ajaxOptions, thrownError) {
			alert("in getCleared" + xhr.status + " "+ thrownError);
			}
	}); //END $.ajax
}; //END getBikes
// On change of the dropdown do the ajax
function getBikeInfo() {
    var ID = document.getElementById("bikeID").value;
	$.ajax({
		url: './ajax-getBike.php?bikeID=' + ID,
		type: 'post',
		success: function(response) {
			// Parse the jSON that is returned
			// Using conditions here would probably apply
			// incase nothing is returned
			var Vals    =   JSON.parse(response);
			// These are the inputs that will populate
			$("input[name='brand']").val(Vals.brand);
			$("input[name='model']").val(Vals.model);
			$("input[name='color']").val(Vals.color);
		}, //END success fn
		error: function (xhr, ajaxOptions, thrownError) {
		alert("in getBike" + xhr.status + " "+ thrownError);
		}

	}); //END $.ajax
}; //END getBikeInfo


