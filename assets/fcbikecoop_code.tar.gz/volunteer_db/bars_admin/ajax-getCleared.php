<?php
// Turn off all error reporting
error_reporting(0);
//Connect to the Bike Co-op database
require_once($_SERVER['DOCUMENT_ROOT'].'db_connect.php');
$db = db_connect ();
//Get the list of BARS volunteers
try
	{
	$query = $db->prepare("SELECT * FROM RECOVEREDBIKES WHERE DateCleared != 0000-00-00 AND DispDate = 0000-00-00 ORDER BY BikeID");
	$query->execute();
	}
catch (PDOException $e)
	{
	print ("The statement failed.\n");
	echo "boo-boo";
	echo "getMessage(): " . $e->getMessage () . "\n";
	}
//Fetch the log numbers for use in the bike selection list
$options="";
echo "<option value=\"\">Please select a bike ...</option>";
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$log = $result_row["BikeID"];
	$type = $result_row["Type"];
	echo "<option  class='".$type."' value='".$log."'>".$log."</option>\n";
	}
?>
