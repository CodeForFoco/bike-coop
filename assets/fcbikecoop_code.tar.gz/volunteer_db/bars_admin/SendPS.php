<?php
/**
	*	SendPS.php - part of the Fort Collins Bike Co-op system for tracking recovered bikes
	*
	* This script presents the page for checking bikes not yet sent to FCPS.
	*/
session_start();
$_SESSION['list']="SendPS";
$HTTP_SESSION_VARS ["list"] = "SendPS";

$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>

<script src="../sorttable.js"></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>B.A.R.S. Admin</a> <b>&raquo;</b>Bikes to PS</td>
				</tr>
			</table>

			<div class="heading">List of Bikes that can be Sent to Police Services</div>
<?php
//Connect to the Bike Co-op database
require_once "../../db_connect.php";
$db = db_connect ();
try
	{
	$query = $db->prepare("SELECT * FROM RECOVEREDBIKES WHERE (Type = ? OR Type = ?) AND (SentPS = 0000-00-00 AND ToPurchasing=0000-00-00 AND DateCleared = 0000-00-00 AND DispDate = 0000-00-00) ORDER BY BikeID");
	$query->bindValue(1, "recovery", PDO::PARAM_STR);
	$query->bindValue(2, "donated", PDO::PARAM_STR);
	$query->execute();
	}
catch (PDOException $e)
	{
	print ("The statement failed.\n");
	echo "boo-boo";
	echo "getMessage(): " . $e->getMessage () . "\n";
	}

?>

Note:  list can be sorted by clicking on the column headers.
<font size=1>
			<table border=2 class="sortable">
				<tr>
				<th>Log</th><th>Type</th><th>Recovered</th><th>Serial #</th><th>Brand</th><th>Model</th><th>Color</th><th>Description</th>
				</tr>
<?php
//Fetch & display the results
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$bike = $result_row["BikeID"];
	$log = $result_row["Log"];
// Instead of using a Co-op "case number", which is confusing because we also have a FCPS case number, we 
// are switching to using the automatically generated record ID (Bike_ID) as the identity for a recovered bike.
// So, if Co-op case number is blank, use record ID.  
	if (empty($log)) $log = $bike;
	$type = $result_row["Type"];
	// Shorten "type" to a single letter
	if ($type == "donated") {$type = "D";}
	elseif ($type == "FCPS") {$type = "P";}
	else {$type = "R";}
	$rdate = $result_row["RecoveredDate"];
	// Change the date format for siplay purposes.
	$vdate = date("m/d/Y",strtotime($rdate));
	$serial = $result_row["Serial"];
	$brand = $result_row["Brand"];
	$model = $result_row["Model"];
	$color = $result_row["Color"];
	$description = $result_row["Description"];
	echo "<td><a href=\"../bars/EditBike.php?BikeID=".$bike."\">$log</td><td style='text-align:center'>$type</td><td>$vdate</td><td>$serial</td><td>$brand</td><td>$model</td><td>$color</td><td>$description</td>";
	echo "</tr>";
	echo "\n";
	}
?>
			</table>
<?php
// Close the connection to the database
$db = null;

include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
