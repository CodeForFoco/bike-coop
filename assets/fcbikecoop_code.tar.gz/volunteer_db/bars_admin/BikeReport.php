<?php
/**
	*	BikeReport.php - part of the Fort Collins Bike Co-op system for tracking recovered bikes
	*
	* This script presents the page for allowing the user to enter a date range for generating a
	* list of recovered bike activity.
	*/

session_start();
/**
	*	The script assumes that a session variable has been set by the calling script.
	* That variable is used to build the "breadcrumb" list that helps the user navigate back.
	*/
// get the variables that will let us get back
$origin = $_SESSION['origin'];
if ($origin == "bars")
	{
	$link_back = "<a href='./index.php'>B.A.R.S.</a>";
	}
if ($origin == "bars_admin")
	{
	$link_back = "<a href='../bars_admin/index.php'>B.A.R.S. Admin</a>";
	}
$_SESSION['list']="BikeReport";
$HTTP_SESSION_VARS ["list"] = "BikeReport";

$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once($_SERVER['DOCUMENT_ROOT'].'header.php');
?>
<!-- We will be using JQuery functions and a JavaScript for processing the form. -->
<link rel="stylesheet" href="/css/jquery-ui.min.css" />
<script src="/js/jquery.min.js" ></script>
<script src="/js/jquery-ui.min.js"></script>
<style type="text/css">
.ui-widget { font-family: Lucida Grande, Lucida Sans, Arial, sans-serif; font-size: 0.6em; }
</style>
<script>
$.datepicker.setDefaults({
	autoSize: true,
	showOn: "both",
	buttonImageOnly: true,
	buttonImage: "../iconCalendar.gif",
	buttonText: "Calendar"
});
   $(function() {
     $("#date1").datepicker({dateFormat: 'yy-mm-dd'});
     $("#date2").datepicker({dateFormat: 'yy-mm-dd'});
   });
 </script>
<!-- "breadcrumbs" -->
<table cellpadding='5'>
	<tr>
		<td style='width:0%; white-space:nowrap'>
		<td><b>&raquo;</b><?php echo $link_back;?> <b>&raquo;</b>Recovered Bike Report</td>
	</tr>
</table>
<div class="heading">Recovered Bike Report</div>
<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
<!-- Build the fields for a recovered bike. -->
Select a start and end date from the dropdown calendars and click on Submit.
<p>Start Date:<input type="text" name="StartDate" id="date1">
	End Date:<input type="text" name="EndDate" id="date2">
<p><input type="submit" name="Submit" value="submit">
</form> 
<?php
// Connect to the Bike Co-op database.
require_once "../../db_connect.php";
$db = db_connect ();
// If form has been submitted, search the RECOVEREDBIKES table.
if(isset($_POST['Submit']))
	{
	$startdate=$_POST['StartDate'];
//	$startdate = date("Y-m-d", $start);
	$enddate=$_POST['EndDate'];
//	$enddate = date("Y-m-d", $end);
	// Close PHP so we can output the header info.
	?>
	<p>
	<table border=2 id="dataTable" class="tablesorter">
		<thead>
			<tr>
				<th style='width:50px'>Log</th><th>Type</th><th>Recovered</th><th>Serial #</th><th>Checked</th><th>Manifest</th><th>Cleared</th><th>Disposed</th><th>Status</th>
			</tr>
		</thead>
		<tbody>
	<?php
	// Re-open PHP so we can output the results.
	//Assign the query
	$query = $db->prepare("SELECT BikeID, Type, DATE_FORMAT(RecoveredDate, '%m/%d/%y') as Recovered, Serial,
	DATE_FORMAT(SentPS, '%m/%d/%y') as Checked, DATE_FORMAT(ToPurchasing, '%m/%d/%y') as Manifest,
	DATE_FORMAT(DateCleared, '%m/%d/%y') as Cleared, DATE_FORMAT(DispDate, '%m/%d/%y') as Disposed,
	Disposition FROM RECOVEREDBIKES WHERE (RecoveredDate >= :startdate && RecoveredDate <= :enddate) 
	|| (SentPS >= :startdate && SentPS <= :enddate) 
	|| (ToPurchasing >= :startdate && ToPurchasing <= :enddate) 
	|| (DateCleared >= :startdate && DateCleared <= :enddate) 
	|| (DispDate >= :startdate && DispDate <= :enddate && Status = 'returned')order by BikeID");
	$query->bindValue(':startdate', $startdate, PDO::PARAM_STR);
	$query->bindValue(':enddate', $enddate, PDO::PARAM_STR);
	$query->execute();
	// Fetch & display the results of the query.
	while($result_row = $query->fetch(PDO::FETCH_ASSOC))
		{
		$bike = $result_row["BikeID"];
		$type = $result_row["Type"];
		// Shorten "type" to a single letter
		if ($type == "donation") {$type = "D";}
		elseif ($type == "FCPS") {$type = "P";}
		else {$type = "R";}
		$rdate = $result_row["Recovered"];
		$serial = strtoupper($result_row["Serial"]);
		$checked = $result_row["Checked"];
		if ($checked == '00/00/00') $checked = '';
		$manifest = $result_row["Manifest"];
		if ($manifest == '00/00/00') $manifest = '';
		$cleared = $result_row["Cleared"];
		if ($cleared == '00/00/00') $cleared = '';
		$disposed = $result_row["Disposed"];
		if ($disposed == '00/00/00') $disposed = '';
		$disposition = $result_row["Disposition"];
		echo "<tr>";
		echo"<td><a href=\"#\" onclick='window.open(\"../bars/EditBike.php?BikeID=".$bike."\",\"_blank\",\"status=yes,toolbar=no,menubar=no,location=no\");return false'>$bike</a></td><td>$type</td><td>$rdate</td><td>$serial</td><td>$checked</td><td>$manifest</td><td>$cleared</td><td>$disposed</td><td>$disposition</td>";
		echo "</tr>";
		echo "\n";
		}
	?>
	</tbody>
	</table>
	<?php
// Free used resources
	$query->closeCursor();
	$db = null;
// Get the standard Bike Co-op page footer.
	}
include_once($_SERVER['DOCUMENT_ROOT'].'footer.php');
?>
