<?php
/**
	*	ReleaseBike.php - part of the Fort Collins Bike Co-op system for tracking recovered bikes
	*
	* This script presents the page for checking for bikes that can be released.
	* According to the Scope of Work, bikes are released to the Co-op after they have been posted 
	* on the city's Purchasing web page for 10 days.  Since we record the date we send the manifest 
	* to Purchasing and not the date they actually post it, this code assumes that they are released 
	* 10 days after the list is sent to Purchasing.  There may be cases where there is a delay in 
	* having the list posted so care should be taken to make sure that all the bikes presented in 
	* this list are, in fact, "released". So, this script is not run until the day after FCPS tells
	* us the list is cleared and removed from the city's Purchasing web page.
	* Starting in 2014, we treat donated bikes and bikes released to us from Police Services as 
	* "cleared" after we check their serial numbers against the Stolen Bikes list they send us (i.e.,
	* the FCPS table in our database).
	*/

session_start();
$_SESSION['list']="ReleaseBike";
$HTTP_SESSION_VARS ["list"] = "ReleaseBike";

$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once($_SERVER['DOCUMENT_ROOT'].'header.php');
?>

<script src="../sorttable.js"></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>B.A.R.S. Admin</a> <b>&raquo;</b>Release Bikes</td>
				</tr>
			</table>

			<div class="heading">Released Bikes</div>

<script language="JavaScript">
var gAutoPrint = true; // Tells whether to automatically call the print function

function printSpecial()
	{
	if (document.getElementById != null)
		{
		var html = '<HTML>\n<HEAD>\n';
//		if (document.getElementsByTagName != null)
//			{
//			var headTags = document.getElementsByTagName("head");
//			if (headTags.length > 0) html += headTags[0].innerHTML;
//			}
//		html += '<link rel="stylesheet" type="text/css" href="./printing.css">';

		html += '\n</HE>\n<BODY>\n';
		var printReadyElem = document.getElementById("printReady");
		if (printReadyElem != null)
			{
			html += printReadyElem.innerHTML;
			}
		else
			{
			alert("Could not find the printReady function");
			return;
			}
		html += '\n</BO>\n</HT>';
		var printWin = window.open("","printSpecial");
		printWin.document.open();
		printWin.document.write(html);
		printWin.document.close();
		if (gAutoPrint) printWin.print();
		}
	else
		{
		alert("The print ready feature is only available if you are using an browser. Please update your browswer.");
		}
	}

</script>

<?php
//Connect to the Bike Co-op database
require_once "../../db_connect.php";
$db = db_connect ();
try
	{
	$query = $db->prepare("SELECT * FROM RECOVEREDBIKES WHERE (((Type = ? OR Type = ? OR Type = ?) AND DateCleared = 0000-00-00 AND DispDate = 0000-00-00) OR (ToPurchasing != 0000-00-00 AND DATEDIFF(CURDATE(), ToPurchasing)>10 AND DateCleared = 0000-00-00 AND DispDate = 0000-00-00)) ORDER BY BikeID");
	$query->bindValue(1, "donation", PDO::PARAM_STR);
	$query->bindValue(2, "FCPS", PDO::PARAM_STR);
	$query->bindValue(3, "donated", PDO::PARAM_STR);
	$query->execute();
	}
catch (PDOException $e)
	{
	print ("The statement failed.\n");
	echo "boo-boo";
	echo "getMessage(): " . $e->getMessage () . "\n";
	}
?>
Note:  list can be sorted by clicking on the column headers.
<form id="printMe" name="printMe">  <input type="button" name="printMe" onClick="printSpecial()" value="Print the Table"> </form> 
<font size=1>
<div id=printReady>
	<table border=2 class="sortable" style="font-size: 10px; width: 175px">
		<thead>
			<tr>
				<th>Log</th><th>Type</th><th>Manifest</th><th>Recovered</th><th>Serial #</th><th>Brand</th><th>Model</th><th>Color</th><th>Description</th>
			</tr>
		</thead>
<?php
//Fetch & display the results
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$bike = $result_row["BikeID"];
	$log = $result_row["Log"];
// Instead of using a Co-op "case number", which is confusing because we also have a FCPS case number, we 
// are switching to using the automatically generated record ID (BikeID) as the identity for a recovered bike.
// So, if Co-op case number is blank, use record ID.  
	if (empty($log)) $log = $bike;
	$type = $result_row["Type"];
	// Shorten "type" to a single letter
	if ($type == "donation") {$type = "D";}
	elseif ($type == "FCPS") {$type = "P";}
	elseif ($type == "donated") {$type = "D";}
	else {$type = "R";}
	$rdate = $result_row["RecoveredDate"];
	$serial = $result_row["Serial"];
	$brand = $result_row["Brand"];
	$model = $result_row["Model"];
	$color = $result_row["Color"];
	$description = $result_row["Description"];
	$contact = $result_row["Contact"];
	$location = $result_row["Location"];
	$phone = $result_row["Phone"];
	$volunteer = $result_row["Volunteer"];
	$manifest = $result_row["ToPurchasing"];
	// shorten the description for display purposes
	$descr = substr($description,0,15)." ...";
	// Change the date format for siplay purposes.
	$vrdate = date("m/d/Y",strtotime($rdate));
	if ($manifest == '0000-00-00') {$vmanifest = "n/a";}
	else {$vmanifest = date("m/d/Y",strtotime($manifest));}
	echo "<td><a href=\"#\" onclick='window.open(\"../bars/EditBike.php?operation=release&BikeID=".$bike."\",\"_blank\",\"resizable=yes,scrollbars=yes,status=yes,toolbar=no,menubar=no,location=no\");return false'>$log</a></td><td style='text-align:center'>$type</td><td>$vmanifest</td><td>$vrdate</td><td>$serial</td><td>$brand</td><td>$model</td><td>$color</td><td>$description</td>";
	echo "</tr>";
	echo "\n";
	}
?>
	</table>
</div>

<?php
// Close the connection to the database
$db = null;
include_once($_SERVER['DOCUMENT_ROOT'].'footer.php');
?>
