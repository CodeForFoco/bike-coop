<?php
// This script presents the B.A.R.S. Admin main page
// set the variables that will let us get back
session_start();
//session_register("origin");
$_SESSION['origin']="bars_admin";
$HTTP_SESSION_VARS ["origin"] = "bars_admin";
//session_register("list");
$_SESSION['list']="SearchStolen";
$HTTP_SESSION_VARS ["list"] = "SearchStolen";
$current_page = htmlentities($_SERVER['PHP_SELF']);
$title = "BARS Admin";
include_once($_SERVER['DOCUMENT_ROOT'].'header.php');
?>

<div class="heading">B.A.R.S. Admin</div>
<a href="http:../bars/ListBikes.php">List Recovered Bikes</a><br>
<a href="http:./BikeReport.php">Recovered Bike Report</a><br>
<a href="http:./StolenBikes.php">List Stolen Bikes</a><br>
<a href="http:../bars/SearchStolen.php">Search Stolen Bikes</a><br>
<a href="http:./LoadStolen.html">Load Stolen Bike Report</a><br>
<a href="http:./MatchStolenBikes.php">Check Matching Bikes</a><br>
<a href="http:./CheckPostable.php">Check for "Postable" Bikes</a><br>
<a href="http:./ReleaseBike.php">Release Bikes</a><br>
<!-- temporarily hide
<a href="http:./BikeDisposition.php">Bike Disposition</a><br>
-->
<?php
include_once($_SERVER['DOCUMENT_ROOT'].'footer.php');
exit;
?>
