<?php
/**
	*	CheckPostable.php - part of the Fort Collins Bike Co-op system for tracking recovered bikes
	*
	* This script presents the page for checking "postable" bikes.
	*/
session_start();
$_SESSION['list']="CheckPostable";
$HTTP_SESSION_VARS ["list"] = "CheckPostable";

$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>

<script src="../restricted/sorttable.js"></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>B.A.R.S. Admin</a> <b>&raquo;</b>Check for Postable Bikes</td>
				</tr>
			</table>

			<div class="heading">Postable Bikes</div>
<?php
//Connect to the Bike Co-op database
require_once "../../db_connect.php";
$db = db_connect ();
try
	{
	$query = $db->prepare("SELECT * FROM RECOVEREDBIKES WHERE Type = ? AND SentPS>0000-00-00 AND (DATEDIFF(CURDATE(),RecoveredDate) > 30) AND ToPurchasing=0000-00-00 AND DispDate = 0000-00-00 AND Status!=? ORDER BY BikeID, RecoveredDate DESC");
	$query->bindValue(1, "recovery", PDO::PARAM_STR);
	$query->bindValue(2, "returned", PDO::PARAM_STR);
	$query->execute();
	}
catch (PDOException $e)
	{
	print ("The statement failed.\n");
	echo "boo-boo";
	echo "getMessage(): " . $e->getMessage () . "\n";
	}

?>

Note:  list can be sorted by clicking on the column headers.
<font size=1>
			<table border=2 class="sortable">
				<tr>
				<th>Description</th><th>Serial #</th><th>Log</th>
				</tr>
<?php
//Fetch & display the results
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$bike = $result_row["BikeID"];
	$bin = $result_row["Bin"];
	$log = $result_row["Log"];
// Instead of using a Co-op "case number", which is confusing because we also have a FCPS case number, we 
// are switching to using the automatically generated record ID (Bike_ID) as the identity for a recovered bike.
// So, if Co-op case number is blank, use record ID.  
	if (empty($log)) $log = $bike;
	$rdate = $result_row["RecoveredDate"];
	$serial = $result_row["Serial"];
	$brand = $result_row["Brand"];
	$model = $result_row["Model"];
	$color = $result_row["Color"];
	$description = $result_row["Description"];
	$contact = $result_row["Contact"];
	$location = $result_row["Location"];
	$phone = $result_row["Phone"];
	$volunteer = $result_row["Volunteer"];
// shorten the description for display purposes
	$descr = substr($description,0,15)." ...";
	echo "<td>$brand $model $color $description</td><td>$serial</td><td><a href=\"#\" onclick='window.open(\"../bars/EditBike.php?BikeID=".$bike."\",\"_blank\",\"status=yes,toolbar=no,menubar=no,location=no\");return false'>$log</a></td>";
	echo "</tr>";
	echo "\n";
	}
?>
			</table>
<?php
// Close the connection to the database
$db = null;

include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
