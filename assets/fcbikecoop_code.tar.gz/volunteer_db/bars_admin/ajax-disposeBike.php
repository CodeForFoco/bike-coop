<?php
// Turn off all error reporting
//error_reporting(0);
//Connect to the Bike Co-op database
require_once "../../db_connect.php";
$db = db_connect ();

$bike=($_GET['bikeID']);
$disposition=($_GET['disposition']);
echo "Disp: ".$disposition;
$dispdate=date('Y-m-d');
$sql = "UPDATE `RECOVEREDBIKES` SET `Disposition`='".$disposition."',`DispDate`='".$dispdate."' WHERE BikeID='".$bike."'";
echo "SQL: ".$sql;
$update = $db->prepare($sql);
try
	{
	// run the query
	$update->execute();
	}
catch (PDOException $e)
	{
	echo "The statement failed.\n";
	echo "getCode: ". $e->getCode () . "\n";
	echo "getMessage: ". $e->getMessage () . "\n";
	}
echo "Bike #".$bike." logged as ".$disposition.".";
?>
