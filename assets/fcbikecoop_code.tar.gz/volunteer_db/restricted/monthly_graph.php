<?php
header ("Content-type: image/jpg");

// Include our login information
include('../db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
die ("Could not connect to the database: <br />". mysql_error());
}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
die ("Could not select the database: <br />". mysql_error());
}

$qt=mysql_query("SELECT YEAR(vDate) as year, MONTH(vDate) as month, sum(Elapsed) AS total_hours FROM `TIMECARDS` GROUP BY YEAR(vDate), MONTH(vDate)");
$numoptions = mysql_num_rows($qt);
$x_gap=40; // The gap between each point in y axis

$x_max=$x_gap*26; // Maximum width of the graph or horizontal axis
$y_max=200; // Maximum height of the graph or vertical axis
$y_base=$y_max+20;
// Above two variables will be used to create a canvas of the image//

$barwidth = floor(300/$numoptions);
$im = @ImageCreate ($x_max, $y_base)
or die ("Cannot Initialize new GD image stream");
$background_color = ImageColorAllocate ($im, 234, 234, 234);
$text_color = ImageColorAllocate ($im, 233, 14, 91);
$graph_color = ImageColorAllocate ($im,25,25,25);
$grid_color = ImageColorAllocate ($im,125,125,125);
$red = imagecolorallocate ($im, 255, 0, 0);
$x1=0;
$y1=0;
$first_one="yes";
while($nt=mysql_fetch_array($qt)){
//echo "$nt[month], $nt[sales]";
$yr=$nt[year];
$qtr=$nt[month]*100;
$hrs=$nt[total_hours]/10;
$x2=$x1+$x_gap; // Shifting in X axis
$y2=$y_max-$hrs; // Coordinate of Y axis
ImageString($im,2,$x2,$y2-20,round($nt[total_hours]),$graph_color);
$x_label=$nt[month]."/".substr($nt[year],2);
ImageString($im,2,$x2,$y_base-15,$x_label,$graph_color);
//Line above is to print month names on the graph

if($first_one=="no"){ // this is to prevent from starting $x1= and $y1=0
imageline ($im,$x1,$y1,$x2,$y2,$text_color); // Drawing the line between two points
}
$x1=$x2; // Storing the value for next draw
$y1=$y2;
$first_one="no"; // Now flag is set to allow the drawing
}

ImageJPEG ($im);

?>

