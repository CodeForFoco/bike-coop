<?php
session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
  			<td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>Volunteer Only Area</a> <b>&raquo;</b> <a href='../vol_select.php'>Select Volunteer</a> <b>&raquo;</b>Volunteer Hours</td>
				</tr>
			</table>
			<div class="heading">Volunteer Hours</div>
			<table border="2">
				<tr>
				<th>Date</th><th>Hours</th><th>Date</th><th>Hours</th><th>Date</th><th>Hours</th><th>Date</th><th>Hours</th>
				</tr>
<?php
// Include our login information
include('../db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
die ("Could not connect to the database: <br />". mysql_error());
}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
die ("Could not select the database: <br />". mysql_error());
}
?>
<form method="post" action="<?php echo $PHP_SELF;?>">
<!-- Build the fields for adding hours. -->
<p>Enter a date (in month/day/year format), select hours and/or minutes, select the project worked on and click on submit.</p>
Date:  
<input type="text" name="volDate" id="volDate"  size="10" maxlength="10" value="<?php echo $volDate ?>">
 Hours:   
<select id='volHrs' name='volHrs'>
<option value='00'>00</option>
<option value='01'>01</option>
<option value='02'>02</option>
<option value='03'>03</option>
<option value='04'>04</option>
<option value='05'>05</option>
<option value='06'>06</option>
<option value='07'>07</option>
<option value='08'>08</option>
<option value='09'>09</option>
<option value='10'>10</option>
<option value='11'>11</option>
<option value='12'>12</option>
<option value='13'>13</option>
<option value='14'>14</option>
<option value='15'>15</option>
<option value='16'>16</option>
<option value='17'>17</option>
<option value='18'>18</option>
<option value='19'>19</option>
<option value='20'>20</option>
<option value='21'>21</option>
<option value='22'>22</option>
<option value='23'>23</option>
</select>
:
<select id='volMin' name='volMin'>
<option value='00'>00</option>
<option value='25'>15</option>
<option value='50'>30</option>
<option value='75'>45</option>
</select>
Project:
<select id='program' name='program'>
<option value='art'>Art Committee Work</option>
<option value='BARS'>Bike Retrieval</option>
<option value='safety'>Bike Safety</option>
<option value='valet'>Bike Valet</option>
<option value='outreach'>Community Outreach</option>
<option value='EAB'>Earn-a-Bike</option>
<option value='fundraising'>Fundraising</option>
<option value='recycle'>Recycling</option>
<option value='admin'>Office Work</option>
<option value='maint'>Shop Maintenance/Construction</option>
<option value='shop'>Shop Work (not wrenching)</option>
<option value='fixing'>Wrenching</option>
</select>
<br><br>
<input type="submit" name="Submit" value="submit">
</form>
<?php
if(isset($_POST['volunteer']))
	{
	$volid = $_POST['volunteer'];
	$_SESSION['volid'] = $volid;
	}
else
	{
	$volid = $_SESSION['volid'];
	}
// If form has been submitted, post the hours to the TIMECARDS table.
if(isset($_POST['Submit']))
	{
	$volHrs = $_POST['volHrs'];
	$volMin = $_POST['volMin'];
	$volHours = $volHrs.".".$volMin;
	$project = $_POST['program'];
	// make sure hours/minutes were specified
	if($volHours > 0)
		{
		$volDate = $_POST['volDate'];
		$volDate = strftime("%F",strtotime($volDate));
		$volDate = str_replace("-","",$volDate);
		$query = ' INSERT HIGH_PRIORITY INTO `TIMECARDS`(`VolID`,`vDate`,`Elapsed`,`Program`) VALUES ('.$volid.', '.$volDate.', '.$volHours.', "'.$project.'")';
		$result = mysql_query( $query );
		if (!$result)
			{
			die ("Could not insert the record in the database: <br />". mysql_error());
			}
		}
	}
// Get the volunteer's name
$result = mysql_query('SELECT * FROM `VOLUNTEERS` WHERE `VolID` = '.$volid);
$row = mysql_fetch_row($result);
$volname = $row[1].' '.$row[2];
// Get the total hours for this volunteer
$result = mysql_query('SELECT sum(Elapsed) AS total_hours FROM `TIMECARDS` WHERE `VolID` = '.$volid);
$row = mysql_fetch_row($result);
$tothours = $row[0];
echo "<h4>Total Hours for ".$volname.":  ".$tothours."</h4>\n";
// Set up to display the hours log
echo "<h4>Hours Log</h4>\n";
// Get the timecard data for the volunteer selected
$select = ' SELECT ';
$column = ' * ';
$from = ' FROM ';
$table = ' `TIMECARDS` ';
$where = ' WHERE VolID = ';
$order = ' ORDER BY vDate DESC, "In" ASC';
$query = $select.$column.$from.$table.$where.$volid.$order;
$result = mysql_query( $query );
if (!$result)
	{
	die ("Could not query the database: <br />". mysql_error());
	}
// Initialize the total hours field
$tothours = 0;
//Fetch & display the results
echo "				<tr>";
$i = 1;
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$vdate = $result_row["vDate"];
	$vhours = $result_row["Elapsed"];
	$tothours = $tothours + $vhours;
//	echo "				<tr>";
	echo "<td>$vdate</td><td align='right'>$vhours</td>";
	if ($i > "3")
		{
		echo "</tr>";
		echo "\n";
		echo "				<tr>";
		$i = 0;
		}
		$i=$i+1;
	}
echo "</tr>";
// $_SESSION['volid'] = $volid;

// Close the connection
mysql_close($connection);
?>
			</table>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
