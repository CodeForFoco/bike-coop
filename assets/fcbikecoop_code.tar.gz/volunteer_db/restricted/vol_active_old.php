<?php
/**
	*	vol_active.php - part of the Fort Collins Bike Co-op system for managing volunteer work.
	*
	* This script lists volunteers that have signed up in the last 30 days or have logged at least 20 
	* hours and have been active in the last 90 days.
*/
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>Volunteer Management</a> <b>&raquo;</b>Volunteer List</td>
				</tr>
			</table>
			<div class="heading">Active Volunteers</div>
			<p>These volunteers signed up in the last 30 days or have at least 20 hours and have been active in the last 90 days.</p>
			<table border="1">
				<tr>
				<th>#</th>
				<th>Volunteer</th>
				<th>Total Hours</th>
				<th>Last Worked</th>
				<th>Email</th>
				<th>Phone</th>
				</tr>

<?php
// Connect to the Bike Co-op database.
require_once "../../db_connect.php";
$db = db_connect ();
//Assign the query
$query = $db->prepare("SELECT VolunteerStatusAll.Volunteer AS Volunteer, 
	VolunteerStatusAll.Email AS Email, VolunteerStatusAll.Phone AS Phone, 
	VolunteerStatusAll.LastTime AS LastTime,VolunteerStatusAll.TotalHours AS TotalHours, 
	VolunteerStatusAll.AppDate AS AppDate from VolunteerStatusAll 
	where ((VolunteerStatusAll.TotalHours >= 20) 
	and ((to_days(curdate()) - to_days(VolunteerStatusAll.LastTime)) < 90) 
	or ((to_days(curdate()) - to_days(VolunteerStatusAll.AppDate)) < 30)) 
	order by VolunteerStatusAll.TotalHours desc");
$query->execute();

// Fetch & display the results of the query.
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$ct++;
	$volunteer = $result_row["Volunteer"];
	$last = date("m/d/Y",strtotime($result_row["LastTime"]));
	$hours = $result_row["TotalHours"];
	$email = $result_row["Email"];
	$phone = $result_row["Phone"];
	echo "<tr>";
	echo "<td>$ct</td>";
	echo "<td>$volunteer</td>";
	echo "<td align='right'>$hours</td>";
	echo "<td align='center'>$last</td>";
	echo "<td align='left'>$email</td>";
	echo "<td align='left'>$phone</td>";
	echo "</tr>";
	}
// Finish the page.
?>
	</tbody>
</table>
</div>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
// Free used database resources.
$result->closeCursor();
$db = null;
?>
