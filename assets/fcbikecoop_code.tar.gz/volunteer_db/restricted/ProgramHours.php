<?php
// This script shows program hours
$current_page = htmlentities($_SERVER['PHP_SELF']);

include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<script src="../sorttable.js"></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
  			<td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>Volunteer Management</a> <b>&raquo;</b>Volunteer Hours by Program</td>
				</tr>
			</table>			<div class="heading">Volunteer Hours by Program</div>

<?php
//Connect to the Bike Co-op database
// Include our login information
include('../db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
die ("Could not connect to the database: <br />". mysql_error());
}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
die ("Could not select the database: <br />". mysql_error());
}
$query = "SELECT `Program` as program, YEAR(`vDate`) as year, sum(`Elapsed`) as hours from TIMECARDS where `vDate`>'2010-01-00' group by `Program`, YEAR(`vDate`)";
$result = mysql_query($query) or die(mysql_error());
?>

<font size=1>
<table border=2 class="sortable">
	<thead>
		<tr>
			<th>Program</th><th>Year</th><th>Hours</th><th>....</th>
			</tr>
	</thead>
	<tbody style='height:300px; overflow:auto;'>
<?php
//Fetch & display the results
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$program = $result_row["program"];
	$year = $result_row["year"];
	$hours = $result_row["hours"];
	echo "<tr>";
	echo "<td>$program</a></td><td align=center>$year</td><td align=right>$hours</td>";
	echo "</tr>";
	echo "\n";
	}
?>
	</tbody>
</table>

<?php
// Close the connection to the database
mysql_close($connection);

include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
