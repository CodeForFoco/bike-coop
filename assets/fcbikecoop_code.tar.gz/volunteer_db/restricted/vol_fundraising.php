<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<script src="sorttable.js"></script>
 <!-- "breadcrumbs" -->
<div class='path'>
<table cellpadding='5' class='stand' summary=''>
<tr>
  <td style='width:0%; white-space:nowrap'>
  <td> <b>&raquo;</b> <a href='./index.php'>Volunteer Management</a> <b>&raquo;</b> Fundraising Volunteers</td>

</tr>
</table>
</div>

<div class="heading">Fundraising Volunteers</div>
<p>These volunteers are interested in fundraising.</p>
Note:  list can be sorted by clicking on the column headers.
			<table border="1" class="sortable">
				<tr><th>Volunteer</th><th>Email</th><th>Phone</th><th>Date Joined</th><th>Last Worked</th></tr>
<?php
// Include our login information
include('../db_login.php');
//Connect
$db_error='There was a problem accessing our system.  Please try again later.';
$connection = @mysql_connect($db_host, $db_username, $db_password) or die($db_error);
// Select the database
$db_select = @mysql_select_db($db_database) or die($db_error);
//Assign the query
$query = "SELECT CONCAT( `VOLUNTEERS`.`FirstName`, ' ', `VOLUNTEERS`.`LastName` ) AS `Volunteer`, `VOLUNTEERS`.`Email` AS `Email`, `VOLUNTEERS`.`Phone` AS `Phone`, `VOLUNTEERS`.`AppDate` AS AppDate, MAX( `TIMECARDS`.`vDate` ) AS `LastTime` FROM `fcbikecoop`.`TIMECARDS` AS `TIMECARDS`, `fcbikecoop`.`VOLUNTEERS` AS `VOLUNTEERS` WHERE `TIMECARDS`.`VolID` = `VOLUNTEERS`.`VolID` AND `VOLUNTEERS`.`Fund` IS TRUE AND DATEDIFF( CURDATE( ) ,`TIMECARDS`.`vDate`) <= 365 GROUP BY `Volunteer` ORDER BY `AppDate` DESC";

//Execute the query
$result = mysql_query( $query );
if (!$result){
die ("Could not query the database: <br />". mysql_error());
}
//Fetch & display the results
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC)){
$volunteer = $result_row["Volunteer"];
$email = $result_row["Email"];
$phone = $result_row["Phone"];
$appdate = $result_row["AppDate"];
$last = date("m/d/Y",strtotime($result_row["LastTime"]));
if (!$appdate | $appdate=="0000-00-00")
	$appdate="unknown";
else
	$appdate = date("m/d/Y",strtotime($result_row["AppDate"]));
echo "<tr>";
echo "<td>$volunteer</td>";
echo "<td>$email</td>";
echo "<td>$phone</td>";
echo "<td>$appdate</td>";
echo "<td>$last</td>";
echo "</tr>";
}

// Close the connection
mysql_close($connection);
?>
</table>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
