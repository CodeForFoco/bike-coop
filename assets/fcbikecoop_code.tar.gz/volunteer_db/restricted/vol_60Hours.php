<?php
// List volunteers that have at least 60 hours in the last 365 days.
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>Volunteer Management</a> <b>&raquo;</b>Volunteers w. 60 Hours</td>
				</tr>
			</table>
			<div class="heading">Active Volunteers</div>
			<p>These volunteers have at least 60 hours in the last 365 days.</p>
			<table border="1">
				<tr>
				<th>#</th>
				<th>Volunteer</th>
				<th>Hours</th>
				<th>Last Worked</th>
				</tr>

<?php
// Include our login information
include('../db_login.php');

//Connect
$db_error='There was a problem accessing our system.  Please try again later.';
$connection = @mysql_connect($db_host, $db_username, $db_password) or die($db_error);
// Select the database
$db_select = @mysql_select_db($db_database) or die($db_error);
//Assign the query
$query = "SELECT CONCAT( `VOLUNTEERS`.`FirstName`, ' ', `VOLUNTEERS`.`LastName` ) AS `Volunteer`, SUM( `TIMECARDS`.`Elapsed` ) AS `TotalHours`, MAX( `TIMECARDS`.`vDate` ) AS `LastTime` FROM `fcbikecoop`.`TIMECARDS` AS `TIMECARDS`, `fcbikecoop`.`VOLUNTEERS` AS `VOLUNTEERS` WHERE `TIMECARDS`.`VolID` = `VOLUNTEERS`.`VolID` AND DATEDIFF( CURDATE( ) ,`TIMECARDS`.`vDate`) <= 365 GROUP BY `Volunteer` ORDER BY `TotalHours` DESC";

//Execute the query
if(!mysql_query($query))
	{
	echo 'Query failed '.mysql_error();
	echo $query;
	exit();
	}
$result = mysql_query( $query );
if (!$result){
die ("Could not query the database: <br />". mysql_error());
}
//Fetch & display the results
$ct = 0;
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC)){
$volunteer = $result_row["Volunteer"];
$last = date("m/d/Y",strtotime($result_row["LastTime"]));
$hours = $result_row["TotalHours"];
$ct++;
// only show those with at least 60 hours.
if ($hours >= 60)
	{
	echo "<tr>";
	echo "<td>$ct</td>";
	echo "<td>$volunteer</td>";
	echo "<td align='right'>$hours</td>";
	echo "<td align='center'>$last</td>";
	echo "</tr>";
	}
}

// Close the connection
mysql_close($connection);
?>
</table>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
