<?php
/**
	*	vol_by_program.php - part of the Fort Collins Bike Co-op system for managing volunteer work.
	*
	* This script lists volunteer hours by program.
*/
session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
/**
	*	The script assumes that session variables have been set by the calling script.
	* That variable is used to build the "breadcrumb" list that helps the user navigate back.
	*/
?>
<!-- "breadcrumbs" -->
<table cellpadding='5'>
	<tr>
		<td style='width:0%; white-space:nowrap'>
		<td><b>&raquo;</b><a href='./index.php'>Volunteer Management</a> <b> &raquo;</b>Volunteer Hours by Program</td>
	</tr>
</table>
<div class="heading">Volunteer Hours by Program</div>
<table border=1>
	<tr>
		<th>Program</th><th>Hours</th><th>Program</th><th>Hours</th><th>Program</th><th>Hours</th><th>Program</th><th>Hours</th>
	</tr>
<?php
// Connect to the Bike Co-op database.
require_once "../../db_connect.php";
$db = db_connect ();

// Get totals by program
$query = $db->prepare("SELECT Program, sum(Elapsed) AS total_hours FROM TIMECARDS GROUP BY Program ASC");
$query->execute();
echo "				<tr>";
$i = 1;
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$program = $result_row["Program"];
	if ($program == "") $program = "not specified";
	$tothours = $result_row["total_hours"];
	echo "<td>$program</td><td align='right'>$tothours</td>";
	if ($i > "3")
		{
		echo "</tr>";
		echo "\n";
		echo "				<tr>";
		$i = 0;
		}
		$i=$i+1;
	}
echo "</tr>";
echo "</table>";
echo "</table>";
// Finish the page.
echo "</tr>";
echo "</table>";
include_once('/var/www/fcbikecoop.org/root/footer.php');
// Free used database resources.
$query->closeCursor();
$db = null;
?>
