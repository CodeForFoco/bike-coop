<?php
// This script shows volunteer applications by month
$current_page = htmlentities($_SERVER['PHP_SELF']);

include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<script src="../sorttable.js"></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
  			<td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>Volunteer Management</a> <b>&raquo;</b>Volunteer Applications by Month</td>
				</tr>
			</table>			<div class="heading">Volunteer Applications by Month</div>
<?php
//Connect to the Bike Co-op database
// Include our login information
include('../db_login.php');
//Connect
$connection = mysql_connect($db_host, $db_username, $db_password);
if (!$connection){
die ("Could not connect to the database: <br />". mysql_error());
}
// Select the database
$db_select = mysql_select_db($db_database);
if (!$db_select){
die ("Could not select the database: <br />". mysql_error());
}

$result = mysql_query('SELECT YEAR(VOLUNTEERS.AppDate) AS Year, MONTHNAME(VOLUNTEERS.AppDate) AS Month, COUNT(DISTINCT VOLUNTEERS.VolID) AS Vols
FROM VOLUNTEERS, TIMECARDS
WHERE VOLUNTEERS.VolID = TIMECARDS.VolID
AND YEAR(VOLUNTEERS.AppDate)>=2008
GROUP BY YEAR(VOLUNTEERS.AppDate)desc,MONTH(VOLUNTEERS.AppDate)desc
HAVING COUNT(TIMECARDS.vDate) > 1
');
?>
<p>Note: list can be sorted by clicking on the column headers.

<font size=1>
<table border=2 class="sortable">
	<thead>
		<tr>
			<th>Year</th><th>Month</th><th>Volunteers</th><th>....</th>
			</tr>
	</thead>
	<tbody style='height:300px; overflow:auto;'>
<?php
//Fetch & display the results
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$year = $result_row["Year"];
	$month = $result_row["Month"];
	$vols = $result_row["Vols"];
	echo "<td>$year</td><td align=center>$month</td><td align=right>$vols</td>";
	echo "</tr>";
	echo "\n";
	}
?>
	</tbody>
</table>
<?php
// Close the connection to the database
mysql_close($connection);

include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
