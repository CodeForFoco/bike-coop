<?php
// Add a volunteer to the CommunityService table
session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b><a href='./index.php'> B.A.R.S.</a><b>&raquo;</b> Add to BARS List</td>
				</tr>
			</table>
			<div class="heading">Community Service Volunteers</div>

//Connect to the Bike Co-op database
include_once($_SERVER['DOCUMENT_ROOT'].'db_connect.php');
$db = db_connect ();

	$insert = $db->prepare("INSERT INTO CommunityService (Type, RecoveredDate, Serial, Brand, Model, Color, Description, Contact, Location, Phone, Volunteer, SentPS) VALUES  (:type, :rdate, :serial, :brand, :model, :color, :description, :donor, :donorID, :phone, :volunteer, :sentPS)");
	$insert->bindValue(':type', $type, PDO::PARAM_STR);
	$insert->bindValue(':rdate', $rdate, PDO::PARAM_STR);
	$insert->bindValue(':serial', $serial, PDO::PARAM_STR);
	$insert->bindValue(':brand', $brand, PDO::PARAM_STR);
	$insert->bindValue(':model', $model, PDO::PARAM_STR);
	$insert->bindValue(':color', $color, PDO::PARAM_STR);
	$insert->bindValue(':description', $description, PDO::PARAM_STR);
	$insert->bindValue(':donor', $donor, PDO::PARAM_STR);
	$insert->bindValue(':donorID', $donorID, PDO::PARAM_STR);
	$insert->bindValue(':phone', $phone, PDO::PARAM_STR);
	$insert->bindValue(':volunteer', $volunteer, PDO::PARAM_STR);
	// since bikes are logged into LeadsOnline, the SentPS date is the same are the log date
	$insert->bindValue(':sentPS', $rdate, PDO::PARAM_STR);

	try
		{
		// run the query
		$insert->execute();
		$log = $db->lastInsertId();
		}
	catch (PDOException $e)
		{
		echo "The statement failed.\n";
		echo "getCode: ". $e->getCode () . "\n";
		echo "getMessage: ". $e->getMessage () . "\n";
		unset($_POST['submit']); // reset since the insert failed
		exit();
		}

// Connect to the MySQL database
// Include our login information
include('../db_login.php');
//Connect
$db_error='There was a problem accessing our system.  Please try again later.';
$connection = @mysql_connect($db_host, $db_username, $db_password) or die($db_error);
// Select the database
$db_select = @mysql_select_db($db_database) or die($db_error);
//Get the volunteer names from the database
// SELECT CONCAT("FirstName",' ',"LastName") AS "Name", "VolID" FROM "VOLUNTEERS" AS "VOLUNTEERS" ORDER BY "Name" ASC
$select = ' SELECT ';
$column = ' `Name`, `VolID` ';
$from = ' FROM ';
$tables = ' `Names` ';
$where = '  ';
$query = $select.$column.$from.$tables.$where;
//Execute the query
$result = mysql_query( $query );
if (!result){
die ("Could not query the database: <br />". mysql_error());
}
//Fetch & display the results
$options="";
while ($row=mysql_fetch_assoc($result))
	{
	$volid=$row["VolID"];
	$volname = $row["Name"];
	$options.="<OPTION VALUE=\"$volid\">$volname</option>";
	}
?>
<form method="post" action="<?php echo $PHP_SELF;?>">
<br>
Find the name in the drop-down list and then click on the Select button.
<br>Names are listed alphabetically by first name (as entered on the volunteer application).
<br>If your name is not on the list, please <a href="volunteer_form.php">submit a volunteer application</a>.
<br>
<SELECT NAME="volunteer">
<OPTION VALUE="\"$volid\">Choose a Name</option>"
<OPTION SELECTED VALUE = "\"$volid\">
<?=$options?>
</SELECT>
<input type="submit" name="Select" value="Select">

<?php
// If form has been submitted
if(isset($_POST['Select']))
	{
	$volid = $_POST['volunteer'];
	//Assign the query
	$result = mysql_query('SELECT * FROM `VOLUNTEERS` WHERE `VolID` = '.$volid);
	if (!result){
		die ("Could not query the database: <br />". mysql_error());
		}
	// Get the volunteer's name
	$row = mysql_fetch_row($result);
	$volname = $row[2].' '.$row[3];
	// Add the volunteer to the BARS table.
	$sql = "INSERT INTO BARS (Volunteer, VolID) VALUES ('".$volname."', ".$volid.")";
	$result = mysql_query($sql);
	if (!result){
		echo "result: ".$result;
		die ("Could not query the database: <br />". mysql_error());
		}
	}
// Display the List
echo "<table>";
$result = mysql_query('SELECT * FROM `BARS`');
//Fetch & display the results
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$volunteer = $result_row["Volunteer"];
	echo "<td>$volunteer</td>";
	echo "</tr>";
	echo "\n";
	}
// Close the connection
mysql_close($connection);
?>
	</table>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
