<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);

//Connect to the Bike Co-op database
include_once($_SERVER['DOCUMENT_ROOT'].'db_connect.php');
$db = db_connect ();

// Do this if form has been submitted
// If form has been submitted, post the record to the EAB table.
if(isset($_POST['Submit']))
	{
	$volunteer=ucwords($_POST['supervisor']);
	$type=$_POST['type'];
	$owner=$_POST['volunteer'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	$agency=$_POST['agency'];
	$referrer=$_POST['referrer'];

	$insert = $db->prepare("INSERT INTO CommunityService (Date, Supervisor, Type, Volunteer, Email, Phone, Agency, Referrer) VALUES  (:rdate, :supervisor, :type, :volunteer, :email, :phone, :agency, :referrer)");
	$insert->bindValue(':type', $type, PDO::PARAM_STR);
	$insert->bindValue(':rdate', $rdate, PDO::PARAM_STR);
	$insert->bindValue(':description', $description, PDO::PARAM_STR);
	$insert->bindValue(':donor', $donor, PDO::PARAM_STR);
	$insert->bindValue(':phone', $phone, PDO::PARAM_STR);
	$insert->bindValue(':volunteer', $volunteer, PDO::PARAM_STR);
	// since bikes are logged into LeadsOnline, the SentPS date is the same are the log date
	$insert->bindValue(':sentPS', $rdate, PDO::PARAM_STR);

	try
		{
		// run the query
		$insert->execute();
		$log = $db->lastInsertId();
		}
	catch (PDOException $e)
		{
		echo "The statement failed.\n";
		echo "getCode: ". $e->getCode () . "\n";
		echo "getMessage: ". $e->getMessage () . "\n";
		unset($_POST['submit']); // reset since the insert failed
		exit();
		}


// If PHP is still reading this, it must be the first page visit,
// OR an error was detected.
// Display the HTML page and your signup form.

include_once('/var/www/fcbikecoop.org/root/header.php');
?>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
  			<td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>EAB</a> <b>&raquo;</b> Community Service Volunteer</td>
				</tr>
			</table>
<script src="../sorttable.js"></script>
<SCRIPT LANGUAGE="JavaScript" SRC="../CalendarPopup.js"></SCRIPT>
			<div class="heading">Earn A Bike Volunteer Data Sheet</div>

<form method="POST" action="<?php echo $PHP_SELF;?>" enctype="multipart/form-data">
<SCRIPT LANGUAGE="JavaScript" ID="js1">
var cal1 = new CalendarPopup();
</SCRIPT>
<p>
Date Entered: <input type="text" name="entryDate" size=8 id="entrydate">
<A HREF="#" onClick="cal1.select(document.forms[0].entrydate,'anchor1','MM/dd/yyyy'); return false;" TITLE="cal1.select(document.forms[0].entrydate,'anchor1','MM/dd/yyyy'); return false;" NAME="anchor1" ID="anchor1"><input type="image" src="../iconCalendar.gif"></A>
Logged by: <input type="text" name="volunteer" size=15>
<Input type = 'Radio' Name ='type' value= 'EAB'>EAB
<Input type = 'Radio' Name ='type' value= 'Referral'>Referral
<p>
Volunteer: <input type="text" id="owner" name="volunteer" size=15>
Email: <input type="text" id="email" name="email" size=15>
Phone: <input type="text" id="phone" name="phone" size=10>
<h2>Referral Information</h2>
Agency: <input type="text" id="agency" name="agency" size=15>
Referrer: <input type="text" id="referrer" name="referrer" size=15>
<input type="submit" name="Submit" value="submit">
Enter the information and click on submit.
</form>
<?php
// Get the supervisor list.
$select = ' SELECT ';
$column = ' * ';
$from = ' FROM ';
$table = ' `EAB` ';
$order = ' ORDER BY `DateEntered` DESC';
$query = $select.$column.$from.$table.$order;
$result = mysql_query( $query );
if (!$result)
	{
	die ("Could not query the database: <br />". mysql_error());
	}
?>

<h2>EAB</h2>
Note:  list can be sorted by clicking on the column headers.
<font size=1>
<table border=2 class="sortable">
	<thead>
		<tr>
			<th>ID</th><th>Entered</th><th>Owner</th><th>Earned</th><th>Serial #</th><th>Brand</th><th>Model</th><th>Color</th><th>Description</th><th>....</th>
		</tr>
	</thead>
	<tbody style='height:200px; overflow:auto;'>
<?php
//Fetch & display the results
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$ID = $result_row["ID"];
	$enterdate = $result_row["DateEntered"];
	$owner = $result_row["Owner"];
	$earndate = $result_row["DateEarned"];
	$serial = $result_row["Serial"];
	$brand = $result_row["Brand"];
	$model = $result_row["Model"];
	$color = $result_row["Color"];
	$description = $result_row["Description"];

	echo "<td><a href=\"./EditEAB.php?ID=".$ID."\">$ID</td><td>$enterdate</td><td>$owner</td><td>$earndate</td><td>$serial</td><td>$brand</td><td>$model</td><td>$color</td><td>$description</td>";
	echo "</tr>";
	echo "\n";
	}

?>
	</tbody>
</table>
<?php
// Close the connection
mysql_close($connection);
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
