<?php
// List volunteers that have at least 20 hours and have been active in the last 90 days.
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<script src="sorttable.js"></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>Volunteer Management</a> <b>&raquo;</b>Volunteer Status</td>
				</tr>
			</table>
			<div class="heading">Volunteer Status</div>
Note:  list can be sorted by clicking on the column headers.
			<table border="1" class="sortable">
				<tr>
				<th>Volunteer</th>
				<th>Total Hours</th>
				<th>Last Worked</th>
				</tr>

<?php
// Include our login information
include('../db_login.php');

//Connect
$db_error='There was a problem accessing our system.  Please try again later.';
$connection = @mysql_connect($db_host, $db_username, $db_password) or die($db_error);
// Select the database
$db_select = @mysql_select_db($db_database) or die($db_error);
//Assign the query
$select = ' SELECT ';
$column = ' * ';
$from = ' FROM ';
$tables = ' `VolunteerStatus` ';
$where = ' ORDER BY `TotalHours` DESC';
$query = $select.$column.$from.$tables.$where;
//Execute the query
$result = mysql_query( $query );
if (!$result){
die ("Could not query the database: <br />". mysql_error());
}
//Fetch & display the results
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC)){
$volunteer = $result_row["Volunteer"];
$last = date("m/d/Y",strtotime($result_row["LastTime"]));
$hours = $result_row["TotalHours"];
echo "<tr>";
echo "<td>$volunteer</td>";
echo "<td align='right'>$hours</td>";
echo "<td align='center'>$last</td>";
echo "</tr>";
}

// Close the connection
mysql_close($connection);
?>
</table>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
