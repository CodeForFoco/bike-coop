<?php
// List volunteers that have at least 20 hours in the last 365 days.
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>Volunteer Management</a>  <b>&raquo;</b> <a href='../vol_select.php'>Select Volunteer</a> <b>&raquo;</b> Volunteer Hours</td>
				</tr>
			</table>
			<div class="heading">Volunteer Hours</div>

<?php

// Get the records for this volunteer
if(isset($_POST['volunteer']))
	{
	$volid = $_POST['volunteer'];
	$_SESSION['volid'] = $volid;
	}
else
	{
	$volid = $_SESSION['volid'];
	}

// Connect to the MySQL database
// Include our login information
include('../db_login.php');
//Connect
$db_error='There was a problem accessing our system.  Please try again later.';
$connection = @mysql_connect($db_host, $db_username, $db_password) or die($db_error);
// Select the database
$db_select = @mysql_select_db($db_database) or die($db_error);
//Assign the query
$result = mysql_query('SELECT * FROM `VOLUNTEERS` WHERE `VolID` = '.$volid);
if (!$result){
die ("Could not query the database: <br />". mysql_error());
}
// Get the volunteer's name
$row = mysql_fetch_row($result);
$volname = $row[1].' '.$row[2];
// Get the total hours for this volunteer
$result = mysql_query('SELECT sum(Elapsed) AS total_hours FROM `TIMECARDS` WHERE `VolID` = '.$volid);
$row = mysql_fetch_row($result);
$tothours = $row[0];
echo "<br>Total Hours for ".$volname.":  ".$tothours."\n";
// Get the total hours in the last year for this volunteer
$result = mysql_query('SELECT sum(Elapsed) AS total_hours FROM `TIMECARDS` WHERE `VolID` = '.$volid.' AND (DATEDIFF(CURDATE(),vDate) < 365)');
$row = mysql_fetch_row($result);
$tothours = $row[0];
echo "<br>Total Hours in the last 365 days:  ".$tothours." (award qualifying period).\n";
// Show award level(s)
$next_award = "<br>At 20 hours you will be eligible for a volunteer t-shirt.";
if ($tothours >= 20) 
	{
	echo "<br>You qualify for a volunteer t-shirt for volunteering 20 hours.";
	$next_award = "<br>At 40 hours you will be eligible for access to volunteer-only parts.";
	}
if ($tothours >= 40) 
	{
	echo "<br>You qualify for access to volunteer-only parts for volunteering 40 hours.";
	$next_award = "<br>At 60 hours you will be eligible for access to volunteer-only parts.";
	}
if ($tothours >= 60) 
	{
	echo "<br>You qualify for a high-end bike for volunteering 60 hours.";
	$next_award = "<br>At 80 hours you will be eligible for access to volunteer-only parts.";
	}
if ($tothours >= 80) 
	{
	echo "<br>You qualify for wholesale parts ordering for volunteering 80 hours.";
	$next_award = "";
	}
echo $next_award;
// Set up to display the quarterly hours log
echo "<h2>Quarterly Hours Log</h2>\n";
echo "			<table border=1>
				<tr>
				<th>Year</th>
				<th>Quarter</th>
				<th>Hours</th>
				</tr>";

$result = mysql_query('SELECT YEAR(vDate) as year, QUARTER(vDate) as quarter, sum(Elapsed) AS total_hours FROM `TIMECARDS` WHERE `VolID` = '.$volid.' GROUP BY YEAR(vDate) DESC, QUARTER(vDate) DESC');

while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$year = $result_row["year"];
	$quarter = $result_row["quarter"];
	$tothours = $result_row["total_hours"];
	echo "				<tr>";
	echo "<td>$year</td><td align='center'>$quarter</td><td align='right'>$tothours</td>";
	echo "</tr>";
	}
echo "</table>";
// Set up to display the hours log
echo "<h2>Daily Hours Log</h2>\n";
echo "			<table border=2>
				<tr>
				<th>Date</th><th>Hours</th><th>Date</th><th>Hours</th><th>Date</th><th>Hours</th><th>Date</th><th>Hours</th>
				</tr>";

// Get the timecard data for the volunteer selected
$select = ' SELECT ';
$column = ' * ';
$from = ' FROM ';
$table = ' `TIMECARDS` ';
$where = ' WHERE VolID = ';
$order = ' ORDER BY vDate DESC, "In" ASC';
$query = $select.$column.$from.$table.$where.$volid.$order;
$result = mysql_query( $query );
if (!$result)
	{
	die ("Could not query the database: <br />". mysql_error());
	}

//Fetch & display the results
echo "				<tr>";
$i = 1;
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
	$vdate = date("m/d/Y",strtotime($result_row["vDate"]));
	$vhours = $result_row["Elapsed"];
	echo "<td>$vdate</td><td align='right'>$vhours</td>";
	if ($i > "3")
		{
		echo "</tr>";
		echo "\n";
		echo "				<tr>";
		$i = 0;
		}
		$i=$i+1;
	}
echo "</tr>";
// $_SESSION['volid'] = $volid;

// Close the connection
mysql_close($connection);
?>
			</table>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
