<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<script src="sorttable.js"></script>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>Volunteer Management</a> <b>&raquo;</b>Volunteers Who Logged Hours Once</td>
				</tr>
			</table>

			<div class="heading">Volunteers Who Logged Hours One Time</div>
Note:  list can be sorted by clicking on the column headers.
			<table border="1" class="sortable">
				<tr><th>Volunteer</th><th>Joined</th><th>Volunteered</th><th>Email</th><th>Phone</th></tr>
<?php
// Include our login information
include('../db_login.php');
//Connect
$db_error='There was a problem accessing our system.  Please try again later.';
$connection = @mysql_connect($db_host, $db_username, $db_password) or die($db_error);
// Select the database
$db_select = @mysql_select_db($db_database) or die($db_error);
//Assign the query

$select = ' SELECT ';
$column = ' * ';
$from = ' FROM ';
$tables = ' `VOLUNTEERS` left join `TIMECARDS` on VOLUNTEERS.VolID = TIMECARDS.VolID ';
$where = ' WHERE TIMECARDS.VolID IS NOT NULL ';
$group = ' GROUP BY VOLUNTEERS.VolID ';
$having = ' HAVING COUNT(TIMECARDS.vDate)=1 ';
$order = ' ORDER BY VOLUNTEERS.VolID DESC ';
$query = $select.$column.$from.$tables.$where.$group.$having.$order;
//Execute the query
$result = mysql_query( $query );
if (!$result){
die ("Could not query the database: <br />". mysql_error());
}
//Fetch & display the results
while ($result_row = mysql_fetch_array($result, MYSQL_ASSOC)){
$volid = $result_row["VolID"];
$volunteer = $result_row["FirstName"].' '.$result_row["LastName"];
$email = $result_row["Email"];
$phone = $result_row["Phone"];
$appdate = $result_row["AppDate"];
$vdate = $result_row["vDate"];
if (!$appdate | $appdate=="0000-00-00")
	$appdate="unknown";
else
	$appdate = date("m/d/Y",strtotime($result_row["AppDate"]));
echo "				<tr>";
echo "<td>$volunteer</td>";
echo "<td>$appdate</td>";
echo "<td>$vdate</td>";
echo "<td>$email</td>";
echo "<td>$phone</td>";
echo "</tr>";
echo "\n";
}

// Close the connection
mysql_close($connection);
?>
			</table>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
