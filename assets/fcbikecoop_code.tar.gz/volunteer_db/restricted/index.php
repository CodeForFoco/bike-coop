<?php
session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>

<div class="heading">Volunteer Management Database</div>
<a href="http:./vol_active.php">Active Volunteers.</a><br>
<a href="http:./vol_list.php">Volunteer List (includes inactives)</a><br>
<a href="http:./vol_apps_by_qtr.php">Volunteer Applications by Quarter</a><br>
<a href="http:./vol_apps_by_month.php">Volunteer Applications by Month</a><br>
<a href="http:./vol_hours_by_qtr.php">Volunteer Hours by Quarter</a><br>
<a href="http:./vol_hours_by_month.php">Volunteer Hours by Month</a><br>
<a href="http:./vol_hours_by_program.php">Volunteer Hours by Program</a><br>
<a href="http:./vol_no_hours.php">Volunteers who have logged no hours</a><br>
<a href="http:./vol_one_time.php">Volunteers who logged hours one time</a><br>
<a href="http:./vol_status.php">Volunteers Status</a><br>
<a href="http:./vol_100Hours.php">Volunteers with 100 hours or more</a><br>
<a href="http:./vol_80Hours.php">Volunteers with 80 hours or more</a><br>
<a href="http:./vol_60Hours.php">Volunteers with 60 hours or more</a><br>
<a href="http:./vol_40Hours.php">Volunteers with 40 hours or more</a><br>
<a href="http:./vol_20Hours.php">Volunteers with 20 hours or more</a><br>
<a href="http:../vol_select.php?action=./restricted/vol_report.php">Volunteer Hours Report</a><br>
<a href="http:./vol_greeter.php">Volunteers interested in Front Desk / Retail</a><br>
<a href="http:./vol_outreach.php">Volunteers interested in Community Outreach</a><br>
<a href="http:./vol_fundraising.php">Volunteers interested in Fundraising</a><br>
<a href="http:./vol_handyman.php">Volunteers interested in Construction/Renovation</a><br>
<a href="http:./vol_safety.php">Volunteers interested in Bike Safety</a><br>
<a href="http:./vol_bars.php">Volunteers interested in Bike Retrieval</a><br>
<a href="http:./vol_mechanic.php">Volunteers interested in Bike Mechanics</a><br>
<h3>Program Management</h2>
<a href="http:../bars/">BARS</a><br>
<a href="http:../eab/">EAB</a>

<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
