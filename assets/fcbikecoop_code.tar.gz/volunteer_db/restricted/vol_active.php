<?php
/**
	*	vol_active.php - part of the Fort Collins Bike Co-op system for managing volunteer work.
	*
	* This script lists volunteers that have signed up in the last 30 days or 
	*	have at logged at least 3 hours in the last 7 days or 
	* 	have at logged at least 10 hours and have been active in the last 30 days or
	* 	have logged at least 20 hours and have been active in the last 90 days.
*/
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>Volunteer Management</a> <b>&raquo;</b>Volunteer List</td>
				</tr>
			</table>
			<div class="heading">Active Volunteers</div>
			<p style="margin:0">These volunteers signed up in the last 30 days or</p>
			<ul style="margin:0">
				<li style="margin:0;padding:0">have at logged at least 3 hours in the last 7 days.
				<li style="margin:0;padding:0">have at logged at least 10 hours and have been active in the last 30 days.
				<li style="margin:0;padding:0">have at logged at least 20 hours and have been active in the last 90 days.
			</ul>
			<table border="1">
				<tr>
				<th>#</th>
				<th>Volunteer</th>
				<th>Application Date</th>
				<th>Total Hours</th>
				<th>Last Worked</th>
				<th>Email</th>
				<th>Phone</th>
				</tr>

<?php
// Connect to the Bike Co-op database.
require_once "../../db_connect.php";
$db = db_connect ();
//Assign the query
$query = $db->prepare("SELECT Volunteers.Volunteer AS Volunteer, 
	Volunteers.Email AS Email, Volunteers.Phone AS Phone, 
	Volunteers.LastTime AS LastTime,Volunteers.TotalHours AS TotalHours, 
	Volunteers.AppDate AS AppDate from Volunteers 
	where (
	(to_days(curdate()) - to_days(Volunteers.AppDate)) < 30) 
	or ((Volunteers.TotalHours >= 3) and ((to_days(curdate()) - to_days(Volunteers.LastTime)) <= 7)) 
	or ((Volunteers.TotalHours >= 10) and ((to_days(curdate()) - to_days(Volunteers.LastTime)) <= 30)) 
	or ((Volunteers.TotalHours >= 20) and ((to_days(curdate()) - to_days(Volunteers.LastTime)) <= 90)) 
	order by Volunteers.TotalHours desc");
$query->execute();

// Fetch & display the results of the query.
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$ct++;
	$volunteer = $result_row["Volunteer"];
	if ($result_row["LastTime"]) {$last = date("m/d/Y",strtotime($result_row["LastTime"]));}
	else {$last = "";}
	$hours = $result_row["TotalHours"];
	$email = $result_row["Email"];
	$phone = $result_row["Phone"];
	if ($result_row["AppDate"]) {$appdate = date("m/d/Y",strtotime($result_row["AppDate"]));}
	echo "<tr>";
	echo "<td>$ct</td>";
	echo "<td>$volunteer</td>";
	echo "<td align='right'>$appdate</td>";
	echo "<td align='right'>$hours</td>";
	echo "<td align='center'>$last</td>";
	echo "<td align='left'>$email</td>";
	echo "<td align='left'>$phone</td>";
	echo "</tr>";
	}
// Finish the page.
?>
	</tbody>
</table>
</div>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
// Free used database resources.
$result->closeCursor();
$db = null;
?>
