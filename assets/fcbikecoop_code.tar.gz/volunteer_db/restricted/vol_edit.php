<?php
/**
	*	vol_edit.php - part of the Fort Collins Bike Co-op system for managing volunteer signups.
	*
	* This script displays a volunteer's record and allow you to update some of the data.
*/
session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
/**
	*	The script assumes that session variables have been set by the calling script.
	* That variable is used to build the "breadcrumb" list that helps the user navigate back.
	*/
// get the variables that will let us get back
	$origin = $_SESSION['origin'];
	if ($origin == "vol_bars")
		{
		$link_back = "<a href='./vol_bars.php'>Volunteers Interested in Bike Retrieval</a>";
		}
	if ($origin == "vol_list")
		{
		$link_back = "<a href='./vol_list.php'>Volunteer List</a>";
		}
	$list = $_SESSION['list'];

// check ALL the POST variables

// get the volunteer to be edited
if (is_null($volid)) {$volid=$_GET['ID'];}

function checkSet(){
	return isset($_POST['firstname'], $_POST['lastname'], $_POST['phone'], $_POST['email'], $_POST['address']);
}
/**
 * This function can be used to check the sanity of variables
 *
 * @access private
 *
 * @param string $type  The type of variable can be bool, float, numeric, string, array, or object
 * @param string $string The variable name you would like to check
 * @param string $length The maximum length of the variable
 *
 * return bool
*/
function sanityCheck($string, $type, $length){
  // assign the type
  $type = 'is_'.$type;

  if(!$type($string))
    {
    return FALSE;
    }
  // now we see if there is anything in the string
  elseif(empty($string))
    {
    return FALSE;
    }
  // then we check how long the string is
  elseif(strlen($string) > $length)
    {
    return FALSE;
    }
  else
    {
    // if all is well, we return TRUE
    return TRUE;
		}
}
// check number is greater than 0 and $length digits long
// returns TRUE on success
function checkNumber($num, $length){
	if($num > 0 && strlen($num) == $length)
		{
		return TRUE;
		}
}
function checkEmail($email){
  return preg_match('/^\S+@[\w\d.-]{2,}\.[\w]{2,6}$/iU', $email) ? TRUE : FALSE;
}
/**
Validate an email address.
Provide email address (raw input)
Returns true if the email address has the email 
address format and the domain exists.
*/
function validEmail($email){
	$isValid = true;
	$atIndex = strrpos($email, "@");
	if (is_bool($atIndex) && !$atIndex)
		{
		$isValid = false;
		}
	else
		{
		$domain = substr($email, $atIndex+1);
		$local = substr($email, 0, $atIndex);
		$localLen = strlen($local);
		$domainLen = strlen($domain);
		if ($localLen < 1 || $localLen > 64)
			{
			// local part length exceeded
			$isValid = false;
			}
		else if ($domainLen < 1 || $domainLen > 255)
			{
			// domain part length exceeded
			$isValid = false;
			}
		else if ($local[0] == '.' || $local[$localLen-1] == '.')
			{
			// local part starts or ends with '.'
			$isValid = false;
			}
		else if (preg_match('/\\.\\./', $local))
			{
			// local part has two consecutive dots
			$isValid = false;
			}
		else if (!preg_match('/^[A-Za-z0-9\\-\\.]+$/', $domain))
			{
			// character not valid in domain part
			$isValid = false;
			}
		else if (preg_match('/\\.\\./', $domain))
			{
			// domain part has two consecutive dots
			$isValid = false;
			}
		else if (!preg_match('/^(\\\\.|[A-Za-z0-9!#%&`_=\\/$\'*+?^{}|~.-])+$/', str_replace("\\\\","",$local)))
			{
			// character not valid in local part unless 
			// local part is quoted
			if (!preg_match('/^"(\\\\"|[^"])+"$/', str_replace("\\\\","",$local)))
				{
				$isValid = false;
				}
			}
		if ($isValid && !(checkdnsrr($domain,"MX") || checkdnsrr($domain,"A")))
			{
			// domain not found in DNS
			$isValid = false;
			}
		}
	return $isValid;
}

// Checks to see if the form has been submitted.
// If it hasn't, PHP ignores heaps of this code and display the form.
// If the form was submitted, it will create variables based on
// form field names and users answers.

// this will be the default message if the form accessed without POSTing
$error_msg="Please fill in the form.<br />";

// Connect to the Bike Co-op database.
require_once "../../db_connect.php";
$db = db_connect ();

// Run the query to get the volunteer record.
$query = $db->prepare("SELECT * FROM VOLUNTEERS WHERE VolID=?");
$query->bindValue(1, $volid, PDO::PARAM_INT);
$query->execute();
//Fetch & display the results
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$status = $result_row["Inactive"];
	if ($status == 0)
			{$active_button = "checked";}
		else
			{$active_button = "";}
	if ($status == 1)
			{$inactive_button = "checked";}
		else
		{	$cancel_button = "";}
	$firstname = $result_row["FirstName"];
	$lastname = $result_row["LastName"];
	$email = $result_row["Email"];
	$phone = $result_row["Phone"];
	$address = $result_row["Address"];
	$city = $result_row["City"];
	$emer_name = $result_row["EmergencyContact"];
	// Change the date format for display purposes.
	if ($dateofbirth > '0000-00-00') {$v_dob = date("m/d/Y",strtotime($dateofbirth));}
	$state = $result_row["State"];
	$zip = $result_row["Zip"];
	$emer_phone = $result_row["EmergencyPhone"];
	$relationship = $result_row["Relationship"];
	$greeter = $result_row["Greeter"];
	$mechanic = $result_row["Mechanic"];
	$recycling = $result_row["Recycling"];
	$bars = $result_row["BARS"];
	$cleaning = $result_row["Clean"];
	$handyman = $result_row["Handyman"];
	$newsletter = $result_row["Newsletter"];
	$art = $result_row["Art"];
	$fundraising = $result_row["Fund"];
	$community = $result_row["Outreach"];
	$local_events = $result_row["Events"];
	$safety = $result_row["BikeSafety"];
	$kidtrips = $result_row["KidTrips"];
	}

if (isset ($_POST['submit']))
	{
	foreach($_POST as $key=>$value)
		{
		$$key = $value;
		}

	// Create an empty error_msg
	$error_msg='';

	if(checkSet() != FALSE)
		{
		// check for valid email address
		if(sanityCheck($_POST['email'], 'string', 50) != FALSE)
			{
			if (validEmail($_POST['email']) != FALSE)
    		{
				$email = $_POST['email'];
				}
			else
				{
				$error_msg.="* invalid Email address<br />";
				}
			}
		else
			{
			if(sanityCheck($_POST['phone'], 'string', 10) != FALSE)
				{
				$phone = $_POST['phone'];
				}
			else
				{
				$error_msg.="* please provide an email address and/or phone number so we can contact you<br />";
				}
			}
		// check the sanity of the zipcode and that it is greater than zero and 5 digits long - it can be left blank
		$zip = substr($_REQUEST['zip'],0,5);
		if(sanityCheck(substr($_POST['zip'],0,5), 'numeric', 5) != FALSE && checkNumber(substr($_POST['zip'],0,5), 5) == TRUE)
			{
			$zip = substr($_POST['zip'],0,5);
			}
		else
			{
			$zip='';
			}
		// convert stuff to initial caps (also handles "loud" text)
		$address = ucwords(strtolower($_POST['address']));
		$city = ucwords(strtolower($_POST['city']));
		$emer_name = ucwords(strtolower($_POST['emer_name']));
		$state = ucwords(strtolower($_POST['state']));
		$emer_phone = $_POST['emer_phone'];
		$relationship = $_POST['relationship'];
		$status = $_POST['status'];
		$greeter = $_POST['greeter'];
		$mechanic = $_POST['mechanic'];
		$recycling = $_POST['recycling'];
		$bars = $_POST['bars'];
		$cleaning = $_POST['cleaning'];
		$handyman = $_POST['handyman'];
		$newsletter = $_POST['newsletter'];
		$art = $_POST['art'];
		$fundraising = $_POST['fundraising'];
		$community = $_POST['community'];
		$local_events = $_POST['local_events'];
		$safety = $_POST['safety'];
		$kidtrips = $_POST['kidtrips'];
		}
	}

// END BASIC ERROR CHECKING
// You need to create your own code to validate the information
// and allowed values - never send "unclean" user responses
// to a database without cleaning them up and
// checking for allowed answers.
// Google for "SQL injection" and "insecure contact form"

// Do this if no errors were detected AND form has been submitted
if ($error_msg == '' && isset($_POST['submit']))
	{
	// Build the SQL statement.
	$update = $db->prepare("UPDATE VOLUNTEERS SET Inactive=:status, Phone=:phone, Email=:email, Address=:address, City=:city, 
	State=:state, Zip=:zip, EmergencyContact=:emer_name, 
	EmergencyPhone=:emer_phone, Relationship=:relationship, Greeter=:greeter, Mechanic=:mechanic, 
	Recycling=:recycling, BARS=:bars, Clean=:cleaning, Handyman=:handyman, Newsletter=:newsletter, 
	Art=:art, Fund=:fundraising, Outreach=:community, Events=:events, KidTrips=:kidtrips, BikeSafety=:safety WHERE VolID = :volid");
	$update->bindValue(':status', $status, PDO::PARAM_STR);
	$update->bindValue(':phone', $phone, PDO::PARAM_STR);
	$update->bindValue(':email', $email, PDO::PARAM_STR);
	$update->bindValue(':address', $address, PDO::PARAM_STR);
	$update->bindValue(':city', $city, PDO::PARAM_STR);
	$update->bindValue(':state', $state, PDO::PARAM_STR);
	$update->bindValue(':zip', $zip, PDO::PARAM_STR);
	$update->bindValue(':emer_name', $emer_name, PDO::PARAM_STR);
	$update->bindValue(':emer_phone', $emer_phone, PDO::PARAM_STR);
	$update->bindValue(':relationship', $relationship, PDO::PARAM_STR);
	$update->bindValue(':greeter', $greeter, PDO::PARAM_STR);
	$update->bindValue(':mechanic', $mechanic, PDO::PARAM_STR);
	$update->bindValue(':recycling', $recycling, PDO::PARAM_STR);
	$update->bindValue(':bars', $bars, PDO::PARAM_STR);
	$update->bindValue(':cleaning', $cleaning, PDO::PARAM_STR);
	$update->bindValue(':handyman', $handyman, PDO::PARAM_STR);
	$update->bindValue(':newsletter', $newsletter, PDO::PARAM_STR);
	$update->bindValue(':art', $art, PDO::PARAM_STR);
	$update->bindValue(':fundraising', $fundraising, PDO::PARAM_STR);
	$update->bindValue(':community', $community, PDO::PARAM_STR);
	$update->bindValue(':events', $local_events, PDO::PARAM_STR);
	$update->bindValue(':kidtrips', $kidtrips, PDO::PARAM_STR);
	$update->bindValue(':safety', $safety, PDO::PARAM_STR);
	$update->bindValue(':volid', $volid, PDO::PARAM_STR);
	try
		{
		// run the update
		$update->execute();
		}
	catch (PDOException $e)
		{
    var_dump($e->getMessage());
    var_dump($db->errorInfo());
    die('....');
		}
// Return to the calling list
	header("Location:".$list.".php");
	exit();
	}

// If PHP is still reading this, it must be the first page visit,
// OR an error was detected.
// Display the HTML page and your signup form.
include_once('/var/www/fcbikecoop.org/root/header.php');

// If the form has been submitted,
// display the error messages above the form.
if ($error_msg <> '' && isset($_POST['submit']))
	{
	echo "<font color=\"yellow\" size=\"3\">The following problems were detected:<br><i>" .$error_msg ."</i></font><br>";
	}
?>

 <!-- "breadcrumbs" -->
			<table cellpadding='5'>
				<tr>
			  <td style='width:0%; white-space:nowrap'>
  			<td> <b>&raquo;</b> <a href='./index.php'>Volunteer Management</a> <b>&raquo;</b><a href='vol_list.php'>Volunteer List</a><b>&raquo;</b>Volunteer Info</td>
				</tr>
			</table>

<form id="editForm" method="POST" action="<?php echo $PHP_SELF;?>" enctype="multipart/form-data">
   <div class="heading">FC Bike Co-op Volunteer Information</div></td>
<table width="550">
	<tr>
		<td align=right width="25%">First Name:</td>
		<td align=left><input name="firstname" type="text" id="firstname" size="35" maxlength="25" readonly="readonly" value="<?php echo $firstname ?>">
	</tr>
	<tr>
		<td align=right width="25%">Last Name:</td>
		<td align=left><input name="lastname" type="text" id="lastname" size="35" maxlength="25" readonly="readonly" value="<?php echo $lastname ?>">
	</tr>
	<tr>
		<td align=right width="25%">Status:</td>
		<td align=left><Input type="Radio" name="status" id="status" class="required" value='0' <?php echo $active_button ?>>Active
			<Input type= "Radio" name="status" id="status" class="required" value='1' <?php echo $inactive_button ?>>Inactive
</td>
	</tr>
	<tr>
		<td align=right width="25%">Phone:</td>
		<td align=left><input name="phone" type="text" id="phone" size="35" maxlength="15" value="<?php echo $phone ?>">
	</tr>
	<tr>
		<td align=right width="25%">Email Address:</td>
		<td align=left><input name="email" type="text" id="email" size="35" maxlength="50" value="<?php echo $email ?>">
	</tr>
	<tr>
		<td align=right width="25%">Address:</td>
		<td align=left><input name="address" type="text" id="address" size="35" maxlength="100" value="<?php echo $address ?>">
	</tr>
	<tr>
		<td align=right width="25%">City:</td>
		<td align=left><input name="city" type="text" id="city" size="35" maxlength="25" value="<?php echo $city ?>">
	</tr>
	<tr>
		<td align=right width="25%">State:</td>
		<td align=left><select name="state" id="state">
			<option value="<?php echo $state ?>" selected="selected"><?php echo $state ?></option>
			<option value="CO">Colorado</option>
			<option value="WY">Wyoming</option>			
			<option value="AL">Alabama</option>
			<option value="AK">Alaska</option>
			<option value="AZ">Arizona</option>
			<option value="AR">Arkansas</option>
			<option value="CA">California</option>
			<option value="CT">Connecticut</option>
			<option value="DC">District of Columbia</option>
			<option value="DE">Delaware</option>
			<option value="FL">Florida</option>
			<option value="GA">Georgia</option>
			<option value="HI">Hawaii</option>
			<option value="ID">Idaho</option>
			<option value="IL">Illinois</option>
			<option value="IN">Indiana</option>
			<option value="IA">Iowa</option>
			<option value="KS">Kansas</option>
			<option value="KY">Kentucky</option>
			<option value="LA">Louisiana</option>
			<option value="ME">Maine</option>
			<option value="MD">Maryland</option>
			<option value="MA">Massachusetts</option>
			<option value="MI">Michigan</option>
			<option value="MN">Minnesota</option>
			<option value="MS">Mississippi</option>
			<option value="MO">Missouri</option>
			<option value="MT">Montana</option>
			<option value="NE">Nebraska</option>
			<option value="NV">Nevada</option>
			<option value="NH">New Hampshire</option>
			<option value="NJ">New Jersey</option>
			<option value="NM">New Mexico</option>
			<option value="NY">New York</option>
			<option value="NC">North Carolina</option>
			<option value="ND">North Dakota</option>
			<option value="OH">Ohio</option>
			<option value="OK">Oklahoma</option>
			<option value="OR">Oregon</option>
			<option value="PA">Pennsylvania</option>
			<option value="RI">Rhode Island</option>
			<option value="SC">South Carolina</option>
			<option value="SD">South Dakota</option>
			<option value="TN">Tennessee</option>
			<option value="TX">Texas</option>
			<option value="UT">Utah</option>
			<option value="VT">Vermont</option>
			<option value="VA">Virginia</option>
			<option value="WA">Washington</option>
			<option value="WV">West Virginia</option>
			<option value="WI">Wisconsin</option>
		</select>
	</tr>
	<tr>
		<td align=right width="25%">Zip Code:</td>
		<td align=left><input name="zip" type="text" id="zip" size="6" maxlength="5" value="<?php echo $zip ?>">
	</tr>
	<tr>
		<td align=left colspan="2"><h2>Emergency Contact</h2></td>
	</tr>
	<tr>
		<td align=right width="25%">Name:</td>
		<td align=left><input name="emer_name" type="text" id="emer_name" size="35" maxlength="50" value="<?php echo $emer_name ?>">
	</tr>
	<tr>
		<td align=right width="25%">Phone:</td>
		<td align=left><input name="emer_phone" type="text" id="emer_phone" size="35" maxlength="15" value="<?php echo $emer_phone ?>">
	</tr>
	<tr>
		<td align=right width="25%">Relationship:</td>
		<td align=left><input name="relationship" type="text" id="relationship" size="35" maxlength="25" value="<?php echo $relationship ?>">
	</tr>
   </table>
   <table width="550">
	<tr>
		<td colspan="2"><h2>Interests as a volunteer.</h2>
	</tr>
	<tr>
		<td width="50% align="right"><input type=checkbox name="greeter" value="1"<?php if ($greeter=="1") { echo 'checked'; } ?>>Front Desk / Retail / Greeter
		<td align="left"><input type=checkbox name="mechanic" value="1"<?php if ($mechanic=="1") { echo 'checked'; } ?>>Bike Mechanic
	</tr>
	<tr>
		<td width="50% align="right"><input type=checkbox name="recycling" value="1"<?php if ($recycling=="1") { echo 'checked'; } ?>>Recycling
		<td align="left"><input type=checkbox name="bars" value="1"<?php if ($bars=="1") { echo 'checked'; } ?>>Bike Retrieval
	</tr>
	<tr>
		<td width="50% align="right"><input type=checkbox name="cleaning" value="1"<?php if ($cleaning=="1") { echo 'checked'; } ?>>Cleaning/Organizing the Shop
		<td align="left"><input type=checkbox name="handyman" value="1"<?php if ($handyman=="1") { echo 'checked'; } ?>>Handyman/Construction
	</tr>
	<tr>
		<td width="50% align="right"><input type=checkbox name="newsletter" value="1"<?php if ($newsletter=="1") { echo 'checked'; } ?>>Newsletter Drafting/PR
		<td align="left"><input type=checkbox name="art" value="1"<?php if ($art=="1") { echo 'checked'; } ?>>Art Contributions / Graphic Design
	</tr>
	<tr>
		<td width="50% align="right"><input type=checkbox name="fundraising" value="1"<?php if ($fundraising=="1") { echo 'checked'; } ?>>Fundraising / Grant Writing
		<td align="left"><input type=checkbox name="community" value="1"<?php if ($community=="1") { echo 'checked'; } ?>>Helping with Community Outreach
	</tr>
	<tr>
		<td width="50% align="right"><input type=checkbox name="local_events" value="1"<?php if ($local_events=="1") { echo 'checked'; } ?>>Assist With Local Bike Events
		<td align="left"><input type=checkbox name="kidtrips" value="1"<?php if ($kidtrips=="1") { echo 'checked'; } ?>>Trips for Kids
	</tr>
	<tr>
		<td width="50% align="right"><input type=checkbox name="safety" value="1"<?php if ($safety=="1") { echo 'checked'; } ?>>Bike Safety Education
	</tr>
</table>

<input type="submit" value="Submit" name="submit">
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
