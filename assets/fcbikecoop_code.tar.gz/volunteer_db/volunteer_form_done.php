<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">Volunteer Signup</div>
         <p>Thank you. You have started the sign-up process.<br><br>
	 <p>Next you will receive an email to confirm that you are, in fact, you.  The subject will be "Your confirmation is required to join the Volunteers mailing list"  It will be from an addres that looks something like volunteers-confirm+f2c700f304454f5c9508bb1adfecf9a42946XXXX@fcbikecoop.org  Just follow the simple directions in the email and you'll recieve a welcome email with directions on how to get tied into the co-op.  If you do not recieve this email, but would still like to be on the mailing list, please email <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "john@fcbikecoop.org");?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">jo...@fcbikecoop.org</a></p>
<a href="http://fcbikecoop.org/volunteers.php">Back To the Volunteer Page</a><br>
	<h2>Thanks for signing up, we're excited that you have decided to lend a hand.</h2>

	<p>Please join us at our volunteer orientation. It's a great way to learn about the different programs at the co-op, meet some people, and and get started. We hold them on the first Wednesday of the month, 6:30 pm at the co-op. 
	<p>Depending on how you filled out the form, you may receive an email directly from one of the program coordinators.
	<p>For folks who can't wait to get started, we put together this list of common questions.</p>
	<h2>How Do I Get Involved?</h2>
	<p>Great question, head on over to our <a href=" http://fcbikecoop.org/programs/">programs page</a></p>
	<p>Every one of these programs is run by our volunteers, and any of these programs could use your help.  If you see any that match your interests, please contact the coordinator to ask how to get involved.  Each page should have the program coordinators email at the bottom.</p>
	<h2>How Does The Shop Work?</h2>
	<p>Probably the best way to learn about the shop itself is to come in during open hours and get a tour of the shop. <a href="http://fcbikecoop.org/calendar.php">Calendar/Hours</a>  Once you're in the shop you can get a feel for what we work on directly with the public, as well as start to get a feel for what goes on behind the scenes.  When things are slow enough, you can even shadow a mechanic and learn some mechanic skills yourself.</p>
	<h2>I'm A Super Duper Skilled Mechanic, Can I Come And Work On Bikes?</h2>
	<p>We'd love to have your help, keep in mind the first couple of times you come in you'll also be learning about shop policy. Once we feel you have a good understanding of the shop you'll be able to help us fix up recovered bikes for our programs, and help teach the public how to work on their bikes.</p>
	<h2>Can I Earn A Bike For My Neighbor/Sister/Son?</h2>
	<p>Volunteering might not be what you're looking for.  You would want to learn about our <a href="http://fcbikecoop.org/programs/earnabike.php">Earn A Bike program</a>.  I don't mean to dissuade you from volunteering, you can do both, but if you're looking to earn a  bike and move along, then by all means do just that.  We're excited to see you out riding in the city.</p>
	<h2>What Benefits Does Volunteering Provide?</h2>
	<p>Volunteering at the co-op instantly makes you twice as attractive, and that's not all.  You'll be joining the most dynamic group supporting all levels of bicycling in Fort Collins, from keeping all bike parts out of the landfill, to providing education, maintenance, and bikes to all levels of the public.  There are multiple benefits for our different levels of volunteers including: access to volunteer only shop days, cool volunteer clothes, prime part picking, and parts at wholesale.  Besides all this you'll get to hang out with our fun-loving bike-riding volunteer corp, meet some new friends, learn some new skills, and help the community all at the same time.</p>
	<p>I'm sure you have a lot of questions that we haven't covered here.  Please feel free to contact us, and help us in our mission of, Building Community Through Bicycling.</p>
Welcome!  -The Fort Collins Bike Co-op Staff
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
