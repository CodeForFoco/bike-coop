<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">Volunteer Signup</div>
         <p>Thank you. You have started the sign-up process.<br><br>
	 Next you will receive an Email from volunteers-bounces@fcbikecoop.org to confirm that you are, in fact, you.  The Email subject will be something like "confirm a224cd058b75f1168140a90acb05b431fdeXXXXX".  Just follow the simple directions in the email and you'll recieve a welcome email with directions on how to get tied into the co-op.
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
