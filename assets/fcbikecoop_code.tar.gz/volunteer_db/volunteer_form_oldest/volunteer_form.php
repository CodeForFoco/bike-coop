<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
   <form action="http://fcbikecoop.org/signup" method="post">
   <div class="heading">FC Bike Co-op Volunteer Application</div></td>
   <table width=550>
   <tr>
      <td align="left" colspan="2">
   </tr>
   <tr>
      <td align="left" colspan="2">This application will let us know of your intent to volunteer and we'll get you plugged into the co-op via email.  After you're tied in and get some volunteer hours under your belt you will be eligible for volunteer privileges.
   </tr>
   <tr>
      <td align=right width="25%">First Name:</td>
      <td align=left><input name="firstname" type="text" id="firstname" size="35">
   </tr>
   <tr>
      <td align=right width="25%">Last Name:</td>
      <td align=left><input name="lastname" type="text" id="lastname" size="35">
   </tr>
   <tr>
      <td align=right width="25%">Phone:</td>
      <td align=left><input name="phone" type="text" id="phone" size="35">
   </tr>
   <tr>
      <td align=right width="25%">Email Address:</td>
      <td align=left><input name="email" type="text" id="email" size="35">
   </tr>
   <tr>
      <td align=right width="25%">Date of Birth:</td>
      <td align=left><input name="dateofbirth" type="text" id="dateofbirth" size="35">
   </tr>
   <tr>
      <td align=right width="25%">Address:</td>
      <td align=left><input name="address" type="text" id="address" size="35">
   </tr>
   <tr>
      <td align=right width="25%">City:</td>
      <td align=left><input name="city" type="text" id="city" size="35">
   </tr>
   <tr>
      <td align=right width="25%">State:</td>
      <td align=left><input name="state" type="text" id="state" size="35">
   </tr>
   <tr>
      <td align=right width="25%">Zip Code:</td>
      <td align=left><input name="zip" type="text" id="zip" size="35">
   </tr>
   <tr>
      <td align="left" colspan="2"><h2>Emergency Contact</h2></td>
   </tr>
   <tr>
      <td align=right width="25%">Name:</td>
      <td align=left><input name="emer_name" type="text" id="emer_name" size="35">
   </tr>
   <tr>
      <td align=right width="25%">Phone:</td>
      <td align=left><input name="emer_phone" type="text" id="emer_phone" size="35">
   </tr>
   <tr>
      <td align=right width="25%">Relationship:</td>
      <td align=left><input name="relationship" type="text" id="relationship" size="35">
   </tr>
   <tr>
      <td align="left" colspan="2"><h2>Experience</h2></td>
   </tr>
   <tr>
      <td align=left colspan="2">How did you learn about the Co-op?</td>
   </tr>
      <td align=left colspan="2"><input type=hidden name="how_learn" value="NULL"><textarea name="how_learn" rows="5" cols="65" wrap="virtual"></textarea>
   </tr>
   <tr>
      <td align=left colspan="2">Do you have any prior experience fixing bikes? Explain...</td>
   </tr>
      <td align=left colspan="2"><input type=hidden name="experience" value="NULL"><textarea name="experience" rows="5" cols="65" wrap="virtual"></textarea>
   </tr>
   <tr>
      <td align=left colspan="2">Do you have any other skills that may help the Co-op?</td>
   </tr>
      <td align=left colspan="2"><input type=hidden name="other_skills" value="NULL"><textarea name="other_skills" rows="5" cols="65" wrap="virtual"></textarea>
   </tr>
   <tr>
      <td align="left" colspan="2">How skilled are you with tools?</td>
   </tr>
   <tr>
      <td align="left" colspan="2"><select name="skill">
         <option value="0">0</option>
         <option value="1">1</option>
         <option value="2">2</option>
         <option value="3">3</option>
         <option value="4">4</option>
         <option value="5">5</option>
         <option value="6">6</option>
         <option value="7">7</option>
         <option value="8">8</option>
         <option value="9">9</option>
         <option value="10">10</option></select></td>
   </tr>
   </table>
   <table width="550">
   <tr>
      <td colspan="2"><h2>Interests as a volunteer.</h2>
   </tr>
   <tr>
      <td width="50% align="right"><input type=hidden name="sorting" value="NULL"><input type=checkbox name="sorting" value="x">Sorting Out Donations
      <td align="left"><input type=hidden name="fixing" value="NULL"><input type=checkbox name="fixing" value="x">Fixing Bikes
   </tr>
   <tr>
      <td width="50% align="right"><input type=hidden name="teaching" value="NULL"><input type=checkbox name="teaching" value="x">Teaching People How-To's
      <td align="left"><input type=hidden name="cleaning" value="NULL"><input type=checkbox name="cleaning" value="x">Cleaning/Organizing the Shop
   </tr>
   <tr>
      <td width="50% align="right"><input type=hidden name="community" value="NULL"><input type=checkbox name="community" value="x">Helping with Community Outreach
      <td align="left"><input type=hidden name="fundraising" value="NULL"><input type=checkbox name="fundraising" value="x">Fundraising
   </tr>
   <tr>
      <td width="50% align="right"><input type=hidden name="grant_writing" value="NULL"><input type=checkbox name="grant_writing" value="x">Grant Writing
      <td align="left"><input type=hidden name="web_design" value="NULL"><input type=checkbox name="web_design" value="x">Web Design
   </tr>
   <tr>
      <td width="50% align="right"><input type=hidden name="graphic_design" value="NULL"><input type=checkbox name="graphic_design" value="x">Graphic Design
      <td align="left"><input type=hidden name="art" value="NULL"><input type=checkbox name="art" value="x">Art Contributions
   </tr>
   <tr>
      <td width="50% align="right"><input type=hidden name="valet" value="NULL"><input type=checkbox name="valet" value="x">Bicycle Valet
      <td align="left"><input type=hidden name="newsletter" value="NULL"><input type=checkbox name="newsletter" value="x">Newsletter Drafting/PR
   </tr>
   <tr>
      <td width="50% align="right"><input type=hidden name="volunteer_recruit" value="NULL"><input type=checkbox name="volunteer_recruit" value="x">Volunteer Recruitment/Coordination
      <td align="left"><input type=hidden name="local_events" value="NULL"><input type=checkbox name="local_events" value="x">Assist With Local Bike Events
   </tr>
   <tr>
      <td align=left colspan="2">What are your expectations out of volunteering for the Co-op?</td>
   </tr>
   <tr>
      <td align=left colspan="2"><input type=hidden name="expectations" value="NULL"><textarea name="expectations" rows="5" cols="65" wrap="virtual"></textarea>
   </tr>
   <tr>
   </table>
   <!--<table width="550">
   <tr>
      <td colspan="2"><h2>Availability</h2>
   </tr>
   <tr>
      <td align="left">Monday
      <td align="left"><input type=hidden name="monday_morning" value="NULL"><input type=checkbox name="monday_morning" value="x">Morning
      <td align="left"><input type=hidden name="monday_afternoon" value="NULL"><input type=checkbox name="monday_afternoon" value="x">Afternoon
      <td width="50%" align="left"><input type=hidden name="monday_evening" value="NULL"><input type=checkbox name="monday_evening" value="x">Evening
   </tr>
   <tr>
      <td align="left">Tuesday
      <td align="left"><input type=hidden name="tuesday_morning" value="NULL"><input type=checkbox name="tuesday_morning" value="x">Morning
      <td align="left"><input type=hidden name="tuesday_afternoon" value="NULL"><input type=checkbox name="tuesday_afternoon" value="x">Afternoon
      <td width="50%" align="left"><input type=hidden name="tuesday_evening" value="NULL"><input type=checkbox name="tuesday_evening" value="x">Evening
   </tr>
   <tr>
      <td align="left">Wednesday
      <td align="left"><input type=hidden name="wednesday_morning" value="NULL"><input type=checkbox name="wednesday_morning" value="x">Morning
      <td align="left"><input type=hidden name="wednesday_afternoon" value="NULL"><input type=checkbox name="wednesday_afternoon" value="x">Afternoon
   <td width="50%" align="left"><input type=hidden name="wednesday_evening" value="NULL"><input type=checkbox name="wednesday_evening" value="x">Evening
   </tr>
   <tr>
      <td align="left">Thursday
      <td align="left"><input type=hidden name="thursday_morning" value="NULL"><input type=checkbox name="thursday_morning" value="x">Morning
      <td align="left"><input type=hidden name="thursday_afternoon" value="NULL"><input type=checkbox name="thursday_afternoon" value="x">Afternoon
      <td width="50%" align="left"><input type=hidden name="thursday_evening" value="NULL"><input type=checkbox name="thursday_evening" value="x">Evening
   </tr>
   <tr>
      <td align="left">Friday
      <td align="left"><input type=hidden name="friday_morning" value="NULL"><input type=checkbox name="friday_morning" value="x">Morning
      <td align="left"><input type=hidden name="friday_afternoon" value="NULL"><input type=checkbox name="friday_afternoon" value="x">Afternoon
      <td width="50%" align="left"><input type=hidden name="friday_evening" value="NULL"><input type=checkbox name="friday_evening" value="x">Evening
   </tr>
   <tr>
      <td align="left">Saturday
      <td align="left"><input type=hidden name="saturday_morning" value="NULL"><input type=checkbox name="saturday_morning" value="x">Morning
      <td align="left"><input type=hidden name="saturday_afternoon" value="NULL"><input type=checkbox name="saturday_afternoon" value="x">Afternoon
      <td width="50%" align="left"><input type=hidden name="saturday_evening" value="NULL"><input type=checkbox name="saturday_evening" value="x">Evening
   </tr>
   <tr>
      <td align="left">Sunday
      <td align="left"><input type=hidden name="sunday_morning" value="NULL"><input type=checkbox name="sunday_morning" value="x">Morning
      <td align="left"><input type=hidden name="sunday_afternoon" value="NULL"><input type=checkbox name="sunday_afternoon" value="x">Afternoon
      <td width="50%" align="left"><input type=hidden name="sunday_evening" value="NULL"><input type=checkbox name="sunday_evening" value="x">Evening
   </tr>
   </table>
   <table width="550">-->
   <tr>Any other questions, comments, or concerns?
   </tr>
   <tr><input type=hidden name="concerns" value="NULL"><textarea name="concerns" rows="5" cols="65" wrap="virtual"></textarea>
   </tr>
   </table>
   <br>
      <h3>This is not an application for the Earn-a-Bike program.
      Stop by during <a href="http://fcbikecoop.org/calendar.php">public hours</a> to start the Earn-a-Bike Program.</h3>
   <input type="submit" value="Send"><input type="reset"><br><br>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
