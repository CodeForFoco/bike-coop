<?php
// check ALL the POST variables
	function checkSet(){
		return isset($_POST['firstname'], $_POST['lastname'], $_POST['phone'], $_POST['email'], $_POST['address']);
	}
	if(checkSet() != FALSE)
        	{
		// this is where the checking starts
		}
        $firstname = $_REQUEST['firstname'];
	$lastname = $_REQUEST['lastname'];
	$phone = $_REQUEST['phone'];
	$email = $_REQUEST['email'];
	$dateofbirth = $_REQUEST['dateofbirth'];
	$address = $_REQUEST['address'];
	$city = $_REQUEST['city'];
	$state = $_REQUEST['state'];
	$zip = $_REQUEST['zip'];
	$emer_name = $_REQUEST['emer_name'];
	$emer_phone = $_REQUEST['emer_phone'];
	$relationship = $_REQUEST['relationship'];
	$how_learn = $_REQUEST['how_learn'];
	$experience = $_REQUEST['experience'];
	$other_skills = $_REQUEST['other_skills'];
	$skill = $_REQUEST['skill'];
	$sorting = $_REQUEST['sorting'];
	$fixing = $_REQUEST['fixing'];
	$teaching = $_REQUEST['teaching'];
	$cleaning = $_REQUEST['cleaning'];
	$community = $_REQUEST['community'];
	$fundraising = $_REQUEST['fundraising'];
	$grant_writing = $_REQUEST['grant_writing'];
	$web_design = $_REQUEST['web_design'];
	$graphic_design = $_REQUEST['graphic_design'];
	$art = $_REQUEST['art'];
	$expectations = $_REQUEST['expectations'];
	$concerns = $_REQUEST['concerns'];
	$monday_morning = $_REQUEST['monday_morning'];
	$monday_afternoon = $_REQUEST['monday_afternoon'];
	$monday_evening = $_REQUEST['monday_evening'];
	$tuesday_morning = $_REQUEST['tuesday_morning'];
	$tuesday_afternoon = $_REQUEST['tuesday_afternoon'];
	$tuesday_evening = $_REQUEST['tuesday_evening'];
	$wednesday_morning = $_REQUEST['wednesday_morning'];
	$wednesday_afternoon = $_REQUEST['wednesday_afternoon'];
	$wednesday_evening = $_REQUEST['wednesday_evening'];
	$thursday_morning = $_REQUEST['thursday_morning'];
	$thursday_afternoon = $_REQUEST['thursday_afternoon'];
	$thursday_evening = $_REQUEST['thursday_evening'];
	$friday_morning = $_REQUEST['friday_morning'];
	$friday_afternoon = $_REQUEST['friday_afternoon'];
	$friday_evening = $_REQUEST['friday_evening'];
	$saturday_morning = $_REQUEST['saturday_morning'];
	$saturday_afternoon = $_REQUEST['saturday_afternoon'];
	$saturday_evening = $_REQUEST['saturday_evening'];
	$sunday_morning = $_REQUEST['sunday_morning'];
	$sunday_afternoon = $_REQUEST['sunday_afternoon'];
	$sunday_evening = $_REQUEST['sunday_evening'];
	
require_once('recaptchalib.php');
$privatekey = "6LcljgQAAAAAAPouSflWvq1dlfio5lRYJ4RvEsGt";
$publickey = "6LcljgQAAAAAAL1T9O8K4Rv0n3at7RUhFQBsLnoG";
$resp = recaptcha_check_answer ($privatekey,
				$_SERVER["REMOTE_ADDR"],
				$_POST["recaptcha_challenge_field"],
				$_POST["recaptcha_response_field"]);
   if ($resp->is_valid) {
      mail( "john@fcbikecoop.org", "[fcbikecoop] New Volunteer - $lastname, $firstname",
"New Volunteer Info

$lastname, $firstname
$address
$city, $state
$zip
$email
$phone
Born: $dateofbirth

Emergency Contact
$emer_name
$emer_phone
$relationship

How did they learn about the Co-op?
$how_learn

Prior Experience
$experience

Other Skills
$other_skills

Tool Skill Level \(1-10\)
$skill

Interests as a volunteer

$sorting Sorting Out Donations
$fixing Fixing Bicycles
$teaching Teaching People How-To's
$cleaning Cleaning/Organizing the Shop
$community Helping with Community Outreach
$fundraising Fundraising
$grant_writing Grant Writing
$web_design Web Design
$graphic_design Graphic Design
$art Art Contributions

What are the Volunteers expectations from the Co-op?
$expectations

Other questions, comments, or concerns.
$concerns

Availability

$monday_morning Morning   $monday_afternoon Afternoon   $monday_evening Evening Monday
$tuesday_morning Morning   $tuesday_afternoon Afternoon   $tuesday_evening Evening Tuesday
$wednesday_morning Morning   $wednesday_afternoon Afternoon   $wednesday_evening Evening Wednesday
$thursday_morning Morning   $thursday_afternoon Afternoon   $thursday_evening Evening Thursday
$friday_morning Morning   $friday_afternoon Afternoon   $friday_evening Evening Friday
$saturday_morning Morning   $saturday_afternoon Afternoon   $saturday_evening Evening Saturday
$sunday_morning Morning   $sunday_afternoon Afternoon   $sunday_evening Evening Sunday

Database Listing
$firstname\\$lastname\\$address\\$city\\$state\\$zip\\$email\\$phone\\$dateofbirth\\$emer_name\\$emer_phone\\$relationship\\$how_learn\\$experience\\$other_skills\\$skill\\$sorting\\$fixing\\$teaching\\$cleaning\\$community\\$fundraising\\$grant_writing\\$web_design\\$graphic_design\\$art\\$expectations\\$concerns\\$monday_morning\\$monday_afternoon\\$monday_evening\\$tuesday_morning\\$tuesday_afternoon\\$tuesday_evening\\$wednesday_morning\\$wednesday_afternoon\\$wednesday_evening\\$thursday_morning\\$thursday_afternoon\\$thursday_evening\\$friday_morning\\$friday_afternoon\\$friday_evening\\$saturday_morning\\$saturday_afternoon\\$saturday_evening\\$sunday_morning\\$sunday_afternoon\\$sunday_evening",

"From: webmaster@fcbikecoop.org");
   }
   if (!$resp->is_valid) {
       $error = $resp->error;
       echo "<html>
	<body>
	   Incorrect pass-phrase response.  Please go back and try again
	</body>
	</html>";
   }
   else {
   }
include_once('/var/www/fcbikecoop.org/root/volunteer_forms/volunteer_form_done.php');
?>
