<?php
# db_connect.php - function for connecting to the Bike Coop database
function db_connect ()
	{
	if (empty($_SERVER['db_username']))
		{
    echo 'missing db_username, SetEnv missing in apache config?<br>';
    echo '<hr>';
    phpinfo();
    exit;
		}
	$db_host = $_SERVER['db_host'];
	$db_username = $_SERVER['db_username'];
	$db_password = $_SERVER['db_password'];
	$db_database = $_SERVER['db_database'];
	$dsn = "mysql:host=".$db_host";dbname=".$db_database;
	$db = new PDO($dsn, $db_username, $db_password);
	$db->setAttribute (PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
	return ($db);
	}
?>
