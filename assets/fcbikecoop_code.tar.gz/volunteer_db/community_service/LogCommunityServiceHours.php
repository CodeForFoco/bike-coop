<?php
/**
	*	LogComunityServiceHours.php - part of the Fort Collins Bike Co-op system for managing volunteer work.
	*
	* This script lets work nght leaders log community service volunteers' hours.
*/
session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once($_SERVER['DOCUMENT_ROOT'].'header.php');
?>
<!-- We will be using JQuery functions and JavaScript for processing the form. -->
<script type='text/javascript' src='/js/jquery.min.js'></script>
<script type='text/javascript' src='/js/jquery.validate.min.js'></script>
<!-- The following script does form data validation -->
<script src="gen_validatorv4.js" type="text/javascript"></script>
<script type='text/javascript' src='./community_service.js'></script>
<script language="JavaScript">
var gAutoPrint = true; // Tells whether to automatically call the print function

function printSpecial()
	{
	if (document.getElementById != null)
		{
		var html = '<HTML>\n<HEAD>\n';
		html += '\n</HEAD>\n<BODY>\n<h1>Fort Collins Bike Co-op</h1>\n';
		var printHdrElem = document.getElementById("volhdr");
		html += printHdrElem.innerHTML;
		var printReadyElem = document.getElementById("printReady");
		if (printReadyElem != null)
			{html += printReadyElem.innerHTML;}
		else
			{
			alert("Could not find the printReady function");
			return;
			}
		var printTotElem = document.getElementById("TotPrt");
		html += printTotElem.innerHTML;
		html += '\n</BO>\n</HT>';
		var printWin = window.open("","printSpecial");
		printWin.document.open();
		printWin.document.write(html);
		printWin.document.close();
		if (gAutoPrint) printWin.print();
		}
	else
		{
		alert("The print ready feature is only available if you are using a current browser. Please update your browswer.");
		}
	}
</script>

<html>
<!-- "breadcrumbs" -->
<table cellpadding='5'>
	<tr>
		<td style='width:0%; white-space:nowrap'>
		<td><a href='./index.php'>Community Service</a> <b>&raquo;</b><a href='./CSvolSelect.php'>Select Volunteer</a>  <b>&raquo;</b>Volunteer Hours</td>
	</tr>
</table>
<?php
// Connect to the Bike Co-op database.
require_once($_SERVER['DOCUMENT_ROOT'].'db_connect.php');
$db = db_connect ();

if(isset($_POST['volunteer']))
	{
	$volid = $_POST['volunteer'];
	$_SESSION['volid'] = $volid;
	}
else
	{
	$volid = $_SESSION['volid'];
	}

// Get the volunteer's name
$query = $db->prepare("SELECT * FROM CommunityServiceVolunteers WHERE VolID=?");
$query->bindValue(1, $volid, PDO::PARAM_INT);
$query->execute();
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$volname = $result_row["FirstName"].' '.$result_row["LastName"];
	$reason = $result_row["Reason"];
	}
$query->closeCursor();

?>
<div class="heading" id="volhdr">Community Service Hours for <?php echo $volname;?></div>
<script src="../CalendarPopup.js" type="text/javascript"></script>
<script LANGUAGE="JavaScript" ID="js1">
var cal1 = new CalendarPopup();
</script>

<form id="logForm" method="post" action="<?php echo $PHP_SELF;?>">
<!-- unused field to stop browsers from overriding form style -->
<input type='password' style = 'display:none' />
<!-- Build the fields for adding hours. -->
<?php
//Get the list of authorized volunteers
try
	{
	$query = $db->prepare("SELECT * FROM CommunityServiceSupervisors");
	$query->execute();
	}
catch (PDOException $e)
	{
	print ("The statement failed.\n");
	echo "boo-boo";
	echo "getMessage(): " . $e->getMessage () . "\n";
	}

//Fetch the names for use in the supervisor selection list
$options="";
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$supervisor = $result_row["Volunteer"];
	$options.="<OPTION VALUE=\"$supervisor\">$supervisor</option>";
	}
?>
<label for='supervisor'>Bike Co-op Supervisor: </label>
<select id="supervisor" name="supervisor">
				<option value="000" selected>Work Night Leader</option>"
				<?=$options?>
			</select>
<label for='password'>password: </label>
<input type="password" name="password" id="password" size=10 autocomplete="off">
<p>Click on the calendar icon to select a date or enter a date (in mm/dd/yyyy format), select hours and/or minutes, type the password and click on submit.</p>
Date:  
<input type="text" name="volDate" size=10 id="volDate" value="<?php echo date('m/d/Y');?>">
<a href="#" onClick="cal1.select(document.forms[0].volDate,'anchor1','MM/dd/yyyy'); return false;" title="Click on the calendar icon to select a date." name="anchor1" id="anchor1"><input type="image" src="http://fcbikecoop.org/script/iconCalendar.gif"></a>
 Hours:   
<select id='volHrs' name='volHrs'>
<option value='00'>00</option>
<option value='01'>01</option>
<option value='02'>02</option>
<option value='03'>03</option>
<option value='04'>04</option>
<option value='05'>05</option>
<option value='06'>06</option>
<option value='07'>07</option>
<option value='08'>08</option>
<option value='09'>09</option>
<option value='10'>10</option>
<option value='11'>11</option>
<option value='12'>12</option>
<option value='13'>13</option>
<option value='14'>14</option>
<option value='15'>15</option>
<option value='16'>16</option>
<option value='17'>17</option>
<option value='18'>18</option>
<option value='19'>19</option>
<option value='20'>20</option>
<option value='21'>21</option>
<option value='22'>22</option>
<option value='23'>23</option>
</select>
:
<select id='volMin' name='volMin'>
<option value='00'>00</option>
<option value='25'>15</option>
<option value='50'>30</option>
<option value='75'>45</option>
</select>
<input type="submit" name="Submit" value="submit">

<style>
div.error_strings ul {border: 1px solid;}
</style>
<div id='logForm_errorloc' class='error_strings'></div>

<br>
</form>
<script  type="text/javascript">
	function DoCustomValidation()
		{
		var frm = document.forms["logForm"];
		if(frm.password.value != "FCB1keC00p")
			{
			sfm_show_error_msg("Please enter the correct password!",frm.password);
			return false;
			}
		else
			{
			return true;
			}
		};
 var frmvalidator = new Validator("logForm");
 frmvalidator.setAddnlValidationFunction(DoCustomValidation);
 frmvalidator.addValidation("supervisor","dontselect=000","<i>Please select your name from the drop-down list</i>");
 frmvalidator.EnableOnPageErrorDisplaySingleBox();
 frmvalidator.EnableMsgsTogether();
</script>

<?php
// If form has been submitted, post the record to the CommunityServiceTimecards table.
if (isset($_POST['Submit']))
	{
	$supervisor = ucwords($_POST['supervisor']);
	$volDate = $_POST['volDate'];
	$volHrs = $_POST['volHrs'];
	$volMin = $_POST['volMin'];
	$volHours = $volHrs.".".$volMin;
	if($volHours > 0 && !empty($volDate))
		{
		// Add the timecard record
		$query = $db->prepare("INSERT HIGH_PRIORITY INTO CommunityServiceTimecards(VolID,vDate,Hours,Supervisor) 
		VALUES(:volid, STR_TO_DATE(:voldate, '%m/%d/%Y'), :volhours, :supervisor)");
		$query->bindValue(':volid', $volid, PDO::PARAM_STR);
		$query->bindValue(':voldate', $volDate, PDO::PARAM_STR);
		$query->bindValue(':volhours', $volHours, PDO::PARAM_STR);
		$query->bindValue(':supervisor', $supervisor, PDO::PARAM_STR);
		$query->execute();
		}
	}

// Get the total hours for this volunteer
$query = $db->prepare("SELECT SUM(Hours) FROM CommunityServiceTimecards WHERE VolID= ?");
$query->bindValue(1, $volid, PDO::PARAM_INT);
$query->execute();
$tothours = $query->fetchColumn();
if ($tothours == "") {$tothours=0;}
echo "<h4 id='TotPrt'>Total Hours for ".$volname.":  ".$tothours."</h5>\n";
$query->closeCursor();

// Set up to display the hours log
echo "<h2>Hours Log</h2>";
echo "			
	<div id=printReady>
	<table border=2>
		<tr><th>Date</th><th>Hours</th><th>Supervisor</th></tr>";
//Fetch & display the results, sorted by ascending date.
$query = $db->prepare("SELECT * FROM CommunityServiceTimecards WHERE VolID=? ORDER BY vDate ASC");
$query->bindValue(1, $volid, PDO::PARAM_INT);
$query->execute();
//Fetch & display the results
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$vdate = date("m/d/Y",strtotime($result_row["vDate"]));
	$vhours = $result_row["Hours"];
	$supervisor = $result_row["Supervisor"];
	echo "<tr><td>$vdate</td><td align='center'>$vhours</td><td>$supervisor</td></tr>";
	}

// Finish the page.
echo "</tr>";
echo "</table>";
echo "</div>";
echo "<form id='printMe' name='printMe'>
		<input type='button' name='printMe' onClick='printSpecial()' value='Print the Table'>
		</form>";
include_once($_SERVER['DOCUMENT_ROOT'].'footer.php');
// Free used database resources.
$query->closeCursor();
$db = null;
?>
