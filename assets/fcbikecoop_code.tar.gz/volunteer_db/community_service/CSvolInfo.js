$(document).ready(function()
	{
	// the volunteer id is on the page for use in this script, but it should not be displayed.
	document.getElementById('volid').style.display = 'none';
	// handle the changed in the status radio buttons
	$('input:radio[name=status]').click(function(){
	    var volid = $("p#volid").text();
    	if ($('input[name=status]:checked').val() == "completed") {var status = "C";}
    	else {var status = "A";}
    	updateVolStatus(volid,status);
    	});
	}); // END document.ready

function updateVolStatus(volid,status) {
   	var data = 'volid='+volid+'&status='+status;
	$.ajax({url: './ajax-updateVolStatus.php?' + data,
			type: "POST",
			success: function(output) {
				alert(output);
				window.close();
				}
	}); //END ajax
	window.opener.location.reload(true);

}; // END updateVolStatus

