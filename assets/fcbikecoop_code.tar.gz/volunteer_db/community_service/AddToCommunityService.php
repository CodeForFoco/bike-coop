<?php
/**
	*	AddToComunityServiceHours.php - part of the Fort Collins Bike Co-op system for managing community service volunteer work.
	*
	* This script lets work nght leaders add a community service volunteer to the system.
*/
$current_page = htmlentities($_SERVER['PHP_SELF']);
//Connect to the Bike Co-op database
require_once($_SERVER['DOCUMENT_ROOT'].'db_connect.php');
$db = db_connect ();

// If form has been submitted, post the record to the CommunityService table.
if(isset($_POST['Submit']))
	{
	$reason=$_POST['reason'];
	if ($reason == 'other'){$reason=ucwords($_POST['other']);}
	$firstname=ucwords($_POST['firstname']);
	$lastname=ucwords($_POST['lastname']);
	$dob=$_POST['dob'];
	$address=ucwords($_POST['address']);
	$phone=$_POST['phone'];
	$emer_name=ucwords($_POST['emer_name']);
	$emer_phone=$_POST['emer_phone'];
	$insert = $db->prepare("INSERT INTO CommunityServiceVolunteers (Reason, FirstName, LastName, DOB, Address, Phone, EmergencyContact, EmergencyPhone) VALUES  (:reason, :firstname, :lastname, :dob, :address, :phone, :econtact, :ephone)");
	$insert->bindValue(':reason', $reason, PDO::PARAM_STR);
	$insert->bindValue(':firstname', $firstname, PDO::PARAM_STR);
	$insert->bindValue(':lastname', $lastname, PDO::PARAM_STR);
	$insert->bindValue(':dob', $dob, PDO::PARAM_STR);
	$insert->bindValue(':address', $address, PDO::PARAM_STR);
	$insert->bindValue(':phone', $phone, PDO::PARAM_STR);
	$insert->bindValue(':econtact', $emer_name, PDO::PARAM_STR);
	$insert->bindValue(':ephone', $emer_phone, PDO::PARAM_STR);

	try
		{
		// run the query
		$insert->execute();
		$log = $db->lastInsertId();
		}
	catch (PDOException $e)
		{
/**
		header("Location:index.php");
		echo "The statement failed.\n";
		echo "getCode: ". $e->getCode () . "\n";
		echo "getMessage: ". $e->getMessage () . "\n";
		*/
		unset($_POST['submit']); // reset since the insert failed
		echo "<script>alert('".$firstname." ".$lastname.", born ".$dob." is already in the system.');window.location.href='index.php';</script>";
		exit();
		}
	// No errors were detected - go back to the Community Service home page.
	header("Location:index.php");
	exit();
	}

// If PHP is still reading this, it must be the first page visit,
// OR an error was detected.
// Display the HTML page and your signup form.
include_once($_SERVER['DOCUMENT_ROOT'].'header.php');
?>
<link rel="stylesheet" href="form.css" type="text/css" media="screen" charset="utf-8"/>
<!-- We will be using JQuery functions and JavaScript for processing the form. -->
<script type='text/javascript' src='../jquery-1.7.1.min.js'></script>
<script type='text/javascript' src='../jquery.validate.min.js'></script>
<!-- The following script does form data validation -->
<script type='text/javascript' src='./community_service.js'></script>
<html>
 <!-- "breadcrumbs" -->
	<table cellpadding='5'>
		<tr>
	  		<td style='width:0%; white-space:nowrap'>
	  		<td> <a href='./index.php'>Community Service</a> <b>&raquo;</b> Community Service Volunteer</td>
		</tr>
	</table>
<div class="heading">Community Service Volunteer Data Sheet</div>
<form id="appForm" method="POST" action="<?php echo $PHP_SELF;?>" enctype="multipart/form-data">
<p>Note: Information in fields marked "**" is required.
<p>Reason:
<input type='Radio' name='reason' class='required' value='court ordered'>court ordered
<input type='Radio' name='reason' value='other'>other
<input type='text' id='other' name='other' size=25 placeholder='specify the reason'> **
<p>
<fieldset>
<legend>Volunteer</legend>
<div>
<label for="firstname">First Name: </label><input type="text" id="firstname" name="firstname" size=35 value="<?php echo $firstname ?>">**
</div>
<div>
<label for="lastname">Last Name: </label><input type="text" id="lastname" name="lastname" size=35 maxlength="25" value="<?php echo $lastname ?>">**
</div>
<div>
<label for="dob">Date of Birth: </label><input type="text" id="dob" name="dob" size=10 maxlength="10" placeholder="(MM/DD/YYYY)" value="<?php echo $dob ?>">**
</div>
<div>
<label for="address">Address: </label><input type="text" id="address" name="address" size=35 maxlength="100" value="<?php echo $address ?>">
</div>
<div>
<label for="phone">Phone: </label><input type="text" id="phone" name="phone" size=35 maxlength="15" value="<?php echo $phone ?>">
</div>
</fieldset>
<fieldset>
<legend>Emergency Contact</legend>
<div>
<label for="emer_name">Name: </label><input name="emer_name" type="text" id="emer_name" size="35" maxlength="50" value="<?php echo $emer_name ?>">
</div>
<div>
<label for="emer_phone">Phone: </label><input name="emer_phone" type="text" id="emer_phone" size="35" maxlength="15" value="<?php echo $emer_phone ?>">
</div>
</fieldset>
<p>Enter the information and click on submit.
<input type="submit" name="Submit" value="submit">
</form>
<?php
// Free used database resources.
$result->closeCursor();
$db = null;
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
