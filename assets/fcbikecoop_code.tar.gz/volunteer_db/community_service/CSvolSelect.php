<?php
/**
	*	CSvolSelect.php - part of the Fort Collins Bike Co-op system for managing volunteer work.
	*
	* This script presents a selection list of the community service volunteers.
*/
session_start();
$_SESSION['origin']="CSvolSelect";
$action = "./LogCommunityServiceHours.php";
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<!-- We will be using JQuery functions and JavaScript for processing the form. -->
<script type='text/javascript' src='/js/jquery.min.js'></script>
<script type='text/javascript' src='/js/jquery.validate.min.js'></script>
<!-- The following script does form data validation -->
<script type='text/javascript' src='./community_service.js'></script>
<!-- "breadcrumbs" -->
<table cellpadding='5'>
	<tr>
		<td style='width:0%; white-space:nowrap'>
		<td><a href='./index.php'>Community Service</a> <b>&raquo;</b>Select Volunteer</td>
	</tr>
</table>
<div class="heading">Select the Volunteer</div>
<?php
// Connect to the Bike Co-op database.
require_once($_SERVER['DOCUMENT_ROOT'].'db_connect.php');
$db = db_connect ();

//Get the volunteer names from the database
$query = $db->prepare("SELECT VolID, CONCAT(FirstName, ' ', LastName) as Name, DOB FROM CommunityServiceVolunteers WHERE Status='A' ORDER BY LastName ASC");
$query->execute();

//Fetch & display the results
$options="Volunteer";
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$volid=$result_row["VolID"];
	$volname = $result_row["Name"];
	$dob = $result_row["DOB"];
	$options.="<OPTION VALUE=\"$volid\">$volname, born $dob</option>";
	}
$_SESSION['volid'] = "";

echo "<form id='select' method='post' action='".$action."'>"
?>
<p>Find the name in the drop-down list and then click on the Select button.
<br>Names are listed alphabetically by last name (as entered on the volunteer application).
<br>If the name is not on the list, please <a href=./AddToCommunityService.php>fill out a community service volunteer application</a>.
<p>
<SELECT size="1" id="volunteer" name="volunteer">
<OPTION SELECTED VALUE = "\"<?php echo $volid ?>\">
<?php echo $options ?>
</SELECT>
<input type="submit" name="Select" value="Select">
<?php
// Write out the variables into the session and close it
$_SESSION['volid'] = $volid;

// Finish the page.
echo "</table>";
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
