<?php
/**
	*	CSvolList.php - part of the Fort Collins Bike Co-op system for managing volunteer work.
	*
	* This script lists community service volunteers & their total hours.
*/
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<!-- Start building the page. 
<!-- "breadcrumbs" -->
<table cellpadding='5'>
	<tr>
		<td style='width:0%; white-space:nowrap'>
		<td><a href='./index.php'>Community Service</a> <b>&raquo;</b>Volunteer List</td>
	</tr>
</table>
<div class="heading">Community Service Volunteers</div>
<p>Click on a volunteer's name to view their records.
<table border=2 style="font-size:14px;" cellpadding="5">
	<thead>
		<tr>
			<th>Volunteer</th><th>Birthday</th><th>Total Hours</th><th>Reason</th><th>Status</th>
		</tr>
	</thead>
	<tbody>
<?php
// Connect to the Bike Co-op database.
require_once($_SERVER['DOCUMENT_ROOT'].'db_connect.php');
$db = db_connect ();

//Assign the query
$query = $db->prepare("SELECT * from CommunityServiceVolunteers order by Status, LastName, FirstName");
$query->execute();
// Fetch & display the results of the query.
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$volunteer = $result_row["FirstName"].' '.$result_row["LastName"];
	$dob = $result_row["DOB"];
	$volid = $result_row["VolID"];
	$reason = $result_row["Reason"];
	$status = $result_row["Status"];
	// Now get the hours
	$subquery = $db->prepare("SELECT sum(Hours) AS TotalHours from CommunityServiceTimecards WHERE VolID = ?");
	$subquery->bindValue(1, $volid, PDO::PARAM_INT);
	$subquery->execute();
	while($detail_row = $subquery->fetch(PDO::FETCH_ASSOC))
		{
		$hours = $detail_row["TotalHours"];
		}
	$subquery->closeCursor();
	echo "<tr>";
	echo "<td><a href=\"#\" onclick='window.open(\"./CSvolInfo.php?volunteer=".$volid."\",\"_blank\",\"resizable=yes,scrollbars=no,status=yes,toolbar=no,menubar=no,location=no\");return false'>$volunteer</a></td>";
	echo "<td>$dob</td>";
	echo "<td align='right'>$hours</td>";
	echo "<td align='left'>$reason</td>";
	echo "<td align='center'>$status</td>";
	echo "</tr>";
	}
// Finish the page
echo "</tbody>";
echo "</table>";
include_once('/var/www/fcbikecoop.org/root/footer.php');
// Free used database resources.
$subquery->closeCursor();
$query->closeCursor();
$db = null;
?>
