<?php
// This script presents the Community Service main page
session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>

<div class="heading">Community Service</div>
<p>
<a href="http:./AddToCommunityService.php">Volunteer Sign Up</a><br>
<a href="http:./CSvolSelect.php?action=./LogCommunityServiceHours.php">Log Community Service Hours</a><br>
<a href="http:./CSvolList.php">List Community Service Volunteers</a><br>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
