$(document).ready(function()
	{
	var _csref = $('input[name=reason]');
	$('input[name=other]').hide();
	if(_csref.attr("checked") != "undefined" && _csref.attr("checked") == "checked") 
		{$("#reason").hide();}
	else
		{
		if ($('input[name=reason]:checked').val() == "court ordered")
			{$("#reason").show();}
		};
    $('input:radio[name=reason]').click(function()
    	{
    	if ($('input[name=reason]:checked').val() == "other" ) 
    		{$("#other").show();}
        else {$("#other").hide();}
        });

	jQuery.validator.addMethod("phoneUS", function(phone_number, element) 
		{
		phone_number = phone_number.replace(/\s+/g, ""); //remove whitespace
		return this.optional(element) || phone_number.length > 6 &&
//		phone_number.match(/^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/);
		phone_number.match(/^(1?(-?\d{3})-?)?(\d{3})(-?\d{4})$/);
		}, "Please specify a valid phone number");

	$("#select").validate(
		{
		submitHandler: function(form) 
			{form.submit();},
		rules: 
			{
			supervisor: {required: true},
			volunteer: {required: true, min:0}
			},
		messages:
			{
			supervisor: {required:" work night leader's name"},
			volunteer: {min:" select a volunteer"}
			}
		});
/*
	$("#logForm").validate(
		{
		submitHandler: function(form) 
			{form.submit();},
		rules: 
			{
			supervisor: {required: true},
			password; {required: true}
			},
		messages:
			{
			supervisor: {required:" select work night leader's name"}
			}
		});
*/	
	$("#appForm").validate(
		{
		submitHandler: function(form) 
			{form.submit();},
		rules: 
			{
			reason: {required: true},
			firstname: {required: true},
			lastname: {required: true},
			dob: {required: true},
			phone: {phoneUS: true},
			other: 
				{
				required: 
					{
					depends: function()
						{
						return $('input[name=reason]:checked').val() == "other";
						}
					}
				}
			}
		});
	});
