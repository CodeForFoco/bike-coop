<?php
/**
	*	CSvolInfo.php - part of the Fort Collins Bike Co-op system for managing volunteer work.
	*
	* This script lets work night leaders view community service volunteers' hours.
	* It is called by clicking on a volunteer name in CSvolList.php.
*/
session_start();
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once($_SERVER['DOCUMENT_ROOT'].'header.php');
?>
<!-- We will be using JQuery functions and JavaScript for processing the form. -->
<script type='text/javascript' src='/js/jquery.min.js'></script>
<script type='text/javascript' src='/js/jquery.validate.min.js'></script>
<!-- The following script does form data validation -->
<script type='text/javascript' src='./CSvolInfo.js'></script>
<html>
<?php
// Connect to the Bike Co-op database.
require_once($_SERVER['DOCUMENT_ROOT'].'db_connect.php');
$db = db_connect ();

// Get the VolID passed by CSvolList.php.
$volid = $_GET['volunteer'];

// Get the volunteer's name
$query = $db->prepare("SELECT * FROM CommunityServiceVolunteers WHERE VolID=?");
$query->bindValue(1, $volid, PDO::PARAM_INT);
$query->execute();
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$volname = $result_row["FirstName"].' '.$result_row["LastName"];
	$reason = $result_row["Reason"];
	$status = $result_row["Status"];
	if ($status == "A")
		{$active_button = "checked";}
	else
		{$active_button = "";}
	if ($status == "C")
		{$completed_button = "checked";}
	else
		{$completed_button = "";}
	}
$query->closeCursor();

?>
<div class="heading">Community Service Hours for <?php echo $volname;?></div>
<p id='volid' name='volid'><?php echo $volid ?></p>
<h3>Reason for community service:  <?php echo $reason;?></h3>
<h3>Status:
<input type='Radio'  id='status' name='status' <?php echo $active_button ?> value='active'>active</input>
<input type='Radio'  id='status' name='status' <?php echo $completed_button ?> value='completed'>completed</input>
</h3>
<?php
// Get the total hours for this volunteer
$query = $db->prepare("SELECT SUM(Hours) FROM CommunityServiceTimecards WHERE VolID= ?");
$query->bindValue(1, $volid, PDO::PARAM_INT);
$query->execute();
$tothours = $query->fetchColumn();
if ($tothours == "") {$tothours=0;}
echo "<h2>Total Hours:  ".$tothours."</h2>\n";
$query->closeCursor();

// Set up to display the hours log
echo "<h2>Hours Log</h2>\n";
echo "			<table border=2>
				<tr>
				<th>Date</th><th>Hours</th><th>Supervisor</th>
				</tr>";
//Fetch & display the results
$query = $db->prepare("SELECT * FROM CommunityServiceTimecards WHERE VolID=? ORDER BY vDate DESC");
$query->bindValue(1, $volid, PDO::PARAM_INT);
$query->execute();
//Fetch & display the results
while($result_row = $query->fetch(PDO::FETCH_ASSOC))
	{
	$vdate = date("m/d/Y",strtotime($result_row["vDate"]));
	$vhours = $result_row["Hours"];
	$supervisor = $result_row["Supervisor"];
	$status = $result_row["Status"];
	echo "<tr><td>$vdate</td><td align='center'>$vhours</td><td>$supervisor</td></tr>";
	}

// Finish the page.
echo "</tr>";
echo "</table>";

include_once($_SERVER['DOCUMENT_ROOT'].'footer.php');
// Free used database resources.
$query->closeCursor();
$db = null;
?>
