<?php
// Turn off all error reporting
error_reporting(0);
//Connect to the Bike Co-op database
require_once "../../db_connect.php";
$db = db_connect ();

$status=($_GET['status']);
$volid=($_GET['volid']);
$sql = "UPDATE `CommunityServiceVolunteers` SET `Status`='".$status."'WHERE VolID='".$volid."'";
$update = $db->prepare($sql);
try
	{
	// run the query
	$update->execute();
	}
catch (PDOException $e)
	{
	echo "The statement failed.\n";
	echo "getCode: ". $e->getCode () . "\n";
	echo "getMessage: ". $e->getMessage () . "\n";
	}
if ($status == "C") {$message = "completed";}
else {$message = "active";}
echo "Status set to ".$message.".";
?>
