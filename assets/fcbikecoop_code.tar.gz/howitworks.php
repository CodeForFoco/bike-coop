<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">How it Works</div>
	 <h2>Our shop is your shop...</h2>
	 <p>1. You are welcome to use any of our tools.</p>
	 <p>2. We will teach you how to use the tools properly to fix your bike.</p>
	 <p>3. You can purchase parts from our huge selection of used parts.</p>
	 <h2>The community donates bikes...</h2>
	 <p>1. The public are always encouraged to <a href="http://fcbikecoop.org/programs/grants/donations.php">Donate</a></p>
	 <p>2. Local businesses like to help us out too.  <a href="http://fcbikecoop.org/sponsors.php">See our Sponsers.</a></p>
	 <p>3. Lots of bikes come in from our <a href="http://fcbikecoop.org/programs/recovered.php"> Lost and stolen bike program</a></p>
	 <h2>Sort, Sort, Sort...</h2>
	 <p>1. We sort out the parts that are beyond repair and/or poor quality.  These parts are dismantled for <a href="http://fcbikecoop.org/programs/recycling.php">recycling.</a></p>
	 <p>2. All donated bikes are held for a period of time and cross referenced with the Fort Collins Police departments stolen bikes database.  <a href="http://fcbikecoop.org/programs/recovered.php">More about our police connections.</a></p>
	 <p>3. Parts that are determined good are separated into three groups, Parts for the <a href="http://fcbikecoop.org/programs/earnabike.php">Earn-a-bike</a> program, parts for retail to help keep the Co-op running, and parts to be sent the <a href="http://fcbikecoop.org/programs/ghana.php">Ghana</a></p>
	 <h2>We get the bikes running...</h2>
	 <p>Once all the parts are determined good, we use them to build bikes for our Earn a bike program, for local non-profits, for local community programs, and for sale.
	 <h2>More Questions?</h2>
	 <p>See our <a href="http://fcbikecoop.org/faq.php">Frequently Asked Questions</a></p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
