<?

echo phpinfo();

?>
