<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
        <div class="heading">Sponsors</div>
	The Co-op would not exist without the generous support of our sponsors.  We can't thank them enough!  They are the best at what they do and your continued support of them helps the co-op stay alive.
	<h2>Program Sponsors</h2>
	(Alphabetical)
	<table width="650px">
		<tr valign=bottom height="200px"><td><a href="http://www.alpineent.com/"><img src="http://fcbikecoop.org/images/sponsors/ENT_lgo.jpg" height="90px" width="150px" alt="Newbelgium Logo"><br>Alpine Ear, Nose & Throat</a></td><td><a href="http://www.bohemianfoundation.org/"><img src="http://fcbikecoop.org/images/sponsors/bohemian.jpg" height="90px" width="165px" align="bottom" alt="The Bohemian Foundation"><br>The Bohemian Foundation</a></td><td><a href="http://www.thecycologist.com/"><img src="http://fcbikecoop.org/images/sponsors/cycologist.jpg" height="140px" width=150px" align="bottom" alt="The Cycologist"><br>The Cycologist</a></td></tr>
		<tr valign-bottom height="200px"><td><a href="http://www.intel.com/community/"><img src="http://fcbikecoop.org/images/sponsors/intel.jpg" height="150px" width="150px" alt="Intel Logo"><br>Intel Corporation</a></td><td><a href="http://newbelgium.com"><img src="http://fcbikecoop.org/images/sponsors/new_belgium.jpg" height="150px" width="150px" alt="Newbelgium Logo"><br>New Belgium Brewing</a></td><td><a href="http://www.odellbrewing.com/"><img src="http://fcbikecoop.org/images/sponsors/odells.jpg" height="150px" width="150px" alt="Odell Brewing Logo"><br>Odell Brewing Co.</a></td></tr>
		<tr valign-bottom height="200px"><td><a href="http://www.onepercentfortheplanet.org/en/"><img src="http://fcbikecoop.org/images/sponsors/1FTP_horiz.jpg"><br>1% For The Planet</a></td><td><a href="http://www.rei.com/stores/49"><img src="http://fcbikecoop.org/images/sponsors/rei_logo.gif" height="90px" width="149px" alt="REI Logo"><br>REI</a></td><td><a href="http://www.specialized.com/us/en/bc/home.jsp"><img src="http:///fcbikecoop.org/images/sponsors/specialized.gif" height="150px" alt="Specialized Logo"><br>Specialized</a></tr>
	</table>
	<h2>Volunteer Appreciation Sponsors</h2>
	(Alphabetical)
	<ul>
		<li><a href="http://www.alleycatcoffeehouse.com">Alley Cat Cafe</a></li>
		<li><a href="http://www.balancedbike.com/">Balanced Rock Bike & Ski</a></li>
		<li><a href="http://www.thebeancycle.com/">The Bean Cycle</a></li>
		<li><a href="http://www.benjerry.com/fortcollins/">Ben & Jerry's</a></li>
		<li><a href="http://www.bravenewwheel.com/">Brave New Wheel</a></li>
		<li><a href="http://www.christysports.com/">Christy Sports</a></li>
		<li><a href="http://www.thecupboard.net/">The Cupboard</a></li>
		<li><a href="http://www.thecycologist.com/">The Cycologist</a></li>
		<li><a href="http://fcgov.com/bicycling/">FC Bikes</a></li>
		<li><a href="http://www.greatharvest.com/">Great Harvest Bread Co.</a></li>
		<li><a href="http://www.gulleygreenhouse.com/">Gulley Greenhouse & Garden Center</a></li>
		<li>Heavenly Delights - Catholic Gifts & Ice Cream Shop</li>
		<li><a href="http://www.justgowest.com/">Go West</a></li>
		<li><a href="http://leescyclery.com/">Lee's Cyclery Inc.</a></li>
		<li><a href="http://www.luciles.com/">Lucille's Creole Cafe</a></li>
		<li><a href="http://www.madgreens.com/">Mad Green's</a></li>
		<li><a href="http://www.meltingpot.com/locations.aspx?z=80524&n=597720">The Melting Pot</a></li>
		<li><a href="http://newbelgium.com">New Belgium Brewing</a></li>
		<li><a href="http://www.odellbrewing.com/">Odell Brewing Co.</a></li>
		<li><a href="http://overlandmtb.org">Overland Mountain Bike Patrol</a></li>
		<li><a href="http://www.panerabread.com/">Panera Bread</a></li>
		<li><a href="http://www.performancebike.com/bikes/Product_10052_10551_500037_-1_600000__">Performance Bicycle</a></li>
		<li>Pizza Casbah</li>
		<li><a href="http://www.rei.com/stores/49">REI</a></li>
		<li><a href="http://www.road34.com/">Road 34</a></li>
		<li><a href="http://www.startthepress.com/">Start The Press</a></li>
		<li><a href="http://www.sfmarkets.com/ftcollins.html">Sunflower Farmers Market</a></li>
		<li><a href="http://www.walrusicecream.com/">Walrus Ice Cream</a></li>
		<li><a href="http://www.wolverinefarmpublishing.org/">Wolverine Farm Publishing</a></li>
	</ul>
	<div class="heading">Links and Friends</div><br>
		<a href="http://www.bikeleague.org/"><img src="http://fcbikecoop.org/images/sponsors/lab_weblogo2006.gif"> League of American Bicyclists (member)</a><br>
		<a href="http://www.peoplepoweredmovement.org/site/"><img src="http://fcbikecoop.org/images/sponsors/Alliance_member_stamp.jpg"> Alliance for Biking and Walking (member)</a><br>
		<a href="http://tripsforkidsfoco.org/">Trips for Kids Fort Collins</a><br>
		<a href="http://www.belocalnc.org/">Be Local</a><br>
		<a href="http://www.fallharvestbrewfest.com/">Fall Harvest Brewfest</a><br>
		<a href="http://www.platinumbikeplan.blogspot.com/">Fort Collins' Platinum Bike Plan</a><br>
		<a href="http://bikefortcollins.org">Bike Fort Collins</a><br>
		<a href="http://fcbikelibrary.org">Fort Collins Bike Library</a><br>
		<a href="http://yourgroupride.com/">Your Group Ride</a><br>
		<a href="http://fcgov.com">FC Bikes</a><br>
		<a href="http://onespeedopen.blogspot.com/">One Speed Open</a><br>
		<a href="http://www.bikecollectives.org">bikecollectives.org</a><br>
		<a href="http://www.bikecollectives.org/wiki/index.php?title=Fort_Collins_Bike_Coop">FCBikeCoop Wiki</a><br>
		<a href="http://www.fcvelodrome.org/">fcvelodrome.org</a><br>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
