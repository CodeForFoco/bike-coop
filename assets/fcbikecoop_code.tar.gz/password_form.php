<?php
// check ALL the POST variables
function checkSet(){
	return isset($_POST['firstname'], $_POST['lastname'], $_POST['username'], $_POST['password1'], $_POST['password2']);
}

// Checks to see if the form has been submitted.
// If it hasn't, PHP ignores heaps of this code and display the form.
// If the form was submitted, it will create variables based on
// form field names and users answers.

// this will be the default message if the form accessed without POSTing

if (isset ($_POST['submit']))
        {
        foreach($_POST as $key=>$value)
                {
                $$key = $value;
                }
	//Create an empty error_msg
	$error_msg='';
	//if something isn't filled in we go into this loop
        if(checkSet() != FALSE)
 		{
		if(empty($_POST['firstname'])==FALSE)
			{
			$firstname = $_POST['firstname'];
			}
		else
			{
			$error_msg.="* first name is not set.<br />";
			}
		if(empty($_POST['lastname'])==FALSE)
			{
			$lastname = $_POST['lastname'];
			}
		else
			{
			$error_msg.="* Last name is not set.<br />";
			}
		if(empty($_POST['username'])==FALSE)
			{
			$username = $_POST['username'];
			}
		else
			{
			$error_msg.="* Username is not set.<br />";
			}
		if(empty($_POST['password1'])==FALSE)
			{
			$password1 = $_POST['password1'];
			}
		else
			{
			$error_msg.="* Password1 is not set.<br />";
			}
		if(empty($_POST['password2'])==FALSE)
			{
			$password2 = $_POST['password2'];
			}
		else
			{
			$error_msg.="* Password2 is not set.<br />";
			}
		}
	if ($password1 != $password2)
		$error_msg.= "Passwords do not match<br />";
	if(strlen($password1) < 6)
		$error_msg.= "Password is too short<br />";
	}
if ($error_msg == '' && isset($_POST['submit']))
	{
	$hash = base64_encode(sha1($password1, true));
	$password_encode = '{SHA}'.$hash;
	//Write the username password pair to the file system
	$myFile = "/home/john/fcbc-pwd.txt";
	$fh = fopen($myFile, 'a') or die("can't write password to file, please email john@fcbikecoop.org");
		$stringData = "$firstname, $lastname \n $username:$password_encode \n";
		fwrite($fh, $stringData);
	fclose($fh);
	//Mail the Admin that a password awaits activation
	mail("john@lackof.org", "[fcbikecoop.org] Restricted User, $lastname, $firstname", "There is a password present in /home/john/fcbc-pwd.txt for
$firstname, $lastname", "From: webmaster@fcbikecoop.org");
	//send the volunteer to a pretty exit page
	header ("Location: password_form_done.php");
	exit;
	}	
// If PHP is still reading this, it must be the first page visit,
// OR an error was detected.
// Display the HTML page and your signup form.
include_once('/var/www/fcbikecoop.org/root/header.php');

// If the form has been submitted,
// display the error messages above the form.
if(isset($_POST['submit']))
	{
	echo "<font color=\"yellow\" size=\"3\">The following problems were detected:<br><i>" .$error_msg ."</i></font><br>";
	}
?>
<form method="POST" action="<?php echo $PHP_SELF;?>" enctype="multipart/form-data">
   <div class="heading">FC Bike Co-op Password Creation Page</div></td>
<table width="550">
        <tr>
        <td align=left colspan="2">This form will allow you to set your username and password for the fcbikecoop website.  Once filled out, the site moderator will be notified that your password has been setup, and they will allow you access to the site.  This typically carries a short delay (we're not always on the computer)
        </tr>
        <tr>
                <td align=right width="25%">First Name:</td>
                <td align=left><input name="firstname" type="text" id="firstname" size="35" maxlength="25" value="<?php echo $firstname ?>">
        </tr>
        <tr>
                <td align=right width="25%">Last Name:</td>
                <td align=left><input name="lastname" type="text" id="lastname" size="35" maxlength="25" value="<?php echo $lastname ?>">
        </tr>
        <tr>
                <td align=right width="25%">User Name:</td>
                <td align=left><input name="username" type="text" id="username" size="35" maxlength="25" value="<?php echo $username ?>">
        </tr>
        <tr>
                <td align=right width="25%">Password:</td>
                <td align=left><input name="password1" type="password" id="password1" size="35" maxlength="25" value="<?php echo $password1 ?>"> <b>(at least 6 characters)<b>
        </tr>
        <tr>
                <td align=right width="25%">Password:</td>
                <td align=left><input name="password2" type="password" id="password2" size="35" maxlength="25" value="<?php echo $password2 ?>"> <b>(at least 6 characters)</b>
        </tr>
</table>
<br><br><input type="submit" value="Send" name="submit">
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
