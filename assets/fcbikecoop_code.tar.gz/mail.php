<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">Mailing Lists</div>
			<p>Want to keep up with the latest news from the Bike Co-op?  Join our News mailing list.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/mailing_list.php');
?>
			<p>You can sign-up for the volunteers mailing list over at the <a href="http://fcbikecoop.org/volunteers.php">Volunteer page</a></p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
