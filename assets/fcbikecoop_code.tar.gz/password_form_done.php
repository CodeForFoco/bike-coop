<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">Password Signup</div>
         <p>Thank you. You have successfully signed up.  Activation will happen as soon as a moderator gets to your request.  Thank you.<br><br>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
