<?php
$ref = getenv("HTTP_REFERER"); 
switch ($ref) {
	case "http://www.fcbikelibrary.org/Index.asp":
	header( 'Location: http://fcbikecoop.org/');
	break;
	case "https://www.fcbikelibrary.org/Index.asp":
	header( 'Location: http://fcbikecoop.org/');
	break;
	case "http://www.fcbikelibrary.org/":
	header( 'Location: http://fcbikecoop.org/');
	break;
	case "http://www.fcbikelibrary.org/sponsors.asp":
	header( 'Location: http://fcbikecoop.org/');
	break;
}
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<div class="heading">Welcome to the Fort Collins Bicycle Co-op</div>
			<br><font color="blue" size="6px"><b>We've Moved!! 1 Mile To The North.</b></font><br><br><font color="blue" size="5px"><b><a href="http://maps.google.com/maps?q=1501+north+college+ave+fort+collins&oe=utf-8&rls=org.debian:en-US:unofficial&client=iceweasel-a&um=1&ie=UTF-8&split=0&gl=us&ei=30GXSrT7NIGCNLuDsIkD&sa=X&oi=geocode_result&ct=image&resnum=1">Visit us at our new home at 1501 North College Ave.</a></b></font><br><br>
			<iframe width="560" height="315" src="https://www.youtube.com/embed/5Ai-3EO5J38" frameborder="0" allowfullscreen></iframe>
			<!---<a href="http://fcbikecoop.org/images/banner_large.jpg"><img src="http://fcbikecoop.org/images/banner.jpg" alt="Co-op Banner Image" width="575px" height="133px" border="0"></a>--->
			<br><br>
			<h2>Building Community Through Bicycling</h2> 
			<ul>
				<li>To keep our <a href="http://fcbikecoop.org/community.php">community</a> riding, including those who can't afford to buy a bike.</li>
				<li>To educate our neighbors in all things bike-related including bike maintenance, bicycle education and safety.</li>
				<li>To keep good bikes out of the landfill and to recycle poorly built or unsafe bikes.</li>
				<li>To refurbish and donate bicycles for a wide variety of charity events and programs for those in need.</li>
			</ul>
			<h2>How it Works</h2>
			<p>The community donates bikes and parts, we help get the bikes running, we give the bikes away to non-profit or for volunteered time.  We also provide tools and know-how to anyone that wants it.&nbsp; &nbsp;<a href="http://fcbikecoop.org/howitworks.php">  More about how it works...</a></p>
			<h2>Our Programs</h2>
			<p>In order to best serve the community, the Co-op has several programs set up to specilize in separate areas.&nbsp; &nbsp;<a href="http://fcbikecoop.org/programs/index.php">  Learn more about our programs...</a></p>
			<h2>Mailing Lists</h2>
			<p>Want to keep up with the latest news from the Bike Co-op?  Join our News mailing list.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/mailing_list.php');
?>
			<p>You can sign-up for the volunteers mailing list over at the <a href="http://fcbikecoop.org/volunteers.php">Volunteer page</a></p>
			<h2>Donations</h2>
			<p>We can always use your donations, or at least we can recycle them so you don't have to send them to the landfill.&nbsp; &nbsp;<a href="http://www.fcbikecoop.org/programs/grants/donations.php">More about donations...</a></p>
			<h2>Lost, Found, and Stolen Bikes</h2>
			<p>The Co-op is working with the Police Services to help return bikes to their owners.  In return, some of the abandoned bikes are turned over to the Co-op.&nbsp; &nbsp;<a href="http://fcbikecoop.org/programs/recovered.php"> More about lost, found, and stolen bikes...</a></p>
			<h2>History</h2>
			<p>You might know us as the Bike Against! collective.  We started in a garage back in 2003.  It's been quite a journey since those days.&nbsp; &nbsp;<a href="http://fcbikecoop.org/history.php">More history...</a></p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
	<form action="http://translate.google.com/translate" method="get">
		<input type="hidden" name="u" value="http://fcbikecoop.org">
		<select name="langpair"><option value="en|de">English to German</option><option value="en|es" selected="selected">English to Spanish</option><option value="en|fr">English to French</option><option value="en|it">English to Italian</option><option value="en|pt">English to Portuguese</option></select><input type="hidden" name="name" value="ul">
		<input type="hidden" name="value" value="en">
		<input type="submit" value="Translate this page">
	</form>
