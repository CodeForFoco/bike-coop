<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<div class="heading">Bike Donation Request</div>
<p>Thank you for submitting a donation request to the Fort Collins Bike Co-op.  Your request will be processed shortly and you should receive a response within the next 1-2 weeks.  If you have any questions during this time, please contact Jami at jmoutreach@yahoo.com.
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
