<?php
// get the email checking code
include('/var/www/fcbikecoop.org/root/script/rfc3696.php');
// check ALL the POST variables
function checkSet(){
	return isset($_POST['contact'], $_POST['address'], $_POST['phone'], $_POST['email'], $_POST['city'], $_POST['narrative']);
}
/**
 * This function can be used to check the sanity of variables
 *
 * @access private
 *
 * @param string $type  The type of variable can be bool, float, numeric, string, array, or object
 * @param string $string The variable name you would like to check
 * @param string $length The maximum length of the variable
 *
 * return bool
*/
function sanityCheck($string, $type, $length){
  // assign the type
  $type = 'is_'.$type;

  if(!$type($string))
    {
    return FALSE;
    }
  // now we see if there is anything in the string
  elseif(empty($string))
    {
    return FALSE;
    }
  // then we check how long the string is
  elseif(strlen($string) > $length)
    {
    return FALSE;
    }
  else
    {
    // if all is well, we return TRUE
    return TRUE;
		}
}
// check number is greater than 0 and $length digits long
// returns TRUE on success
function checkNumber($num, $length){
	if($num > 0 && strlen($num) == $length)
		{
		return TRUE;
		}
}

session_start();
// Checks to see if the form has been submitted.
// If it hasn't, PHP ignores heaps of this code and display the form.
// If the form was submitted, it will create variables based on
// form field names and users answers.

// this will be the default message if the form accessed without POSTing
$error_msg="Please fill in the form.<br />";

if (isset ($_POST['submit']))
	{
	foreach($_POST as $key=>$value)
		{
		$$key = $value;
		}

	// Create an empty error_msg
	$error_msg='';
	require_once('/var/www/fcbikecoop.org/root/recaptcha/recaptchalib.php');
	$privatekey = "6LcljgQAAAAAAPouSflWvq1dlfio5lRYJ4RvEsGt";
	$publickey = "6LcljgQAAAAAAL1T9O8K4Rv0n3at7RUhFQBsLnoG";
	$resp = recaptcha_check_answer ($privatekey,
				$_SERVER["REMOTE_ADDR"],
				$_POST["recaptcha_challenge_field"],
				$_POST["recaptcha_response_field"]);
	if (!$resp->is_valid)
		{
		$error = $resp->error;
		$error_msg.="* incorrect Captcha response<br />";
		}
	if(checkSet() != FALSE)
		{
		// check the POST variable contact is sane, and is not empty
		if(empty($_POST['contact'])==FALSE && sanityCheck($_POST['contact'], 'string', 25) != FALSE)
			{
			$contact = ucwords($_POST['contact']);
			}
		else
			{
			$error_msg.="* contact name is not set.<br />";
			}
		// check the POST variable address is sane, and is not empty
		if(empty($_POST['address'])==FALSE && sanityCheck($_POST['address'], 'string', 25) != FALSE)
			{
			$address = ucwords($_POST['address']);
			}
		else
			{
			$error_msg.="* address is not set.<br />";
			}
		// check the POST variable city is sane, and is not empty
		if(empty($_POST['city'])==FALSE && sanityCheck($_POST['city'], 'string', 25) != FALSE)
			{
			$city = ucwords($_POST['city']);
			}
		else
			{
			$error_msg.="* city name is not set.<br />";
			}
		// check the POST variable state is sane, and is not empty
		if(empty($_POST['state'])==FALSE && sanityCheck($_POST['state'], 'string', 25) != FALSE)
			{
			$state = $_POST['state'];
			}
		else
			{
			$error_msg.="* state is not set.<br />";
			}
		// check for valid email address
		if(sanityCheck($_POST['email'], 'string', 50) != FALSE)
			{
			if (is_rfc3696_valid_email_address($_POST['email']) != FALSE)
    		{
				$email = $_POST['email'];
				}
			else
				{
				$error_msg.="* invalid Email address<br />";
				}
			}
		else
			{
			$error_msg.="* please provide an email address so we can contact you<br />";
			}
		// check the sanity of the zipcode and that it is greater than zero and 5 digits long - it can be left blank
		$zip = substr($_POST['zip'],0,5);
		if(sanityCheck(substr($_POST['zip'],0,5), 'numeric', 5) != FALSE && checkNumber(substr($_POST['zip'],0,5), 5) == TRUE)
			{
			$zip = substr($_POST['zip'],0,5);
			}
		else
			{
			$zip='';
			}
		// check the POST variable narrative is sane, and is not empty
		if(empty($_POST['narrative'])==FALSE)
			{
			$narrative = $_POST['narrative'];
			}
		else
			{
			$error_msg.="* please provide a narrative.<br />";
			}
		// convert stuff to initial caps
		$orgname = $_POST['orgname'];
		$relationship = $_POST['relationship'];
		$orgtype = $_POST['orgtype'];
		$orgID = $_POST['orgID'];
		$beneficiary = $_POST['beneficiary'];
		$age = $_POST['age'];
		$gender = $_POST['gender'];
		$height = $_POST['height'];
		$inseam = $_POST['inseam'];
		$eventdate = $_POST['eventdate'];
		$eventname = $_POST['eventname'];
		}
		$requestdate = date('m/d/Y');
	}

// END BASIC ERROR CHECKING
// You need to create your own code to validate the information
// and allowed values - never send "unclean" user responses
// to a database without cleaning them up and
// checking for allowed answers.
// Google for "SQL injection" and "insecure contact form"

// Do this if no errors were detected AND form has been submitted
if ($error_msg == '' && isset($_POST['submit']))
	{
	//Close the session
	session_write_close();

	// No errors were detected.
	// Send the request.
  // This version is for production and should the commented out when in test.
	$mail_to = 'outreach@fcbikecoop.org';
  // This version is for testing and should the commented out when in production.
	// $mail_to = 'FCBC.Paul@gmail.com';

	mail( $mail_to,"Bike Donation Request for $contact",
	"Bike Donation Request Form

	CONTACT INFORMATION
		Contact Name:  $contact
		Relationship to Organization: $relationship
		Organization Name: $orgname
		$orgtype
		Organization Tax ID No: $orgID
		Address: $address
		City: $city
		State: $state
		Zip: $zip
		Phone: $phone
		Email: $email
	DONATION REQUEST
		Beneficiary Name: $beneficiary
		Age: $age
		Gender: $gender
		Height (in.) $height
		Inseam (in.) $inseam
		Date Needed By (if applicable): $eventdate
		Event Name (If applicable): $eventname
	NARRATIVE
		$narrative
	",
	"From: $email");

	// end of email to staff
	// Redirect to confirmation page.
	header ("Location: http:bike_request_done.php");
	exit;
	}

// If PHP is still reading this, it must be the first page visit,
// OR an error was detected.
// Display the HTML page and your signup form.
// include_once('/var/www/fcbikecoop.org/root/header.php');

// If the form has been submitted,
// display the error messages above the form.
if(isset($_POST['submit']))
{
echo "<font color=\"red\" size=\"3\">The following problems were detected:<br><i>" .$error_msg ."</i></font><br>";
}
?>
<SCRIPT LANGUAGE="JavaScript" SRC="http://fcbikecoop.org/script/CalendarPopup.js"></SCRIPT>
<form method="POST" action="<?php echo $PHP_SELF;?>" enctype="multipart/form-data">
<a href="http://fcbikecoop.org/"><img align="left" src="http://fcbikecoop.org/images/fcbikecoop.png" alt="Co-op Logo" border="0" width="120" hspace="20"></a>

<h2>Fort Collins Bike Co-Op</h2>
<small align="right"><i>Building Community Through Bicycling</i></small>
<h3>Bike Donation Request Form</h3>
<FONT SIZE=2 STYLE="font-size: 10pt">
<p>Questions should be emailed to our Community Outreach Group, at
<a href="mailto:outreach@fcbikecoop.org?subject=Bike%20Donation%20Request">outreach@fcbikecoop.org</a>.</p>
<p>Requests are evaluated based on need, availability and relativity to the Co-op's mission. Please allow at least one week after submission for your request to be processed. If approved, please allow at least one month for delivery, depending on request. A donation request consists of a completed Request Form and a narrative (see narrative guidelines below).</p>
<h4>CONTACT INFORMATION</h4>
<hr>
<p>Contact Name: <input name="contact" type="text" id="contact" size="35" maxlength="25" value="<?php echo $contact ?>"> Relationship to Organization: <input name="relationship" type="text" id="relationship" size="35" maxlength="25" value="<?php echo $relationship ?>"></p>
<p>Organization Name: <input name="orgname" type="text" id="orgname" size="50" maxlength="50" value="<?php echo $orgname ?>"></p>
<p><Input type = 'Radio' Name ='orgtype' value= '501c3'>501c3 Organization - Tax ID No: <input name="orgID" type="text" id="orgID" size="10" maxlength="20" value="<?php echo $orgID ?>">&nbsp; &nbsp; &nbsp;<Input type = 'Radio' Name ='orgtype' value= 'profit'>For Profit
<p>Address:  <input name="address" type="text" id="address" size="35" maxlength="25" value="<?php echo $address ?>">
<p>City:  <input name="city" type="text" id="city" size="35" maxlength="25" value="<?php echo $city ?>">
State:  <select name="state" id="state">
			<option value="<?php echo $state ?>" selected="selected"><?php echo $state ?></option>
			<option value="CO">Colorado</option>
			<option value="WY">Wyoming</option>			
			<option value="AL">Alabama</option>
			<option value="AK">Alaska</option>
			<option value="AZ">Arizona</option>
			<option value="AR">Arkansas</option>
			<option value="CA">California</option>
			<option value="CT">Connecticut</option>
			<option value="DC">District of Columbia</option>
			<option value="DE">Delaware</option>
			<option value="FL">Florida</option>
			<option value="GA">Georgia</option>
			<option value="HI">Hawaii</option>
			<option value="ID">Idaho</option>
			<option value="IL">Illinois</option>
			<option value="IN">Indiana</option>
			<option value="IA">Iowa</option>
			<option value="KS">Kansas</option>
			<option value="KY">Kentucky</option>
			<option value="LA">Louisiana</option>
			<option value="ME">Maine</option>
			<option value="MD">Maryland</option>
			<option value="MA">Massachusetts</option>
			<option value="MI">Michigan</option>
			<option value="MN">Minnesota</option>
			<option value="MS">Mississippi</option>
			<option value="MO">Missouri</option>
			<option value="MT">Montana</option>
			<option value="NE">Nebraska</option>
			<option value="NV">Nevada</option>
			<option value="NH">New Hampshire</option>
			<option value="NJ">New Jersey</option>
			<option value="NM">New Mexico</option>
			<option value="NY">New York</option>
			<option value="NC">North Carolina</option>
			<option value="ND">North Dakota</option>
			<option value="OH">Ohio</option>
			<option value="OK">Oklahoma</option>
			<option value="OR">Oregon</option>
			<option value="PA">Pennsylvania</option>
			<option value="RI">Rhode Island</option>
			<option value="SC">South Carolina</option>
			<option value="SD">South Dakota</option>
			<option value="TN">Tennessee</option>
			<option value="TX">Texas</option>
			<option value="UT">Utah</option>
			<option value="VT">Vermont</option>
			<option value="VA">Virginia</option>
			<option value="WA">Washington</option>
			<option value="WV">West Virginia</option>
			<option value="WI">Wisconsin</option>
		</select>
Zip:   <input name="zip" type="text" id="zip" size="10" maxlength="10" value="<?php echo $zip ?>">
<p>Phone:   <input name="phone" type="text" id="phone" size="13" maxlength="13" value="<?php echo $phone ?>">
Email:   <input name="email" type="text" id="email" size="35" maxlength="200" value="<?php echo $email ?>">
<h4>DONATION REQUEST</h4>
<hr>
<p>Beneficiary Name (if different than above): <input name="beneficiary" type="text" id="beneficiary" size="35" maxlength="25" value="<?php echo $beneficiary ?>">
<p>Age:  <input name="age" type="text" id="age" size="3" maxlength="3" value="<?php echo $age ?>">
Gender: <Input type = 'Radio' Name ='gender' value= 'male'>Male
<Input type = 'Radio' Name ='gender' value= 'female'>Female
<p>Height (in.)  <input name="height" type="text" id="height" size="2" maxlength="2" value="<?php echo $height ?>">
Inseam (in.)  <input name="inseam" type="text" id="inseam" size="2" maxlength="2" value="<?php echo $inseam ?>">
<script LANGUAGE="JavaScript" ID="js1">
var cal1 = new CalendarPopup();
</script>
<p>Date Needed By (if applicable): <input type="text" name="eventdate" size=8 id="eventdate" value="<?php echo $eventdate ?>">
<a href="#" onClick="cal1.select(document.forms[0].eventdate,'anchor1','MM/dd/yyyy'); return false;" title="Click on the calendar icon to select a date." name="anchor1" id="anchor1"><input type="image" src="http://fcbikecoop.org/script/iconCalendar.gif"></a>
Event Name (If applicable):  <input name="eventname" type="text" id="eventname" size="35" maxlength="25" value="<?php echo $eventname ?>">
<h4>NARRATIVE</h4>
<p>Tell us your story. Why do you need a bike? How will it be used? Will you travel the world? Will you haul groceries for your neighbor? Will you be able to get to school or work without using gas or oil? We've saved this bike from bike heaven. How will you help it live?</p>
<FONT SIZE=1 STYLE="font-size: 10pt">
<p>*If being used for a silent auction, event or similar, please include how the donation will be used to support your mission and the mission of the Co-op.  Also, in recognition of the donation your organization may be asked to promote the Fort Collins Bike Coop as an in-kind sponsor; please highlight what this may include.</p>
<textarea name="narrative" cols=80 rows=10><?php echo $narrative ?></textarea>
<?php
require_once('/var/www/fcbikecoop.org/root/recaptcha/recaptchalib.php');
$publickey = "6LcljgQAAAAAAL1T9O8K4Rv0n3at7RUhFQBsLnoG";
echo recaptcha_get_html($publickey, $error);
?>
<br><br><input type="submit" value="Send" name="submit">
</form>
