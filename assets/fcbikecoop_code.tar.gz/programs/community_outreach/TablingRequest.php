<?php
// get the email checking code
include('/var/www/fcbikecoop.org/root/script/rfc3696.php');
// check ALL the POST variables
function checkSet(){
	return isset($_POST['contact'], $_POST['address'], $_POST['phone'], $_POST['email'], $_POST['city']);
}
/**
 * This function can be used to check the sanity of variables
 *
 * @access private
 *
 * @param string $type  The type of variable can be bool, float, numeric, string, array, or object
 * @param string $string The variable name you would like to check
 * @param string $length The maximum length of the variable
 *
 * return bool
*/
function sanityCheck($string, $type, $length){
  // assign the type
  $type = 'is_'.$type;

  if(!$type($string))
    {
    return FALSE;
    }
  // now we see if there is anything in the string
  elseif(empty($string))
    {
    return FALSE;
    }
  // then we check how long the string is
  elseif(strlen($string) > $length)
    {
    return FALSE;
    }
  else
    {
    // if all is well, we return TRUE
    return TRUE;
		}
}
// check number is greater than 0 and $length digits long
// returns TRUE on success
function checkNumber($num, $length){
	if($num > 0 && strlen($num) == $length)
		{
		return TRUE;
		}
}

session_start();
// Checks to see if the form has been submitted.
// If it hasn't, PHP ignores heaps of this code and display the form.
// If the form was submitted, it will create variables based on
// form field names and users answers.

// this will be the default message if the form accessed without POSTing
$error_msg.="Please fill in the form.<br />";

if (isset ($_POST['submit']))
	{
	foreach($_POST as $key=>$value)
		{
		$$key = $value;
		}

	// Create an empty error_msg
	$error_msg='';
	require_once('/var/www/fcbikecoop.org/root/recaptcha/recaptchalib.php');
	$privatekey = "6LcljgQAAAAAAPouSflWvq1dlfio5lRYJ4RvEsGt";
	$publickey = "6LcljgQAAAAAAL1T9O8K4Rv0n3at7RUhFQBsLnoG";
	$resp = recaptcha_check_answer ($privatekey,
				$_SERVER["REMOTE_ADDR"],
				$_POST["recaptcha_challenge_field"],
				$_POST["recaptcha_response_field"]);
	if (!$resp->is_valid)
		{
		$error = $resp->error;
		$error_msg.="* incorrect Captcha response<br />";
		}
	if(checkSet() != FALSE)
		{
		// check the POST variable evntname is sane, and is not empty
		if(empty($_POST['eventname'])==FALSE && sanityCheck($_POST['eventname'], 'string', 100) != FALSE)
			{
			$eventname = ucwords($_POST['eventname']);
			}
		else
			{
			$error_msg.="* event name is not set.<br />";
			}
		// check the POST variable eventdate is sane, and is not empty
		if(empty($_POST['eventdate'])==FALSE && sanityCheck($_POST['eventdate'], 'string', 35) != FALSE)
			{
			$eventdate = $_POST['eventdate'];
			}
		else
			{
			$error_msg.="* please provide the date(s) and time(s) of your event.<br />";
			}
		// check the POST variable location is not empty
		if(empty($_POST['location'])==FALSE)
			{
			$location = $_POST['location'];
			}
		else
			{
			$error_msg.="* please provide the location of your event.<br />";
			}
		// check the POST variable eventdesc is not empty
		if(empty($_POST['eventdesc'])==FALSE)
			{
			$eventdesc = $_POST['eventdesc'];
			}
		else
			{
			$error_msg.="* please provide a brief description of your event.<br />";
			}
		// check the POST variable contact is sane, and is not empty
		if(empty($_POST['contact'])==FALSE && sanityCheck($_POST['contact'], 'string', 35) != FALSE)
			{
			$contact = ucwords($_POST['contact']);
			}
		else
			{
			$error_msg.="* contact name is not set.<br />";
			}
		// check the POST variable phone is sane, and is not empty
		if(empty($_POST['phone'])==FALSE && sanityCheck($_POST['phone'], 'string', 35) != FALSE)
			{
			$phone = $_POST['phone'];
			}
		else
			{
			$error_msg.="* pleease provide a contact phone number.<br />";
			}
		// check for valid email address
		if(sanityCheck($_POST['email'], 'string', 50) != FALSE)
			{
			if (is_rfc3696_valid_email_address($_POST['email']) != FALSE)
    		{
				$email = $_POST['email'];
				}
			else
				{
				$error_msg.="* invalid Email address<br />";
				}
			}
		else
			{
			$error_msg.="* please provide an email address so we can contact you<br />";
			}
		// check the sanity of the zipcode and that it is greater than zero and 5 digits long - it can be left blank
		$zip = substr($_POST['zip'],0,5);
		if(sanityCheck(substr($_POST['zip'],0,5), 'numeric', 5) != FALSE && checkNumber(substr($_POST['zip'],0,5), 5) == TRUE)
			{
			$zip = substr($_POST['zip'],0,5);
			}
		else
			{
			$zip='';
			}
		// check the indoor/outdoor status
		if ($inout == 'indoors') {
			$in_status = 'checked';
			}
		else if ($inout == 'outdoors') {
			$out_status = 'checked';
			}
		// check the bike knowledge status
		$knowledge = $_POST['knowledge'];
		switch ($knowledge) {
			case "beginner":
				$beginner_status = 'checked';
				break;
			case "intermediate":
				$intermediate_status = 'checked';
				break;
			case "advanced":
				$advanced_status = 'checked';
				break;
			case "all":
			$all_status = 'checked';
			}
		// check the 501c3 status
		if ($orgtype == '501c3') {
			$np_status = 'checked';
			}
		else if ($orgtype == 'profit') {
			$p_status = 'checked';
			}
		// convert stuff to initial caps
		$inout = $_POST['inout'];
		$space = $_POST['space'];
		$attendance = $_POST['attendance'];
		$audience = $_POST['audience'];
		$orgname = $_POST['orgname'];
		$orgdesc = $_POST['orgdesc'];
		$relationship = $_POST['relationship'];
		$orgtype = $_POST['orgtype'];
		$orgID = $_POST['orgID'];
		$city = $_POST['city'];
		$state = $_POST['state'];
		$website = $_POST['website'];
		$howhear = $_POST['howhear'];
		}
		$requestdate = date('m/d/Y');
	}

// END BASIC ERROR CHECKING
// You need to create your own code to validate the information
// and allowed values - never send "unclean" user responses
// to a database without cleaning them up and
// checking for allowed answers.
// Google for "SQL injection" and "insecure contact form"

// Do this if no errors were detected AND form has been submitted
if ($error_msg == '' && isset($_POST['submit']))
	{
	//Close the session
	session_write_close();

	// No errors were detected.
	// Send the request.
  // This version is for production and should the commented out when in test.
	$mail_to = 'outreach@fcbikecoop.org, alexisogg@gmail.com';
  // This version is for testing and should the commented out when in production.
	// $mail_to = 'FCBC.Paul@gmail.com';

	mail( $mail_to,"Tabling Request for $eventname",
	"Tabling Request Form

	ABOUT THE EVENT
		Event Name: $eventname
		Event Dates & Times: $eventdate
		Event Location: $location
		Estimated Space: $space $inout
		Brief Description of Event: $eventdesc
		Estimated No. of People in Audience: $attendance
		Brief Description of Audience: $audience
		Average Bike Knowledge: $knowledge
	ABOUT THE ORGANIZATION
		Organization Name: $orgname
		Brief Description of the Organization: $orgdesc
		$orgtype
		Organization Tax ID No: $orgID
		Address: $address
		City: $city
		State: $state
		Zip: $zip
		Website: $website
		Contact: $contact
		Relationship to Organization: $relationship
		Phone: $phone
		Email: $email
	HOW DID YOU HEAR ABOUT THE CO-OP?
		$howhear
	",
	"From: $email");

	// end of email to staff
	// Redirect to confirmation page.
	header ("Location: http:tabling_request_done.php");
	exit;
	}

// If PHP is still reading this, it must be the first page visit,
// OR an error was detected.
// Display the HTML page and your signup form.
// include_once('/var/www/fcbikecoop.org/root/header.php');

// If the form has been submitted,
// display the error messages above the form.
if(isset($_POST['submit']))
{
echo "<font color=\"red\" size=\"3\">The following problems were detected:<br><i>" .$error_msg ."</i></font><br>";
}
?>
<form method="POST" action="<?php echo $PHP_SELF;?>" enctype="multipart/form-data">
<a href="http://fcbikecoop.org/"><img align="left" src="http://fcbikecoop.org/images/fcbikecoop.png" alt="Co-op Logo" border="0" width="120" hspace="20"></a>

<h2>Fort Collins Bike Co-Op</h2>
<small align="right"><i>Building Community Through Bicycling</i></small>
<h3>Tabling Request Form</h3>
<FONT SIZE=2 STYLE="font-size: 10pt">
<p>**Please submit this form at least one month prior to your event. Requests are reviewed and confirmed on a
first-come, first-serve basis.</p>
<p>Thank you for the invitation to participate in your event. The mission of the Fort Collins Bike Co-Op is to "build community through bicycling" and we are honored to be asked to attend your event and spread the word about bicycling.</p>
<p><b>"Tabling" consists of an informational table about the Bike Co-Op, the programs we provide, and how people can get involved.</b></p>
<p>We will provide materials and volunteers to staff the table. This does not include onsite mechanics or training.</p>

<h4>ABOUT YOUR EVENT</h4>
<hr>
<p>Event Name: <input name="eventname" type="text" id="eventname" size="50" maxlength="100" value="<?php echo $eventname ?>"></p>
<p>Event Dates and Times: 
	<input type="text" name="eventdate" size="25" id="eventdate" value="<?php echo $eventdate ?>">
<p>Event Location: 
	<input name="location" type="text" id="location" size="50" maxlength="50" value="<?php echo $location ?>"></p>
<p>Estimated Space (sq. ft.): 
	<input name="space" type="text" id="space" size="4" maxlength="6" value="<?php echo $space ?>">
	<Input type = 'Radio' Name ='inout' value= 'indoors' <?PHP print $in_status; ?>>Indoors
	<Input type = 'Radio' Name ='inout' value= 'outdoors' <?PHP print $out_status; ?>>Outdoors
	</p>
<p>Brief Description of Event:</p>
	<textarea name="eventdesc" cols=80 rows=3><?php echo $eventdesc ?></textarea>
<p>Estimated No. of People in Audience: 
	<input name="attendance" type="text" id="attendance" size="4" maxlength="6" value="<?php echo $attendance ?>"></p>
<p>Brief Description of Audience (i.e., ages, common interests): 
	<input name="audience" type="text" id="audience" size="35" maxlength="35" value="<?php echo $audience ?>"></p></p>
<p>Average	Bike Knowledge: 
	<Input type = 'Radio' Name ='knowledge' value= 'beginner' <?PHP print $beginner_status; ?>>Beginner 
	<Input type = 'Radio' Name ='knowledge' value= 'intermediate' <?PHP print $intermediate_status; ?>>Intermediate 
	<Input type = 'Radio' Name ='knowledge' value= 'advanced' <?PHP print $advanced_status; ?>>Advanced 
	<Input type = 'Radio' Name ='knowledge' value= 'all' <?PHP print $all_status; ?>>All levels
</p>
<h4>ABOUT YOUR ORGANIZATION</h4>
<hr>
<p>Organization Name: 
	<input name="orgname" type="text" id="orgname" size="50" maxlength="50" value="<?php echo $orgname ?>"></p>
<p>Brief Description of Organization:</p>
	<textarea name="orgdesc" cols=80 rows=3><?php echo $orgdesc ?></textarea>
<p><input type = 'Radio' Name ='orgtype' value= '501c3' <?PHP print $np_status; ?>>501c3 Organization - 
	Tax ID No: 		
	<input name="orgID" type="text" id="orgID" size="10" maxlength="20" value="<?php echo $orgID ?>">&nbsp; &nbsp; &nbsp;
	<input type = 'Radio' Name ='orgtype' value= 'profit' <?PHP print $p_status; ?>>For Profit
<p>Address:  
	<input name="address" type="text" id="address" size="50" maxlength="50" value="<?php echo $address ?>">
<p>City:  
	<input name="city" type="text" id="city" size="35" maxlength="35" value="<?php echo $city ?>">
State:  
	<select name="state" id="state">
			<option value="<?php echo $state ?>" selected="selected"><?php echo $state ?></option>
			<option value="CO">Colorado</option>
			<option value="WY">Wyoming</option>			
			<option value="AL">Alabama</option>
			<option value="AK">Alaska</option>
			<option value="AZ">Arizona</option>
			<option value="AR">Arkansas</option>
			<option value="CA">California</option>
			<option value="CT">Connecticut</option>
			<option value="DC">District of Columbia</option>
			<option value="DE">Delaware</option>
			<option value="FL">Florida</option>
			<option value="GA">Georgia</option>
			<option value="HI">Hawaii</option>
			<option value="ID">Idaho</option>
			<option value="IL">Illinois</option>
			<option value="IN">Indiana</option>
			<option value="IA">Iowa</option>
			<option value="KS">Kansas</option>
			<option value="KY">Kentucky</option>
			<option value="LA">Louisiana</option>
			<option value="ME">Maine</option>
			<option value="MD">Maryland</option>
			<option value="MA">Massachusetts</option>
			<option value="MI">Michigan</option>
			<option value="MN">Minnesota</option>
			<option value="MS">Mississippi</option>
			<option value="MO">Missouri</option>
			<option value="MT">Montana</option>
			<option value="NE">Nebraska</option>
			<option value="NV">Nevada</option>
			<option value="NH">New Hampshire</option>
			<option value="NJ">New Jersey</option>
			<option value="NM">New Mexico</option>
			<option value="NY">New York</option>
			<option value="NC">North Carolina</option>
			<option value="ND">North Dakota</option>
			<option value="OH">Ohio</option>
			<option value="OK">Oklahoma</option>
			<option value="OR">Oregon</option>
			<option value="PA">Pennsylvania</option>
			<option value="RI">Rhode Island</option>
			<option value="SC">South Carolina</option>
			<option value="SD">South Dakota</option>
			<option value="TN">Tennessee</option>
			<option value="TX">Texas</option>
			<option value="UT">Utah</option>
			<option value="VT">Vermont</option>
			<option value="VA">Virginia</option>
			<option value="WA">Washington</option>
			<option value="WV">West Virginia</option>
			<option value="WI">Wisconsin</option>
		</select>
Zip:   <input name="zip" type="text" id="zip" size="10" maxlength="10" value="<?php echo $zip ?>">
<p>Website: 
	<input name="website" type="text" id="website" size="35" maxlength="35" value="<?php echo $website ?>">
<p>Contact Name: 
	<input name="contact" type="text" id="contact" size="35" maxlength="35" value="<?php echo $contact ?>"> Relationship to Organization: 
	<input name="relationship" type="text" id="relationship" size="35" maxlength="35" value="<?php echo $relationship ?>"></p>
<p>Contact Phone:   
	<input name="phone" type="text" id="phone" size="13" maxlength="13" value="<?php echo $phone ?>">
Contact Email:   
	<input name="email" type="text" id="email" size="35" maxlength="200" value="<?php echo $email ?>">

<h4>HOW DID YOU HEAR ABOUT THE CO-OP?</h4>
<hr>
<input name="howhear" type="text" id="howhear" size="35" maxlength="50" value="<?php echo $howhear ?>">
<hr>
<?php
require_once('/var/www/fcbikecoop.org/root/recaptcha/recaptchalib.php');
$publickey = "6LcljgQAAAAAAL1T9O8K4Rv0n3at7RUhFQBsLnoG";
echo recaptcha_get_html($publickey, $error);
?>
<br><br><input type="submit" value="Send" name="submit">
</form>
