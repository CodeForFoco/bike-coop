<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<h1>Community Listening Sessions</h1>
			<p>As a part of their effort to provide community input into the effort to Plan Fort Collins for the next 5-50 years, the Fort Collins Bike Co-op announces a series of community "listening sessions" or "Bike Town Meetings" to identify issues and opportunities for the future of bicycling in the city.</p>
			<p>Plan Fort Collins includes major updates to both City Plan and to the Master Transportation Plan.  "What will it be like to ride a bicycle in Fort Collins twenty years from now?"  Now is the time to begin imagining that and to provide input about where we'd like to be in 2020, 2030 and beyond.</p>
			<p>To achieve as much public input as possible, the Co-op will hold <b>nine public meetings</b> over the next seven weeks.  The information we gather will be delivered to the Bicycle Advisory Committee, the Transportation Board, the planning team for Plan Fort Collins and other groups or organizations as appropriate.</p>
			<p>The following meetings are open to the public.  Both cyclists and non-cyclists are invited to bring a lunch and to provide comments on bicycling opportunities and issues throughout Fort Collins.  The first and last meetings will focus on the city in general while the other discussions will concentrate on specific areas of the Fort Collins as indicated below.  We will try to address some of the questions listed but please bring your own questions, concerns and great ideas!</p>
			<h2>Tuesday, March 30th;  12-1:30 p.m.</h2>
			<a href="https://www.homestatebank.com/index.cfm">Home State Bank Community Room</a><br>
			303 East Mountain Avenue <a href="http://maps.google.com/maps?oe=utf-8&client=firefox-a&ie=UTF8&q=Home+State+Bank+fort+collins&fb=1&gl=us&hq=Home+State+Bank&hnear=fort+collins&cid=0,0,6245210345804473090&ei=D3yZS--iNIvqNfLrkHo&ved=0CAoQnwIwAA&ll=40.586891,-105.073693&spn=0.009924,0.014527&t=h&z=16&iwloc=A">(map)</a><br>

			Topic:  Planning for the Future of Bicycling in Fort Collins<br>
			A general discussion and introduction to Plan Fort Collins from the bike seats
			<h2>Thursday, April 1st: 12-1:30 p.m.</h2>
			<a href="http://www.rei.com/stores/49">REI</a><br>
			4025 South College Avenue <a href="http://maps.google.com/maps?oe=utf-8&client=firefox-a&hl=en&ie=UTF8&q=REI+fort+collins&fb=1&gl=us&hq=REI&hnear=fort+collins&cid=0,0,15170339916295513249&ei=dHyZS-vhAZPSMvjdnHo&ved=0CAcQnwIwAA&ll=40.531741,-105.078156&spn=0.009932,0.014527&t=h&z=16&iwloc=A">(map)</a><br>
			Topic :  Bicycling in Mid-Town Fort Collins: Prospect to Harmony:  Mason Trail, Foothills Fashion Mall, and back and forth across College Avenue<br>
			This will be a very interesting discussion about issues and opportunities along the Mason Corridor, College Avenue and the area of the Foothills Fashion Mall.
			<h2>Tuesday, April 6th:  12-1:30 p.m</h2>
			<a href="https://www.homestatebank.com/index.cfm">Home State Bank Community Room</a><br>
			303 East Mountain Avenue <a href="http://maps.google.com/maps?oe=utf-8&client=firefox-a&ie=UTF8&q=Home+State+Bank+fort+collins&fb=1&gl=us&hq=Home+State+Bank&hnear=fort+collins&cid=0,0,6245210345804473090&ei=D3yZS--iNIvqNfLrkHo&ved=0CAoQnwIwAA&ll=40.586891,-105.073693&spn=0.009924,0.014527&t=h&z=16&iwloc=A">(map)</a><br>
			Topic:  Bicycling in Downtown Town Fort Collins: Across College, the Downtown Strategic Plan, Alleyways, Bikeways through Oak St. Plaza & Old Town Square & more.<br>
			A discussion of connectivity across College Avenue in Old Town, bicycling or not in Old Town Square and the Oak Street Plaza on College Avenue and more.
			<h2>Tuesday, April 13th:  12-1:30 p.m</h2>
			<a href="http://www.jaxmercantile.com/">Jax Mercantile</a><br>
			1200 N. College Avenue <a href="http://maps.google.com/maps?oe=utf-8&client=firefox-a&hl=en&q=JAX+fort+collins&fb=1&gl=us&ie=UTF8&hq=JAX&hnear=Fort+Collins,+CO&t=h&z=13&iwloc=A">(map)</a><br>
			Topic:  Bicycling on & around North College: access across the Poudre River, access east-west in the area & . . . .<br>
			We will discuss the new Urban Renewal Authority and improvements on North College, including bike lanes, east-west connectivity across College and north-south connections from Old Town north.
			<h2>Wednesday, April 14th:  7-8:30 p.m.</h2>
			<a href="http://www.jaxmercantile.com/">Jax Mercantile</a><br>
			1200 N. College Avenue <a href="http://maps.google.com/maps?oe=utf-8&client=firefox-a&hl=en&q=JAX+fort+collins&fb=1&gl=us&ie=UTF8&hq=JAX&hnear=Fort+Collins,+CO&t=h&z=13&iwloc=A">(map)</a><br>
			Topic:  Bicycling on & around North College: access across the Poudre River, access east-west in the area & . . . .<br>
			We will discuss the new Urban Renewal Authority and improvements on North College, including bike lanes, east-west connectivity across College and north-south connections from Old Town north.
			<h2>Tuesday, April 27th 12-1:30</h2>
			<a href="http://www.sc.colostate.edu/">Lory Student Center, CSU</a><br>
			Room 208<br>
			Topic:  Bicycling on and around the CSU Campus: What about that "car-free" campus we've been hearing about?   East-west cycling on campus; A bikeway through the plaza?<br>
			Getting to and from campus, bicycle access to Old Town and to the City's bike trails.
			<h2>Thursday, April 29th: 12-1:30 p.m.</h2>
			<a href="http://www.thegroupinc.com/">The Group Real Estate</a><br>
			2803 East Harmony Road <a href="http://maps.google.com/maps?f=q&source=s_q&hl=en&geocode=&q=2803+East+Harmony+Road&sll=40.521523,-105.026218&sspn=0.004967,0.007263&gl=us&ie=UTF8&hq=&hnear=2803+E+Harmony+Rd,+Fort+Collins,+Larimer,+Colorado+80528&ll=40.52463,-105.021873&spn=0.019866,0.029054&t=h&z=15&iwloc=A">(map)</a><br>
			Topic :  Bicycling in South Fort Collins:  How to handle bicycling on Harmony & across Harmony;  How will the Power Trail cross Harmony?  What are the alternatives to bicycling ON Harmony?<br>
			Connectivity and safety issues along and across Harmony Road and elsewhere.
			<h2>Thursday, April 29th:  7-8:30 p.m</h2>
			<a href="http://www.rei.com/stores/49">REI</a><br>
			4025 South College Avenue <a href="http://maps.google.com/maps?oe=utf-8&client=firefox-a&hl=en&ie=UTF8&q=REI+fort+collins&fb=1&gl=us&hq=REI&hnear=fort+collins&cid=0,0,15170339916295513249&ei=dHyZS-vhAZPSMvjdnHo&ved=0CAcQnwIwAA&ll=40.531741,-105.078156&spn=0.009932,0.014527&t=h&z=16&iwloc=A">(map)</a><br>
			Topic :  Bicycling in Mid-Town Fort Collins: Prospect to Harmony: Mason Trail, Foothills Fashion Mall, College Avenue, frontage roads on College and more<br>
			This will be a very interesting discussion about issues and opportunities along the Mason Corridor, College Avenue and the area of the Foothills Fashion Mall.
			<h2>Wednesday, May 5th:  7-9 p.m.</h2>
			<a href="http://newbelgium.com">New Belgium Brewing</a><br>
			500 Linden Street <a href="http://maps.google.com/maps?oe=utf-8&client=iceweasel-a&ie=UTF8&q=500+linden+st+fort+collins&fb=1&gl=us&hnear=&cid=0,0,13953154445904158129&ei=SIepS-ztC5TwsgOF3JizBQ&ved=0CAcQnwIwAA&hq=500+linden+st+fort+collins&t=h&z=16&iwloc=A">(map)</a><br>
			We will wrap up our town meetings and summarize our findings with a final evening forum at New Belgium Brewing.<br>
			Topic:  Summarizing all of our meetings: bicycle issues and opportunities over the next 20-30 years
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
