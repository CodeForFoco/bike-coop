<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">Event Request</div>
         <p>Thank you. You have sent us a request for tabling support at your event..<br><br>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
