<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">Fundrasing and Grants</div>
	 <p>The Bike Co-op has an active fundraising program that includes:  1) donations from individuals; 2) corporate or business sponsorship opportunities; 3) foundation grants.</p>
	 1) <a href="http://www.fcbikecoop.org/programs/grants/donations.php">Click here</a> to view our individual donation opportunities through a one-time donation or our monthly subscription donations.<br>
	 2) <a href="http://fcbikecoop.org/programs/grants/business.php">Click here</a> to see our business and corporate sponsorship opportunities.<br>
	 3) <a href="http://fcbikecoop.org/programs/grants/goals.php">Click here</a> to see our foundation grant goals.
	 <h2>Contact</h2>
	 Program Coordinator: <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "grants@fcbikecoop.org")?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">gr...@fcbikecoop.org</a>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
