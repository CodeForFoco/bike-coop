<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<div class="heading">Retail Store</div>
			<p>In addition to our many <a href="http://fcbikecoop.org/programs/index.php">programs</a> the Co-op sells bikes, bikes parts, and more.</p>
			<h3>All retail proceeds are used to support Co-op programs.<h3>
			<h2>Full Bikes</h2>
			<p>Our refurbished bikes are hand picked from donations and built up by our experienced mechanics.  They're rarely last years model, but you can be sure that these are high quality bikes.  We strive to sell bikes that will make your cycling experience enjoyable.
We also have what we call "As is Bikes" these are bikes that have not yet had a Co-op overhaul.  If you're looking for a good deal, these bikes can be very affordable.  You can come in and take a bike home, or if you like, you can work on it at our next <a href="http://fcbikecoop.org/programs/open_shop.php">Open shop</a>.  Bikes can range from just needing some air in the tires, to just a bare frame, and the prices vary accordingly.</p>
<p><a href="http://fortcollins.craigslist.org/search/bid?query=Bike+Co-op&catAbb=bia">Click Here to find our current refurbished bikes.</a></p>
			<h2>Parts</h2>
			<p>We have a huge parts room full used parts that our volunteers have meticulously sorted.  If you're looking for a specific bike part, there is a good chance that we have it, or something that could take it's place.  We also have many new parts.  We stock inexpensive tubes, tires, locks, helmets, and lights.</p>
			<p>The Co-op accepts Cash-Check-Charge</p>
			<p>Check our <a href="http://fcbikecoop.org/calendar.php">Calendar</a> for Retail Store Hours</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
