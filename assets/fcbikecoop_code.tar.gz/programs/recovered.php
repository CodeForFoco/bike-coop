<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">Stolen and Found Bikes</div>
	 <p>The Bike Co-op handles all of Fort Collins recovered bikes. Each recovered bike is logged, tagged, and filed in our database.</p>
	 <h2>Report a Found/Abandoned Bike</h2>
	 <p>If you come across a bike that you believe has been lost or abandoned, we'll do our best to get it back to its owner and back on the road.  Please use the <a href="http://fcbikecoop.org/programs/bars/AbandonedBikeReport.php">Abandoned Bike Report Form</a> to report the bike.  An abandoned bike is defined as a bike that has been left at a location, without moving, for at least 48 hours.</p>
	 <h2>Stolen Bikes</h2>
	<p>If your bike has been stolen the first thing you need to do is report it to the police.  Less than 5% of recovered bikes are returned to their owners, largely due to the lack of filed Police Reports.  The Bike Co-op cross references our recovered bike database with the Police stolen bike reports once a week.  If your bike shows up at the Co-op we will contact the officer in charge of your case, and get your bike back to you as soon as possible.</p>
	<p>Please do not call the Co-op to ask if we have found your bike, the volunteers working on-site are rarely the same volunteers that handle the recovered bikes.  Once you file a police report, your bike will be flagged in our system.</p>
	 <p><b>Stolen bikes can be reported to the Fort Collins Police by phone 970-221-6540 or <a href="http://www.fcgov.com/police/coplogic-start-report.php">online</a></b></p>
	 <p>The Bike Co-op strongly encourages you to record your bike's make, model, description, and serial number just in case it's ever stolen!</p>
	 <h2>Fate of Recovered Bikes</h2>
	<p>When a bike comes in, if its not matched to a Stolen Bike Report, it will be held for a minimum of 40 days. After an initial 30 day holding period, the bikes are listed on the City Website (property manifest) and held for another 10 days. If the owner is not found after this process then each bike's fate will lie in various Co-op programs.</p>
	<h2>History</h2>
	 <p>Starting February 1st, 2008, the Fort Collins Bike Co-op and Fort Collins Police Department created a new partnership. Prior to 2008 every bike that was deemed abandoned in Fort Collins was crammed into a shipping container and shipped off to California to be put up for auction. This usually paid the cost of storing the bikes over the course of the year and shipping them off.  Now, through a contract with the City, the Co-op is able to utilize these bikes in our Earn-A-Bike, Bikes for Ghana, and recycling programs.  No longer do quality bikes leave our community or are bikes fit for recycling expensively shipped around,  ALL recovered bikes are put to their best use.</p>
	 <h2>Contact Info</h2>
	 Project Coordinator: <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "bars@fcbikecoop.org")?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ba...@fcbikecoop.org</a>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
