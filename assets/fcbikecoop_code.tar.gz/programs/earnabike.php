<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
	<div class="heading">Earn A Bike</div>
	<p>Thank you for your interest in our Earn-A-Bike (EAB) program. The program started as a result of the public needing transportation that could not found elsewhere in the community. Bicycles not claimed from Police Services and bicycles donated to the Bike Co-op are overhauled and placed in the EAB program.</p>
	<h2>What</h2>
	<p>Participants earn a bike by volunteering their services to the community. The Earn-A-Bike program requires participants to volunteer at organizations outside the Co-op. Each participant may earn only one bike per 12 month period.</p>
	<p>Bikes can be earned by volunteering twenty hours at a state certified non-profit agency. Another option requires applicants to volunteer ten hours of service with a letter of referral indicating need or hardship. Letters of referral may be obtained from any church organization, humanitarian, government, or social services agency (including the unemployment office).</p>
	<h2>How</h2>
	<ul><li>Pick up an Earn-a-Bike application at the Bike Co-op. Applications are limited and dispersed the first of each month and are on a first come first serve basis.</li>
	<li>Volunteer at any non-profit organization. If you need help finding an organization, check out the <a href="http://uwaylc.org">United Way website.</a> They offer many opportunities to help.</li>
	<li>Hours volunteered at any organization prior to receiving a Co-op application <b>WILL NOT</b> be accepted.</li>
	<li>Volunteer hours must be completed within 60 days of receiving your application.</li>
	<li>It is the responsibility of each EAB applicant to notify the Bike Co-op EAB Coordinator of any change in contact information. If we cannot contact you, you will be dropped from the program.</li>
	<li>We <b>WILL</b> verify your volunteer hours and check your photo ID before you can receive your bike.</li>
	<li>After your hours have been verified, our volunteer mechanics will build you a bike based on the information you provide to us. It may take up to four weeks to build a bike from our supply of used bikes. <b>THE BIKES WILL BE MOUNTAIN BIKES!</b></li>
	<li>The Bike Co-op will attempt to notify you three times to pick up your bike. If you do not respond you will be dropped from the program.</li>
	</ul>
	<h2>Contact Info</h2>
	Project Coordinator: <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "earnabike@fcbikecoop.org")?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ea...@fcbikecoop.org</a>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
