<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<div class="heading">Open Shop</div>
				<p>Open shop is when we open up our shop to you.  You can come in and use any of our tools to tune up your own bike.  You will be paired up with one of our experienced mechanics to work on any part of your bike you please.  In return, we ask that you give us a small donation of $10 per hour*.</p>

				<p>Here's what your $10 per hour gets you:</p>
				<ul>
					<li>Use of your own complete bench of bicycle specific tools.</li>
					<li>Use of your own bicycle stand</li>
					<li>Your very own mechanic to ask any question you can think of... about bikes.</li>
					<li>Chain lube, cable lube, bearing grease</li>
					<li>Access to the parts washer, for removing that caked on grease.</li>
					<li>Unlimited Grease Rags!!</li>
					<li>Clothing saving aprons.</li>
					<li>All the air you can pump.</li>
				</ul>
				<p>Don't forget, we sell new and used parts in our <a href="http://fcbikecoop.org/programs/retail_store.php">retail store</a>.  So, if your working with a mechanic and you find a part that needs to be replaced, there is a good chance we have it.  The shop works on a first come first served basis.  On busy days there may be a wait until the next mechanic frees up.  If it's getting toward the end of the day, and there are people waiting, you may be turned away.<!---  There are a few rules in the shop, you can learn more by reading our welcome card(link)---></p>
				<p>The Co-op accepts Cash-Check-Charge*</p>
				<p>Check our <a href="http://fcbikecoop.org/calendar.php">calendar </a> for open shop hours and closures.</p>
				<p>*Those that are less fortunate can trade work for shop time.  We won't turn good people away.</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
