<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">Recycling</div>
     	 <p>We reuse everything we possible can, but sometimes parts are too far gone so we have to recycle them.  There is always a pile of parts that need to be sorted for multiple different destinations.</p>
	 <h2>Links</h2>
	 <p>All Steel is recycled by <a href=""http://www.coloradoironmetal.com/">Colorado Iron and Metal</a></p>
	 <p>All Aluminum is recycled by <a href="http://www.coloradoironmetal.com/">Colorado Iron and Metal</a></p>
	 <p>Old tires and tubes are recycled by <a href="http://newbelgium.com/">New Belgium Brewing</a></p>
	 <p>Our comingled and paper products are all recycled through the city's recycling program.</p>
	 <h2>Contact</h2>
	 Program Coordinator: <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "recycling@fcbikecoop.org")?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">re...@fcbikecoop.org</a>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
