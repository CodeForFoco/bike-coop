<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
<div class="heading">Abandoned Bike Report</div>
<p>Thank you for submitting an abandoned bike report to the Fort Collins Bike Co-op.  Your report will be processed shortly and you should receive a response within the next 24 hours.  If you have any questions during this time, please contact the Bike Retrieval Squad (BaRS) Coordinator at bars@fcbikecoop.org.
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
