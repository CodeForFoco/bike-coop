<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
		<div class="heading">Help Wanted</div>
		<div class="contents-image">
			<a href="http://4.bp.blogspot.com/_1M4h1qq6CkQ/SckzpAKgrdI/AAAAAAAADxY/hSAdAgRbzYY/s1600-h/DSC_0167.JPG"><img src="http://4.bp.blogspot.com/_1M4h1qq6CkQ/SckzpAKgrdI/AAAAAAAADxY/hSAdAgRbzYY/s320/DSC_0167.JPG" alt="Loading Bikes into a Truck"></a>
			<a href="http://2.bp.blogspot.com/_1M4h1qq6CkQ/SckzL8qzCsI/AAAAAAAADxQ/UQ-WE5E32-c/s1600-h/Rick%27s+Phone+March+001.jpg"><img src="http://2.bp.blogspot.com/_1M4h1qq6CkQ/SckzL8qzCsI/AAAAAAAADxQ/UQ-WE5E32-c/s320/Rick%27s+Phone+March+001.jpg" alt="Moving work benches"></a>
			<a href="http://4.bp.blogspot.com/_1M4h1qq6CkQ/Sckx3Um_wQI/AAAAAAAADxI/z9bxEXA8J14/s1600-h/DSC_0318.JPG"><img src="http://4.bp.blogspot.com/_1M4h1qq6CkQ/Sckx3Um_wQI/AAAAAAAADxI/z9bxEXA8J14/s320/DSC_0318.JPG" alt="Bike Valet"></a>
			<a href="http://2.bp.blogspot.com/_1M4h1qq6CkQ/SckwHee5trI/AAAAAAAADw4/9N80lCnDEmg/s1600-h/IMG_1367.JPG"><img src="http://2.bp.blogspot.com/_1M4h1qq6CkQ/SckwHee5trI/AAAAAAAADw4/9N80lCnDEmg/s320/IMG_1367.JPG" alt="Bike Parade"></a>
			<a href="http://1.bp.blogspot.com/_1M4h1qq6CkQ/SckvnivnUeI/AAAAAAAADww/bFEaX2RN7l0/s1600-h/IMG_1582.JPG"><img src="http://1.bp.blogspot.com/_1M4h1qq6CkQ/SckvnivnUeI/AAAAAAAADww/bFEaX2RN7l0/s320/IMG_1582.JPG" alt="Volunteer Truing a wheel"></a>
		</div>
		<h3>If you have any interest in helping us with these volunteer positions, please head over and get<a href="http://fcbikecoop.org/volunteers.php"> Signed Up</a></h3>
		<h3>Bike Mechanics -</h3>
		Experienced or apprentice mechanics to help with Earn-A-Bikes, For Sale bikes, and restore impounded and donated bikes. Contact <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "coordinator@fcbikecoop.org");?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">co...@fcbikecoop.org</a>
		<h3>Bike Co-op Greeters -</h3>
		Friendly greeters needed every day the Co-op is open.  Help Co-op customers with bike problems, issues and answering questions. Contact <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "earnabike@fcbikecoop.org");?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ea...@fcbikecoop.org</a>
		<h3>Bicycle Retrieval Squad -</h3>
		Help needed to retrieve lost and abandoned bikes as necessary.  Have a truck?  All the better.  Or use our bike + trailer to bring bikes in. Contact <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "bars@fcbikecoop.org");?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ba...@fcbikecoop.org</a>
		<h3>Bike Co-op Art Department -</h3>
		Help wanted to provide artwork for shirts, murals, posters, diagrams, signage, decals, and countless other fun stuff! Contact <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "art-admin@fcbikecoop.org");?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ar...@fcbikecoop.org</a>
		<h3>Community Outreach, Bike Safety & Mechanics Classes -</h3>
		Join our team to talk bike education to school groups, CSU and other community groups. Contact <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "outreach@fcbikecoop.org");?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ou...@fcbikecoop.org</a>
		<h3>Earn-a-Bike Assistants -</h3>
		Help organize, coordinate, and promote our E-a-B program to any & all who would like to build and earn their own recovered bike. Contact <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "earnabike@fcbikecoop.org");?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ea...@fcbikecoop.org</a>
		<h3>Fundraising and Grant writing needed -</h3>
		Help us find that next mini-grant, major donation, and $5 monthly subscription to feed the Bike Co-op system! Contact <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "grants@fcbikecoop.org");?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">gr...@fcbikecoop.org</a>
		<h3>Ghana Bikes Project -</h3>
		Help us & the World to send  450 abandoned bikes to Ghana with the Village Bicycle Project. Contact <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "bikes4ghana@fcbikecoop.org");?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">bi...@fcbikecoop.org</a>
		<h3>Iron mongers, tinkers, tinsmiths and blacksmiths needed -</h3>
		We need help recycling iron, steel, aluminum and more to keep it out of the landfill. Contact <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "recycling@fcbikecoop.org");?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">re...@fcbikecoop.org</a>
		<h3>League Cycling Instructors in Training -</h3>
		Join our team of League of American Cyclists Bike Ed instructors who will develop and teach Bike Ed. To schools! Contact <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "lci@fcbikecoop.org");?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">lc...@fcbikecoop.org</a>
		<!--<h3>Newsletter Editor -</h3>
		We need a wordsmith to help us tell the world what we're doing!  Work with all our lead volunteers to keep people informed, inflamed, and inspired! Contact <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "pr@fcbikecoop.org");?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">p...@fcbikecoop.org</a>-->
		<h3>Racing Volunteers -</h3>
		Help monitor, and cheer the National Collegiate Cycling Championships in May 2009 and 6 day races around the oval this summer. Contact <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "vac@fcbikecoop.org");?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">va...@fcbikecoop.org</a>
		<!--<h3>Valet Bike Parking -</h3>
		Bike Parking at community events make the Co-op more visible in town, spread the word, and ask for tips and donations to the Co-op. Contact <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "outreach@fcbikecoop.org");?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ou...@fcbikecoop.org</a>-->
		<h3>Volunteer coordinators -</h3>
		Every single activity listed above needs help with coordinatin', innovatin', and activatin'.  Maybe that would be you?! Contact <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "vac@fcbikecoop.org");?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">va...@fcbikecoop.org</a>
		<h3>Tabling -</h3>
		Customer service and sales people need to help spread the work about the Bike Co-op and our need for volunteers of all flavors! Contact <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "outreach@fcbikecoop.org");?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ou...@fcbikecoop.org</a>
		<h3>If you have any interest in helping us with these volunteer positions, please head over and get<a href="http://fcbikecoop.org/volunteers.php"> Signed Up</a></h3>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
