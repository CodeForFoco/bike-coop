<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
		<div class="heading">Co-op Classifieds</div>
		<p>Please note:  the following positions are volunteer positions only at this time.   (But who knows, when our collective pedal-boat comes in, we might be able to pay a little for some of this work!)</p>
		<div id="classifieds">
			<table align="top" border="1" cellpadding="5">
				<tr>
					<td><div class="classifieds-title">Bike Mechanics-</div>Experienced or apprentice mechanics to help with Earn-A-Bikes, prep library bikes, and restore impounded and donated bikes.</td>
					<td><div class="classifieds-title">Bike Co-op Greeters-</div>Friendly greeters needed every day the Co-op is open.  Help Co-op customers with bike problems, issues and answering questions.</td>
					<td><div class="classifieds-title">Bicycle Retrieval Squad-</div>Help needed to retrieve lost and abandoned bikes as necessary.  Have a truck?  All the better.  Or use our bike + trailer to bring bikes in.</td>
				</tr>
				<tr>
					<td><div class="classifieds-title">Bike Co-op Art Department-</div>Help wanted to provide artwork for shirts, murals, posters, diagrams, signage, decals, and countless other fun stuff!.</td>
					<td><div class="classifieds-title">Bike Library Checkout Volunteers-</div>Meet, greet, and entertain visitors to the Fort by checking out library bikes from the kiosk or Bike Co-op during the week.</td>
					<td><div class="classifieds-title">Community Outreach, Bike Safety & Mechanics Classes-</div>Join our team to take bike ed to school groups, CSU and other community groups.</td>
				</tr>
				<tr>
					<td><div class="classifieds-title">Earn-a-Bike Assistants-</div>Help organize, coordinate, and promote our E-A-B program to any & all who would like to build and earn their own recovered bike.</td>
					<td><div class="classifieds-title">Fundraising and Grant writing needed-</div>Help us find that next mini-grant, major donation, and $5 monthly subscription to feed the Bike Co-op system!</td>
					<td><div class="classifieds-title">Ghana Bikes Project-</div>Help us & the World to send abandoned bikes to Ghana with the Village Bicycle Project.</td>
				</tr>
				<tr>
					<td><div class="classifieds-title">Iron mongers, tinkers, tinsmiths and blacksmiths needed-</div>We need help recycling iron, steel, aluminum and more to keep it out of the landfill.</td>
					<td><div class="classifieds-title">League Cycling Instructors in Training-</div>Join our team of League of American Cyclists Bike Ed instructors who will develop and teach Bike Ed. To schools!</td>
					<td><div class="classifieds-title">Newsletter Editor-</div>We need a wordsmith to help us tell the world what we're doing! Work with all our lead volunteers to keep people informed, inflamed, and inspired!</td>
				</tr>
				<tr>
					<td><div class="classifieds-title">Racing Volunteers-</div>Help monitor, and cheer the National Collegiate Cycling Championships in May 2009 and 6 day races around the oval this summer.</td>
					<td><div class="classifieds-title">Valet Bike Parking-</div>Bike Parking atcommunity events make the Co-op more visible in town, spread the word, and ask for tips and donations to the Co-op.</td>
					<td><div class="classifieds-title">Volunteer coordinators-</div>Every single activity listed above needs help with coordinatin', constipatin', innovatin', and activatin'.  Maybe that would be you?!</td>
				</tr>
				<tr>
					<td><div class="classifieds-title">Tabling-</div>Customer service and sales people need to help spread the work about the Bike Co-op and our need for volunteers of all flavors!</td>
					<td></td>
					<td></td>
				</tr>
			</table>
		</div>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
