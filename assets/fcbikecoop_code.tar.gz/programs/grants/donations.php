<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
        <div class="heading">Donations</div>
	<p>All donations are welcome!!</p>
	<h2>Bikes and Parts</h2>
	<p>Whole bikes, partial bikes, working bikes, broken bikes, old parts, new parts, bike tools, other tools, single parts, basically anything bike related.  We would love to use all of your donations to build up working functional bikes.  Even if your donation can't be fixed we can recycle it for you.</p>
	<p>The Co-op does not participate in any sort of part trading.  You are welcome to earn or buy new parts, and donate your old ones.</p>
	<p>All donations can be dropped off at 1501 North College.  Please help us avoid theft and vandalism by dropping off your donations during <a href="http://fcbikecoop.org/calendar.php">open hours</a>.  You can drop of your donations at the front door during public hours, or the back door during staff only hours.  You can also <a href="http://fcbikecoop.org/contact.php">contact us</a> and we'll come and pick up your parts by bike.  The Fort Collins Bike Co-op is a 501c3 non-profit corporation, so your donations are tax deductible.  Contact us if you need a receipt for your donation. </p>
	<h2>Monetary Donations</h2>
	 You can also donate money to the Co-op.  You can do a one time donation with the button below.
	<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
		<input type="hidden" name="cmd" value="_s-xclick">
		<input type="hidden" name="hosted_button_id" value="5249669">
		<input type="image" src="http://fcbikecoop.org/images/btn_donate_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
		<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
	</form>
	$90 pays for one bike mechanic for a day to support our earn-a-bike and youth outreach programs
	<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
	 	<input type="hidden" name="cmd" value="_s-xclick">
	 	<input type="hidden" name="hosted_button_id" value="1190629">
	 	<input type="image" src="http://fcbikecoop.org/images/btn_donate_LG.gif" name="submit" alt="Paypal">
	 	<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1"> $90 Payment
	</form><br>
	Or you can set up a subscription to donate a little each month.<br>
	<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
		<input type="hidden" name="cmd" value="_s-xclick">
	 	<input type="image" src="http://fcbikecoop.org/images/btn_subscribe_LG.gif" name="submit" alt="PayPal - The safer, easier way to pay online!">
	 	<img alt="Paypal" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
	 	<input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIHqQYJKoZIhvcNAQcEoIIHmjCCB5YCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYC7Gpg7ZFbZqgKvtIJCPAfjCdYahuDFVdhx0SXYImckxmxKz+qBa2DYDnEuxiuO1iSkJx1k4FDqC8hIwU9YXK+EfPLBliCSu2rvKtRz44EokNuEhejD5vgPJEnHQiwYd1UzyEX/xlAJAJv5eqj35UDoCKoVzdapktYMYModDWsY/jELMAkGBSsOAwIaBQAwggElBgkqhkiG9w0BBwEwFAYIKoZIhvcNAwcECCSl6RznJ5d1gIIBAKyHG7FwI8eb8XB47z4KR92vY8txB9/CNcqzJB7qQ72gWSkFkoxINt77drwI/SrWe+rOM9zZ5Dzb1ZLpbqyHoBn4dRqQ3g1tBBw5N4B41mOlKDEGqX8b5Mw1Qtpros7q73aMDrBtIFMplPTphmLls+ieieBgOyLk8oHVvwE+5W3sQUfbAS1NvxkXCvvwYL+m89Vjamy4MDPsWQvY+e4tF0R2imAW9R0fgOwQYGu07Uac5PloW/HFAV5DHidMLkLQdRZlqlkp50+GQKwkR6EpecURX6vAT+GBM7ZUUjpVPBVv7fFS9tO17bCHY4f1YwRomX83cUeFkqd63c1RtU6yRHGgggOHMIIDgzCCAuygAwIBAgIBADANBgkqhkiG9w0BAQUFADCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wHhcNMDQwMjEzMTAxMzE1WhcNMzUwMjEzMTAxMzE1WjCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAMFHTt38RMxLXJyO2SmS+Ndl72T7oKJ4u4uw+6awntALWh03PewmIJuzbALScsTS4sZoS1fKciBGoh11gIfHzylvkdNe/hJl66/RGqrj5rFb08sAABNTzDTiqqNpJeBsYs/c2aiGozptX2RlnBktH+SUNpAajW724Nv2Wvhif6sFAgMBAAGjge4wgeswHQYDVR0OBBYEFJaffLvGbxe9WT9S1wob7BDWZJRrMIG7BgNVHSMEgbMwgbCAFJaffLvGbxe9WT9S1wob7BDWZJRroYGUpIGRMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbYIBADAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBQUAA4GBAIFfOlaagFrl71+jq6OKidbWFSE+Q4FqROvdgIONth+8kSK//Y/4ihuE4Ymvzn5ceE3S/iBSQQMjyvb+s2TWbQYDwcp129OPIbD9epdr4tJOUNiSojw7BHwYRiPh58S1xGlFgHFXwrEBb3dgNbMUa+u4qectsMAXpVHnD9wIyfmHMYIBmjCCAZYCAQEwgZQwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tAgEAMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0wODA3MDEwNTM1MzFaMCMGCSqGSIb3DQEJBDEWBBQaUmdhQt7BHo/u5PvaW1VhduLnXzANBgkqhkiG9w0BAQEFAASBgGL9Q37LpXHFoqzGnWDRtnqsH/B+XJBMR0EcOiYLzjOTLcxmW0Lug9yFgIJRqYITY1kevI3XtgtSAtkTsgNxo9JB20rPq5tYDNEJebjQ7quVR9dwMRw5vaHjhN5Fof6mI9LA6631j4y25scyDTkOgXpybZyNrita9oCAuzf8fw9Q-----END PKCS7-----
	 	">&nbsp $5/Month
	</form>
	<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
		<input type="hidden" name="cmd" value="_s-xclick">
		<input type="hidden" name="hosted_button_id" value="6055599">
		<input type="image" src="http://fcbikecoop.org/images/btn_subscribe_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
		<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">&nbsp $7.50/Month
	</form>
	<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
	 	<input type="hidden" name="cmd" value="_s-xclick">
	 	<input type="image" src="http://fcbikecoop.org/images/btn_subscribe_LG.gif" name="submit" alt="PayPal - The safer, easier way to pay online!">
	 	<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
	 	<input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIHqQYJKoZIhvcNAQcEoIIHmjCCB5YCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYCkojk1s+vi3pSRDZu+tUm7GhMUdOKsCVBQaC8JJMv20bSnI17xrUAIpAnRoMHkkXNLmsecjBiun07KuLP5x/M5/vDu5dv1jx7RwmSTWZmi5JffLGHAPId9oXLanIF7akiS1B/+EksPm+m47WCcSfsuXQV+FPp+HRFiuvBbsHqwFjELMAkGBSsOAwIaBQAwggElBgkqhkiG9w0BBwEwFAYIKoZIhvcNAwcECMufQKzgJlt3gIIBAIR7LZnmO3RaH35cjhW+sgZ3szJsxeTQ953LsUCdEDA7CXp0xBHsmldZxCNDrihzaH09OpVAJ87Dw12fXW7knoBdwFtPawuIbV0TU9gtYospfE0peSw5P8pNQ3Dbxq/WikMi4tuePlJH6Pwl7/zuCljV+bbfjESegJe0VheXWUvf/elaHVcpeOIvIjzLYeHIj+r7/IrhQqDJG3+5NTXMfCdV9INK3bMbQgSbZJ4avDwZtC7ee+H7GbPwTwq6Rsgkx/+S85kY9Yr8bvbX9at8BNo4hxDjdBAOHYBQf71FZMAP4cxzwta2Ck8T0oSyLL1yZfDvngNO+bJ0jFtkVIbTf/KgggOHMIIDgzCCAuygAwIBAgIBADANBgkqhkiG9w0BAQUFADCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wHhcNMDQwMjEzMTAxMzE1WhcNMzUwMjEzMTAxMzE1WjCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAMFHTt38RMxLXJyO2SmS+Ndl72T7oKJ4u4uw+6awntALWh03PewmIJuzbALScsTS4sZoS1fKciBGoh11gIfHzylvkdNe/hJl66/RGqrj5rFb08sAABNTzDTiqqNpJeBsYs/c2aiGozptX2RlnBktH+SUNpAajW724Nv2Wvhif6sFAgMBAAGjge4wgeswHQYDVR0OBBYEFJaffLvGbxe9WT9S1wob7BDWZJRrMIG7BgNVHSMEgbMwgbCAFJaffLvGbxe9WT9S1wob7BDWZJRroYGUpIGRMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbYIBADAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBQUAA4GBAIFfOlaagFrl71+jq6OKidbWFSE+Q4FqROvdgIONth+8kSK//Y/4ihuE4Ymvzn5ceE3S/iBSQQMjyvb+s2TWbQYDwcp129OPIbD9epdr4tJOUNiSojw7BHwYRiPh58S1xGlFgHFXwrEBb3dgNbMUa+u4qectsMAXpVHnD9wIyfmHMYIBmjCCAZYCAQEwgZQwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tAgEAMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0wODA3MDEwNTM5MDVaMCMGCSqGSIb3DQEJBDEWBBRvePMCuLGRYZgSJxhpJ1E1ab7T8TANBgkqhkiG9w0BAQEFAASBgK7SYkwLyPaTuGR/V+WnXf8kQSF1UbUA8iRdy9Wj6HDFuUUzMa8cZgcBdMpk9Bfa/bHRysdPdzqdlnWtQY6gKupnuO23oRJQvSZSEcxvC/YlDtFYHJoIO4LAYv78AVdIN7IedT7s32b013QpUr5Xr2AT/vy16rZD9KAsW7R8qFHy-----END PKCS7-----
		">$10/Month
	</form>
	<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
	 	<input type="hidden" name="cmd" value="_s-xclick">
	 	<input type="image" src="http://fcbikecoop.org/images/btn_subscribe_LG.gif" name="submit" alt="PayPal - The safer, easier way to pay online!">
	 	<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
	 	<input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIHoAYJKoZIhvcNAQcEoIIHkTCCB40CAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYBgA2mG7kFRNV4ZtUrapJN43NI3zb4k/YG6c5/Wp9EqjQre4gQUVIIie8vDxUDkPOmpawy6OmKPlfOPNDcyE8WeGdx0VydvItTnvK06pbTrzOwh80DfdvQ1xzwdVywNJBVojDS+RaqVCjqnx0/L2e/21kJGSWTUgy69+5R3PCjn5TELMAkGBSsOAwIaBQAwggEcBgkqhkiG9w0BBwEwFAYIKoZIhvcNAwcECATon2/3jMWKgIH4rwIRX45nL40a+K0yMByml6osp9YjZxixIMGtXcMpIjG1XXm56q8i+C5BVR0TfnmExbCkULpvGzmvsMH+mQ9yJTKUcW8J4V0WZRT7YO0RJd8inpvpYUzParGr0wPrh5jimJsk+K3s1ysFIZsGVcUfAssadm76mHgvR2Zcsqp543NfIvrVmHqLAfrfSfrrhk9+Hw+AJqx66nyXrdNmimwyLL9HOrtCFCmfLIKXnkWGPdt+0Ujr9TJGjKQBc+brPu3ertiPxJ0bPj8v+sfxzqGF0+duXXcAabI6K/iVF0DjaioKH8ddi3dRuQ4ciFVGL7w4c5sKxDbi63+gggOHMIIDgzCCAuygAwIBAgIBADANBgkqhkiG9w0BAQUFADCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wHhcNMDQwMjEzMTAxMzE1WhcNMzUwMjEzMTAxMzE1WjCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAMFHTt38RMxLXJyO2SmS+Ndl72T7oKJ4u4uw+6awntALWh03PewmIJuzbALScsTS4sZoS1fKciBGoh11gIfHzylvkdNe/hJl66/RGqrj5rFb08sAABNTzDTiqqNpJeBsYs/c2aiGozptX2RlnBktH+SUNpAajW724Nv2Wvhif6sFAgMBAAGjge4wgeswHQYDVR0OBBYEFJaffLvGbxe9WT9S1wob7BDWZJRrMIG7BgNVHSMEgbMwgbCAFJaffLvGbxe9WT9S1wob7BDWZJRroYGUpIGRMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbYIBADAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBQUAA4GBAIFfOlaagFrl71+jq6OKidbWFSE+Q4FqROvdgIONth+8kSK//Y/4ihuE4Ymvzn5ceE3S/iBSQQMjyvb+s2TWbQYDwcp129OPIbD9epdr4tJOUNiSojw7BHwYRiPh58S1xGlFgHFXwrEBb3dgNbMUa+u4qectsMAXpVHnD9wIyfmHMYIBmjCCAZYCAQEwgZQwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tAgEAMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0wODA3MTgxOTQwMTFaMCMGCSqGSIb3DQEJBDEWBBQvskclDZViX7E874PlbK7k8A8gazANBgkqhkiG9w0BAQEFAASBgB5dg0/qC2+vHcuYOf9uj5VOoptxWw7yXB2k9s76LQs00SWZ53yjhTxyb4tqraom3NDwgg4QT9bXLCTPTofomrPwgavdXCfIVLU4zziX64WR2wMrZog+GJUoxy3h4fkIL+aEPQpJuZ9/RBHAshorW6Ky/rG1JDvGpDrUuWc/724T-----END PKCS7-----
	 	">$20/Month
	</form><br>
	If you need more options, please Email us at <?php echo recaptcha_mailhide_html ($mailhide_pubkey, $mailhide_privkey, "treasurer@fcbikecoop.org"); ?>
	<h2>Monetary Payments</h2>
	Taking a class at the co-op and need to make a payment? You can do that with the buttons below.
	<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
		<input type="hidden" name="cmd" value="_s-xclick">
		<input type="hidden" name="hosted_button_id" value="9089691">
		<table>
			<tr><td><input type="hidden" name="on0" value="Tuition amount">Tuition amount</td></tr><tr><td><select name="os0">
 			<option value="TS101 - full price">TS101 - full price $60.00
 			<option value="TS101 - teacher rate">TS101 - teacher rate $30.00
 			<option value="LCI training">LCI training $200.00
			</select> </td></tr>
		</table>
		<input type="hidden" name="currency_code" value="USD">
		<input type="image" src="https://www.paypal.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
		<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
	</form>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
