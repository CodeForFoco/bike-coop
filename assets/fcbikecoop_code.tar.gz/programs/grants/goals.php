<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">Grants and Fundraising Goals</div>
	 <p>Our Foundation Grants committee seeks foundations that offer grants-in-aid or other funding to facilitate all our programs that provide bicycles and bicycle education programs for youth, the homeless, those on prison release, and other socially and economically disadvantaged groups. </p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
