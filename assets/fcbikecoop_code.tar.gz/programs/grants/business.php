<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">Business Donations</div>
	 <ul><li><u>Individual Day Sponsor:</u>  $90 ($7.50/month) sponsors a bike mechanic for a day.</li>
	 <li><u>One-Week Sponsor:</u>  $540 ($45/month) sponsors a bike mechanic for a week.
	  (50 such donations will keep the co-op open for 50 weeks)</li>
	  <li><u>Corporate Sponsors:</u>   Become a corporate sponsor or provide a community grant:</li>
	   <li><u>Corporate Sponsor:</u>  $1,125 ($93.75/month) sponsors a bike mechanic one day per week for 3 months (12.5 weeks)</li>
	   <li><u>Corporate Partner:</u> $2,700 ($225/month) sponsors a bike mechanic one day per week for 30 weeks (this would be from April through mid-October, the busiest time at the Co-op)</li>
	   <li><u>Corporate Community Grant:</u> $4,500 ($375/month) sponsors one bike mechanic per day per week for 50 weeks to help us keep the community cycling</li>
	   </ul>
	   Please contact us at <?php echo recaptcha_mailhide_html ($mailhide_pubkey, $mailhide_privkey, "grants@fcbikecoop.org"); ?> if you are interested in donating to our cause.
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
