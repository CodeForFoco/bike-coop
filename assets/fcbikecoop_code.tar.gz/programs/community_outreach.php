<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">Community Outreach Group (C.O.G.)</div>
	 <p>The Community Outreach Group (COG) is here to connect the community to the Co-op and the Co-op to the community.  We're spreading the word about bicycling and would like to share our skills, talents and resources with you!  COG works to provide Bike Workshops, Donations for events, Bike Valet and more as services to your agency or organization. </p>
	 <h2>Outreach Requests</h2>
	 <p>We would love to have a table at your next event.  Please fill out the <a href="http://fcbikecoop.org/programs/community_outreach/COG Tabling Request Form _v01_.pdf">Tabling Request Form</a> and we'll check our availability.</p>
	 <!---<p>To request a Bike Donation for your agency or event, use the <a href="http://fcbikecoop.org/programs/community_outreach/BikeDonationRequest.php">Bike Donations Request Form.</a></p>--->
	 <p>We're sorry, but we currently aren't donating bikes to community events.  We hope to restart this program soon with more volunteer support.</p>
	 <!--<p>To request a Bike Donation for your agency or event, use the <a href="http://fcbikecoop.org/programs/community_outreach/Bike_Donation_Request_Form.pdf">Bike Donations Request Form.</a></p>-->
	 <!--<p>To request a Bike Donation for your agency or event, use the <a href="http://fcbikecoop.org/programs/community_outreach/temporary.php">Bike Donations Request Form.</a></p>-->
	 Please return all completed request forms to: <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "outreach@fcbikecoop.org")?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ou...@fcbikecoop.org</a><br><br>
	 Or by mail to:<br>
	 Community Outreach Group (COG)<br>
	 Fort Collins Bike Co-op<br>
	 1501 North College Avenue<br>
	 Fort Collins, CO<br>
	 80521<br>
	 <h2>Contact</h2>
	 Program Coordinator: <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "outreach@fcbikecoop.org")?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ou...@fcbikecoop.org</a><br>
	 To support the efforts of COG and other Bike Co-op programs, please consider giving financially by <a href="http://www.fcbikecoop.org/programs/grants/donations.php">donating here.</a>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
