<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
		<div class="heading">Ghana Bikes and Parts (As of 1/1/09)</div>
		<ul>
			<li>Still need more bikes.  Preference for full size "mountain" bikes, but all decent frames and sizes acceptable.  No trikes or kids bikes are needed right now.</li>
			<li>Please strip trashed or otherwise crummy frames for parts and leave frames to be recycled by FC Bike Co-op.</li>
		</ul>
	
		<h2>Need</h2>
		<ul>
			<li>Small cogs (individually replaceable gear rings)</li>
			<li>Tubes (mostly 26", but some 27" and 700s as well)</li>
			<li>Chains</a>
			<li>Derailleurs - front, but especially rear)</li>
			<li>brake levers, calipers and pads (particularly V-brake)</li>
			<li>Cassettes</li>
			<li>Brake levers, calipers and pads (particularly V-brake)</li>
			<li>seat post clamps</li>
			<li>a few more forks and headsets</li>
			<li>a few more wheel skewers</li>
			<li>some straight bars and/or MTB handlebars</li>
			<li>Fenders would be useful</li>
		</ul>
		<h2>Definitely Do NOT Need</h2>
		<ul>
			<li>seats</li>
			<li>pedals</li>
			<li>"racing" bars</li>
			<li>Cranks</li>
			<li>Wheels (if any, 26" would be most useful</li>
		</ul>
		Back to the <a href="http://fcbikecoop.org/programs/ghana.php">Main Ghana Page.</a>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
