<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
        <div class="heading">Programs</div>
	<p>Here's a list of the multiple programs going on at the Co-op.  Please contact the program coordinator if you would like to get involved.</p> 
	<h2>PUBLIC PROGRAMS</h2>
	<h2><a href="http://fcbikecoop.org/programs/open_shop.php">Open Shop</a></h2>
	Come work on your bike in our shop with the assistance of one of our mechnics.
	<h2><a href="http://fcbikecoop.org/programs/retail_store.php">Retail Store</a></h2>
	The Co-op sells refurbished bikes, as is bikes, bike parts, helmets, shirts, lights, etc.
	 <h2><a href="http://fcbikecoop.org/programs/education/index.php">Education</a></h2>
	 If you want to learn more about your bicycle, or how to safely ride it, we have classes for that.
	 <h2><a href="http://fcbikecoop.org/programs/earnabike.php">Earn-A-Bike</a></h2>
	 Our most popular program, Earn-a-bike is just like it sounds.
	 <h2><a href="http://fcbikecoop.org/programs/recovered.php">Stolen and Found/Abandoned Bikes</a></h2>
	 Through a partnership with the city, the Co-op recovers all lost and abandoned bikes in Fort Collins and attempts to match them up with their owners.
	 <h2><a href="http://fcbikecoop.org/programs/tripsforkids.php">Trips For Kids</a></h2>
	 Trips for kids provides mountain bike outings to underserved youth who might not have the opportunity otherwise.
	 <h2><a href="http://fcbikecoop.org/programs/ghana.php">Bikes for Ghana</a></h2>
	 Many of our excess of bikes are shipped overseas to help those in developing countries.  
	<h2>VOLUNTEER PROGRAMS</h2>
	 <h2><a href="http://fcbikecoop.org/programs/art.php">Art Department</a></h2>
	 Prepares graphics materials, signs, logos, and related materials.
	 <h2><a href="http://fcbikecoop.org/programs/bars.php">BaRS (Bike Retrieval Squad)</a></h2>
	 Responds to public reports of lost and abandoned bikes to coordinate retrieval;  works with Police Services in tracking found bikes and returning them to their owners.
	 <h2><a href="http://fcbikecoop.org/programs/community_outreach.php">COG (Community Outreach Group)</a></h2>
	 Our volunteer group that works to coordinate all requests for special events, event booths, donations of bikes, valet parking, and so much more.
	 <h2><a href="http://fcbikecoop.org/programs/recycling.php">Cycling Recyclers</a></h2>
	 With all of the bikes and parts that come through the Co-op, there are a lot of parts that are broken or junk.  Somebody has to go through it all.
	 <h2><a href="http://fcbikecoop.org/programs/grants.php">Fundraising and Grants</a></h2>
	 Co-ordinates public outreach seeking donations from the public, funding from foundations, and contracts with public agencies.
	 <h2><a href="http://fcbikecoop.org/programs/volunteer_action.php">V.A.C (Volunteer Action Committee)</a></h2>
	 Recruitment, retention, and recognition of volunteers.
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
