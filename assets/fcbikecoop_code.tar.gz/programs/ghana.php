<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">Bikes for Ghana</div>
		<h2>What & Why</h2>
		<div class="contents-image"><a href="ghana/images/100_3557.jpg"><img src="ghana/images/100_3557.jpg-thumb.jpg" alt="Volunteers loading a shipping container"></a>
			Volunteers Load a container bound for Ghana.(2009)
		</div>
		<p>The Fort Collins Bike Cooperative has paired up with the <a href="http://www.ghanabikes.org">Village Bicycle Project  (VBP)</a> to accomplish two primary goals;<br> (1) proliferating sustainable transportation (e.g. bikes) to less developed areas of the world that can really use them, but don't necessarily have the ways and means to obtain them themselves while<br> (2) reducing our stock of bikes and parts that would not have an opportunity to be used locally.  And, it's all in the spirit of Building Community Through Bicycling while keeping bikes and parts out of the landfill!  The Village Bicycle Project is a terrific completely volunteer-run, non-profit program with heavy participation from other highly respected organizations such as Bikes Not Bombs.  As contributors to the VBP, the FC Bike Co-op is amassing over 400 bikes, scores of parts, and some tools, enough to fill a freight container that will be shipped via boat to Ghana.</p>
		<h2>How</h2>
		<div class="contents-image"><a href="ghana/images/100_3656.jpg"><img src="ghana/images/100_3656.jpg-thumb.jpg" alt="Ghana Image"></a>
			Each shipping container holds ~450 bikes and multiple boxes of assorted parts.(2009)
		</div>
		<p>The FC Bike Co-op is fortunate enough to be a part of a wonderful and generous bike community.  Because of this we end up with more donations than we can realistically utilize and distribute effectively locally alone.  As such the VBP provides an excellent means and outlet for our surplus inventory where the bikes can be offered a new life and the people that acquire them a new opportunity.<p>
		<h2>What can I do?</h2>
		<p>We're still collecting bikes and parts, so feel free to drop donations at our 1501 North College <a href="http://fcbikecoop.org/contact.php">location</a>.  The FC Bike Co-op also gladly accepts monetary donations at our <a href="http://fcbikecoop.org/contact.php">shop</a>, or <a href="http://fcbikecoop.org/programs/grants/donations.php">online</a>. Or you can lend a hand!  If you'd like to get involved with the Ghana Bikes Project or other aspects of the Co-op, please don't hesitate to contact us.  We will need help sorting and packing bikes, as well as coordinating events to help make the Ghana Project a success and lead the way for more endeavors like it.</p>
		<p>Please see <a href="http://fcbikecoop.org/programs/ghana/ghana_parts.php">the needed parts page</a> for more specific bike and part needs for VBP and Ghana.</p>
	<h2>Container Loading</h2>
	Here's a video showing a time lapse of our 2010 container filling.
	<iframe class="youtube-player" type="text/html" width="500" height="315" src="http://www.youtube.com/embed/DR9nqAdoI2M" frameborder="0"></iframe><br>
	<a href="http://fcbikecoop.org/blog/2010/09/ghana-shipment-2010/">Read more about the 2010 container here.</a>
	 <h2>Feedback</h2>
	 In February 2010 we received a <a href="http://fcbikecoop.org/programs/ghana/Ghana_Submission_Feb_2010.pdf">letter</a> from some film makers that were in Ghana.  The letter covers many topics, including the Village Bicycle Project.  <a href="http://fcbikecoop.org/programs/ghana/Ghana_Submission_Feb_2010.pdf">Read the letter.</a>
	 <h2>Links</h2>
	 A partnership with <a href="http://villagebicycleproject.org">Village Bicycle Project</a>
	 <h2>Contact</h2>
	 Program Coordinator: <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "bikes4ghana@fcbikecoop.org")?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">bi...@fcbikecoop.org</a>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
