<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<div class="heading">Trips For Kids</div>
			<p>Trips for Kids is an <a href="http://www.tripsforkids.org/">international organization</a> that provides mountain bike outings and environmental education to underserved youth who would not otherwise be exposed to such activities. The outings create a positive, fun, outdoor experience for children, while teaching valuable lessons about healthy life-choices, environmental awareness, and building positive self-esteem.</p>
			<p>More about Trips For Kids Fort Collins can be found at the <a href="http://tripsforkidsfoco.org/">Trips for Kids Fort Collins website.</a>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
