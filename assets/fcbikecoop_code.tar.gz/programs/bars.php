<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">BaRS (Bike Retrieval Squad)</div>
	 <p>The Co-op has taken on the role of managing all of Fort Collins' abandoned bikes.  BaRS is our volunteer operated bike retreival program.  When a report comes in notifying us of an abandoned bike, BaRS jumps into action.  The easiest way for us to process the bike is if you drop it off at the Co-op during our Open Hours. If that's not possible you can contact us to set up a drop off time. If you are not capable of dropping the bike off, we can come pick it up. For this to happen you will need to take the bike "off the street" and store it until a volunteer can come pick it up. As an all volunteer organization pickup times will vary based on volunteer availability, and could take up to two weeks. Once the bike is in the Co-op's hands it will go through the entire <a href="http://fcbikecoop.org/programs/recovered.php">process detailed here.</a></p>
	<!---<h2>Coordinator opening</h2>
	<p>We are looking to find a new BaRS program coordinator.  If you're interested, take a look at the <a href="http://fcbikecoop.org/programs/bars/BARS_Coordinator_Position.pdf">BaRS Coordinator Positon Description</a> and contact the current BaRS coordinator by <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "bars@fcbikecoop.org")?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">Email</a>	 </p>-->
	<p>The documents below help to explain that BaRS Process.</p>
	 <h2>Links</h2>
	 <a href="http://fcbikecoop.org/programs/recovered.php">Stolen, and Found/Abandoned Bikes</a><br>
	 <a href="http://fcbikecoop.org/volunteer_db/bars/">Log a Recovered Bike (current volunteers only)</a><br>
	 <h2>Contact</h2>
	 Program Coordinator: <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "bars@fcbikecoop.org")?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ba...@fcbikecoop.org</a>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
