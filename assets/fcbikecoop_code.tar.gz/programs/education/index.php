<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<div class="heading">Bicycle Safety Program</div>
			<p>The Bike Co-op has a contract from the City of Fort Collins to train 100 Safe Routes to School instructors over the next several months.  So if you are interested in being a volunteer or an hourly employee to teach children in elementary schools or in middle school sign up today for one of these Saturday afternoon classes.</p>

			<h2>Bicycling 123 - Youth Skills (certificate program)</h2>
			<p>This is a 4 hour class sponsored by the Bike Co-op to train instructors in safe cycling skills for youth.  You must be at least 14 years old to take the class.  Those who complete the class with receive a Bicycilng 123 Youth Skills certificate.</p>
				<p>The Bicycling 123 Youth guide outlines 13 stations - four administrative stations and nine activity stations - designed to teach you how to run a youth skills clinic (i.e., a "Bike Rodeo").</p>
				<h3>You will learn how to teach:</h3>

				<ol>
					<li>The principles of vehicular cycling;</li>
					<li>Factors that determine when children are ready to ride on the road;</li>
					<li>How to perform an ABC Quick Check (a safety check) on bicycles;</li>
					<li>How to properly fit a helmet;</li>
					<li>Teaching kids to mount, dismount, start and stop;</li>
					<li>Basic bike handling skills for those under 10 years of age;</li>
					<li>Tips for teaching children how to ride without training wheels;</li>
					<li>Straight line riding, scanning and signaling;</li>
					<li>How crashes happen;</li>
					<li>Basic rules of the road;</li>
					<li>Hazard detection and avoidance;</li>
					<li>Riding on the sidewalk vs. riding on the street;</li>
					<li>Colorado Bicycle Law;</li>
					<li>Teaching children how to handle intersections.</li>
				</ol>
				<h3>Class Schedule:</h3>
				<p>The above class will be taught on the following schedule (you need take only ONE class):</p>
				<p>Every Saturday afternoon from 1:30 until 5:30 at the Bike Co-op (1501 North College Ave.) on the following dates.</p>
				<ul>
					<li>March 24 and 31</li>
					<li>April 7, 14, and 21</li>
					<li>May 12 and 19</li>
				</ul>
				<h3>Signup:</h3>
				<p> If you would like to get signed up for one of these classes, please go to the <a href="http://www.signupgenius.com/go/20F0C45ABAF229-bicycling">Signup Page</a></p>
				<h3>Weather conditions:</h3>
				<p>Classes will be held as scheduled IF there are at least 4 people signed up for the class and if the following weather conditions are met:  if at noon the day before the class there is no snow on the ground in the parking lot on the north side of the Bike Co-op and the forecast for a high temperature in Fort Collins is at least 45 degree Fahrenheit</p>
				<h3>Groups:</h3>
				<p>If you have a group of at least 6 parents, school volunteers, service club members or others and would like to schedule your own class please send an inquiry to <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "education@fcbikecoop.org")?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ed...@fcbikecoop.org</a></p>
	 		Project Coordinator: <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "education@fcbikecoop.org")?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ed...@fcbikecoop.org</a> (Preferred Method)<br>
			Phone: (970)310-5238
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
