<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<div class="heading">Bicycle Safety Program</div>
			<p>The Bike Co-op has four League Cycling Instructors on its board thanks to the generous support of the Pharos Fund of the Bohemian Foundation and the Community Grants program of Intel Corporation.  The Co-op also operates bicycle education classes and bike skills rodeos for local elementary and junior high school students thanks to a Community Grant from <a href="http://rei.com">REI (Recreational Equipment, Inc.)</a></p>
			<table width="500px">
				<tr width="250px"><td><a href="http://rei.com"><img src="http://fcbikecoop.org/images/sponsors/rei_logo.gif"></a></td><td><a href="http://www.bohemianfoundation.org/"><img src="http://fcbikecoop.org/images/sponsors/bohemian.jpg"></a></td></tr>
			</table>
			<ul>
				<li><a href="#available">Available Classes</a></li>
				<li><a href="#scheduled">Scheduled Classes</a></li>
				<li><a href="#payments">Payments</a></li>
			</ul>
			<hr>
			<h2><a name="available">AVAILABLE CLASSES</a></h2>
			<h3>Brief Program and Presentation (Adults)</h3>
			<p>The Co-op has an adult education program designed to introduce the basic concepts of vehicular cycling in a fifty-minute presentation. This program is ideal for lunch-time or breakfast meetings, for clubs and bike shops. Cost: Free.</p>
			<h3>Traffic Skills 101 (TS101)</h3>
			<p>This League of American Bicyclists (LAB) approved class is a nine-hour course on vehicular cycling. The course gives cyclists knowledge and confidence to ride safely and legally in traffic or on the trail. This is recommended for adults and children above the age of fourteen. This class is a prerequisite for the LAB League Cycling Instructor (LCI) seminar, a 32 hour course required to become an LCI. TS 101 is a perfect course for PE, Health and Wellness teachers who wish to teach safe cycling to children in school programs. Cost: $60 ($30 for students and educators). Special classes available on request.</p>
			<h3>Shorter TS 101 classes</h3>
			<p>Classes can be adapted for those who don't have time for a complete TS 101 class. Commuters, bike clubs, business groups, and recreational cyclists, and others would benefit from a shorter class. Cost: to be determined.</p>
			<h3>Master Cyclist Training</h3>
			<p>As a Master Cyclist you will undergo a state-of-the-art training developed by the League of American Bicyclists (LAB).  Instruction is conducted both online and locally by League Certified Instructors (LCIs).  Upon completion of the program you will be certified to conduct youth skills courses ("bike rodeos") and to teach cycling skills to children under 10 and those 10 to 14 years old.  <a href="http://fcbikecoop.org/programs/education/classes/master_cyclist.php">More about the Master Cyclist Classes</a><p>
			<h3>Kids I</h3>
			<p>Designed for younger children (under age 10) AND PARENTS. Instructors explain how to teach a child to ride a bike. Topics also include how to perform a bicycle safety check, helmet fitting and bike sizing. Includes 10-minute 'Kids Eye View' video presentation.</p>
			<h3>Kids II</h3>
			<p>This 5-7-hour class is designed for 5th and 6th graders and covers the same topics as Traffic Skills 101, including on-bike skills as well as choosing safe routes for riding. The difference with TS 101 is that it is geared to children.</p>
			<h3>Brief program and presentation (Children)</h3>
			<p>The Co-op has developed a variety of programs and presentations for children of varying ages including: K-2; 3-5 and 6-8. These presentations may take a variety of formats and include sections on helmet use and fit, bicycle safety check, bike sizing, rules of the road, road positioning and riding, and vehicular cycling (depending on the ages of the audience).</p>
			<hr>
			<h2><a name="scheduled">SCHEDULED CLASSES</a></h2>
			See the calendar below for upcoming classes.
	 <iframe src="http://www.google.com/calendar/embed?height=450&amp;wkst=1&amp;bgcolor=%23825127&amp;src=6f2at5n72kp8u13778n7iepqlc%40group.calendar.google.com&amp;color=%235229A3&amp;ctz=America%2FDenver" style=" border-width:0 " width="550" height="450" frameborder="0" scrolling="no"></iframe>
<!---
			<h3>Traffic Skills 101 (TS101)</h3>
			<table>
				<tr><td width="100">When:</td><td>Feb. 25th - April 15th (Every Thurs 7:00PM-8:30PM)</td></tr>
				<tr><td>Where:</td><td>The Bike Co-op, 331 North College Ave., Fort Collins</td></tr>
				<tr><td>Cost:</td><td>Free</td></tr>
				<tr><td>Instructor:</td><td>Rick Price and Local League Cycling Instructors</td></tr>
				<tr><td>Email:</td><td><a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "rick@experienceplus.com");?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ri...@experienceplus.com</a></td></tr>
				<tr><td>Phone:</td><td>(970)310-5238</td></tr>
				<tr><td>Notes:</td><td>This course counts as a pre-requisite for the LCI training course.  IF you complete the entire course, take the exam, and pay the $60 fee ($30 for students and educators)</td></tr>
				<tr><td>Topics:</td><td>-Feb. 25 . Vehicular Cycling Philosophy and Practice (What this class can do for youth, adults, beginning cyclists, educators, commuters, and motorists);</td></tr>
				<tr><td></td><td>-March 4 . Picking a bike : what kind of bike should I buy ?</td></tr>
				<tr><td></td><td>-March 11 . Bike Maintenance Basics;</td></tr>
				<tr><td></td><td>-March 18 . Spring Break . NO CLASS;</td></tr>
				<tr><td></td><td>-March 25 . Safety equipment, Bike Clothing, accessories, & on-the-bike tools;</td></tr>
				<tr><td></td><td>-April 1 . Principles of Traffic Law (in general and in Colorado);</td></tr>
				<tr><td></td><td>-April 8 . How crashes happen and how to avoid them;</td></tr>
				<tr><td></td><td>-April 15 . Riding basics (classroom); </td></tr>
				<tr><td></td><td>-April 17 (Saturday) Bike Handling basics . Parking lot drills (1.5 hours) On-the-road practice (1.5 hours)</td></tr>
			</table>
			<h3>Kids II: BICYCLING SKILLS 123 (Youth 10-14)</h3>
			<table>
				<tr><td width="100">When:</td><td><strike>April 10th</strike> Cancelled, or May 8th, or June 12th 8:30AM-12:30PM</td></tr>
				<tr><td>Where:</td><td>Boys and Girls Clubs of Larimer County, 1608 Lancer Drive, Fort Collins, CO, 80521</td></tr>
				<tr><td>Cost:</td><td>$10</td></tr>
				<tr><td>Description:</td><td>This class teaches youth how to be responsible, safe and legal bicyclists on neighborhood streets. Classroom presentation covers the principals of traffic law, lane positioning and intersections.  Students learn how to avoid the 5 major causes or car-bike crashes.  Bicycle and helmet fitting are followed by skills practice and a one-hour neighborhood ride with immediate feedback on technique.  Everyone must bring a bike and a helmet. The minimum age is 10 years.  The class is 4 hours in duration. This class is taught in conjunction with the Fort Collins Bike Co-op.</td></tr>
				<tr><td>Instructor:</td><td>Rick Price</td></tr>
				<tr><td>Email:</td><td><a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "rick@experienceplus.com");?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ri...@experienceplus.com</a></td></tr>
				<tr><td>Phone:</td><td>(970)310-5238</td></tr>
				<tr><td>Website:</td><td><a href="http://fcbikecoop.org/programs/education/">http://fcbikecoop.org</a></td></tr>
				<tr><td>Signup Req'd:</td><td>Yes</td></tr>
				<tr><td>Notes:</td><td>Send an e-mail to the contact to request a registration form</td></tr>
				<tr><td>Equipment:</td><td>Bring your own Bicycle, Helmet, gloves(optional)</td></tr>
			</table>
--->
			<hr>
	 		<h2><a name="payments">PAYMENT INFORMATION</a></h2>
			If you need to make a payment for a Co-op cycling class, you can do so on our <a href="http://fcbikecoop.org/programs/grants/donations.php">Donations page.</a>
			<hr>
	 		<h2><a name="contact">BICYCLE SAFETY PROGRAM CONTACT INFO</a></h2>
	 		Project Coordinator: <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "education@fcbikecoop.org")?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ed...@fcbikecoop.org</a> (Preferred Method)<br>
			Phone: (970)310-5238
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
