<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
			<div class="heading">Master Cyclist</div>
			<ul>
				<li>Become a certified "Smart Cyclist"</li>
				<li>Volunteer to Teach Fort Collins' Youth Smart Cycling Skills</li>
			</ul>
			<h2>Tell Me More!</h2>
			<p>Fort Collins' Master Cyclists are experienced cyclists with a passion for "smart" and "safe" cycling.  They want to share that passion with the community.  Smart cycling is vehicular cycling, also known as "utility cycling" for those who believe that bicycles are a valid form of transportation, especially for short trips to work, to run errands and for recreation.  Above all Master Cyclists share their passion through teaching others, speaking to groups, and conducting youth skills bicycle workshops.</p>
			<p>Fort Collins' Master Cyclist program was started by the Bike Co-op in conjunction with the City's Safe Routes to School Program.  The ultimate goal of the Master Cyclist program is to help Fort Collins' PE teachers teach smart cycling skills to school children, their parents and teachers.</p>
			<p>As a Master Cyclist you will undergo a state-of-the-art training developed by the League of American Bicyclists (LAB).  Instruction is conducted both online and locally by League Certified Instructors (LCIs).  Upon completion of the program you will be certified to conduct youth skills courses ("bike rodeos") and to teach cycling skills to children under 10 and those 10 to 14 years old.</p>
			<p><b>The training program is FREE</b> for those who agree to volunteer with the Safe Routes to School Program.  You need only provide your bicycle, helmet, gloves and a water bottle.  </p>
			<p>This training program is the same program that local PE teachers, after school program providers, wellness coordinators and parent volunteers will be taking.</p>
			<h2>Master Cyclists Learn:</h2>
			<ol>
				<li>The principles of vehicular cycling</li>
				<ol>
					<li>Where to ride on the road to be safest and most visible</li>

					<li>How to "drive your bike" like a car</li>
					<li>The correct use of bike lanes and sidewalks</li>
					<li>Rules of the Road</li>
				</ol>
				<li>Essentials of riding for beginners, including</li>
				<ol>
					<li>Correct procedures for starting, stopping, mounting and dismounting</li>
					<li>Straight line riding</li>
					<li>Scanning, signaling, merging and turning</li>
				</ol>
				<li>Selection and use of appropriate equipment</li>
				<ol>
					<li>Bicycle type, size and proper fit</li>
					<li>Helmet use and the importance of helmets</li>
					<li>"ABC Quick Check" bike maintenance and diagnostics</li>
					<li>Efficient cycling: where bike fit, maintenance, and skills come together</li>
					<li>Teaching cycling skills to children under 10 (and the importance of reaching their parents)</li>
				</ol>
				<li>Teaching cycling skills to children 10 to 14</li>
				<ol>
					<li>How crashes happen and how to avoid them</li>
					<li>The law as it relates to bicycles and more rules of the road</li>
					<li>Hazard avoidance</li>
				</ol>
				<li>Laying out a bicycle skills course ("bike rodeo") and conducting youth skills classes</li>
				<li>Practice:</li>
				<ol>
					<li>On the road</li>
					<li>On the trail</li>
				</ol>
				<li>Teaching techniques and bicycle field trips</li>
			</ol>

			<h2>Training for Master Cyclists involves the following steps:</h2>
			<ol>
				<li>Traffic Skills 101 - an online course offered by the League of the American Bicyclists.  You can take this course at www.BikeEd.org.  There is no charge for the course.  This self-paced course provides the theoretical basis for most of the points mentioned above and takes 3-4 hours.</li>
				<li>On-the-bike follow-up with a local League Cycling Instructor offers:</li>
				<ol>
					<li>Parking lot drills and basic handling skills</li>
					<li>Road rides teach lane positioning, speed positioning and offer practical examples of these.</li>
					<li>Special needs of children under and over 10 years of age</li>
					<li>Design and layout of a youth skills course (bike rodeo)</li>
				</ol>
				<li>Once you've completed the above you are a Master Cyclist "in training"</li>
				<ol>
					<li>Participate in two youth skills courses in the Safe Routes to School program and you have completed your Master Cyclist training.</li>
					<li>You receive your Bicycling 123 Youth Skills Certificate from the League of American Bicyclists.  </li>
				</ol>
			</ol>
			<p>Once you have completed steps one and two above you will have completed the Traffic Skills 101 class of the League of American Bicyclists.  This is a prerequisite course for anyone wishing to go on to achieve their League Cycling Instructor (LCI) certification.   LCI certification is offered at weekend seminars around the country several times each year.  You can read more about LCI certification and look for seminars that have been scheduled here: <a href="http://www.bikeleague.org/programs/education/seminars.php">http://www.bikeleague.org/programs/education/seminars.php</a>

			<h2>Safe Routes to School - Teaching our Children Smart Cycling Skills</h2>
			<p>Master Cyclists are a critical component of making Fort Collins a safe bicycling community.   As a participant in this program you will be encouraged to volunteer to help local schools offer bike skills classes as a part of PE classes, after school programs, and weekend events.  Classes will be coordinated through a coalition of local community groups, including The Bike Co-op, the Bicycle and Pedestrian Education Coalition (BPEC), Poudre School District, and the City's Safe Routes to school Program</p>
			<b>Time Commitment:</b> Mandatory training of approximately ten hours plus commitment to assist with at least two school events within twelve months. 
			<h3>Qualifications:</h3>
			<ul>
				<li>Must be sixteen years or older</li>
				<li>Must be an experienced cyclist able to demonstrate mastery of the skills and concepts in the class</li>
				<li>Must pass a background check to work in Poudre Schools</li>
			</ul>
			<h3>Requirements:</h3>
			<ul>
				<li>Assist with two skills classes within twelve months of completing the program</li>
				<li>Regularly work with program coordinator's and report volunteer hours logged</li>
			</ul>
			<h3>Benefits:</h3>
				<li>Become a smarter and safer cyclist</li>
				<li>Help our children become safe cyclists</li>
				<li>Meet people with similar interests</li>
				<li>Be a part of making Fort Collins a friendlier and safer bicycle community</li>
				<li>Take pride in knowing you are helping Fort Collins to become one of the top bicycle communities in the US (even more than it is!)</li>
			</ul>
			<h3>Application Process</h3>
			<ol>
				<li>Complete the online class as soon as possible:  <a href="http://www.BikeEd.org">www.BikeEd.org</a></li>
				<li>E-mail your final score from this course to <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "education@fcbikecoop.org")?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ed...@fcbikecoop.org</a> (cut and paste the page results with your name into your e-mail).</li>
				<li>We will advise you of on-the-bike follow up classes this winter as they are scheduled.</li>
			</ol>
			<h3>Information:</h3>
			 Rick Price, Ph.D., Safe Cycling Coordinator, Fort Collins Bike Co-op; <a href="#" onclick="MyWindow=window.open('<?php echo recaptcha_mailhide_url ($mailhide_pubkey, $mailhide_privkey, "education@fcbikecoop.org")?>', 'MyWindow', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=500,height=300'); return false;">ed...@fcbikecoop.org</a> (970-310-5238)
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
