<?php
$current_page = htmlentities($_SERVER['PHP_SELF']);
include_once('/var/www/fcbikecoop.org/root/header.php');
?>
         <div class="heading">Fort Collins Lost and Stolen Bikes</div>
	 <h2>Background</h2>
	 <p>Starting February 1st 2008 the Fort Collins Bike Co-op and Fort Collins Police Department have created a new partnership.  Prior to 2008 every bike that was deemed abandoned in Fort Collins was crammed into a shipping container and shipped off to California to be put up for auction.  This usually paid the cost of storing the bikes over the course of the year and shipping them off.  The new system takes those bikes, and through the Bike Co-op, redistributes those bikes back into the Northern Colorado community.  In return, the Co-op will take over the collection and storage of the bikes.  The Co-op will also help to record the serial numbers, and determine the final fate of each bike.</p>
	 <h2>Process</h2>
	 <p>The whole process is detailed in the <a href="http://fcbikecoop.org/documents/police_bike_process.pdf">Police Bike Process PDF</a><br>
	 There is also a nice <a href="http://fcbikecoop.org/documents/police_bike_flow_chart.pdf">Flow Chart PDF</a> that shows the process.<br>
	 There's even more information over at the <a href="http://citydocs.fcgov.com/?cmd=convert&vid=72&docid=1197860&PHPSESSID=33">City Docs pages</a></p>
	 <h2>How To Report Found Bikes</h2>
	 <p>If you come across a bike that you believe has been lost or abandoned, we'd love to have it.  The easiest way for us to process the bike is if you drop it off at the co-op during our <a href="http://fcbikecoop.org/calendar.php">Open Hours.</a>  If that's not possible you can <a href="http://fcbikecoop.org/contact.php">Contact us</a> to set up a drop off time.  If you are not capable of dropping the bike off, we can come and pick it up.  For this to happen you will need to take the bike "off the street" and store it until a volunteer can come and pick it up.  As a volunteer organization pickup times will vary based on volunteer availability, and could take up to two weeks.  Once the bike is in the Co-op's hands it will go through the entire process detailed above.  <a href="http://fcbikecoop.org/programs/bars.php"> Learn about out B.A.R.S. program.</a></p>
	 <h2>How to Report Stolen Bikes</h2>
	 <p>If your bike has been stolen you still need to report it to the police.  The Fort Collins Bike Co-op is not responsible for stolen bike cases. Once you've reported you bike stolen to the police your bikes description/serial number will be cross checked with our database bi-weekly</p>
<?php
include_once('/var/www/fcbikecoop.org/root/footer.php');
?>
