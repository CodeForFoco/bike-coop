<?php
$button1 = "menu-item";
$button2 = "menu-item";
$button3 = "menu-item";
$button4 = "menu-item";
$button5 = "menu-item";
$button6 = "menu-item";
$button7 = "menu-item";
$button8 = "menu-item";
$button9 = "menu-item";
$button0 = "menu-item";
$button10 = "menu-item";
$title = "Fort Collins Bike Co-op";
switch ($current_page) {
	case "/index.php":
		$button1 = "menu-item-current";
		break;
	case "/calendar.php":
		$button4 = "menu-item-current";
		$title = "Calendar/Hours - Fort Collins Bike Co-op";
		break;
	case "/sponsors.php":
		$button5 = "menu-item-current";
		$title = "Sponsors - Fort Collins Bike Co-op";
		break;
	case "/faq.php":
		$button7 = "menu-item-current";
		$title = "FAQ - Fort Collins Bike Co-op";
		break;
	case "/mail.php":
		$button8 = "menu-item-current";
		$title = "Mailing Lists - Fort Collins Bike Co-op";
		break;
	case "/contact.php":
		$button9 = "menu-item-current";
		$title = "Contact - Fort Collins Bike Co-op";
		break;
	case "/community.php":
		$button1 = "menu-item-current";
		$title = "Community - Fort Collins Bike Co-op";
		break;
	case "/history.php":
		$button1 = "menu-item-current";
		$title = "History - Fort Collins Bike Co-op";
		break;
	case "/howitworks.php":
		$button1 = "menu-item-current";
		$title = "How we work - Fort Collins Bike Co-op";
		break;
}
if (preg_match("/^\/pictures/", $current_page))
	{
		$button0 = "menu-item-current";
		$title = "Videos/Photos - Fort Collins Bike Co-op";
	}
if (preg_match("/^\/programs/", $current_page))
	{
		$button3 = "menu-item-current";
		$title = "Programs - Fort Collins Bike Co-op";
	}
if (preg_match("/^\/volunteer/", $current_page))
	{
		$button6 = "menu-item-current";
		$title = "Volunteers - Fort Collins Bike Co-op";
	}
if (preg_match("/^\/volunteer_db/", $current_page))
	{
		$title = "Volunteer Only Area - Fort Collins Bike Co-op";
	}
if (preg_match("/^\/blog/", $current_page))
	{
		$button2 = "menu-item-current";
	}
switch ($current_page) {
	case "/AbandonedBikeReport.php":
		$button10 = "menu-item-current";
		$button3 = "menu-item";
		$title = "Report a Bike - Fort Collins Bike Co-op";
		break;
}
?>
